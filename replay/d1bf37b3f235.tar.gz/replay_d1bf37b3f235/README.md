# Replay package — entry d1bf37b3f235

Conjecture: Total Influence of Clause-XOR Aggregate Bounds DPLL Tree Leaves

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 15:16 UTC.
Pre-registration hash committed before this test ran: `821b4dec7c9204ee`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
