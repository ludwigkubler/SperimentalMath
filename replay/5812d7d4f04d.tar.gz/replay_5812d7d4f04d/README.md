# Replay package — entry 5812d7d4f04d

Conjecture: Minimal p-Adic Root Count and Communication Complexity Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 10:58 UTC.
Pre-registration hash committed before this test ran: `ab459d67c9e07f3c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
