# Replay package — entry 0484cfac45e9

Conjecture: Minimal Rank of Tropicalized Algebraic Topology over Boolean Algebras vs BP_ReadTwice Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 07:09 UTC.
Pre-registration hash committed before this test ran: `2b91ffa2e64e0257`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
