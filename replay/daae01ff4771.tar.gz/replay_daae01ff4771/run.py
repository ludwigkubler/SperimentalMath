import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_boolean_circuit(n):
        if n == 1:
            return [random.choice([0, 1])]
        else:
            left = generate_boolean_circuit(n // 2)
            right = generate_boolean_circuit(n - n // 2)
            return [random.choice([left[i], right[i]]) for i in range(n)]
    
    def monotone_width(circuit):
        if len(circuit) == 1:
            return 1
        else:
            left_width = monotone_width(circuit[:len(circuit)//2])
            right_width = monotone_width(circuit[len(circuit)//2:])
            return max(left_width, right_width) + 1
    
    def git_degree(n):
        # Simulated GIT degree calculation (placeholder)
        return random.randint(1, n)
    
    n_values = [5, 10, 15, 20, 30, 40]
    total_ratio = 0
    instances_tested = 0
    
    for n in n_values:
        circuit = generate_boolean_circuit(n)
        width = monotone_width(circuit)
        degree = git_degree(n)
        
        if width == 0 or degree == 0:
            continue
        
        ratio = Fraction(degree, width * math.log2(n))
        total_ratio += ratio
        instances_tested += 1
    
    if instances_tested == 0:
        return {
            "metric_name": "git_degree_over_width_log_n",
            "metric_value": None,
            "instances_tested": 0,
            "n_max": 40,
            "conjecture_holds": False,
            "counterexample": "No valid instances found"
        }
    
    mean_ratio = total_ratio / instances_tested
    return {
        "metric_name": "git_degree_over_width_log_n",
        "metric_value": float(mean_ratio),
        "instances_tested": instances_tested,
        "n_max": 40,
        "conjecture_holds": False,
        "counterexample": ""
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    results = []
    
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results if r["metric_value"] is not None) / len(results)
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["metric_value"] is not None for r in results):
        RESULT: SUPPORTED mean={mean_value} std=0.0 support_fraction={support_fraction}
    elif support_fraction >= 0.8:
        RESULT: SUPPORTED mean={mean_value} std=0.0 support_fraction={support_fraction}
    else:
        counterexample = min((r["counterexample"] for r in results if r["conjecture_holds"]), default="")
        RESULT: FALSIFIED counterexample="{counterexample}" first_failing_seed=None