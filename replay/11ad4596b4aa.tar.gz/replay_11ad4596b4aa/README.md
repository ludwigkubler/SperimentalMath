# Replay package — entry 11ad4596b4aa

Conjecture: Minimal Diophantine Exponent Bounds Circuit Complexity of Random k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 12:45 UTC.
Pre-registration hash committed before this test ran: `134df9e2e585b1de`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
