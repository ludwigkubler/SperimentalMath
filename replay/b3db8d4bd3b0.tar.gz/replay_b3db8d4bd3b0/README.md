# Replay package — entry b3db8d4bd3b0

Conjecture: Minimal Rank of Symplectic Matrices and Communication Complexity Rank Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 04:26 UTC.
Pre-registration hash committed before this test ran: `dff79e7043630de5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
