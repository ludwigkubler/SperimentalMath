import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def gaussian_elimination(matrix):
        rows, cols = len(matrix), len(matrix[0])
        for i in range(rows):
            max_row = i + max(range(i, rows), key=lambda r: abs(matrix[r][i]))
            matrix[i], matrix[max_row] = matrix[max_row], matrix[i]
            factor = 1 / matrix[i][i]
            for j in range(cols):
                matrix[i][j] *= factor
            for k in range(rows):
                if k != i:
                    factor = matrix[k][i]
                    for j in range(cols):
                        matrix[k][j] -= factor * matrix[i][j]
        return matrix
    
    def rank(matrix):
        rows, cols = len(matrix), len(matrix[0])
        row echelon_form = gaussian_elimination(matrix)
        rank = 0
        for i in range(rows):
            if any(row[i] != 0 for row in row_echelon_form):
                rank += 1
        return rank
    
    def tensor_product(a, b):
        result = []
        for x in a:
            for y in b:
                result.append([x * y])
        return result
    
    def tropicalize(matrix):
        rows, cols = len(matrix), len(matrix[0])
        tropicalized = [[max(matrix[i][j], matrix[j][i]) for j in range(cols)] for i in range(rows)]
        return tropicalized
    
    n = random.randint(5, 40)
    a = [random.randint(-10, 10) for _ in range(n)]
    b = [random.randint(-10, 10) for _ in range(n)]
    
    tensor_result = tensor_product(a, b)
    tropicalized_tensor = tropicalize(tensor_result)
    
    minimal_rank = rank(tropicalized_tensor)
    conjecture_holds = minimal_rank <= n**2 * math.log(n)
    counterexample = "" if conjecture_holds else f"Minimal rank {minimal_rank} exceeds O({n**2 * math.log(n)})"
    
    return {
        "metric_name": "Minimal Rank",
        "metric_value": minimal_rank,
        "instances_tested": 1,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or list(range(2, 30))  # Default to first 29 primes if no seeds provided
    
    results = []
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    mean_value = sum(result["metric_value"] for result in results) / len(results)
    std_value = math.sqrt(sum((result["metric_value"] - mean_value)**2 for result in results) / len(results))
    support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)
    
    if support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not result["conjecture_holds"] for result in results):
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{results[0]['counterexample']}\" first_failing_seed={first_failing_seed}")
    else:
        print(f"RESULT: INCONCLUSIVE reason=insufficient_evidence")