# Replay package — entry e10a38fc2892

Conjecture: Genus of Communication Curve Bounds Disjointness Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 20:37 UTC.
Pre-registration hash committed before this test ran: `60d85e5062327e74`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
