# Replay package — entry 661b05479d3e

Conjecture: Plethysm Coefficient Gap in Symmetric Squares of Permutation Representations for Random CNFs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 08:36 UTC.
Pre-registration hash committed before this test ran: `ac6c7b9e3faa7e9b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
