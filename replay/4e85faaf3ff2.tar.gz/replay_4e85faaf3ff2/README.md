# Replay package — entry 4e85faaf3ff2

Conjecture: Coxeter Group Order Bounds Cumulative Proof Entropy of Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 12:39 UTC.
Pre-registration hash committed before this test ran: `19c89caf9fb8ec31`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
