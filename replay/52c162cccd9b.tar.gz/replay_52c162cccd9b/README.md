# Replay package — entry 52c162cccd9b

Conjecture: SOS Refutation Degree Bounded by Clause Density for Random 3-SAT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 01:51 UTC.
Pre-registration hash committed before this test ran: `2f2ae0ebd1b7e228`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
