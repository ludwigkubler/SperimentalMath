# Replay package — entry d1779d47a9da

Conjecture: Euler Characteristic of Clause-Link Complex Equals Karchmer-Wigderson Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 08:29 UTC.
Pre-registration hash committed before this test ran: `1ab624b76a3cdf38`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
