# Replay package — entry 56779c9244c7

Conjecture: Fourier Coefficient Concentration and ACC⁰ Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 14:39 UTC.
Pre-registration hash committed before this test ran: `ae631066bec9bcd5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
