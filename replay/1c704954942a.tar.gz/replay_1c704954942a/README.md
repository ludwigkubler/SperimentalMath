# Replay package — entry 1c704954942a

Conjecture: Minimal Index of p-adic Analytic Curves and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 20:11 UTC.
Pre-registration hash committed before this test ran: `3999a7db4d47695b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
