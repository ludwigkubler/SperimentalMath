# Replay package — entry 647c37275cee

Conjecture: Minimal Hodge Decomposition Rank and Circuit Monotone Width Correlation via Tropicalization

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 06:04 UTC.
Pre-registration hash committed before this test ran: `729d4f63beb76320`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
