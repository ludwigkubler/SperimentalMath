# Replay package — entry 121736aabe59

Conjecture: Poincare Series

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-23 22:57 UTC.
Pre-registration hash committed before this test ran: `?`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
