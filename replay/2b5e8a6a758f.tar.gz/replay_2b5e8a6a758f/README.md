# Replay package — entry 2b5e8a6a758f

Conjecture: Minimal Generators of Geometric Group Actions Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 11:51 UTC.
Pre-registration hash committed before this test ran: `d5bdf820f460369e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
