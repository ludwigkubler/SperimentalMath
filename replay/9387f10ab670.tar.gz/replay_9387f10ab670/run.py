import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def gaussian_elimination(matrix):
        rows, cols = len(matrix), len(matrix[0])
        for i in range(rows):
            max_row = i
            for j in range(i + 1, rows):
                if abs(matrix[j][i]) > abs(matrix[max_row][i]):
                    max_row = j
            matrix[i], matrix[max_row] = matrix[max_row], matrix[i]
            factor = matrix[i][i]
            for j in range(cols):
                matrix[i][j] /= factor
            for k in range(rows):
                if k != i:
                    factor = matrix[k][i]
                    for j in range(cols):
                        matrix[k][j] -= factor * matrix[i][j]
        return matrix
    
    def rank(matrix):
        rows, cols = len(matrix), len(matrix[0])
        row echelon_form = gaussian_elimination(matrix)
        rank = 0
        for i in range(rows):
            if any(row_echelon_form[i]):
                rank += 1
        return rank
    
    def xor_circuit_size(n):
        if n == 1:
            return 1
        return 2 * xor_circuit_size(n // 2) + 1
    
    n = random.randint(5, 40)
    xor_bits = [random.choice([0, 1]) for _ in range(n)]
    xor_result = reduce(lambda x, y: x ^ y, xor_bits)
    
    # Minimal rank of the first-order representation of a level-N modular form
    # This is a placeholder; actual computation depends on N and modular forms
    minimal_rank = n + 1
    
    # Size of the smallest tautology circuit for an AND-OR tree computing the XOR of N bits
    circuit_size = xor_circuit_size(n)
    
    ratio = minimal_rank / circuit_size if circuit_size != 0 else float('inf')
    
    return {
        "metric_name": "Ratio",
        "metric_value": ratio,
        "instances_tested": 1,
        "conjecture_holds": ratio >= n,  # Placeholder; actual condition depends on C_N
        "counterexample": "" if ratio >= n else f"XOR of {n} bits with result {xor_result}"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_ratio = sum(r["metric_value"] for r in results) / len(results)
    std_ratio = math.sqrt(sum((r["metric_value"] - mean_ratio) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_ratio} std={std_ratio} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"XOR of {n} bits\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE reason=insufficient_evidence")