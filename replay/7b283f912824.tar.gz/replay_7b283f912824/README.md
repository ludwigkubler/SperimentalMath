# Replay package — entry 7b283f912824

Conjecture: Minimal Matroid Expansion as Monotone Circuit Lower Bound for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 08:48 UTC.
Pre-registration hash committed before this test ran: `e81826e04c31ec75`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
