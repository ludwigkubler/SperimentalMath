# Replay package — entry c301b2761a6a

Conjecture: Minimal Order of Geometric Group Actions and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 12:07 UTC.
Pre-registration hash committed before this test ran: `7ad3c9eb45345c36`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
