# Replay package — entry c5c4b106a0cf

Conjecture: Monomer-Dimer Entropy Lower-Bounds Tseitin Resolution Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 13:54 UTC.
Pre-registration hash committed before this test ran: `1963a7fce33f3194`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
