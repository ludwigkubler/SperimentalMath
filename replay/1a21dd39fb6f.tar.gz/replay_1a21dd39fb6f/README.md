# Replay package — entry 1a21dd39fb6f

Conjecture: Secant Rank Lower Bound for Disjointness Communication Matrices

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-29 01:14 UTC.
Pre-registration hash committed before this test ran: `f08ec0cb5471f14a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
