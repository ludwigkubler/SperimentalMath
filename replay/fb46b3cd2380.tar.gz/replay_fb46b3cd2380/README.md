# Replay package — entry fb46b3cd2380

Conjecture: Quadratic Form Solution Count Exponential Gap in ACC⁰ Sipser Circuits

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 17:00 UTC.
Pre-registration hash committed before this test ran: `b1332d993d1795b0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
