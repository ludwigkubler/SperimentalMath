# Replay package — entry ce6a6c40a567

Conjecture: Permutation Polynomial Width Conjecture

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 21:07 UTC.
Pre-registration hash committed before this test ran: `7450e05feebfd57d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
