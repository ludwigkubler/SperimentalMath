# Replay package — entry 70dcad1bedab

Conjecture: Minimal Local Index in Tropical Geometry Bounds DPLL Path Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 13:10 UTC.
Pre-registration hash committed before this test ran: `7f1e4bdb33fa03ad`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
