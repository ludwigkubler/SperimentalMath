# Replay package — entry 5421dda86f76

Conjecture: Symmetric Polynomial Monomial Count and Resolution Proof Size for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 01:10 UTC.
Pre-registration hash committed before this test ran: `6eeabe09a533f483`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
