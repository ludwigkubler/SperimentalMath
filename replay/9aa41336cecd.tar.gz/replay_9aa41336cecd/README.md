# Replay package — entry 9aa41336cecd

Conjecture: Viennot Heap Radius of Clause-Conflict Graph Bounds Frege Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 11:02 UTC.
Pre-registration hash committed before this test ran: `ce2fe08edb76a771`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
