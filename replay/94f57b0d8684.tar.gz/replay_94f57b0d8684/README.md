# Replay package — entry 94f57b0d8684

Conjecture: Minimal Rank of Tropicalized Sheaves over Manifolds vs AC0 Parity Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 04:40 UTC.
Pre-registration hash committed before this test ran: `2df1a6eb464523c3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
