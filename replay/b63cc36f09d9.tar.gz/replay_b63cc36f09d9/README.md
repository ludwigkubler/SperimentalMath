# Replay package — entry b63cc36f09d9

Conjecture: Minimal Rank of Configuration Spaces over Boolean Functions vs AC⁰ Circuit Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 12:50 UTC.
Pre-registration hash committed before this test ran: `514711f3e29e3e7f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
