# Replay package — entry 7a3f7bf977fb

Conjecture: Minimal Local Index of Lie Algebroids and Communication Complexity Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 20:51 UTC.
Pre-registration hash committed before this test ran: `6d692288b3e19e4b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
