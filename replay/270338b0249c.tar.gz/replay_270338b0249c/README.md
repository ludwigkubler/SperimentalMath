# Replay package — entry 270338b0249c

Conjecture: Barratt-Floer Homology Bounds ACC⁰ Circuit Size for XOR Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 22:39 UTC.
Pre-registration hash committed before this test ran: `677c5e7e44cc3bc4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
