# Replay package — entry a374f6d4e4e0

Conjecture: Minimal Rank of Quandle Representations vs Decision Tree Width for SAT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 18:10 UTC.
Pre-registration hash committed before this test ran: `c01c5c2666f1ae7e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
