# Replay package — entry 859b399fd4b6

Conjecture: Minimal Tropical Hodge Rank vs. Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 05:37 UTC.
Pre-registration hash committed before this test ran: `5c2f40ea5ec53cde`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
