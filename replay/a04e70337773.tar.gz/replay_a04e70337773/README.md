# Replay package — entry a04e70337773

Conjecture: Minimal Order of Automorphism Groups in Simple Lie Algebras and DPLL Path Length Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 11:19 UTC.
Pre-registration hash committed before this test ran: `73679a4ce0a7d851`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
