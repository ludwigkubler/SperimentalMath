# Replay package — entry cb66523ac3ef

Conjecture: Kronecker Coefficient Asymmetry in Permanent vs Determinant Decompositions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 12:48 UTC.
Pre-registration hash committed before this test ran: `dd8ae938acd5d5b8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
