# Replay package — entry 64cbbb31145a

Conjecture: Minimal Rank of Twisted Quotient Sheaves vs. DPLL Proof Width for Random k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 01:24 UTC.
Pre-registration hash committed before this test ran: `97fc4daeb31556f9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
