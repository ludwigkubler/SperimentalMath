# Replay package — entry a8323471011a

Conjecture: Minimal Order of p-Adic Units Bounds Determinant Depth of Circuits

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 19:01 UTC.
Pre-registration hash committed before this test ran: `298d14a84c5e4a81`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
