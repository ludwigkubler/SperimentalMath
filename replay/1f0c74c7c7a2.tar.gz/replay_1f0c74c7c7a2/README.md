# Replay package — entry 1f0c74c7c7a2

Conjecture: Minimal Topological Entropy and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 10:31 UTC.
Pre-registration hash committed before this test ran: `d451d6e9fe2dc8f2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
