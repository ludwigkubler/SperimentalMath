# Replay package — entry ea528936a40b

Conjecture: Minimal Rank of Free Probability Distributions vs BP_ReadTwice Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 21:19 UTC.
Pre-registration hash committed before this test ran: `acd4661b1d1b5335`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
