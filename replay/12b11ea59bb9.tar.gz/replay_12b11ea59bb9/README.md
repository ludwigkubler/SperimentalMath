# Replay package — entry 12b11ea59bb9

Conjecture: Minimal Order of Formal Power Series Bounds Circuit Depth for Ternary Operations

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 23:20 UTC.
Pre-registration hash committed before this test ran: `abdc8e35cbc618c2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
