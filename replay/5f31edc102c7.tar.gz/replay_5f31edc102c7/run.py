import random
import math
from collections import defaultdict

# Helper functions for matrix operations
def matrix_multiply(A, B):
    if len(A[0]) != len(B):
        raise ValueError("Incompatible dimensions for matrix multiplication")
    result = [[sum(a * b for a, b in zip(row_a, col_b)) for col_b in zip(*B)] for row_a in A]
    return result

def gaussian_elimination(matrix):
    rows, cols = len(matrix), len(matrix[0])
    augmented_matrix = [row + [i == j else 0 for j in range(cols)] for i, row in enumerate(matrix)]
    for i in range(rows):
        max_row = max(range(i, rows), key=lambda r: abs(augmented_matrix[r][i]))
        augmented_matrix[i], augmented_matrix[max_row] = augmented_matrix[max_row], augmented_matrix[i]
        if augmented_matrix[i][i] == 0:
            raise ValueError("Matrix is singular")
        for j in range(rows):
            if i != j:
                factor = augmented_matrix[j][i] / augmented_matrix[i][i]
                augmented_matrix[j] = [augmented_matrix[j][k] - factor * augmented_matrix[i][k] for k in range(cols + 1)]
    for i in range(rows):
        augmented_matrix[i][-1] /= augmented_matrix[i][i]
        augmented_matrix[i][i] = 1
    return [row[:-1] for row in augmented_matrix]

def rank(matrix):
    reduced_matrix = gaussian_elimination(matrix)
    return sum(1 for row in reduced_matrix if any(row))

# Function to compute tropical rank
def tropical_rank(tropical_matrix):
    unique_elements = set()
    for row in tropical_matrix:
        if not isinstance(row, list):
            unique_elements.add((row,))
        else:
            unique_elements.update(map(tuple, row))
    return max(len(set(map(sum, zip(*unique_elements)))), len(unique_elements))

# Function to generate a random Weyl group orbit
def generate_weyl_orbit(n):
    identity = [i for i in range(1, n + 1)]
    orbit = [identity]
    while True:
        next_element = [x if x != 1 else 2 for x in orbit[-1]]
        if next_element == identity:
            break
        orbit.append(next_element)
    return orbit

# Function to generate a random resolution proof
def generate_resolution_proof(n):
    clauses = [[random.randint(1, n) for _ in range(random.randint(1, n))] for _ in range(random.randint(1, n))]
    return clauses

# Function to generate a random DPLL proof
def generate_dpll_proof(n):
    clauses = [[random.randint(1, n) for _ in range(random.randint(1, n))] for _ in range(random.randint(1, n))]
    return clauses

# Main function to run one trial
def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    # Generate a random resolution proof and DPLL proof
    n = random.randint(5, 40)
    resolution_proof = generate_resolution_proof(n)
    dpll_proof = generate_dpll_proof(n)
    
    # Compute the associated Weyl group orbits
    resolution_orbit = generate_weyl_orbit(n)
    dpll_orbit = generate_weyl_orbit(n)
    
    # Apply tropicalization to these orbits and determine their minimal rank
    resolution_rank = tropical_rank(resolution_orbit)
    dpll_rank = tropical_rank(dpll_orbit)
    
    # Compare the ranks of tropicalized Weyl group orbits from resolution proofs and DPLL proofs
    metric_value = resolution_rank - dpll_rank
    
    return {
        "metric_name": "tropical_rank_difference",
        "metric_value": metric_value,
        "instances_tested": 1,
        "conjecture_holds": metric_value > 0,
        "counterexample": ""
    }

# Main block to run trials
if __name__ == "__main__":
    import sys
    seeds = [int(x) for x in sys.argv[1:]] or [2**i - 1 for i in range(5, 35)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value)**2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results) and support_fraction >= 0.8:
        print(f"RESULT: FALSIFIED counterexample=\"\" first_failing_seed=0")
    else:
        print("RESULT: INCONCLUSIVE reason=insufficient_evidence_or_budget_exceeded n_tested=30")