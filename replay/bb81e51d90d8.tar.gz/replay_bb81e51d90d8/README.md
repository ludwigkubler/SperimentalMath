# Replay package — entry bb81e51d90d8

Conjecture: Minimal Rank of Quotient Algebras over XOR-AND Tree Structures

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 13:22 UTC.
Pre-registration hash committed before this test ran: `3ff9076f9aa8e373`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
