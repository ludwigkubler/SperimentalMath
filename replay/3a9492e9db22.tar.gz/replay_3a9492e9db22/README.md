# Replay package — entry 3a9492e9db22

Conjecture: Ihara Zeta Entropy Lower-Bounds DPLL Depth on 3-Regular Tseitin

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 19:45 UTC.
Pre-registration hash committed before this test ran: `a0755e6f88e6ff95`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
