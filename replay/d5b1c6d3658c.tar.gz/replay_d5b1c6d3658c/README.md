# Replay package — entry d5b1c6d3658c

Conjecture: Minimal Rank of Graphical Subgroup Actions vs Frege Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 09:34 UTC.
Pre-registration hash committed before this test ran: `71750e44335bc0d4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
