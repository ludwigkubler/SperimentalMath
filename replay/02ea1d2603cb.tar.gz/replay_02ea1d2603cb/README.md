# Replay package — entry 02ea1d2603cb

Conjecture: Minimal Rank of Quandle Representations vs Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 23:37 UTC.
Pre-registration hash committed before this test ran: `b6a37a972e51a93a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
