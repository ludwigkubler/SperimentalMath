# Replay package — entry 8c7fedba9647

Conjecture: Minimal Rank of Geometric Loci vs Resolution Refutation Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 13:42 UTC.
Pre-registration hash committed before this test ran: `e0f40772ea45157e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
