# Replay package — entry f89319bf92ad

Conjecture: Condition Number of Moment Matrix Inversely Proportional to SOS Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 04:34 UTC.
Pre-registration hash committed before this test ran: `edb0a0f6979b1bee`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
