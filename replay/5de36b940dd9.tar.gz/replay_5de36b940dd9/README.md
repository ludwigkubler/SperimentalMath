# Replay package — entry 5de36b940dd9

Conjecture: Minimal Rank of Hodge Classes over Boolean Function Entropies

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 01:16 UTC.
Pre-registration hash committed before this test ran: `4d0202f18b72fab5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
