# Replay package — entry 8c0c1213d839

Conjecture: Diophantine Solutions and Frege Proof Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 03:36 UTC.
Pre-registration hash committed before this test ran: `7d4531f78a59bb61`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
