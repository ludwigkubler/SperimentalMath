# Replay package — entry f18019fc9eff

Conjecture: Minimal Rank of Quaternionic Forms Bounds Circuit Depth of XOR 3-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 10:36 UTC.
Pre-registration hash committed before this test ran: `ec2e3b08cbb1b130`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
