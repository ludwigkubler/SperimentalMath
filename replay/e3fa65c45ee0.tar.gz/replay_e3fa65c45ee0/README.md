# Replay package — entry e3fa65c45ee0

Conjecture: Algebraic Hodge Theory of Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 06:13 UTC.
Pre-registration hash committed before this test ran: `01850c17d3e0a589`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
