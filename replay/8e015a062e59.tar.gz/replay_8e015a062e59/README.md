# Replay package — entry 8e015a062e59

Conjecture: Minimal Local Ring Index and Frege Proof Depth Correlation via Tropicalization

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 19:28 UTC.
Pre-registration hash committed before this test ran: `cecf4e84d3aeaf43`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
