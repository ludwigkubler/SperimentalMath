# Replay package — entry 5f49c0d34464

Conjecture: Noncommutative Fourier Coefficient Inversion in Greater-Than Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 00:29 UTC.
Pre-registration hash committed before this test ran: `5fa6108fac14168f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
