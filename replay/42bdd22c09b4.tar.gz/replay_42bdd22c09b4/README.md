# Replay package — entry 42bdd22c09b4

Conjecture: Persistent Homology Barcode Length Inversely Proportional to DPLL Tree Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 19:41 UTC.
Pre-registration hash committed before this test ran: `d98d4ada15d16f57`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
