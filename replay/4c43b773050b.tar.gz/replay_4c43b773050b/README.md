# Replay package — entry 4c43b773050b

Conjecture: Minimal Local Ring Norm in Affine Geometry and DPLL Search Tree Diameter

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 11:19 UTC.
Pre-registration hash committed before this test ran: `bbd223441726cdc7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
