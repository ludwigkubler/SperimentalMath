# Replay package — entry d823e29c60c1

Conjecture: Algebraic Solution Count Bounds Nisan-Wigderson Seed Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 14:34 UTC.
Pre-registration hash committed before this test ran: `e89ee32d4c447417`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
