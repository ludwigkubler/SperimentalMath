# Replay package — entry e8b5d7beb1ac

Conjecture: Minimal Rank of Quotient Modules over Tropicalized Boolean Algebras vs Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 10:22 UTC.
Pre-registration hash committed before this test ran: `3681b4e8eb8925b6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
