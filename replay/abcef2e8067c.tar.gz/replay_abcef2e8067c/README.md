# Replay package — entry abcef2e8067c

Conjecture: Minimal Gromov-Witten Class and MCSP Depth Invariant

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 15:03 UTC.
Pre-registration hash committed before this test ran: `7638c1b8c0bfe9f4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
