# Replay package — entry 0e0b501d7e79

Conjecture: Tropicalization of Boolean Functions to Coxeter Matrix Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 15:57 UTC.
Pre-registration hash committed before this test ran: `9cca968ffe45da94`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
