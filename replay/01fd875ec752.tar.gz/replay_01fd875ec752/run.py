import random
import math
from fractions import Fraction

def read_twice_bp(n):
    if n == 1:
        return [0]
    bp = []
    for i in range(2 ** (n - 1) - 1):
        bp.append(bp[i // 2] ^ (i % 2))
    return bp

def calculate_tropical_curve_index(bp, n):
    # Simplified tropical curve index calculation
    return len(bp)

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    results = []
    for n in [5, 10, 15, 20, 30, 40]:
        size_P = 2 ** n
        bp = read_twice_bp(n)
        
        if len(bp) != size_P - 1:
            return {
                "metric_name": "tropical_curve_index",
                "metric_value": None,
                "instances_tested": 1,
                "conjecture_holds": False,
                "counterexample": "bp_size_mismatch"
            }
        
        index = calculate_tropical_curve_index(bp, n)
        results.append(index)
    
    mean_index = sum(results) / len(results)
    max_index = max(results)
    
    if all(index <= size_P for index in results):
        conjecture_holds = True
        counterexample = ""
    else:
        conjecture_holds = False
        counterexample = f"index={max_index} > size(P)={size_P}"
    
    return {
        "metric_name": "tropical_curve_index",
        "metric_value": mean_index,
        "instances_tested": len(results),
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    
    if not sys.argv[1:]:
        seeds = [2**i + 1 for i in range(5, 6)]  # Default list of 30 primes
    else:
        seeds = [int(seed) for seed in sys.argv[1:]]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result["metric_value"])
    
    mean_value = sum(results) / len(results)
    support_fraction = sum(1 for r in results if r is not None and r <= 2**math.ceil(math.log2(len(results))) else 0) / len(results)
    
    if all(r is not None and r <= 2**math.ceil(math.log2(len(results))) for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std=NA support_fraction={support_fraction}")
    elif any(r is not None and r > 2**math.ceil(math.log2(len(results))) for r in results):
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if result is not None and result > 2**math.ceil(math.log2(len(results))))
        print(f"RESULT: FALSIFIED counterexample='index_exceeds_size_P' first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE reason=metric_value_none_or_unsupported")