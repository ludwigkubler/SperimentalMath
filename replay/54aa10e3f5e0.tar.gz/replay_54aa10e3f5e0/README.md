# Replay package — entry 54aa10e3f5e0

Conjecture: Hypergeometric Function Rank Bounds Tree-Like Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 14:54 UTC.
Pre-registration hash committed before this test ran: `16eeef9bc44509f0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
