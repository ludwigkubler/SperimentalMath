# Replay package — entry dc98e63645dd

Conjecture: Minimal Rank of Tropicalized Configuration Spaces vs ACC⁰ Circuit Threshold for Tensor Product

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 13:36 UTC.
Pre-registration hash committed before this test ran: `8b7441693e26f7fe`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
