# Replay package — entry 6c4b0ac0af03

Conjecture: Minimal Rank of Geometric Invariant Theory (GIT) over Affine Schemes vs Communication Complexity for Disjointness

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 23:24 UTC.
Pre-registration hash committed before this test ran: `d4b519c0040ab58b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
