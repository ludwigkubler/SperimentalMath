# Replay package — entry a81b4af0bc2b

Conjecture: Oracle Collapse of κ: Anti-Relativization Stress Test for the Coarse-KW Invariant (A4)

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 17:34 UTC.
Pre-registration hash committed before this test ran: `601f7ebc71b9eba2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
