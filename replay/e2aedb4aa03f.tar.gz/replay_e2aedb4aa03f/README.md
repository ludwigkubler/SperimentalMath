# Replay package — entry e2aedb4aa03f

Conjecture: Fourier Coefficient Sum Lower-Bounds Resolution Length for 3-CNFs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-07 20:48 UTC.
Pre-registration hash committed before this test ran: `431bc530f3e5406c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
