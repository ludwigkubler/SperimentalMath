# Replay package — entry 025337d8bbcc

Conjecture: SOS Refutation Rounds and Symmetric Polynomial Rank

Verdict (original run): FALSIFIED

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 08:50 UTC.
Pre-registration hash committed before this test ran: `a19b591e97c1d157`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
