# Replay package — entry e0a06bc1af46

Conjecture: Hochster Regularity of Variable Co-Occurrence Graph Lower-Bounds Resolution Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 06:44 UTC.
Pre-registration hash committed before this test ran: `deac4029347f65c7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
