# Replay package — entry 933cb1283eb7

Conjecture: Minimal Rank of Quadratic Forms in Characteristic p vs Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 21:49 UTC.
Pre-registration hash committed before this test ran: `d46fb770b25570a7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
