# Replay package — entry acd6cc56e682

Conjecture: Minimal Rank of Quotient Algebras over Max-CUT Approximations

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 09:26 UTC.
Pre-registration hash committed before this test ran: `b8cf5e5ad6ecaeb9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
