# Replay package — entry dd74abbacec1

Conjecture: Irreducible Component Count of IP_2 BP Variety Bounds Read-Twice Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 22:54 UTC.
Pre-registration hash committed before this test ran: `28feb2e1e9ce2b99`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
