# Replay package — entry 2e3287498df8

Conjecture: Minimal Rank of Geometric Algebraic Curves and Communication Complexity Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 09:00 UTC.
Pre-registration hash committed before this test ran: `85781a1dd7104fd5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
