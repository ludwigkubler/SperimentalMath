# Replay package — entry c18380f06df9

Conjecture: Minimal Diophantine Root Count and Frege Proof Tree Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 07:22 UTC.
Pre-registration hash committed before this test ran: `a2af3ca326c17ee4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
