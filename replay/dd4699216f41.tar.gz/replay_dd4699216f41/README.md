# Replay package — entry dd4699216f41

Conjecture: Modular Character Degree Gap in Permanent vs Determinant Circuits

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 07:48 UTC.
Pre-registration hash committed before this test ran: `cad3dec921772440`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
