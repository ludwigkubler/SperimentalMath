# Replay package — entry e6716159d788

Conjecture: Real Radical Generator Count Bounds Karchmer-Wigderson Protocol Cost

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 22:23 UTC.
Pre-registration hash committed before this test ran: `b3004bf321a8e3a0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
