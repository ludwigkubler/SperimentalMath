# Replay package — entry fb49bf354760

Conjecture: Minimal Rank of Quadratic Reciprocity Tables vs Randomized Communication Complexity for XOR-AND Networks

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 20:28 UTC.
Pre-registration hash committed before this test ran: `83f90f32a0d11bfd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
