# Replay package — entry b3c84360a041

Conjecture: Rank of Young Tableaux vs Decision Tree Depth for Monotone Circuits

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 14:37 UTC.
Pre-registration hash committed before this test ran: `f9d4cb2f9249bdd3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
