# Replay package — entry 9956de739341

Conjecture: Minimal Lattice Point Counting and Communication Complexity Rank Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 00:50 UTC.
Pre-registration hash committed before this test ran: `de2b67d0113db327`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
