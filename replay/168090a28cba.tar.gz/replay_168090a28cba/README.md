# Replay package — entry 168090a28cba

Conjecture: Minimal Rank of Geometric Group Actions vs AC0 Parity Circuit Threshold

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 00:17 UTC.
Pre-registration hash committed before this test ran: `0d9b44588638e3bf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
