# Replay package — entry f07a47a73b4f

Conjecture: Kronecker Coefficient Exponential Gap in Symmetric Powers of Permanent vs Determinant

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 09:25 UTC.
Pre-registration hash committed before this test ran: `aa3c2509c9d20419`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
