# Replay package — entry 9020e29f840c

Conjecture: Cubical First-Betti Linearly Lower-Bounds DNF-MCSP

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 01:33 UTC.
Pre-registration hash committed before this test ran: `6692915bd1cd5a6b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
