# Replay package — entry 090386d08c4a

Conjecture: Quantum Entanglement Index and Read-Twice BP Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 15:19 UTC.
Pre-registration hash committed before this test ran: `e0208995059664bf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
