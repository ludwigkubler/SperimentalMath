# Replay package — entry 6623505195c8

Conjecture: Noncommutative Fourier Coefficient Inverse Proportionality to Communication Complexity Lower Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 14:29 UTC.
Pre-registration hash committed before this test ran: `b730123374388c4c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
