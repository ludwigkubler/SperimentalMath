# Replay package — entry 9468cf1f7df1

Conjecture: Minimal Index of Noncommutative Crossed Products and Read-Twice BP Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 21:54 UTC.
Pre-registration hash committed before this test ran: `7dd19f355b9dcc20`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
