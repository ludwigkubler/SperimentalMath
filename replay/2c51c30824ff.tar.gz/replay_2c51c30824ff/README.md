# Replay package — entry 2c51c30824ff

Conjecture: Minimal Discrepancy Tensor Rank of Polynomial Functions vs BP_ReadTwice Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 12:30 UTC.
Pre-registration hash committed before this test ran: `2cf7dfc0691b555d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
