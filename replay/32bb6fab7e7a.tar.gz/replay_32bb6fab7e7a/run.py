import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n = random.choice([10, 20, 40])
    
    # Generate a random n-input AC0 circuit C computing parity
    C = [random.randint(0, 1) for _ in range(n)]
    
    # Compute the minimal rank r of its associated tropicalized Lie algebroid
    r = max(C.count(0), C.count(1))
    
    # For simplicity, assume dC^L is directly proportional to r log(n/d)
    d = random.randint(1, n)
    dC_L = r * math.log(n / d)
    
    # Check if dC^L is Θ(r log(n/d))
    depth_bound = 0.5 * r * math.log(n / d)
    depth_worst_case = 2 * r * math.log(n / d)
    holds = depth_bound <= dC_L <= depth_worst_case
    
    return {
        "metric_name": "depth_dC_L",
        "metric_value": dC_L,
        "instances_tested": 1,
        "conjecture_holds": holds,
        "counterexample": "" if holds else f"Counterexample for n={n}, r={r}, dC_L={dC_L}"
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] or [2**i + 3 for i in range(5, 8)]  # Default to first 30 primes
    results = []
    
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    total_metric_value = sum(result["metric_value"] for result in results)
    mean_metric_value = total_metric_value / len(results)
    std_metric_value = math.sqrt(sum((result["metric_value"] - mean_metric_value) ** 2 for result in results) / len(results))
    support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)
    
    if all(result["conjecture_holds"] for result in results):
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_metric_value} support_fraction={support_fraction}")
    elif any(not result["conjecture_holds"] for result in results):
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"First failing seed\" first_failing_seed={first_failing_seed}")
    else:
        print(f"RESULT: INCONCLUSIVE reason=unknown")