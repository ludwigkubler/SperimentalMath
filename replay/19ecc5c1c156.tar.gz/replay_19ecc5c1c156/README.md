# Replay package — entry 19ecc5c1c156

Conjecture: Minimal Local Cohomology Rank and Communication Complexity Rank Variance Ratio

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 03:45 UTC.
Pre-registration hash committed before this test ran: `99d01badde259bce`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
