# Replay package — entry ddff7b518beb

Conjecture: Algebraic Stochastic Order of Boolean Functions vs Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 17:21 UTC.
Pre-registration hash committed before this test ran: `31b2ffc798e66a65`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
