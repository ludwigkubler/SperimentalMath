# Replay package — entry dab8f318c24f

Conjecture: Minimal Hodge Norm of Algebraic Curves and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 09:38 UTC.
Pre-registration hash committed before this test ran: `40ec6b5c29f14241`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
