# Replay package — entry 637e2de2b093

Conjecture: Minimal Order of Quadratic Reciprocity and DPLL Proof Tree Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 05:45 UTC.
Pre-registration hash committed before this test ran: `288ec17c281b8e50`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
