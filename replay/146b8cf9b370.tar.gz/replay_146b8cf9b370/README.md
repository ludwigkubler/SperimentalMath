# Replay package — entry 146b8cf9b370

Conjecture: Spectral Mahler Measure of Tseitin Moment Matrix Bounds SOS Refutation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-07 20:05 UTC.
Pre-registration hash committed before this test ran: `2fe863c42b93cc89`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
