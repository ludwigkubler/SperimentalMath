# Replay package — entry 5540f2e88bbf

Conjecture: Minimal Rank of Categorical Functors over Tseitin Clauses vs BP_ReadTwice Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 20:23 UTC.
Pre-registration hash committed before this test ran: `db5650d87432eea2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
