# Replay package — entry 1d9163fa810a

Conjecture: Galois Theory Invariant Bounds SAT Clause Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 05:03 UTC.
Pre-registration hash committed before this test ran: `21f189a90670e6f2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
