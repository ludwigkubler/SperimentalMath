# Replay package — entry a05be7217792

Conjecture: Minimal Rank of Twisted Tensor Products vs Monotone Circuit Size for k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 03:07 UTC.
Pre-registration hash committed before this test ran: `e3a16c1c7337ce4a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
