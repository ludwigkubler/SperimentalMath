# Replay package — entry 023dd98c00ee

Conjecture: GF(2)-Rank Defect of Term-Indicator Matrix Lower-Bounds Monotone DNF for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-29 00:11 UTC.
Pre-registration hash committed before this test ran: `af8a5d8c339698cb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
