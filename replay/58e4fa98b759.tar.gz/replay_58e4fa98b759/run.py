import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_cnf(n):
        clauses = []
        for _ in range(2**n):
            clause = [random.choice([1, -1]) * (i + 1) for i in range(n)]
            if all(clause[i] != -clause[j] for i in range(n) for j in range(i+1, n)):
                clauses.append(clause)
        return clauses
    
    def gromov_witten_invariant(cnf):
        # Placeholder function to simulate Gromov-Witten invariant calculation
        return len(cnf)
    
    def acc0_circuit_size(cnf):
        # Placeholder function to simulate ACC0 circuit size calculation
        return 2 ** gromov_witten_invariant(cnf)
    
    n = random.randint(5, 40)
    cnf = generate_cnf(n)
    mu_F = gromov_witten_invariant(cnf)
    acc0_size = acc0_circuit_size(cnf)
    
    return {
        "metric_name": "acc0_circuit_size",
        "metric_value": acc0_size,
        "instances_tested": 1,
        "conjecture_holds": mu_F <= acc0_size,
        "counterexample": "" if mu_F <= acc0_size else f"CNF with n={n} has μ(F)={mu_F}, but ACC0 circuit size is {acc0_size}"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2**i + 3 for i in range(5, 8)]  # Default to first 3 primes if no seeds provided
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value)**2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{results[0]['counterexample']}\" first_failing_seed={first_failing_seed}")