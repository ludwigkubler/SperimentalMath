# Replay package — entry d9ef369c3fb2

Conjecture: Minimal Rank of Tropicalized Quivers Bounds Circuit Monotonicity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 21:54 UTC.
Pre-registration hash committed before this test ran: `6252b549e2dd576c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
