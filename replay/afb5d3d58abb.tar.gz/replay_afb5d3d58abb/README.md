# Replay package — entry afb5d3d58abb

Conjecture: Minimal Rank of Algebraic Automorphism Groups Bounds Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 11:14 UTC.
Pre-registration hash committed before this test ran: `f093a1f31193798a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
