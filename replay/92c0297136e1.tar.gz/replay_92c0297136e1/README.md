# Replay package — entry 92c0297136e1

Conjecture: Minimal Lattice Point Density Correlation with Resolution Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 19:36 UTC.
Pre-registration hash committed before this test ran: `064c18ec2516004a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
