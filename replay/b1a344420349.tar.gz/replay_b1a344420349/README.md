# Replay package — entry b1a344420349

Conjecture: Moment Matrix Rank Lower Bound for Max-CUT SOS Approximation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 14:54 UTC.
Pre-registration hash committed before this test ran: `ed1dac8fe88791ea`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
