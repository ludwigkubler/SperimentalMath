# Replay package — entry 78a0daff2b40

Conjecture: Plateau-Duration Lemma: T_plateau ≥ |S|/4 for DP on Tseitin

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 11:25 UTC.
Pre-registration hash committed before this test ran: `d241a06f80d1387d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
