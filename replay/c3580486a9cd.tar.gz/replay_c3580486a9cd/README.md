# Replay package — entry c3580486a9cd

Conjecture: Minimal Symplectic Form Degree and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 02:59 UTC.
Pre-registration hash committed before this test ran: `4ddc509e719185c5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
