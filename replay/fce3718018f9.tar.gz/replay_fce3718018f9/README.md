# Replay package — entry fce3718018f9

Conjecture: Algebraic Geometry of Cubes and Circuit Monotone Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 09:21 UTC.
Pre-registration hash committed before this test ran: `c8cef9fdf07a26cd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
