# Replay package — entry e9d326294e7e

Conjecture: Minimal Rank of Geometric Entanglement vs Quantum Query Complexity for XOR

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 00:23 UTC.
Pre-registration hash committed before this test ran: `6926faa78d0639dc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
