# Replay package — entry 1ecbca5d4eed

Conjecture: Minimal Rank of Quadratic Forms and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 14:33 UTC.
Pre-registration hash committed before this test ran: `8e298c3ffa85f4f7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
