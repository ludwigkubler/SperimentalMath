# Replay package — entry d94fe886c87d

Conjecture: Galois Group Action and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 22:35 UTC.
Pre-registration hash committed before this test ran: `d9388275875df03a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
