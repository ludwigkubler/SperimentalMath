# Replay package — entry f7629b0b1da6

Conjecture: Minimal Order of p-Adic Differentials Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 05:03 UTC.
Pre-registration hash committed before this test ran: `523fdd1857cbcfb8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
