# Replay package — entry 66678383559c

Conjecture: Minimal Order of Eta-Invariant and Communication Complexity Rank Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 23:00 UTC.
Pre-registration hash committed before this test ran: `00ce18b30e49fbc2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
