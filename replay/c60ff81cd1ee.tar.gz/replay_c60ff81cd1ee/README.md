# Replay package — entry c60ff81cd1ee

Conjecture: Minimal Geometric Entropy of Affine Schemes Bounds Resolution Proof Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 10:22 UTC.
Pre-registration hash committed before this test ran: `9c0a48c107368435`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
