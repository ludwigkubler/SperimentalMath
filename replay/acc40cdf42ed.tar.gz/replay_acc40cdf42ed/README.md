# Replay package — entry acc40cdf42ed

Conjecture: Ideal Minimal Generator Count Bounds ACC^0 Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 15:59 UTC.
Pre-registration hash committed before this test ran: `b26d1163c23b307d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
