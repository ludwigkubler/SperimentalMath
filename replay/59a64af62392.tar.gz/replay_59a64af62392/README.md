# Replay package — entry 59a64af62392

Conjecture: Minimal Number of Integral Points in Algebraic Curves and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 05:08 UTC.
Pre-registration hash committed before this test ran: `bf4e42bb45821f95`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
