# Replay package — entry e80d60e179ec

Conjecture: Minimal Number of Automorphism Groups and Circuit Entropy Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 03:28 UTC.
Pre-registration hash committed before this test ran: `ce343762c144d4c6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
