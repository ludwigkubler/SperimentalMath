# Replay package — entry 1de2d7187fe1

Conjecture: Additive Energy Lower Bound via Read-Twice Branching Program Discrepancy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 07:07 UTC.
Pre-registration hash committed before this test ran: `bfaff13147d10cc5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
