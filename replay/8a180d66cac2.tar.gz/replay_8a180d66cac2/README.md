# Replay package — entry 8a180d66cac2

Conjecture: Polynomial Threshold Function Degree Bounds Karchmer-Wigderson Protocol Cost for PARITY

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 05:41 UTC.
Pre-registration hash committed before this test ran: `3648d9f99e664252`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
