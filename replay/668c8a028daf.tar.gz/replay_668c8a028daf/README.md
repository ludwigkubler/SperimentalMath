# Replay package — entry 668c8a028daf

Conjecture: Minimal Rank of Kähler Forms vs Decision Tree Width for XOR Tautologies

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 08:18 UTC.
Pre-registration hash committed before this test ran: `7d09695aaaf12523`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
