# Replay package — entry 34c115ca17e4

Conjecture: Minimal Rank of Configuration Spaces Bounds Communication Complexity for DISJOINTNESS

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 19:23 UTC.
Pre-registration hash committed before this test ran: `9226055c4275416e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
