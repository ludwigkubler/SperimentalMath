# Replay package — entry 06856744ef95

Conjecture: Minimal Symmetry of Quiver Representations in Resolution Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 18:42 UTC.
Pre-registration hash committed before this test ran: `1d1502ef88425fdd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
