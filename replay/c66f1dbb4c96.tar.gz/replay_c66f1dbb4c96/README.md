# Replay package — entry c66f1dbb4c96

Conjecture: Minimal Local Cohomology Rank of Tseitin Formulas Bounds Cumulative Proof Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 06:43 UTC.
Pre-registration hash committed before this test ran: `ed104261e844f175`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
