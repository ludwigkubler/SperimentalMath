# Replay package — entry e94a84320037

Conjecture: Minimal Rank of Quadratic Forms over Boolean Tensor Product Valuations

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 03:13 UTC.
Pre-registration hash committed before this test ran: `58e15d2b3c3e023e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
