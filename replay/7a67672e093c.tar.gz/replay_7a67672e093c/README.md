# Replay package — entry 7a67672e093c

Conjecture: Minimal Geometric Entropy of Metric Trees and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 02:44 UTC.
Pre-registration hash committed before this test ran: `5237a244831dd4bf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
