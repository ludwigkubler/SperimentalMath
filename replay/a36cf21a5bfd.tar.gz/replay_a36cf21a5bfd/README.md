# Replay package — entry a36cf21a5bfd

Conjecture: Minimal Number of Integral Points in Real Algebraic Variety and Resolution Proof Tree Height

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 18:51 UTC.
Pre-registration hash committed before this test ran: `52baf8ba7bf35c9d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
