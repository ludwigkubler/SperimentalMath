# Replay package — entry db811b9212d2

Conjecture: Minimal L^2 Norm of Quadratic Forms Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 07:25 UTC.
Pre-registration hash committed before this test ran: `2ad51ee8daca5df3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
