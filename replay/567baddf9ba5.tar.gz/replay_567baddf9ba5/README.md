# Replay package — entry 567baddf9ba5

Conjecture: Symmetric Group Fourier Coefficients Inverse Proportional to ACC⁰ Circuit Size for Sipser Function

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 01:48 UTC.
Pre-registration hash committed before this test ran: `4b5c17751a6c3da2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
