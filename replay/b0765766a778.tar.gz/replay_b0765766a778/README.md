# Replay package — entry b0765766a778

Conjecture: Asymptotic Dimension of KW Space for PARITY Matches Optimal Formula Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 03:25 UTC.
Pre-registration hash committed before this test ran: `4fa2cb8f0f7e4e28`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
