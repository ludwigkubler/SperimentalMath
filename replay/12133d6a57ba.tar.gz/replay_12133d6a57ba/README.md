# Replay package — entry 12133d6a57ba

Conjecture: Minimal Geometric Complexity of Boolean Functions and Communication Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 01:33 UTC.
Pre-registration hash committed before this test ran: `8bf4b02fdb9373a5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
