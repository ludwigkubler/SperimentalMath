import random
from fractions import Fraction
import math

def generate_boolean_formula(n):
    if n == 1:
        return 'x1'
    else:
        subformulas = [generate_boolean_formula(random.randint(1, n-1)) for _ in range(2)]
        operator = random.choice(['&', '|'])
        return f'({subformulas[0]} {operator} {subformulas[1]})'

def frege_proof_depth(formula):
    if formula.isalpha():
        return 1
    else:
        subdepths = [frege_proof_depth(sub) for sub in formula.split()[2:]]
        return max(subdepths) + 1

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    n_values = [5, 10, 15, 20, 30, 40]
    total_min_order = 0
    instances_tested = 0
    
    for n in n_values:
        for _ in range(5):  # Ensure at least 30 instances per seed
            formula = generate_boolean_formula(n)
            min_order = len(formula.split())  # Simplistic proxy for complexity
            total_min_order += min_order
            instances_tested += 1
    
    mean_min_order = Fraction(total_min_order, instances_tested)
    conjecture_holds = all(min_order >= n for n in n_values for _ in range(5))
    
    return {
        "metric_name": "min_order",
        "metric_value": float(mean_min_order),
        "instances_tested": instances_tested,
        "n_max": 40,
        "conjecture_holds": conjecture_holds,
        "counterexample": ""
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2**i + 3 for i in range(5, 8)]  # Default to first 30 primes
    
    results = []
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    mean_value = sum(result["metric_value"] for result in results) / len(results)
    support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)
    
    if all(result["conjecture_holds"] for result in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std=0.0 support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std=0.0 support_fraction={support_fraction}")
    else:
        first_failing_seed = next(seed for seed, result in enumerate(results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"not supported\" first_failing_seed={first_failing_seed}")