# Replay package — entry 52ba9a0b4010

Conjecture: Littlewood-Richardson Coefficient Gap in Permanent vs Determinant Decompositions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 08:38 UTC.
Pre-registration hash committed before this test ran: `41bcd94b0b29e6fa`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
