# Replay package — entry fd57783d2ed4

Conjecture: Cross-Read Kronecker Sum Rank Lower-Bounds Read-Twice BP for IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 00:32 UTC.
Pre-registration hash committed before this test ran: `90301348303b3e1f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
