# Replay package — entry f8faa3ec05b0

Conjecture: Coxeter Group Action on SAT Clause Complexities

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 20:11 UTC.
Pre-registration hash committed before this test ran: `c7c8fde59e6a7299`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
