# Replay package — entry 57639c301858

Conjecture: Minimal Rank of Quasi-Orthogonal Matrices over Function Fields vs AC0 Parity Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 06:28 UTC.
Pre-registration hash committed before this test ran: `49c8506b802ff623`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
