# Replay package — entry 257b7d27950c

Conjecture: Minimal Geometric Complexity of Riemann Surfaces in CNF Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 02:53 UTC.
Pre-registration hash committed before this test ran: `e6f16cb6dffb3b58`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
