# Replay package — entry 881a213ae900

Conjecture: Minimal Order of Integer-Valued Quasi-Crystals and Circuit Monotone Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 08:15 UTC.
Pre-registration hash committed before this test ran: `df99bceb7354ace7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
