# Replay package — entry 13665578f781

Conjecture: Minimal Local Zeta Function Order and Frege Proof Depth Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 18:39 UTC.
Pre-registration hash committed before this test ran: `c8502b8217cd577e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
