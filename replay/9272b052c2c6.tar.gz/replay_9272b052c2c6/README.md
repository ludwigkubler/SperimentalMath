# Replay package — entry 9272b052c2c6

Conjecture: SOS Moment Matrix Rank and Real Variety Dimension for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-30 16:12 UTC.
Pre-registration hash committed before this test ran: `45352571dfc40be9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
