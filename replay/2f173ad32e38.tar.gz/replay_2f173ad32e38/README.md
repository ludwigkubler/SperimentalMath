# Replay package — entry 2f173ad32e38

Conjecture: Poset Dimension and Karchmer-Wigderson Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 00:17 UTC.
Pre-registration hash committed before this test ran: `365af9ae651c469f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
