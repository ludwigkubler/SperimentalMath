# Replay package — entry c3471d87796d

Conjecture: Minimal Number of Algebraic Curves with Bounded Intersection and SAT Clause Subset Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 23:13 UTC.
Pre-registration hash committed before this test ran: `6d8f1497e84392de`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
