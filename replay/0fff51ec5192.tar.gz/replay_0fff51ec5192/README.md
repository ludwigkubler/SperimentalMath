# Replay package — entry 0fff51ec5192

Conjecture: Minimal Quaternionic Norm Correlation with Circuit Monotone Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 20:09 UTC.
Pre-registration hash committed before this test ran: `20b8270af84cb5f1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
