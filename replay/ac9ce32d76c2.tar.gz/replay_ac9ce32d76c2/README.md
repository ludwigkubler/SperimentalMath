# Replay package — entry ac9ce32d76c2

Conjecture: Minimal Symplectic Invariant Bound on Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 11:41 UTC.
Pre-registration hash committed before this test ran: `3d351f8a65cc6e8d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
