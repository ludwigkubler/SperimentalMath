import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_k_cnf(n, k):
        variables = set(range(1, n + 1))
        clauses = []
        for _ in range(k):
            clause = random.sample(variables, 2)
            clauses.append(clause)
        return clauses
    
    def graphical_realization(clauses):
        n = len(clauses)
        graph = {i: [] for i in range(n)}
        for i in range(n):
            for j in range(i + 1, n):
                if set(clauses[i]) & set(clauses[j]):
                    graph[i].append(j)
                    graph[j].append(i)
        return graph
    
    def noncrossed_product_k_theory(graph):
        n = len(graph)
        rank = 0
        for i in range(n):
            neighbors = graph[i]
            if not neighbors:
                continue
            matrix = [[0] * (n + 1) for _ in range(n + 1)]
            for j in neighbors:
                matrix[i][j] = 1
                matrix[j][i] = 1
            matrix[n][i] = -1
            matrix[i][n] = -1
            rank += gaussian_elimination(matrix)
        return rank
    
    def gaussian_elimination(matrix):
        n = len(matrix)
        for i in range(n):
            if matrix[i][i] == 0:
                for j in range(i + 1, n):
                    if matrix[j][i] != 0:
                        matrix[i], matrix[j] = matrix[j], matrix[i]
                        break
                else:
                    return 0
            pivot = matrix[i][i]
            for j in range(n + 1):
                matrix[i][j] /= pivot
            for j in range(n):
                if i != j:
                    factor = matrix[j][i]
                    for k in range(n + 1):
                        matrix[j][k] -= factor * matrix[i][k]
        return sum(1 for row in matrix if any(row))

    n_values = [5, 10, 15, 20, 30, 40]
    total_rank = 0
    instances_tested = 0
    
    for n in n_values:
        for _ in range(5):
            k = random.randint(1, min(n * (n - 1) // 2, 10))
            clauses = generate_k_cnf(n, k)
            graph = graphical_realization(clauses)
            rank = noncrossed_product_k_theory(graph)
            total_rank += rank
            instances_tested += 1
    
    mean_rank = total_rank / instances_tested
    conjecture_holds = mean_rank <= 2 * math.log(n) for n in n_values]
    
    return {
        "metric_name": "mean_rank",
        "metric_value": mean_rank,
        "instances_tested": instances_tested,
        "conjecture_holds": all(conjecture_holds),
        "counterexample": "" if all(conjecture_holds) else "mapping_undefined"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {{\"seed\": {seed}, \"metric_name\": \"{result['metric_name']}\", \"metric_value\": {result['metric_value']}, \"instances_tested\": {result['instances_tested']}, \"conjecture_holds\": {result['conjecture_holds']}, \"counterexample\": \"{result['counterexample']}\"}}")
        results.append(result)
    
    mean_rank = sum(r["metric_value"] for r in results) / len(results)
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_rank} std=0.0 support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(s for s, r in zip(seeds, results) if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"mapping_undefined\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE reason=unknown")