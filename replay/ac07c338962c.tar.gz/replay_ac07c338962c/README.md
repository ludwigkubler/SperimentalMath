# Replay package — entry ac07c338962c

Conjecture: Finite-Field Rank Threshold for ACC⁰ Circuit Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 10:35 UTC.
Pre-registration hash committed before this test ran: `6507095556e19b53`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
