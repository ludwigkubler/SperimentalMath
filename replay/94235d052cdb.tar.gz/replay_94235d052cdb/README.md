# Replay package — entry 94235d052cdb

Conjecture: Minimal Local Defect Complexity of Affine Quotients vs Resolution Proof Tree Diameter

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 06:25 UTC.
Pre-registration hash committed before this test ran: `030a919eb1b2b72b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
