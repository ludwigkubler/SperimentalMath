# Replay package — entry b81e6538851e

Conjecture: Gauss-Kuzmin Deviation Bounds Truth-Table Lempel-Ziv Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 09:02 UTC.
Pre-registration hash committed before this test ran: `1384421249ccf520`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
