# Replay package — entry 8c645d7e16b2

Conjecture: Minimal Rank of Schur Polynomials in Binary Decision Diagrams vs. Monotone Circuit Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 00:01 UTC.
Pre-registration hash committed before this test ran: `9bc60a03ce85a746`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
