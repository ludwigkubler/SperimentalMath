# Replay package — entry d6edb54962f2

Conjecture: Minimal Rank of Deligne–Lusztig Cones over Tseitin Resolution Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 06:35 UTC.
Pre-registration hash committed before this test ran: `a64caa4802ee531c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
