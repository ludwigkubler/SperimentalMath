# Replay package — entry 348009afca74

Conjecture: Minimal Order of Tropicalizations of Graphs and SAT Satisfiability Degree

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 13:38 UTC.
Pre-registration hash committed before this test ran: `89e8b543a9d7da79`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
