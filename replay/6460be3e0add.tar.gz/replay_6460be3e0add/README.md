# Replay package — entry 6460be3e0add

Conjecture: Minimal Index of Birational Geometry and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 18:43 UTC.
Pre-registration hash committed before this test ran: `a4ec13df1c4a60a2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
