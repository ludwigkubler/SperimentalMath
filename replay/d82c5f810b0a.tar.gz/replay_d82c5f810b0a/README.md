# Replay package — entry d82c5f810b0a

Conjecture: Minimal Order of Noncommutative Crossed Products and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 01:56 UTC.
Pre-registration hash committed before this test ran: `4024a65b2a38d3bf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
