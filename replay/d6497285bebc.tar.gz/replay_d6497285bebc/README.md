# Replay package — entry d6497285bebc

Conjecture: SBM Detectability Gap of Literal Conflict Graph Bounds DPLL Time

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 12:32 UTC.
Pre-registration hash committed before this test ran: `ac3cc6b70a99e620`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
