# Replay package — entry ea46e1d39086

Conjecture: Slice Rank Lower Bound for Disjointness Communication Matrices

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 22:15 UTC.
Pre-registration hash committed before this test ran: `12cf62628464a8c0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
