# Replay package — entry 6ade8b9067eb

Conjecture: Minimal Rank of Geometric Measure Theory over Max-Cut Relaxations

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 11:22 UTC.
Pre-registration hash committed before this test ran: `3aaa1e2cc8ce5b3e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
