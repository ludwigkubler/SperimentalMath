# Replay package — entry 239251aecfea

Conjecture: Minimal Rank of Configuration Spaces Bounds Monomial Ideal Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 21:58 UTC.
Pre-registration hash committed before this test ran: `63001b821219bef9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
