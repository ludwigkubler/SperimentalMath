# Replay package — entry 34f4f9958da2

Conjecture: Sub-Sqrt-Log Concentration of Tropical Doubling Discrepancy at β=5

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 09:50 UTC.
Pre-registration hash committed before this test ran: `4d87eeab585818b5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
