# Replay package — entry 288b1eeba389

Conjecture: Minimal Rank of Configuration Spaces over Function Fields vs Communication Complexity for k-Clique

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 18:40 UTC.
Pre-registration hash committed before this test ran: `baaf57c6727d1363`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
