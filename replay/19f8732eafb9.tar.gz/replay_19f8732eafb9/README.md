# Replay package — entry 19f8732eafb9

Conjecture: Coxeter Group Action on Boolean Functions via Representation Theory

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 21:27 UTC.
Pre-registration hash committed before this test ran: `71a184dbc7f1d280`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
