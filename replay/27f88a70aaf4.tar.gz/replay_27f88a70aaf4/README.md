# Replay package — entry 27f88a70aaf4

Conjecture: Matroid Spread Bounded by Monotone DNF Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 06:40 UTC.
Pre-registration hash committed before this test ran: `e78e028b0b294d84`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
