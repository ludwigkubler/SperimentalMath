# Replay package — entry b84003030ac2

Conjecture: Minimal Index of Symmetric Matrix Power Bounds Quantum Communication Complexity for XOR

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 10:48 UTC.
Pre-registration hash committed before this test ran: `b662a9de4ff3516f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
