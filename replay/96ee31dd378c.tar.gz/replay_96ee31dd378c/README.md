# Replay package — entry 96ee31dd378c

Conjecture: Minimal Rank of Topological Insulators vs DPLL Proof Time

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 23:17 UTC.
Pre-registration hash committed before this test ran: `f9b3904b366b162a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
