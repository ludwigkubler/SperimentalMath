import random
from fractions import Fraction

def gaussian_elimination(A):
    m, n = len(A), len(A[0])
    for i in range(m):
        # Find pivot row
        max_row = i
        for j in range(i+1, m):
            if abs(A[j][i]) > abs(A[max_row][i]):
                max_row = j
        A[i], A[max_row] = A[max_row], A[i]
        
        # Eliminate below the pivot
        for j in range(i+1, m):
            factor = Fraction(A[j][i], A[i][i])
            for k in range(n):
                A[j][k] -= factor * A[i][k]

    return A

def rank(matrix):
    A = [row[:] for row in matrix]
    gaussian_elimination(A)
    rank = 0
    for row in A:
        if any(row): rank += 1
    return rank

def tseitin_formula(n, m=None):
    variables = list(range(1, n+1))
    clauses = []
    
    # Generate clauses
    for i in range(m or n):
        clause = [random.choice(variables), random.choice([-var for var in variables])]
        clauses.append(clause)
    
    return variables, clauses

def resolution_proof_tree_width(n, m):
    # Simplified model of RPTW for demonstration purposes
    return m ** (1/3)

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    n = random.randint(5, 40)
    m = random.randint(2*n, 4*n)
    variables, clauses = tseitin_formula(n, m)
    
    k_theory_rank = rank([[1 if i == j else 0 for j in range(n)] for i in range(n)])
    rptw = resolution_proof_tree_width(n, m)
    
    conjecture_holds = rptw <= m ** (1/3) * k_theory_rank
    counterexample = "" if conjecture_holds else f"RPTW={rptw} > {m**(1/3)*k_theory_rank}"
    
    return {
        "metric_name": "Resolution Proof Tree Width",
        "metric_value": rptw,
        "instances_tested": 1,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2**i + 3 for i in range(5, 8)]
    
    results = []
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    mean_rptw = sum(result["metric_value"] for result in results) / len(results)
    std_rptw = (sum((result["metric_value"] - mean_rptw)**2 for result in results) / len(results))**0.5
    support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)
    
    if all(result["conjecture_holds"] for result in results):
        print(f"RESULT: SUPPORTED mean={mean_rptw} std={std_rptw} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_rptw} std={std_rptw} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{result['counterexample']}\" first_failing_seed={first_failing_seed}")