import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_read_twice_function(n):
        return [random.choice([0, 1]) for _ in range(2**n)]
    
    def calculate_noncommutative_entropy(matrix):
        n = len(matrix)
        entropy = 0
        for i in range(n):
            for j in range(i+1, n):
                if matrix[i][j] != matrix[j][i]:
                    entropy += math.log2(2)
        return entropy
    
    def generate_matrix_representation(function):
        n = int(math.log2(len(function)))
        matrix = [[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1, n):
                if function[i*2**j] != function[j*2**i]:
                    matrix[i][j] = 1
                    matrix[j][i] = 1
        return matrix
    
    def sum_noncommutative_entropy(functions):
        total_entropy = 0
        for function in functions:
            matrix = generate_matrix_representation(function)
            entropy = calculate_noncommutative_entropy(matrix)
            total_entropy += entropy
        return total_entropy
    
    n_values = [5, 10, 15, 20, 30, 40]
    results = []
    
    for n in n_values:
        function = generate_read_twice_function(n)
        functions = [function] * 30
        total_entropy = sum_noncommutative_entropy(functions)
        
        if total_entropy <= math.log2(n):
            return {
                "metric_name": "Noncommutative Entropy Sum",
                "metric_value": total_entropy,
                "instances_tested": len(functions),
                "conjecture_holds": False,
                "counterexample": f"n={n}, Total Entropy <= log(n)"
            }
        
        if total_entropy < n**2:
            return {
                "metric_name": "Noncommutative Entropy Sum",
                "metric_value": total_entropy,
                "instances_tested": len(functions),
                "conjecture_holds": False,
                "counterexample": f"n={n}, Total Entropy < n^2"
            }
        
        results.append(total_entropy)
    
    mean_entropy = sum(results) / len(results)
    std_dev = math.sqrt(sum((x - mean_entropy)**2 for x in results) / len(results))
    
    return {
        "metric_name": "Noncommutative Entropy Sum",
        "metric_value": mean_entropy,
        "instances_tested": len(results),
        "conjecture_holds": True,
        "counterexample": ""
    }

if __name__ == "__main__":
    import sys
    seeds = [int(x) for x in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113]
    
    results = []
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    mean_entropy = sum(x["metric_value"] for x in results) / len(results)
    std_dev = math.sqrt(sum((x["metric_value"] - mean_entropy)**2 for x in results) / len(results))
    support_fraction = sum(1 for x in results if x["conjecture_holds"]) / len(results)
    
    if support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_entropy} std={std_dev} support_fraction={support_fraction}")
    elif any(not x["conjecture_holds"] for x in results):
        first_failing_seed = next(x["seed"] for x in results if not x["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"n={results[0]['metric_value']}\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE reason=insufficient_evidence")