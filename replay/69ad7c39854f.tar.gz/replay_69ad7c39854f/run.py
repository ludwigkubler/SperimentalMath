import random
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    n = random.randint(5, 40)
    m = random.randint(1, min(n, 10))
    
    # Generate a random XOR-AND network with n inputs and m outputs
    network = [[random.choice([0, 1]) for _ in range(m)] for _ in range(n)]
    
    # Compute the minimal rank of the geometric invariant associated with the representation theory of the input space
    # This is a placeholder function. Replace it with actual computation if possible.
    min_rank = sum(1 for row in network if any(row))
    
    return {
        "metric_name": "Minimal Rank",
        "metric_value": min_rank,
        "instances_tested": 1,
        "conjecture_holds": False,
        "counterexample": "mapping_undefined"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(x) for x in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    
    results = []
    
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_rank = sum(res["metric_value"] for res in results) / len(results)
    support_fraction = sum(1 for res in results if res["conjecture_holds"]) / len(results)
    
    RESULT = "SUPPORTED" if support_fraction >= 0.8 else "FALSIFIED"
    counterexample = next((res["counterexample"] for res in results if not res["conjecture_holds"]), "")
    first_failing_seed = next((res["seed"] for res in results if not res["conjecture_holds"]), None)
    
    print(f"RESULT: {RESULT} mean={mean_rank:.2f} std=0.00 support_fraction={support_fraction:.2f}")