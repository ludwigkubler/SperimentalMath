# Replay package — entry d4f65b616cde

Conjecture: Minimal Rank of Tropicalized Symplectic Forms Bounds AC⁰ Parity Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 00:35 UTC.
Pre-registration hash committed before this test ran: `a8d7b4559d489d30`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
