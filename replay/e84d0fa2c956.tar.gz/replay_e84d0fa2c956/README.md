# Replay package — entry e84d0fa2c956

Conjecture: Minimal Rank of Geometric Loci vs Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 02:06 UTC.
Pre-registration hash committed before this test ran: `82f46e4b5d06c70f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
