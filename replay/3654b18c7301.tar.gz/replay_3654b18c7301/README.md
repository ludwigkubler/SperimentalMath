# Replay package — entry 3654b18c7301

Conjecture: SOS Moment Matrix Eigenvalue Threshold for ACC⁰ Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 04:03 UTC.
Pre-registration hash committed before this test ran: `051c7bad7b47eef4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
