# Replay package — entry a76313b69bc0

Conjecture: Minimal p-Adic Hodge Theory Rank Bounds SAT Clause Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 08:33 UTC.
Pre-registration hash committed before this test ran: `3607cd51e109cb18`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
