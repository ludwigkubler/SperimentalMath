# Replay package — entry 89d6411dc65f

Conjecture: Minimal Local Coherence of Matroids Bounds Davis-Putnam Refutation Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 04:12 UTC.
Pre-registration hash committed before this test ran: `24b9f35bbab11301`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
