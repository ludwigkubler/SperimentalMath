# Replay package — entry ab159b005263

Conjecture: Minimal Diophantine Complexity of Symmetric Braid Groups and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 00:16 UTC.
Pre-registration hash committed before this test ran: `adf91e92c9e9c57d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
