# Replay package — entry da476af6b27a

Conjecture: Subword Complexity of Lifted Rows Lower-Bounds Real Rank for IND_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 19:01 UTC.
Pre-registration hash committed before this test ran: `91d595f7f1f9c7b8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
