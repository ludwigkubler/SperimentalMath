# Replay package — entry bb6c081cf697

Conjecture: Minimal Order of Cuspidal Subgroups and Resolution Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 04:22 UTC.
Pre-registration hash committed before this test ran: `5e1125218184889f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
