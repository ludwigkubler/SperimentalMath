# Replay package — entry 4083661b959f

Conjecture: Minimal Rank of Noncommutative Crossed Products over Tree-like Resolution Trees Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 01:10 UTC.
Pre-registration hash committed before this test ran: `55c3e423b0dec115`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
