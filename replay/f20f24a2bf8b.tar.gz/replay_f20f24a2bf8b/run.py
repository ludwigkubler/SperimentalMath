import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_xor_function(n):
        return [random.choice([0, 1]) for _ in range(2**n)]
    
    def support_size(g, f):
        return sum(1 for x in range(len(f)) if g(x) == 1 and f[x] == 1)
    
    def quadratic_form_complexity(g):
        # Placeholder for actual computation
        return len(g)
    
    def circuit_complexity(f):
        # Placeholder for actual computation
        return len(f)
    
    n = random.choice([5, 10, 15, 20, 30, 40])
    f = generate_xor_function(n)
    g = lambda x: sum(x[i] * i for i in range(n)) % 2
    
    q_f = quadratic_form_complexity(g)
    C_f = circuit_complexity(f)
    
    if q_f == 0:
        return {
            "metric_name": "q(f)",
            "metric_value": q_f,
            "instances_tested": 1,
            "n_max": n,
            "conjecture_holds": False,
            "counterexample": "mapping_undefined"
        }
    
    O_qf = math.log2(q_f)
    Omega_qf_squared = q_f ** 2
    
    if O_qf > C_f or C_f < Omega_qf_squared:
        return {
            "metric_name": "q(f)",
            "metric_value": q_f,
            "instances_tested": 1,
            "n_max": n,
            "conjecture_holds": False,
            "counterexample": f"O(q(f)) > C(f) or C(f) < Ω(q(f)^2)"
        }
    
    if support_size(g, f) < n / 2:
        return {
            "metric_name": "q(f)",
            "metric_value": q_f,
            "instances_tested": 1,
            "n_max": n,
            "conjecture_holds": False,
            "counterexample": f"support_size(g) < n/2"
        }
    
    return {
        "metric_name": "q(f)",
        "metric_value": q_f,
        "instances_tested": 1,
        "n_max": n,
        "conjecture_holds": True,
        "counterexample": ""
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    results = []
    
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE reason=insufficient_support_fraction")