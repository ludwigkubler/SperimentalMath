# Replay package — entry 3d93cdba3971

Conjecture: Symmetric Square Irreducible Component Count Gap in Permanent vs Determinant Polynomials

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-13 11:20 UTC.
Pre-registration hash committed before this test ran: `a569d66117ee7459`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
