# Replay package — entry 4f20cd3e07b3

Conjecture: Minimal Order of Quandle Operations and Resolution Proof Width Relation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 18:34 UTC.
Pre-registration hash committed before this test ran: `9f5dfd3e4f8118c5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
