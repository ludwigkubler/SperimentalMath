# Replay package — entry 807f8a158fa7

Conjecture: Plethysm Multiplicity Exponential Gap in Monotone Permanent vs Determinant

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 23:33 UTC.
Pre-registration hash committed before this test ran: `c1b5518c96f32a00`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
