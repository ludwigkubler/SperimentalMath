# Replay package — entry 226cd77ad310

Conjecture: Non-Abelian Fourier Coefficient Boundedness in Tseitin Resolution Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-07 20:58 UTC.
Pre-registration hash committed before this test ran: `efee514c32001682`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
