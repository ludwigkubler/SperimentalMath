# Replay package — entry 75f0568b00e8

Conjecture: Minimal Local Cross Section Rank Bounds Resolution Proof Width for Random k-CNF under Non-Commutative Geometry

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 07:14 UTC.
Pre-registration hash committed before this test ran: `6460afaf4cd2ac58`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
