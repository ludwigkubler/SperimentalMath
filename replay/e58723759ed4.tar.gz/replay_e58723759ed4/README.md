# Replay package — entry e58723759ed4

Conjecture: Symmetric Group Fourier Coefficient Sum Exponential Gap Between Permanent and Determinant

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 12:27 UTC.
Pre-registration hash committed before this test ran: `25a62a68592e5fa0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
