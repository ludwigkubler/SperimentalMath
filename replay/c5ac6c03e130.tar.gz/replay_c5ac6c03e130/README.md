# Replay package — entry c5ac6c03e130

Conjecture: Minimal Rank of Schur-Weyl Duality Representation over Boolean Lattices vs Permutation Circuit Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 11:28 UTC.
Pre-registration hash committed before this test ran: `1b64086d57563c99`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
