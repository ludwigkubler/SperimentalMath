# Replay package — entry d98f11e514f7

Conjecture: Minimal Rank of Hodge Integrals over Boolean Functions vs Sum-of-Squares Approximation Degree

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 11:35 UTC.
Pre-registration hash committed before this test ran: `f5c17a3830eb007b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
