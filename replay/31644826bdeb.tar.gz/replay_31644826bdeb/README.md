# Replay package — entry 31644826bdeb

Conjecture: Minimal Rank of Hodge Decomposition Loci vs Resolution Proof Size for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 23:25 UTC.
Pre-registration hash committed before this test ran: `37b6322ac442e4d7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
