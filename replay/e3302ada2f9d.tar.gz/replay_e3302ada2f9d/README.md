# Replay package — entry e3302ada2f9d

Conjecture: Polymatroid Rank Gap in Monotone DNF Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-07 20:16 UTC.
Pre-registration hash committed before this test ran: `e1dbe98c6d03f637`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
