# Replay package — entry 0e00dc9ac245

Conjecture: Minimal Local Cohomology Rank of Geometric Langlands Lattices Bounds XOR-AND Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 17:54 UTC.
Pre-registration hash committed before this test ran: `65c1929d29e3f168`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
