# Replay package — entry cefe1013b737

Conjecture: Additive Energy Threshold and ACC⁰ Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 18:20 UTC.
Pre-registration hash committed before this test ran: `f26d42997fb5e326`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
