# Replay package — entry 834e913154a8

Conjecture: Polymatroid Rank Lower Bound for Monotone CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 07:36 UTC.
Pre-registration hash committed before this test ran: `2638711d55bdb73a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
