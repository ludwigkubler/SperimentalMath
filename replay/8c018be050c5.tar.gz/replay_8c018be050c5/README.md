# Replay package — entry 8c018be050c5

Conjecture: Submodular Matroid Rank Defect for Monotone CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-29 05:58 UTC.
Pre-registration hash committed before this test ran: `8170f234ebee5fab`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
