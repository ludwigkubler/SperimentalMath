# Replay package — entry 0fac4d1cec89

Conjecture: Minimal Order of Quasi-crystalline Sheaves and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 00:19 UTC.
Pre-registration hash committed before this test ran: `fea37edc5b7298bb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
