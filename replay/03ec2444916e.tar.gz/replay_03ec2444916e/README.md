# Replay package — entry 03ec2444916e

Conjecture: Tropicalized Belyi Functions and Resolution Proof Depth for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 03:58 UTC.
Pre-registration hash committed before this test ran: `b96faff226754019`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
