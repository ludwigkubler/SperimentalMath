# Replay package — entry 618e9867e153

Conjecture: Halász L^2 Spectrum Discrepancy Lower-Bounds Sign-Matrix Rigidity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 08:28 UTC.
Pre-registration hash committed before this test ran: `bcbc3db087fc8527`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
