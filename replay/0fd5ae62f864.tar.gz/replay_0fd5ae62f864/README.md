# Replay package — entry 0fd5ae62f864

Conjecture: Tropical Geometry of Boolean Functions and AC0 Parity Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 01:24 UTC.
Pre-registration hash committed before this test ran: `4459c51d7c5eb3c0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
