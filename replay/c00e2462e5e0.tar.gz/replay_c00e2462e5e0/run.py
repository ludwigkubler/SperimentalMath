import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_random_function(n):
        return [random.choice([0, 1]) for _ in range(2**n)]
    
    def communication_complexity(f):
        n = int(math.log2(len(f)))
        max_comm = 0
        for i in range(2**n):
            for j in range(i+1, 2**n):
                if f[i] != f[j]:
                    comm = bin(i ^ j).count('1')
                    if comm > max_comm:
                        max_comm = comm
        return max_comm
    
    def tropical_hermitian_form(f):
        n = int(math.log2(len(f)))
        H = [[0 for _ in range(n)] for _ in range(n)]
        for i in range(2**n):
            for j in range(i+1, 2**n):
                if f[i] != f[j]:
                    comm = bin(i ^ j).count('1')
                    H[comm][i % n] += 1
                    H[comm][j % n] += 1
        return H
    
    def min_rank(H):
        n = len(H)
        rank = 0
        for i in range(n):
            if any(H[j][i] != 0 for j in range(rank, n)):
                rank += 1
                for j in range(n):
                    if H[j][i]:
                        for k in range(n):
                            H[j][k] -= H[i][k]
        return rank
    
    n_values = [5, 10, 15, 20, 30, 40]
    total_rank = 0
    instances_tested = 0
    
    for n in n_values:
        f = generate_random_function(n)
        comm = communication_complexity(f)
        if comm > n**(1/4):
            H = tropical_hermitian_form(f)
            rank = min_rank(H)
            total_rank += rank
            instances_tested += 1
    
    mean_rank = total_rank / instances_tested if instances_tested > 0 else 0
    conjecture_holds = mean_rank >= math.sqrt(n_values[-1])
    
    return {
        "metric_name": "min_rank",
        "metric_value": mean_rank,
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": "" if conjecture_holds else f"mean_rank={mean_rank} < sqrt({n_values[-1]})"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_rank = sum(r["metric_value"] for r in results) / len(results)
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_rank} std=0.0 support_fraction=1.0")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_rank} std={math.sqrt(sum((r['metric_value'] - mean_rank)**2 for r in results) / len(results)):.2f} support_fraction={support_fraction:.2f}")
    else:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"mean_rank<{mean_rank} < sqrt({n_values[-1]})\" first_failing_seed={first_failing_seed}")