import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_k_cnf(n, k):
        clauses = []
        for _ in range(k * n):
            clause = [random.randint(1, n), -random.randint(1, n)]
            if len(set(clause)) == 2:
                clauses.append(clause)
        return clauses
    
    def resolution_width(clauses):
        queue = set()
        unit_clauses = {i: [] for i in range(1, n + 1)}
        
        for clause in clauses:
            if len(clause) == 1:
                unit_clauses[abs(clause[0])].append(clause)
                queue.add(clause)
        
        width = 0
        while queue:
            new_queue = set()
            for clause in queue:
                p, q = abs(clause[0]), abs(clause[1])
                if p > q:
                    p, q = q, p
                
                if -p in unit_clauses[q]:
                    continue
                
                new_clause = [-q]
                if len(new_clause) == 1:
                    return float('inf')
                
                width = max(width, len(new_clause))
                for cl in clauses:
                    if set(cl).issubset(set(new_clause)):
                        continue
                    if -p in cl and q not in cl:
                        new_queue.add(tuple(sorted([x for x in cl if x != p]))
            queue = new_queue
        
        return width
    
    def hodge_order(n):
        return math.log2(n) ** 2
    
    n = random.randint(5, 40)
    k = random.randint(1, min(n // 2, 3))
    clauses = generate_k_cnf(n, k)
    
    w = resolution_width(clauses)
    if w == float('inf'):
        return {
            "metric_name": "resolution_width",
            "metric_value": float('inf'),
            "instances_tested": 1,
            "n_max": n,
            "conjecture_holds": False,
            "counterexample": "resolution_width_infinite"
        }
    
    h = hodge_order(n)
    if w <= h:
        return {
            "metric_name": "resolution_width",
            "metric_value": w,
            "instances_tested": 1,
            "n_max": n,
            "conjecture_holds": True,
            "counterexample": ""
        }
    
    return {
        "metric_name": "resolution_width",
        "metric_value": w,
        "instances_tested": 1,
        "n_max": n,
        "conjecture_holds": False,
        "counterexample": f"resolution_width_exceeds_hodge_order (w={w}, h={h})"
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        counterexample = next(r["counterexample"] for r in results if r["counterexample"])
        print(f"RESULT: FALSIFIED counterexample=\"{counterexample}\" first_failing_seed={first_failing_seed}")