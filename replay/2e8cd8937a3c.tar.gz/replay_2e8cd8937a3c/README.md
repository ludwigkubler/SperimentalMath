# Replay package — entry 2e8cd8937a3c

Conjecture: Plethysm Multiplicity Inverse Proportional to Monotone Circuit Size for Permanent

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 16:08 UTC.
Pre-registration hash committed before this test ran: `816f1c2f23c4954f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
