# Replay package — entry c87e07b4e9c9

Conjecture: Minimal Rank of Algebraic K-Theory Groups over Boolean Rings vs Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 00:37 UTC.
Pre-registration hash committed before this test ran: `0a7951c6a26e75e3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
