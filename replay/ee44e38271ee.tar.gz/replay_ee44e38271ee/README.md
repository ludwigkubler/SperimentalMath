# Replay package — entry ee44e38271ee

Conjecture: Fourier Variance Ratio of Violated-Clause Counter Bounds Tree-Resolution Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 16:59 UTC.
Pre-registration hash committed before this test ran: `d1365230ea4c7b2a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
