# Replay package — entry 7fd54f81c03b

Conjecture: Minimal Rank of Quasi-Group Representations Bounds ACC⁰ Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 19:06 UTC.
Pre-registration hash committed before this test ran: `fed0165bb5eea2e5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
