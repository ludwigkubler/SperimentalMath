# Replay package — entry 0cbee9de2c0d

Conjecture: Minimal Rank of Twisted Hodge Theory Invariants vs ACC⁰ Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 22:32 UTC.
Pre-registration hash committed before this test ran: `a4964a7d788044a8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
