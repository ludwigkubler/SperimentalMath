# Replay package — entry 614f26dd51ba

Conjecture: Treewidth of Prime-Implicant Compatibility Graph Tracks DNF-MCSP

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 23:14 UTC.
Pre-registration hash committed before this test ran: `c235aaf9f2485b09`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
