# Replay package — entry dc964fc9921d

Conjecture: Minimal Frobenius Monomial Rank and Frege Proof Length Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 06:08 UTC.
Pre-registration hash committed before this test ran: `d42bbaa9d3d47f94`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
