# Replay package — entry 29af0c7a223d

Conjecture: Nisan-Wigderson Seed Length Bounded by Finite Geometry Line Count

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 17:10 UTC.
Pre-registration hash committed before this test ran: `fd07f049f968b5cb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
