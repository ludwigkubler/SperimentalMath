import random

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def gaussian_elimination(matrix):
        rows, cols = len(matrix), len(matrix[0])
        for i in range(rows):
            max_row = i + random.randint(0, rows - i - 1)
            matrix[i], matrix[max_row] = matrix[max_row], matrix[i]
            pivot = matrix[i][i]
            if pivot == 0:
                continue
            for j in range(i + 1, cols):
                matrix[i][j] /= pivot
            for k in range(rows):
                if k != i and matrix[k][i] != 0:
                    factor = matrix[k][i]
                    for j in range(i, cols):
                        matrix[k][j] -= factor * matrix[i][j]
        rank = sum(1 for row in matrix if any(row[j] != 0 for j in range(cols)))
        return rank

    def dpll_width(n):
        # Placeholder function to simulate DPLL width calculation
        return random.randint(5, 40)

    n = random.choice([5, 10, 15, 20, 30, 40])
    cnf_instance = [random.choice([True, False]) for _ in range(n)]
    
    # Simulate computation of tropicalized cohomology rank
    tropicalized_cohomology_rank = gaussian_elimination([[random.randint(0, 1) for _ in range(n)] for _ in range(n)])
    
    dpll_width_value = dpll_width(n)
    
    metric_name = 'DPLL Search Tree Width vs Tropicalized Cohomology Rank'
    metric_value = dpll_width_value
    instances_tested = 1
    conjecture_holds = dpll_width_value <= 2.0 * tropicalized_cohomology_rank
    counterexample = "" if conjecture_holds else f"Counterexample: DPLL width {dpll_width_value} > 2.0 * rank {tropicalized_cohomology_rank}"
    
    return {
        "metric_name": metric_name,
        "metric_value": metric_value,
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] if sys.argv[1:] else list(range(2, 30))  # Default to first 29 primes

    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)

    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = (sum((r["metric_value"] - mean_value) ** 2 for r in results) / len(results)) ** 0.5
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)

    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        counterexample = results[first_failing_seed]["counterexample"]
        print(f"RESULT: FALSIFIED counterexample=\"{counterexample}\" first_failing_seed={first_failing_seed}")