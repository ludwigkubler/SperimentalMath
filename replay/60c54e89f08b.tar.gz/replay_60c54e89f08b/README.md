# Replay package — entry 60c54e89f08b

Conjecture: Minimal Local Index of Tropical Pseudo-Derivatives and Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 13:31 UTC.
Pre-registration hash committed before this test ran: `a5e0a462dd742e89`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
