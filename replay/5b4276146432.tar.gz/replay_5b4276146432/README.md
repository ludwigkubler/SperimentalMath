# Replay package — entry 5b4276146432

Conjecture: Minimal Order of Brauer Characters and Frege Proof Depth Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 01:17 UTC.
Pre-registration hash committed before this test ran: `d1b71f4a22f29491`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
