# Replay package — entry 5acea8240273

Conjecture: Free Probability Tensor Product over DPLL Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 21:24 UTC.
Pre-registration hash committed before this test ran: `aed4cb78aec5a914`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
