# Replay package — entry 216401784e29

Conjecture: Minimal Number of Affine Plane Points and Frege Proof Depth Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 22:17 UTC.
Pre-registration hash committed before this test ran: `3571b4f4d58b390f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
