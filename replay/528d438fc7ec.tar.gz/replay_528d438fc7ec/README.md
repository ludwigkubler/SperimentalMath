# Replay package — entry 528d438fc7ec

Conjecture: Minimal Order of Symmetric Braid Groups and Resolution Proof Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 04:42 UTC.
Pre-registration hash committed before this test ran: `ed847eecde153560`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
