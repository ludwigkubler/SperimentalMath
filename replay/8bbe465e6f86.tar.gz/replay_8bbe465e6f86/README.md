# Replay package — entry 8bbe465e6f86

Conjecture: Quantum Entanglement Index Bounds BP Read-Twice Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 12:15 UTC.
Pre-registration hash committed before this test ran: `c0277219df22bfaa`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
