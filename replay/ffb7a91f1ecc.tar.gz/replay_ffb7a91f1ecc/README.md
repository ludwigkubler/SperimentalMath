# Replay package — entry ffb7a91f1ecc

Conjecture: Minimal Order of Quadratic Residues in Tseitin Formulas Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 08:09 UTC.
Pre-registration hash committed before this test ran: `46461bc0100bcf7e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
