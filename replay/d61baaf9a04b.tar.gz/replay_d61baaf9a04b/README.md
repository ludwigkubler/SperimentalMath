# Replay package — entry d61baaf9a04b

Conjecture: Minimal Representation Rank of Algebraic Tori and AC0 Circuit Parity Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 06:22 UTC.
Pre-registration hash committed before this test ran: `700e2b906b29b254`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
