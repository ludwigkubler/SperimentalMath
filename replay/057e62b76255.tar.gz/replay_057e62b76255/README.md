# Replay package — entry 057e62b76255

Conjecture: Minimal Hyperbolic Distance to Isometry and Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 06:34 UTC.
Pre-registration hash committed before this test ran: `6dccd8c25a65f106`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
