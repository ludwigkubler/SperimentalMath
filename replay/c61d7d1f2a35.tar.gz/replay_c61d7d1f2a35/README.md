# Replay package — entry c61d7d1f2a35

Conjecture: Automorphic L-Function Rank and Polynomial Hierarchy Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 12:38 UTC.
Pre-registration hash committed before this test ran: `ff5d363e0089feb8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
