# Replay package — entry df652a96b325

Conjecture: Minimal Symplectic Form Complexity Bounds Resolution Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 14:38 UTC.
Pre-registration hash committed before this test ran: `da97564acf7036ed`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
