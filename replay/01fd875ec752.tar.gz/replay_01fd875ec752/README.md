# Replay package — entry 01fd875ec752

Conjecture: Minimal Index of Tropical Curves over Riemann Surfaces and Read-Twice BP Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 00:08 UTC.
Pre-registration hash committed before this test ran: `b7196c68c5b1bce0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
