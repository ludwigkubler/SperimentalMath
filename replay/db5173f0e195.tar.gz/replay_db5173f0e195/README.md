# Replay package — entry db5173f0e195

Conjecture: Newton Polytope Volume and ACC^0 Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 04:01 UTC.
Pre-registration hash committed before this test ran: `6ad3418c202f1901`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
