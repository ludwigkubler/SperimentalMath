# Replay package — entry 90ca984e48fd

Conjecture: Minimal Rank of Noncommutative Crossed Products vs AC0 Circuit Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 21:07 UTC.
Pre-registration hash committed before this test ran: `1b1be234bef502dc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
