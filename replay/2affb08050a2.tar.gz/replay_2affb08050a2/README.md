# Replay package — entry 2affb08050a2

Conjecture: Minimal Number of Generators in Symmetry Groups and SAT Clause Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 13:46 UTC.
Pre-registration hash committed before this test ran: `e622faadf9f797b6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
