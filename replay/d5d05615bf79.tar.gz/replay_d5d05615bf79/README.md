# Replay package — entry d5d05615bf79

Conjecture: Fourier Coefficient Sum Submodularity for Monotone DNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 17:37 UTC.
Pre-registration hash committed before this test ran: `b1b62b949fc252e2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
