# Replay package — entry 4d29c6985de2

Conjecture: Noncommutative Fourier Coefficient Sum Inversely Proportional to ACC⁰ Circuit Size for Sipser Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 10:22 UTC.
Pre-registration hash committed before this test ran: `3e427a0a8cb955f0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
