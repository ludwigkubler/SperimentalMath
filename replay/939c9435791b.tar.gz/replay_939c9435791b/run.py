import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_ac0_circuit(n):
        # Simplified AC0 circuit for PARITY on n inputs
        return [random.choice([0, 1]) for _ in range(2**n)]
    
    def compute_tensor_representation(circuit):
        # Represent the circuit output as a tensor over the symmetric algebra of boolean functions
        n = int(math.log2(len(circuit)))
        T_f = [[0] * (2**n) for _ in range(2**n)]
        for i in range(2**n):
            for j in range(2**n):
                T_f[i][j] = circuit[(i & j) ^ ((i | j) >> 1)]
        return T_f
    
    def calculate_symmetric_tensor_norm(T_f, n):
        # Calculate the minimal symmetric tensor norm of T_f
        norm = 0
        for i in range(2**n):
            for j in range(2**n):
                norm += abs(T_f[i][j])
        return norm / (2**(2*n))
    
    def is_ac0_circuit(circuit, n):
        # Check if the circuit computes PARITY on n inputs
        for i in range(1 << n):
            input_bits = [i >> j & 1 for j in range(n)]
            output = circuit[i]
            expected_output = sum(input_bits) % 2
            if output != expected_output:
                return False
        return True
    
    n_values = [5, 10, 15, 20, 30, 40]
    total_norm = 0
    instances_tested = 0
    
    for n in n_values:
        circuit = generate_ac0_circuit(n)
        if not is_ac0_circuit(circuit, n):
            return {
                "metric_name": "symmetric_tensor_norm",
                "metric_value": None,
                "instances_tested": 0,
                "conjecture_holds": False,
                "counterexample": "not_ac0_circuit"
            }
        T_f = compute_tensor_representation(circuit)
        norm = calculate_symmetric_tensor_norm(T_f, n)
        total_norm += norm
        instances_tested += 1
    
    mean_norm = total_norm / len(n_values)
    conjecture_holds = mean_norm >= n**2 * math.log(n) for n in n_values
    counterexample = "" if conjecture_holds else "mean_norm < n^2 log n"
    
    return {
        "metric_name": "symmetric_tensor_norm",
        "metric_value": mean_norm,
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] if sys.argv[1:] else list(range(2, 50, 2))
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_norm = sum(r["metric_value"] for r in results if r["metric_value"] is not None) / len(results)
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_norm} std=0.0 support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_norm} std=0.0 support_fraction={support_fraction}")
    else:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"mean_norm < n^2 log n\" first_failing_seed={first_failing_seed}")