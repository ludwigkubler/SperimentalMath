# Replay package — entry 5da693247185

Conjecture: Poset Dimension and Karchmer-Wigderson Communication Complexity for Random CNFs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 10:53 UTC.
Pre-registration hash committed before this test ran: `09a364f3d297fd7e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
