# Replay package — entry 436a24e51464

Conjecture: Minimal Index of Poincaré Duality Bounds Circuit Complexity of XOR Circuits

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 15:35 UTC.
Pre-registration hash committed before this test ran: `6eb4671ad551aba3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
