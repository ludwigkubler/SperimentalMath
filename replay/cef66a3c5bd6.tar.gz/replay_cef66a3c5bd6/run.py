import random
import math
from fractions import Fraction

def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

def lcm(a, b):
    return abs(a*b) // gcd(a, b)

def extended_gcd(a, b):
    if a == 0:
        return b, 0, 1
    else:
        g, x, y = extended_gcd(b % a, a)
        return g, y - (b // a) * x, x

def mod_inverse(a, m):
    g, x, _ = extended_gcd(a, m)
    if g != 1:
        raise ValueError("Modular inverse does not exist")
    else:
        return x % m

def matrix_mod_inv(matrix, mod):
    n = len(matrix)
    det = 0
    for i in range(n):
        det += matrix[0][i] * matrix_minor(matrix, 0, i) * (-1)**(0 + i)
    det = det % mod
    inv_det = mod_inverse(det, mod)
    adjugate = [[matrix_minor(matrix, j, i) * (-1)**(j + i) for i in range(n)] for j in range(n)]
    inverse = [[(adjugate[i][j] * inv_det) % mod for j in range(n)] for i in range(n)]
    return inverse

def matrix_minor(matrix, row, col):
    minor = [row[:col] + row[col+1:] for row in matrix[1:]]
    return determinant(minor)

def determinant(matrix):
    if len(matrix) == 1:
        return matrix[0][0]
    det = 0
    for i in range(len(matrix)):
        det += (-1)**i * matrix[0][i] * determinant([row[:i] + row[i+1:] for row in matrix[1:]])
    return det

def gaussian_elimination(A, b):
    n = len(b)
    A_b = [A[i] + [b[i]] for i in range(n)]
    for i in range(n):
        max_row = i
        for j in range(i+1, n):
            if abs(A_b[j][i]) > abs(A_b[max_row][i]):
                max_row = j
        A_b[i], A_b[max_row] = A_b[max_row], A_b[i]
        pivot = A_b[i][i]
        for j in range(n):
            A_b[i][j] /= pivot
        b[i] /= pivot
        for j in range(i+1, n):
            factor = A_b[j][i]
            for k in range(n):
                A_b[j][k] -= factor * A_b[i][k]
            b[j] -= factor * b[i]
    x = [0]*n
    for i in range(n-1, -1, -1):
        x[i] = b[i]
        for j in range(i+1, n):
            x[i] -= A_b[i][j] * x[j]
    return x

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n = random.randint(5, 40)
    # Generate a random satisfiability instance φ
    phi = [[random.choice([0, 1]) for _ in range(n)] for _ in range(n)]
    
    # Derive the system of equations and solve for its hypergeometric function solutions
    A = []
    b = []
    for i in range(n):
        row = [phi[i][j] for j in range(n) if phi[j][i] == 1]
        A.append(row)
        b.append(sum(phi[i]))
    
    # Solve the system of equations using Gaussian elimination
    solutions = gaussian_elimination(A, b)
    
    # Enumerate the resolution proof trees for φ using a standard algorithm like DPLL or its variants
    def dpll(clauses, assignment):
        if not clauses:
            return True
        unit_clause = next((c for c in clauses if len(c) == 1), None)
        if unit_clause:
            literal = unit_clause[0]
            new_assignment = assignment.copy()
            new_assignment[literal] = True
            if dpll([c for c in clauses if literal not in c and -literal not in c], new_assignment):
                return True
            new_assignment[literal] = False
            if dpll([c for c in clauses if literal not in c and -literal not in c], new_assignment):
                return True
            else:
                return False
        pure_literal = next((l for l in range(1, n+1) if all(l not in c or -l in c for c in clauses)), None)
        if pure_literal is not None:
            new_assignment[pure_literal] = True
            if dpll([c for c in clauses if pure_literal not in c and -pure_literal not in c], new_assignment):
                return True
            else:
                return False
        literal = next((l for l in range(1, n+1) if l not in assignment), None)
        new_assignment[literal] = True
        if dpll([c for c in clauses if literal not in c and -literal not in c], new_assignment):
            return True
        else:
            new_assignment[literal] = False
            if dpll([c for c in clauses if literal not in c and -literal not in c], new_assignment):
                return True
            else:
                return False
    
    resolution_trees = []
    def generate_resolution_tree(clauses, assignment):
        if not clauses:
            resolution_trees.append(assignment.copy())
            return
        unit_clause = next((c for c in clauses if len(c) == 1), None)
        if unit_clause:
            literal = unit_clause[0]
            new_assignment = assignment.copy()
            new_assignment[literal] = True
            generate_resolution_tree([c for c in clauses if literal not in c and -literal not in c], new_assignment)
            new_assignment[literal] = False
            generate_resolution_tree([c for c in clauses if literal not in c and -literal not in c], new_assignment)
        pure_literal = next((l for l in range(1, n+1) if all(l not in c or -l in c for c in clauses)), None)
        if pure_literal is not None:
            new_assignment[pure_literal] = True
            generate_resolution_tree([c for c in clauses if pure_literal not in c and -pure_literal not in c], new_assignment)
            else:
                return False
        literal = next((l for l in range(1, n+1) if l not in assignment), None)
        new_assignment[literal] = True
        generate_resolution_tree([c for c in clauses if literal not in c and -literal not in c], new_assignment)
        else:
            new_assignment[literal] = False
            generate_resolution_tree([c for c in clauses if literal not in c and -literal not in c], new_assignment)
    
    generate_resolution_tree(phi, {})
    
    # Compute the ratio |{solutions} - 1| / (number of resolution proof trees)^order(CoxeterGroup(φ))
    num_solutions = len(solutions)
    num_trees = len(resolution_trees)
    order_coxeter_group = n  # Simplified for demonstration
    ratio = abs(num_solutions - 1) / (num_trees ** order_coxeter_group)
    
    return {
        "metric_name": "Ratio",
        "metric_value": ratio,
        "instances_tested": 1,
        "n_max": n,
        "conjecture_holds": ratio <= 1.1 and ratio >= 0.9,
        "counterexample": "" if ratio <= 1.1 and ratio >= 0.9 else "Ratio out of bounds"
    }

if __name__ == "__main__":
    seeds = [int(arg) for arg in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_ratio = sum(r["metric_value"] for r in results) / len(results)
    std_ratio = math.sqrt(sum((r["metric_value"] - mean_ratio)**2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_ratio} std={std_ratio} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_ratio} std={std_ratio} support_fraction={support_fraction}")
    else:
        first_failing_seed = next((r["seed"] for r in results if not r["conjecture_holds"]), None)
        counterexample = results[first_failing_seed]["counterexample"]
        print(f"RESULT: FALSIFIED counterexample=\"{counterexample}\" first_failing_seed={first_failing_seed}")