# Replay package — entry 33f8ea7c6adc

Conjecture: Minimal Rank of Quasigroup Representations vs Tseitin Formula Resolution Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 11:18 UTC.
Pre-registration hash committed before this test ran: `9be8f4300eb79908`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
