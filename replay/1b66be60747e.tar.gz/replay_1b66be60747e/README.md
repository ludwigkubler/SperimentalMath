# Replay package — entry 1b66be60747e

Conjecture: Minimal Rank of Tropicalized K-theory over Resolution Proof Trees

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 13:58 UTC.
Pre-registration hash committed before this test ran: `cfece74137d850ae`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
