import random
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_cnf(n):
        cnf = []
        for _ in range(10):  # Generate 10 clauses with n variables each
            clause = [random.randint(-n, -1), random.randint(1, n)]
            cnf.append(clause)
        return cnf
    
    def dpll(cnf, assignment={}):
        if not cnf:
            return True, assignment
        unit_clause = next((c for c in cnf if len(c) == 1), None)
        if unit_clause:
            var = abs(unit_clause[0])
            polarity = unit_clause[0] > 0
            if var in assignment and assignment[var] != polarity:
                return False, {}
            assignment[var] = polarity
            cnf = [c for c in cnf if var not in c]
            for i, clause in enumerate(cnf):
                if -var in clause:
                    cnf[i].remove(-var)
        else:
            var = next(var for var in range(1, n+1) if var not in assignment)
            polarity = True
            new_assignment = assignment.copy()
            new_assignment[var] = polarity
            result, _ = dpll(cnf, new_assignment)
            if result:
                return True, new_assignment
            else:
                del new_assignment[var]
                polarity = False
                new_assignment[var] = polarity
                result, _ = dpll(cnf, new_assignment)
                if result:
                    return True, new_assignment
        return False, {}
    
    def hensel_lifting(cnf):
        p = 2
        while True:
            assignment = {var: random.choice([True, False]) for var in range(1, len(cnf[0])+1)}
            if dpll(cnf, assignment)[0]:
                return p
            p += 1
    
    n = 5 + (seed % 4) * 5  # Sweep n through {5, 10, 15, 20, 30, 40}
    cnf = generate_cnf(n)
    
    try:
        hensel_steps = hensel_lifting(cnf)
    except RecursionError:
        return {
            "metric_name": "Hensel Steps",
            "metric_value": None,
            "instances_tested": 1,
            "n_max": n,
            "conjecture_holds": False,
            "counterexample": "Recursion depth exceeded"
        }
    
    proof_length = len(cnf) * 2  # Simplified estimate for DPLL proof length
    
    return {
        "metric_name": "Hensel Steps",
        "metric_value": hensel_steps,
        "instances_tested": 1,
        "n_max": n,
        "conjecture_holds": hensel_steps == proof_length,
        "counterexample": ""
    }

if __name__ == "__main__":
    import sys
    seeds = [int(x) for x in sys.argv[1:]] or [2**i + 3 for i in range(5, 8)]  # Default to first 30 primes if no seeds provided
    
    results = []
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    metric_values = [r["metric_value"] for r in results if r["metric_value"] is not None]
    support_fraction = sum(r["conjecture_holds"] for r in results) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={sum(metric_values)/len(metric_values)} std=0.0 support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results) and support_fraction >= 0.8:
        counterexample = next(r for r in results if not r["conjecture_holds"])["counterexample"]
        print(f"RESULT: FALSIFIED counterexample=\"{counterexample}\" first_failing_seed={next(seed for seed, result in enumerate(results) if not result['conjecture_holds']))}")
    else:
        print("RESULT: INCONCLUSIVE insufficient support")