# Replay package — entry d072127cd9dc

Conjecture: Minimal Rank of Quaternionic Form Representations Bounds AC⁰ Parity Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 10:19 UTC.
Pre-registration hash committed before this test ran: `6c51d7882ad1c144`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
