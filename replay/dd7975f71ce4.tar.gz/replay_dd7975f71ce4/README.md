# Replay package — entry dd7975f71ce4

Conjecture: Minimal L^p Norm of Affine Line Arrangements Bounds Resolution Proof Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 01:35 UTC.
Pre-registration hash committed before this test ran: `5b8ee49471a9016a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
