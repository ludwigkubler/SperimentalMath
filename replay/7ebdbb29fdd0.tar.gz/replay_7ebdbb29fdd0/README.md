# Replay package — entry 7ebdbb29fdd0

Conjecture: Minimal Number of Hairy Ball Theorems for Circuit Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 22:35 UTC.
Pre-registration hash committed before this test ran: `a2f6d6eae805c5bc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
