import random
import math

def run_trial(seed: int) -> dict:
    n = random.choice([10, 15, 20, 30, 40])
    M = [[random.randint(0, 1) for _ in range(n)] for _ in range(n)]
    
    # Compute free entropy ϕ(M)
    def r_transform(M):
        n = len(M)
        det = 1
        for i in range(n):
            det *= (M[i][i] + 1j * sum(M[j][i] for j in range(i+1, n)))
        return math.log(abs(det))
    
    ϕ_M = r_transform(M) / (2 * math.pi)
    
    # Check the conjecture
    c = 0.1
    if ϕ_M < c * n:
        return {
            "metric_name": "free_entropy",
            "metric_value": ϕ_M,
            "instances_tested": 1,
            "conjecture_holds": False,
            "counterexample": f"ϕ(M) / n = {ϕ_M / n} < {c}"
        }
    else:
        return {
            "metric_name": "free_entropy",
            "metric_value": ϕ_M,
            "instances_tested": 1,
            "conjecture_holds": True,
            "counterexample": ""
        }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2**i - 1 for i in range(5, 8)]
    
    results = []
    for seed in seeds:
        random.seed(seed)
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value)**2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"ϕ(M) / n < 0.1\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE mapping_undefined")