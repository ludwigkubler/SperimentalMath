# Replay package — entry 1ea2045ec8f6

Conjecture: Real Variety Connected Components Lower Bound SOS Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-13 00:30 UTC.
Pre-registration hash committed before this test ran: `1b6fefd7f640a393`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
