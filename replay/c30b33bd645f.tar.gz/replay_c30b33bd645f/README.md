# Replay package — entry c30b33bd645f

Conjecture: Minimal Rank of Algebraic K-Theory over Quantum Query Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 14:36 UTC.
Pre-registration hash committed before this test ran: `01facb81cadb19ea`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
