# Replay package — entry ece004bc4f32

Conjecture: EF Refutation Size vs. Clause-Indicator Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-30 04:40 UTC.
Pre-registration hash committed before this test ran: `5051cb6a1f401036`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
