# Replay package — entry c3a93f0dc63d

Conjecture: Minimal Order of Quaternionic Kähler Manifolds and Circuit Monotone Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 08:35 UTC.
Pre-registration hash committed before this test ran: `9703811499eb404c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
