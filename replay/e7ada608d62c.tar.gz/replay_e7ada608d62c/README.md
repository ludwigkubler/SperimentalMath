# Replay package — entry e7ada608d62c

Conjecture: Minimal Symmetric Tensor Rank Correlation with DPLL Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 23:30 UTC.
Pre-registration hash committed before this test ran: `14ee724bd0968b22`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
