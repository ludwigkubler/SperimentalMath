# Replay package — entry cb842205136a

Conjecture: Noncommutative Algebra Generator Count Bounds Circuit Depth

Verdict (original run): FALSIFIED

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-24 06:29 UTC.
Pre-registration hash committed before this test ran: `?`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
