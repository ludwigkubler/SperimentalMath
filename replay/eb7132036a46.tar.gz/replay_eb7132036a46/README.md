# Replay package — entry eb7132036a46

Conjecture: Minimal Rank of Algebraic Stacks over Monomial Ideals vs BP_ReadTwice Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 21:16 UTC.
Pre-registration hash committed before this test ran: `8b5375c9416adf73`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
