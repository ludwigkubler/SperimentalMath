# Replay package — entry d1547ff94fe1

Conjecture: Minimal Rank of Quadratic Forms Bounds Monomial Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 21:15 UTC.
Pre-registration hash committed before this test ran: `d6bacd19ee4742ae`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
