# Replay package — entry 17eff984c798

Conjecture: Minimal Local Ring Unit Group Size and Frege Proof Depth Correlation via Tropicalization

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 22:44 UTC.
Pre-registration hash committed before this test ran: `d5a730b5d9c5e92c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
