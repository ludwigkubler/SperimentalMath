# Replay package — entry 6bc88662420d

Conjecture: Betti Numbers and Resolution Width in 3-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 07:04 UTC.
Pre-registration hash committed before this test ran: `564244dc235496c7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
