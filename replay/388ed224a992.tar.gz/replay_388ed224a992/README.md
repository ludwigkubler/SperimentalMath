# Replay package — entry 388ed224a992

Conjecture: Schur-Polynomial Positivity Defect Lower-Bounds Tree-Frege Lines for PHP

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 17:55 UTC.
Pre-registration hash committed before this test ran: `b4693431df0d119e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
