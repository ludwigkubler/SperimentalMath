# Replay package — entry dfc077cb4c36

Conjecture: F_2-Corank of Minterm Incidence Bounds Monotone Formula Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 15:55 UTC.
Pre-registration hash committed before this test ran: `d18d1e1574f57898`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
