# Replay package — entry 14a4d3884f9a

Conjecture: Real Rank of SOS Moment Matrix Bounds Max-CUT Refutation Degree

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 10:36 UTC.
Pre-registration hash committed before this test ran: `60a148bdf83dae12`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
