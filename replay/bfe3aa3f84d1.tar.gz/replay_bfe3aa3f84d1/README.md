# Replay package — entry bfe3aa3f84d1

Conjecture: Matroid Rank Gap in Monotone DNF Depth for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 11:42 UTC.
Pre-registration hash committed before this test ran: `77beb4cb1c8a0053`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
