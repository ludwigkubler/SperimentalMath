# Replay package — entry 1c40896be81a

Conjecture: Minimal Order of Theta Functions over Elliptic Curves vs Sum-of-Squares Hierarchy Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 14:15 UTC.
Pre-registration hash committed before this test ran: `669749a50f183c24`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
