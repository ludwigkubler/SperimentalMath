# Replay package — entry 6010af3a708c

Conjecture: FCA Antichain Width of Implicant Lattice Caps DNF-MCSP Within Factor 2n

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 22:41 UTC.
Pre-registration hash committed before this test ran: `80e4dd022e373c4d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
