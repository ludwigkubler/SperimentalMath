import random
import math

def factorial(n):
    if n == 0:
        return 1
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result

def hook_length_formula(row):
    n = len(row)
    numerator = factorial(factorial(n))
    denominator = 1
    for cell in range(len(row)):
        row_length = row[cell]
        col_length = sum(1 for r in row if r > cell)
        denominator *= (row_length + col_length) * (cell + 1)
    return numerator // denominator

def young_symmetrizer(shape, sign):
    n = len(shape)
    basis_size = hook_length_formula(shape)
    basis = [[0] * basis_size for _ in range(basis_size)]
    
    def fill_basis():
        index = 0
        for perm in itertools.permutations(range(n)):
            if all(perm[i] <= shape[i] for i in range(n)):
                sign_factor = 1
                for cell in range(len(shape)):
                    row_length = shape[cell]
                    col_length = sum(1 for r in shape if r > cell)
                    sign_factor *= (-1) ** (sum(1 for p in perm[:cell+1] if p > cell))
                basis[index][index] += sign_factor
                index += 1
    
    fill_basis()
    
    def multiply_matrix(A, B):
        result = [[0] * len(B[0]) for _ in range(len(A))]
        for i in range(len(A)):
            for j in range(len(B[0])):
                for k in range(len(B)):
                    result[i][j] += A[i][k] * B[k][j]
        return result
    
    def transpose_matrix(matrix):
        return [[matrix[j][i] for j in range(len(matrix))] for i in range(len(matrix[0]))]
    
    def inverse_matrix(matrix):
        n = len(matrix)
        det = 0
        if n == 1:
            return [[1 / matrix[0][0]]]
        elif n == 2:
            det = matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0]
            return [[matrix[1][1] / det, -matrix[0][1] / det],
                    [-matrix[1][0] / det, matrix[0][0] / det]]
        else:
            cofactors = []
            for i in range(n):
                minor = [row[:i] + row[i+1:] for row in matrix[1:]]
                cofactor = (-1) ** (i % 2) * determinant(minor)
                cofactors.append(cofactor)
            return transpose_matrix([cofactors[i:i+n] for i in range(0, len(cofactors), n)])
    
    def determinant(matrix):
        if len(matrix) == 1:
            return matrix[0][0]
        elif len(matrix) == 2:
            return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0]
        else:
            det = 0
            for i in range(len(matrix)):
                minor = [row[:i] + row[i+1:] for row in matrix[1:]]
                det += (-1) ** i * matrix[0][i] * determinant(minor)
            return det
    
    def apply_symmetrizer(matrix):
        result = [[0] * len(matrix[0]) for _ in range(len(matrix))]
        for i in range(basis_size):
            for j in range(basis_size):
                if basis[i][j] != 0:
                    result = add_matrices(result, multiply_matrix(multiply_matrix(inverse_matrix(basis[j]), matrix), basis[i]))
        return result
    
    def add_matrices(A, B):
        return [[A[i][j] + B[i][j] for j in range(len(B[0]))] for i in range(len(B))]
    
    return apply_symmetrizer(matrix)

def compute_fourier_coefficients(n):
    perm_basis = young_symmetrizer((n,), 1)
    det_basis = young_symmetrizer((n,), -1)
    
    def permanent(matrix):
        result = 0
        for perm in itertools.permutations(range(n)):
            sign = 1
            for i in range(n):
                sign *= matrix[i][perm[i]]
            result += sign
        return result
    
    def determinant(matrix):
        det = 0
        for perm in itertools.permutations(range(n)):
            sign = (-1) ** sum(1 for p in perm if p > perm.index(p))
            det += sign * product([matrix[i][perm[i]] for i in range(n)])
        return det
    
    def product(lst):
        result = 1
        for x in lst:
            result *= x
        return result
    
    perm_coefficients = [permanent(perm_basis)]
    det_coefficients = [determinant(det_basis)]
    
    return sum(abs(coeff) for coeff in perm_coefficients), sum(abs(coeff) for coeff in det_coefficients)

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n_values = [5, 10, 15, 20, 30, 40]
    total_perm_sum = 0
    total_det_sum = 0
    instances_tested = 0
    
    for n in n_values:
        perm_sum, det_sum = compute_fourier_coefficients(n)
        total_perm_sum += perm_sum
        total_det_sum += det_sum
        instances_tested += 1
    
    ratio = total_perm_sum / total_det_sum
    conjecture_holds = ratio > math.exp(n / 4) for n in n_values
    counterexample = "" if conjecture_holds else "mapping_undefined"
    
    return {
        "metric_name": "Fourier Coefficient Sum Ratio",
        "metric_value": ratio,
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] if sys.argv[1:] else [2**i + 3 for i in range(5, 8)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_ratio = sum(r["metric_value"] for r in results) / len(results)
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_ratio} std=0.0 support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results) and support_fraction >= 0.8:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"mapping_undefined\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE insufficient data or support_fraction < 0.8")