# Replay package — entry 46a899e5eb6b

Conjecture: Minimal Rank of Quantum Cluster States over DPLL Proof Trees

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 04:04 UTC.
Pre-registration hash committed before this test ran: `c5846c7b34fa7a35`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
