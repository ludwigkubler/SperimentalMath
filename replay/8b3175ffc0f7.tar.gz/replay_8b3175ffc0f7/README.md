# Replay package — entry 8b3175ffc0f7

Conjecture: Real Variety Connectedness Lower Bound on SOS Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 08:00 UTC.
Pre-registration hash committed before this test ran: `ac25b37c2f83d19a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
