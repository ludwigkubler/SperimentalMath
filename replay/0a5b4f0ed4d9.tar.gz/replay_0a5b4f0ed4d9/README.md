# Replay package — entry 0a5b4f0ed4d9

Conjecture: Coxeter-Diagram Automorphism Counting and SAT Clause Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 09:23 UTC.
Pre-registration hash committed before this test ran: `012c5e7c8bb37923`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
