# Replay package — entry 1c37303a4e6e

Conjecture: Spectral Gap of Kähler Forms and Tseitin Formula Proof Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 12:45 UTC.
Pre-registration hash committed before this test ran: `026841e71d6b1b96`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
