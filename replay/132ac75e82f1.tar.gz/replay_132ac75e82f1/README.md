# Replay package — entry 132ac75e82f1

Conjecture: Minimal Rank of Lie Algebras in Tseitin Formulas Bounds Cumulative Proof Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 07:34 UTC.
Pre-registration hash committed before this test ran: `ab666095599ba16a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
