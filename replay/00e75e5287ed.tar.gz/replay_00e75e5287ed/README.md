# Replay package — entry 00e75e5287ed

Conjecture: Diophantine Solution Count Bounds Resolution Length in 3-SAT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 14:32 UTC.
Pre-registration hash committed before this test ran: `57aa2a237d0b8c1d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
