# Replay package — entry 9b6defe8501b

Conjecture: Minimal Rank of Geometric Langlands Duality over XOR-AND Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 01:24 UTC.
Pre-registration hash committed before this test ran: `3047f2ebc9cdbdbf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
