# Replay package — entry 8467e1146ba4

Conjecture: Minimal Topological Entropy Bounds Resolution Proof Width for Random k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 05:06 UTC.
Pre-registration hash committed before this test ran: `2c5b6c907b73443e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
