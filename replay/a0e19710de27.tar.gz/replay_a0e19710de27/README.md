# Replay package — entry a0e19710de27

Conjecture: Coxeter Group Action on Circuit Structures

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 17:57 UTC.
Pre-registration hash committed before this test ran: `5afe3b87212392f6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
