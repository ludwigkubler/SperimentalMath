# Replay package — entry a03f0d3fc815

Conjecture: Minimal Generality of Automata over Boolean Algebras Bounds Circuit Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 18:59 UTC.
Pre-registration hash committed before this test ran: `95926542156ab7ef`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
