# Replay package — entry 4dadd596457d

Conjecture: Minimal Order of Monoidal Categorification and SAT Clause Subset Entropy Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 02:15 UTC.
Pre-registration hash committed before this test ran: `f17c4ce62a9c2e82`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
