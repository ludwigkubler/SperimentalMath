# Replay package — entry 0e5b65fdaa8d

Conjecture: Minimal Local Induction Ring Rank and Communication Complexity Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 01:47 UTC.
Pre-registration hash committed before this test ran: `0e9aa18fa5d577f6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
