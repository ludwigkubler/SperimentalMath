# Replay package — entry 2406eeeb8ee7

Conjecture: Minimal Rank of Algebraic K-Theory Groups over Tropical Semirings vs Query Complexity for Tseitin Formulae

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 01:54 UTC.
Pre-registration hash committed before this test ran: `50cfea6f952611ac`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
