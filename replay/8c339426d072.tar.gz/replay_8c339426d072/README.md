# Replay package — entry 8c339426d072

Conjecture: Minimal Rank of Algebraic Cycles in Characteristic p over Affine Schemes vs Quantifier Depth for k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 23:23 UTC.
Pre-registration hash committed before this test ran: `915ed16d20bc9129`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
