# Replay package — entry 3d27a7513285

Conjecture: Minimal Rank of Tropical K-Theory Bounds Communication Complexity of XOR-AND Games

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 18:10 UTC.
Pre-registration hash committed before this test ran: `023e659f2002e347`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
