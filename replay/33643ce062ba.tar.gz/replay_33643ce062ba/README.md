# Replay package — entry 33643ce062ba

Conjecture: Gromov-Witten Invariant and Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 04:28 UTC.
Pre-registration hash committed before this test ran: `3493557570d2e095`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
