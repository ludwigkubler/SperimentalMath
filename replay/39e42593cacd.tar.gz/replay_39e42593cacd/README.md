# Replay package — entry 39e42593cacd

Conjecture: Schur-Weyl Multiplicity Gap in Permanent Communication Matrices

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 02:29 UTC.
Pre-registration hash committed before this test ran: `e5dc7a4b8c789436`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
