# Replay package — entry 3ebfe59d6a54

Conjecture: Minimal Rank of Brauer Groups Bounds XOR Circuit Weights

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 17:56 UTC.
Pre-registration hash committed before this test ran: `7f9d8d7f1a122058`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
