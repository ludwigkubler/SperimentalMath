# Replay package — entry 182e2d5f7a37

Conjecture: Kashin L1-Flatness of Top Laplacian Eigenvector Bounds Max-Cut SoS-2 Gap

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 23:25 UTC.
Pre-registration hash committed before this test ran: `3e4bbebaef4e35ea`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
