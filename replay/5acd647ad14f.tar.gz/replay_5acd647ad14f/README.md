# Replay package — entry 5acd647ad14f

Conjecture: Minimal Ehrhart Polynomial Degree and SAT Clause Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 02:58 UTC.
Pre-registration hash committed before this test ran: `ba25214130d5f6c7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
