# Replay package — entry 4c98a57f0315

Conjecture: Minimal Diophantine Complexity Correlation with Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 13:54 UTC.
Pre-registration hash committed before this test ran: `32a25eed9fb59531`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
