import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_boolean_instance(n, m):
        variables = [f'x{i}' for i in range(n)]
        clauses = []
        for _ in range(m):
            clause = random.sample(variables, random.randint(1, n))
            if random.choice([True, False]):
                clause = [f'-{v}' if v.startswith('-') else f'-{v}' for v in clause]
            clauses.append(clause)
        return variables, clauses
    
    def homology_algorithm(variables, clauses):
        # Simplified homology algorithm to compute quotient space rank
        n = len(variables)
        M = [[0] * (n + 1) for _ in range(n + 1)]
        for clause in clauses:
            for var in clause:
                if var.startswith('-'):
                    row, col = int(var[1:]) - 1, n
                else:
                    row, col = int(var) - 1, n
                M[row][col] += 1
        rank = gaussian_elimination(M)
        return rank
    
    def gaussian_elimination(matrix):
        rows, cols = len(matrix), len(matrix[0])
        for i in range(rows):
            # Find pivot row
            max_row = i
            for r in range(i + 1, rows):
                if abs(matrix[r][i]) > abs(matrix[max_row][i]):
                    max_row = r
            matrix[i], matrix[max_row] = matrix[max_row], matrix[i]
            
            # Eliminate non-pivot elements
            pivot = matrix[i][i]
            for j in range(i + 1, cols):
                matrix[i][j] /= pivot
            matrix[i][i] = 1
            
            for r in range(rows):
                if r != i:
                    factor = matrix[r][i]
                    for j in range(i, cols):
                        matrix[r][j] -= factor * matrix[i][j]
        
        rank = sum(1 for row in matrix if any(row[j] != 0 for j in range(cols)))
        return rank
    
    def frege_proof_length(variables, clauses):
        # Simplified Frege proof length calculation
        return len(clauses) + len(variables)
    
    n_values = [5, 10, 15, 20, 30, 40]
    results = []
    for n in n_values:
        m = random.randint(1, n * (n - 1) // 2)
        variables, clauses = generate_boolean_instance(n, m)
        min_rank_Q = homology_algorithm(variables, clauses)
        proof_length = frege_proof_length(variables, clauses)
        results.append((min_rank_Q, proof_length))
    
    if not results:
        return {
            "metric_name": "min_rank(Q)",
            "metric_value": 0,
            "instances_tested": 0,
            "n_max": 0,
            "conjecture_holds": False,
            "counterexample": "mapping_undefined"
        }
    
    min_rank_Q_values = [r[0] for r in results]
    proof_length_values = [r[1] for r in results]
    
    mean_min_rank_Q = sum(min_rank_Q_values) / len(min_rank_Q_values)
    mean_proof_length = sum(proof_length_values) / len(proof_length_values)
    std_deviation = math.sqrt(sum((x - mean_min_rank_Q) ** 2 for x in min_rank_Q_values) / len(min_rank_Q_values))
    
    correlation_coefficient = sum((min_rank_Q_values[i] - mean_min_rank_Q) * (proof_length_values[i] - mean_proof_length) for i in range(len(min_rank_Q_values))) / (len(min_rank_Q_values) * std_deviation * math.sqrt(sum((x - mean_proof_length) ** 2 for x in proof_length_values)))
    
    return {
        "metric_name": "min_rank(Q)",
        "metric_value": correlation_coefficient,
        "instances_tested": len(results),
        "n_max": max(n_values),
        "conjecture_holds": correlation_coefficient >= 0.8 and all(p <= 50 for p in proof_length_values),
        "counterexample": "" if correlation_coefficient >= 0.8 and all(p <= 50 for p in proof_length_values) else f"Proof length > 50 steps: {max(proof_length_values)}"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] if len(sys.argv) > 1 else [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113]
    results = []
    
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {{\"seed\": {seed}, \"metric_name\": \"{trial_result['metric_name']}\", \"metric_value\": {trial_result['metric_value']}, \"instances_tested\": {trial_result['instances_tested']}, \"n_max\": {trial_result['n_max']}, \"conjecture_holds\": {trial_result['conjecture_holds']}, \"counterexample\": \"{trial_result['counterexample']}\"}}")
        results.append(trial_result)
    
    mean_metric_value = sum(r['metric_value'] for r in results) / len(results)
    std_deviation = math.sqrt(sum((r['metric_value'] - mean_metric_value) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r['conjecture_holds']) / len(results)
    
    if all(r['conjecture_holds'] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_deviation} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_deviation} support_fraction={support_fraction}")
    else:
        first_failing_seed = next((r['seed'] for r in results if not r['conjecture_holds']), None)
        print(f"RESULT: FALSIFIED counterexample=\"{results[next(i for i, r in enumerate(results) if not r['conjecture_holds'])['counterexample']}\" first_failing_seed={first_failing_seed}")