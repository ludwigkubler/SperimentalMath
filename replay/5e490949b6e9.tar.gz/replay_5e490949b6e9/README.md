# Replay package — entry 5e490949b6e9

Conjecture: Minimal Local Indeterminacy in Algebraic Topology vs. SAT Clause Set Simplicity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 02:58 UTC.
Pre-registration hash committed before this test ran: `1172d5369a9fa33b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
