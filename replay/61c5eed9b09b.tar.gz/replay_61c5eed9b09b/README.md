# Replay package — entry 61c5eed9b09b

Conjecture: KW Game Treewidth Equals Formula Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 06:44 UTC.
Pre-registration hash committed before this test ran: `c057a2b0e52a1b97`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
