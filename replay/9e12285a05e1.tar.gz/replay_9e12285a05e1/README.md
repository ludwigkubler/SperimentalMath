# Replay package — entry 9e12285a05e1

Conjecture: Talagrand L1 Influence Spread of Clause-Falsification Polynomial Lower-Bounds Tree-Resolution

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 00:46 UTC.
Pre-registration hash committed before this test ran: `bed4a5c9ba1f6b7e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
