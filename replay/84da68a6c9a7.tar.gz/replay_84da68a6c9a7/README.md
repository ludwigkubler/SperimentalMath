# Replay package — entry 84da68a6c9a7

Conjecture: Minimal Order of Hodge Decomposition and SAT Clause Subset Entropy Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 21:39 UTC.
Pre-registration hash committed before this test ran: `ce7d47355dd594a3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
