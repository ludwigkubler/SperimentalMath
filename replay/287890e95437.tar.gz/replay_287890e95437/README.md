# Replay package — entry 287890e95437

Conjecture: Minimal Hodge Diamond Invariant Bounds Tseitin Formula Proof Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 13:25 UTC.
Pre-registration hash committed before this test ran: `ee72e842007f4cd2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
