import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    n = 16
    M = [[random.randint(0, 1) for _ in range(n)] for _ in range(n)]
    
    def free_entropy(M):
        trace = sum(M[i][i] for i in range(n))
        return -trace / n
    
    chi_M = free_entropy(M)
    
    metric_name = "free_entropy"
    metric_value = chi_M
    instances_tested = 1
    conjecture_holds = chi_M >= 4 * math.sqrt(n)
    counterexample = "" if conjecture_holds else f"chi(M) < 4√n"
    
    return {
        "metric_name": metric_name,
        "metric_value": metric_value,
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    results = []
    
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(res["metric_value"] for res in results) / len(results)
    std_value = math.sqrt(sum((res["metric_value"] - mean_value) ** 2 for res in results) / len(results))
    support_fraction = sum(1 for res in results if res["conjecture_holds"]) / len(results)
    
    if all(res["conjecture_holds"] for res in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not res["conjecture_holds"] for res in results):
        first_failing_seed = next(res["seed"] for res in results if not res["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample='chi(M) < 4√n' first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE")