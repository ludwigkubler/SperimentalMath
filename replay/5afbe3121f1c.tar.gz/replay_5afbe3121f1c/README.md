# Replay package — entry 5afbe3121f1c

Conjecture: Specht Module Decomposition Exponential Gap Between Permanent and Determinant Polynomials

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 04:26 UTC.
Pre-registration hash committed before this test ran: `479486a1c154348b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
