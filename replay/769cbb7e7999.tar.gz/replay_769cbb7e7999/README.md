# Replay package — entry 769cbb7e7999

Conjecture: Minimal Rank of Quadratic Residues in Number Theory vs Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 19:45 UTC.
Pre-registration hash committed before this test ran: `4cf62a641d97a621`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
