# Replay package — entry 77f332fbbf06

Conjecture: Schur-Horn Diagonal-Spectrum Defect Bounds SOS-2 Max-Cut Gap

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 10:49 UTC.
Pre-registration hash committed before this test ran: `759c43ee0426f105`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
