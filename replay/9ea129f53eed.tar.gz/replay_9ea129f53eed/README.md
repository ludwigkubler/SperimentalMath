# Replay package — entry 9ea129f53eed

Conjecture: Mobius-Mertens Cancellation on Fourier Levels vs Total Influence

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-16 22:38 UTC.
Pre-registration hash committed before this test ran: `173074ff4c685e39`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
