import random
import math
from fractions import Fraction

def gaussian_elimination(A):
    m, n = len(A), len(A[0])
    for i in range(m):
        max_row = i
        for j in range(i + 1, m):
            if abs(A[j][i]) > abs(A[max_row][i]):
                max_row = j
        A[i], A[max_row] = A[max_row], A[i]
        for j in range(i + 1, m):
            factor = Fraction(A[j][i], A[i][i])
            for k in range(n):
                A[j][k] -= factor * A[i][k]
    return A

def rank(matrix):
    matrix = [row[:] for row in matrix]
    r = gaussian_elimination(matrix)
    return sum(1 for row in r if any(row))

def tseitin_formula(n, m):
    variables = list(range(1, n + 1))
    clauses = []
    for i in range(m):
        clause = [random.choice(variables), random.choice(variables)]
        clauses.append(clause)
    return variables, clauses

def quasi_monogenic_sequence(variables, clauses):
    n = len(variables)
    m = len(clauses)
    Q = [[0] * (n + 1) for _ in range(m + 1)]
    for i, clause in enumerate(clauses, start=1):
        for var in clause:
            Q[i][var - 1] = 1
    return Q

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    n_values = [5, 10, 15, 20, 30, 40]
    results = []
    
    for n in n_values:
        m = random.randint(1, n // 2)
        variables, clauses = tseitin_formula(n, m)
        Q = quasi_monogenic_sequence(variables, clauses)
        rank_Q = rank(Q)
        
        if m < n ** (1/3):
            if rank_Q > 1:
                return {
                    "metric_name": "rank",
                    "metric_value": rank_Q,
                    "instances_tested": 1,
                    "conjecture_holds": False,
                    "counterexample": f"n={n}, m={m}, rank(Q)={rank_Q}"
                }
        else:
            if rank_Q < math.ceil(2 * math.log2(n + m)):
                return {
                    "metric_name": "rank",
                    "metric_value": rank_Q,
                    "instances_tested": 1,
                    "conjecture_holds": False,
                    "counterexample": f"n={n}, m={m}, rank(Q)={rank_Q}"
                }
        
        results.append(rank_Q)
    
    mean = sum(results) / len(results)
    std = math.sqrt(sum((x - mean) ** 2 for x in results) / len(results))
    support_fraction = all(x >= math.ceil(2 * math.log2(n + m)) for n, m, x in zip(n_values, [random.randint(1, n // 2) for _ in range(len(n_values))], results))
    
    return {
        "metric_name": "rank",
        "metric_value": mean,
        "instances_tested": len(results),
        "conjecture_holds": support_fraction,
        "counterexample": ""
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] if sys.argv[1:] else [2**i + 3 for i in range(5, 8)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result["metric_value"])
    
    mean = sum(results) / len(results)
    std = math.sqrt(sum((x - mean) ** 2 for x in results) / len(results))
    support_fraction = all("conjecture_holds": True for result in results if result["conjecture_holds"])
    
    if support_fraction:
        print(f"RESULT: SUPPORTED mean={mean} std={std} support_fraction=1.0")
    else:
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"\" first_failing_seed={first_failing_seed}")