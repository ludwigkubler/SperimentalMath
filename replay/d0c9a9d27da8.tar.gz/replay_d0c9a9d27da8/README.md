# Replay package — entry d0c9a9d27da8

Conjecture: Minimal Number of Toric Variants in Boolean Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 00:02 UTC.
Pre-registration hash committed before this test ran: `ab5b0e46c5f58d88`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
