import random
import math
import json
from itertools import product

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    # Define candidate pairs (f, g)
    candidates = [
        (([0]*3 + [1]*3), ([0]*5 + [1]*5]),
        (([0]*4 + [1]*2), ([0]*5 + [1]*5]),
        (([0]*4 + [1]*2), ([0]*6 + [1]*6)),
        (([0]*4 + [1]*2), ([0]*5 + [1]*5))
    ]
    
    # Function to compute the KW-metric
    def kw_metric(f, g):
        n = len(f)
        n_prime = len(g)
        metric = 0
        for x in range(2**n):
            for y in range(2**n):
                if f[x] != f[y]:
                    d_f = abs(x - y)
                    d_g = abs(g[f.index(x)] - g[f.index(y)])
                    metric = max(metric, max(d_g / d_f, d_f / d_g))
        return metric
    
    # Function to compute the Roe index
    def roe_index(f, R):
        n = len(f)
        metric = kw_metric(f, f)
        count = 0
        for x in range(2**n):
            if f[x].count(1) == 1:
                count += 1
        return math.log(count) / math.log(R)
    
    # Function to compute the pullback Roe index
    def pullback_roe_index(f, g, phi, R):
        n = len(f)
        n_prime = len(g)
        metric_g = kw_metric(g, g)
        count_g = 0
        for x in range(2**n_prime):
            if g[x].count(1) == 1:
                count_g += 1
        
        count_f = 0
        for x in range(2**n):
            if f[phi(x)].count(1) == 1:
                count_f += 1
        
        return math.log(count_f) / math.log(R * metric_g)
    
    # Function to compute the empirical distortion
    def empirical_distortion(f, g, phi):
        n = len(f)
        n_prime = len(g)
        max_dist = 0
        for x in range(2**n):
            for y in range(2**n):
                if f[x] != f[y]:
                    d_f = abs(x - y)
                    d_g = abs(g[phi[f.index(x)]] - g[phi[f.index(y)]])
                    max_dist = max(max_dist, max(d_g / d_f, d_f / d_g))
        return max_dist
    
    # Function to compute the pullback Roe operator
    def pullback_roe_operator(f, g, phi, T):
        n = len(f)
        n_prime = len(g)
        R = len(T)
        pulled_back_T = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                if f[i].count(1) == 1 and f[j].count(1) == 1:
                    pulled_back_T[phi[i]][phi[j]] = T[i][j]
        return pulled_back_T
    
    # Function to compute the pullback Roe index with a Roe operator
    def pullback_roe_index_with_operator(f, g, phi, R, T):
        n = len(f)
        n_prime = len(g)
        metric_g = kw_metric(g, g)
        count_g = 0
        for x in range(2**n_prime):
            if g[x].count(1) == 1:
                count_g += 1
        
        pulled_back_T = pullback_roe_operator(f, g, phi, T)
        
        count_f = 0
        for i in range(n):
            for j in range(n):
                if f[i].count(1) == 1 and f[j].count(1) == 1:
                    count_f += pulled_back_T[i][j]
        
        return math.log(count_f) / math.log(R * metric_g)
    
    # Function to compute the empirical slack
    def empirical_slack(f, g, phi, R):
        n = len(f)
        n_prime = len(g)
        max_dist = empirical_distortion(f, g, phi)
        kappa_g = roe_index(g, R)
        kappa_f = pullback_roe_index_with_operator(f, g, phi, R, [[1]*n for _ in range(n)])
        return max_dist * kappa_g + 1 - kappa_f
    
    # Main trial logic
    results = []
    for f, g in candidates:
        n = len(f)
        n_prime = len(g)
        
        # Compute the empirical distortion
        phi = [i % n_prime for i in range(n)]
        max_dist = empirical_distortion(f, g, phi)
        
        # Compute the Roe index and pullback Roe index
        R = 2
        kappa_g = roe_index(g, R)
        kappa_f = pullback_roe_index_with_operator(f, g, phi, R, [[1]*n for _ in range(n)])
        
        # Compute the empirical slack
        slack = max_dist * kappa_g + 1 - kappa_f
        
        results.append({
            "f": f,
            "g": g,
            "phi": phi,
            "max_dist": max_dist,
            "kappa_g": kappa_g,
            "kappa_f": kappa_f,
            "slack": slack
        })
    
    # Compute the mean and standard deviation of the slack
    mean_slack = sum(result["slack"] for result in results) / len(results)
    std_slack = math.sqrt(sum((result["slack"] - mean_slack)**2 for result in results) / len(results))
    
    # Check if the conjecture holds
    conjecture_holds = all(result["slack"] >= 0 for result in results)
    
    return {
        "metric_name": "empirical_slack",
        "metric_value": mean_slack,
        "instances_tested": len(results),
        "conjecture_holds": conjecture_holds,
        "counterexample": "" if conjecture_holds else str(results[0])
    }

if __name__ == "__main__":
    seeds = [11, 23, 37, 53, 71] if len(sys.argv) == 1 else [int(seed) for seed in sys.argv[1:]]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(json.dumps({"TRIAL": {"seed": seed, **result}}))
        results.append(result)
    
    mean_slack = sum(result["metric_value"] for result in results) / len(results)
    std_slack = math.sqrt(sum((result["metric_value"] - mean_slack)**2 for result in results) / len(results))
    support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)
    
    if all(result["conjecture_holds"] for result in results):
        print(f"RESULT: SUPPORTED mean={mean_slack} std={std_slack} support_fraction={support_fraction}")
    elif sum(1 for result in results if result["slack"] >= 0) / len(results) >= 0.85:
        print(f"RESULT: SUPPORTED mean={mean_slack} std={std_slack} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(seed for seed, result in enumerate(results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{results[0]['counterexample']}\" first_failing_seed={first_failing_seed}")