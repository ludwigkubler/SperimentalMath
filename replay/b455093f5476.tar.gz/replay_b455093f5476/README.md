# Replay package — entry b455093f5476

Conjecture: Burau Trace Defect of Clause Braid Lower-Bounds Tree-Resolution Steps

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 18:27 UTC.
Pre-registration hash committed before this test ran: `c6ebba77ed512264`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
