# Replay package — entry 6add941ab13a

Conjecture: Minimal Rank of Noncommutative Probability Distributions over Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 08:53 UTC.
Pre-registration hash committed before this test ran: `1277b924e7053dc7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
