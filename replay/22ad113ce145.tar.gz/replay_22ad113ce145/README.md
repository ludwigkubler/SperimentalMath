# Replay package — entry 22ad113ce145

Conjecture: Minimal Rank of Geometric Flows vs Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 20:54 UTC.
Pre-registration hash committed before this test ran: `fb31d8d7af995f17`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
