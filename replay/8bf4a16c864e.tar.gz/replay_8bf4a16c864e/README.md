# Replay package — entry 8bf4a16c864e

Conjecture: Minimal Rank of Tropicalized Hodge Classes vs Communication Complexity for Disjointness

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 13:15 UTC.
Pre-registration hash committed before this test ran: `0123cd8ffa2d9f08`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
