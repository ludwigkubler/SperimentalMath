# Replay package — entry 551cd496fe19

Conjecture: Minimal Rank of Eichler Orders Bounds XOR-AND Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 15:31 UTC.
Pre-registration hash committed before this test ran: `6a8a71e9a6ed0d2e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
