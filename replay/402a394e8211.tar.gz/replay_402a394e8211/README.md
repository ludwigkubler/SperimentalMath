# Replay package — entry 402a394e8211

Conjecture: Minimal Hodge Index of Curves in Characteristic p Bounds Resolution Proof Size for k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 00:48 UTC.
Pre-registration hash committed before this test ran: `b2e04acfbe699565`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
