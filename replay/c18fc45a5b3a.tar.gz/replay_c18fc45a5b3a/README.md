# Replay package — entry c18fc45a5b3a

Conjecture: Bounded Mean-to-Max Ratio for Tropical Doubling Defect at β=5

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 09:57 UTC.
Pre-registration hash committed before this test ran: `46239e2cf89b7d6d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
