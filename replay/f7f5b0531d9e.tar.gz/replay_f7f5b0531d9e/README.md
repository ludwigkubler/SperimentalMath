# Replay package — entry f7f5b0531d9e

Conjecture: Spectral Radius of SOS Moment Matrix Bounds Max-CUT Approximation Ratio

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 00:46 UTC.
Pre-registration hash committed before this test ran: `0489c33372c9d0b3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
