# Replay package — entry cc84f07e5cd1

Conjecture: Minimal Rank of Noncommutative Crossed Products vs BP_ReadTwice Circuit Threshold for k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 21:36 UTC.
Pre-registration hash committed before this test ran: `e559f4723b5266c1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
