# Replay package — entry a348b8a623d9

Conjecture: Frobenius Norm of Polynomial Codes and Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 19:20 UTC.
Pre-registration hash committed before this test ran: `18842b7923b96b9a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
