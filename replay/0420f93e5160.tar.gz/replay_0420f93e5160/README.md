# Replay package — entry 0420f93e5160

Conjecture: Gromov 4-Point Hyperbolicity Gap Separates k-CLIQUE Monotone DNFs from Random

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 10:32 UTC.
Pre-registration hash committed before this test ran: `48d424369eef7b9c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
