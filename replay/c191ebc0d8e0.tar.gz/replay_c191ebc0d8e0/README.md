# Replay package — entry c191ebc0d8e0

Conjecture: K-theory and SAT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-24 11:55 UTC.
Pre-registration hash committed before this test ran: `bf7e28b68216bdf9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
