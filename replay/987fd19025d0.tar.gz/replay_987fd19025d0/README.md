# Replay package — entry 987fd19025d0

Conjecture: Minimal Rank of Hodge Diamond Invariants for Monotone Circuit Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 10:26 UTC.
Pre-registration hash committed before this test ran: `c43687b9a91e99db`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
