# Replay package — entry 50fc0919c645

Conjecture: Real Rank Lower Bound for AC⁰ Communication Matrices of PARITY

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 15:23 UTC.
Pre-registration hash committed before this test ran: `627d2dbd34736d5a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
