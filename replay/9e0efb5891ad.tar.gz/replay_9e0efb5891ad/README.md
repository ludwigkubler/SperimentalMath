# Replay package — entry 9e0efb5891ad

Conjecture: Koszul Complex Lower Bound for SAT Refutation Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 19:46 UTC.
Pre-registration hash committed before this test ran: `3bd7764b4050c3b3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
