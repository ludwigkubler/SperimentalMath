# Replay package — entry aceb7cb67219

Conjecture: Width-5 ABPs for Parity Require Depth Ω(log n)

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 06:05 UTC.
Pre-registration hash committed before this test ran: `b3834844ad60e97e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
