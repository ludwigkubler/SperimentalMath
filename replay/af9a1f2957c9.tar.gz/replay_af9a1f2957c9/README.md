# Replay package — entry af9a1f2957c9

Conjecture: Minimal Rank of Quasi-crystalline Sheaves and DPLL Proof Tree Height

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 01:26 UTC.
Pre-registration hash committed before this test ran: `2926eb090f277bef`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
