# Replay package — entry 01ef48cbdf60

Conjecture: Minimal Local Defect Complexity of Affine Quotients vs DPLL Refutation Path Length for Random k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 04:08 UTC.
Pre-registration hash committed before this test ran: `460f34a53d2b98a0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
