# Replay package — entry dd0beadbf6d6

Conjecture: Gromov 4-Point Hyperbolicity of Gate-Graph Caps ACC^0[2] Bias on MOD_3

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 21:12 UTC.
Pre-registration hash committed before this test ran: `12e810a0a0e0650d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
