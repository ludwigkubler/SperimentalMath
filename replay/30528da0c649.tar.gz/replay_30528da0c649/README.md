# Replay package — entry 30528da0c649

Conjecture: Minimal Geometric Entropy of Tropical Curves and Meta-Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 22:22 UTC.
Pre-registration hash committed before this test ran: `4c64d3cc7b70cf3e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
