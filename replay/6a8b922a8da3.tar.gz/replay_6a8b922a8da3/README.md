# Replay package — entry 6a8b922a8da3

Conjecture: Jacobi Recurrence b₂ Floor Constrains SoS-2 Max-CUT Ratio

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 01:52 UTC.
Pre-registration hash committed before this test ran: `ddd419ec3cde2f82`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
