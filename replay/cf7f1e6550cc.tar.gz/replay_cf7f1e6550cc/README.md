# Replay package — entry cf7f1e6550cc

Conjecture: Hook-Length Ratio Invariance in Symmetric Polynomial Decompositions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 06:23 UTC.
Pre-registration hash committed before this test ran: `2904ea103154885c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
