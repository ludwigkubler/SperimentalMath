# Replay package — entry 09c50eb1a365

Conjecture: Cycle-Space Cocycle Imbalance Lower-Bounds Resolution Width of Tseitin

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 03:18 UTC.
Pre-registration hash committed before this test ran: `a8f0315a35b34080`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
