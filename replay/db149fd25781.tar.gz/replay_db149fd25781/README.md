# Replay package — entry db149fd25781

Conjecture: Minimal Tensor Rank of Quantum State Representations Bounds BP Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 13:18 UTC.
Pre-registration hash committed before this test ran: `c91ea34289b05e20`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
