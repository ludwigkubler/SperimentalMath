# Replay package — entry 0c2d0f9729af

Conjecture: Hypergeometric Function Moments Bounds Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 04:47 UTC.
Pre-registration hash committed before this test ran: `63167bed1d45a6b2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
