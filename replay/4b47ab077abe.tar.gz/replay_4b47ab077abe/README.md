# Replay package — entry 4b47ab077abe

Conjecture: Schur-Weyl Multiplicity Gap in Permanent vs Determinant Tensor Powers

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 04:36 UTC.
Pre-registration hash committed before this test ran: `94a5538f865a8870`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
