# Replay package — entry 9b165d0f2a6e

Conjecture: Minimal Rank of Formal Power Series Bounds Tseitin Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 18:07 UTC.
Pre-registration hash committed before this test ran: `58f156100300a55d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
