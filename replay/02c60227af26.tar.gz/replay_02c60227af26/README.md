# Replay package — entry 02c60227af26

Conjecture: Minimal Local Cohomology Group Order and SAT Clause Depth Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 06:07 UTC.
Pre-registration hash committed before this test ran: `057e889ac9a85a4e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
