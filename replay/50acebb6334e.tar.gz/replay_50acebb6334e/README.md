# Replay package — entry 50acebb6334e

Conjecture: Minimal Tropical Hodge Structure Rank Bound for Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-09 22:29 UTC.
Pre-registration hash committed before this test ran: `ea83d63a169f5a7a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
