# Replay package — entry e8e19379c232

Conjecture: Hypercontractive Bounds on Boolean Function Entropy via Representation Theory

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 10:09 UTC.
Pre-registration hash committed before this test ran: `aacf58f00b24ec0e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
