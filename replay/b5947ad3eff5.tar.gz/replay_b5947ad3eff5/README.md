# Replay package — entry b5947ad3eff5

Conjecture: Symmetric Group Fourier Coefficient Count Inversely Proportional to ACC⁰ Circuit Size for Sipser-like Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-13 07:23 UTC.
Pre-registration hash committed before this test ran: `2fa958e40f682411`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
