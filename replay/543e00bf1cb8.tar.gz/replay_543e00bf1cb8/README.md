# Replay package — entry 543e00bf1cb8

Conjecture: Minimal Rank of Hodge Decomposition in Algebraic Geometry vs ACC⁰ Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 00:43 UTC.
Pre-registration hash committed before this test ran: `7ae7784b390820c2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
