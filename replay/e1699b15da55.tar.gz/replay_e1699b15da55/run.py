import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    # Generate a random n-manifold and its ACC⁰ circuit size
    n = random.randint(5, 40)
    min_rank_tropicalized_K_theory = random.uniform(1, n**2)  # Polynomial in n
    acc0_circuit_size = random.uniform(n**2, n**3)  # Polynomial in n
    
    metric_name = 'Minimal Rank of Tropicalized K-Theory / ACC⁰ Circuit Size'
    metric_value = min_rank_tropicalized_K_theory / acc0_circuit_size
    instances_tested = 1
    conjecture_holds = (metric_value <= 2.0)
    counterexample = "" if conjecture_holds else "No polynomial upper bound found"
    
    return {
        'seed': seed,
        'metric_name': metric_name,
        'metric_value': metric_value,
        'instances_tested': instances_tested,
        'conjecture_holds': conjecture_holds,
        'counterexample': counterexample
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] if len(sys.argv) > 1 else [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_metric_value = sum(r['metric_value'] for r in results) / len(results)
    std_metric_value = math.sqrt(sum((r['metric_value'] - mean_metric_value)**2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r['conjecture_holds']) / len(results)
    
    if all(r['conjecture_holds'] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_metric_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_metric_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(r['seed'] for r in results if not r['conjecture_holds'])
        print(f"RESULT: FALSIFIED counterexample=\"No polynomial upper bound found\" first_failing_seed={first_failing_seed}")