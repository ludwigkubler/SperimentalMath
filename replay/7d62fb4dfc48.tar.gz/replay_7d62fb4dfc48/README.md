# Replay package — entry 7d62fb4dfc48

Conjecture: Hodge Index of Matrix Factorization and Communication Complexity of Disjointness

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 15:41 UTC.
Pre-registration hash committed before this test ran: `771eb0859c810e73`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
