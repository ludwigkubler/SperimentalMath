# Replay package — entry c32bd38878d4

Conjecture: Minimal Rank of Quantum Entanglement Information over AC0 Parity Circuit Threshold

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 06:26 UTC.
Pre-registration hash committed before this test ran: `dbf2645a423534b5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
