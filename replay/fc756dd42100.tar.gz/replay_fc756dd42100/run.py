import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_max_cut_instance(n):
        edges = set()
        for i in range(n):
            for j in range(i + 1, n):
                if random.choice([True, False]):
                    edges.add((i, j))
        return edges
    
    def find_geodesic_length(edges, n):
        # Simplified version of finding the minimum number of moves
        # This is a placeholder and should be replaced with actual algorithm
        return n // 2
    
    def compute_communication_matrix_rank(edges, n):
        # Placeholder for communication matrix rank computation
        # This is a simplified version and should be replaced with actual algorithm
        return n * (n - 1) // 2
    
    n = random.randint(5, 40)
    edges = generate_max_cut_instance(n)
    
    alpha_n = find_geodesic_length(edges, n)
    k_n = compute_communication_matrix_rank(edges, n)
    
    if alpha_n == 0:
        return {
            "metric_name": "k(n)",
            "metric_value": float('inf'),
            "instances_tested": 1,
            "n_max": n,
            "conjecture_holds": False,
            "counterexample": "alpha_n is zero, division by zero"
        }
    
    if k_n > alpha_n ** 2:
        return {
            "metric_name": "k(n)",
            "metric_value": k_n,
            "instances_tested": 1,
            "n_max": n,
            "conjecture_holds": False,
            "counterexample": f"k(n) = {k_n}, alpha_n^2 = {alpha_n ** 2}"
        }
    
    return {
        "metric_name": "k(n)",
        "metric_value": k_n,
        "instances_tested": 1,
        "n_max": n,
        "conjecture_holds": True,
        "counterexample": ""
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113]
    
    results = []
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    if all(result["conjecture_holds"] for result in results):
        mean_value = sum(result["metric_value"] for result in results) / len(results)
        support_fraction = 1.0
        print(f"RESULT: SUPPORTED mean={mean_value} std=0 support_fraction={support_fraction}")
    else:
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        counterexample = next(result["counterexample"] for result in results if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{counterexample}\" first_failing_seed={first_failing_seed}")