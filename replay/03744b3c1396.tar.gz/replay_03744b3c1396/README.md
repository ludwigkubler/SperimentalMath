# Replay package — entry 03744b3c1396

Conjecture: Minimal Local Indefinite Integral and Communication Complexity Rank Correlation via Non-Commutative Geometry

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 09:57 UTC.
Pre-registration hash committed before this test ran: `6ffe637aa45b12f9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
