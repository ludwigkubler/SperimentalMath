# Replay package — entry 9344321fe61c

Conjecture: [c003b_cumulative_entropy/SC4#c21] Φ under a BAD elimination order (max-occurrence) exceeds Φ under min-occurrence by a factor growing in n (order-sensitivity of cumulative entropy).

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 16:49 UTC.
Pre-registration hash committed before this test ran: `9934d090672f1031`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
