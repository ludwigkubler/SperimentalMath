# Replay package — entry 63ccbc681743

Conjecture: Real Critical Point Count Exponential in SOS Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 05:06 UTC.
Pre-registration hash committed before this test ran: `23513f7b9ce0c056`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
