# Replay package — entry 9b0a625047c3

Conjecture: Second-Read Commutator Frobenius Excess Bounds Read-Twice BP Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 04:12 UTC.
Pre-registration hash committed before this test ran: `e34d20a3e288bad5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
