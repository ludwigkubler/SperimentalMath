import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_random_cnf(n):
        cnf = []
        for _ in range(random.randint(10, 20)):
            clause = [random.choice([1, -1]) * (i + 1) for i in range(n)]
            cnf.append(clause)
        return cnf

    def count_irreducible_representations(cnf):
        # Placeholder function to simulate counting irreducible representations
        # This is a dummy implementation and should be replaced with actual computation
        return random.randint(1, 2 ** n)

    metric_name = "irreducible_representations"
    instances_tested = 0
    total_count = 0
    counts = []

    for n in [5, 10, 15, 20, 30, 40]:
        for _ in range(5):
            cnf = generate_random_cnf(n)
            count = count_irreducible_representations(cnf)
            counts.append(count)
            instances_tested += 1

    mean_count = sum(counts) / len(counts)
    std_dev = math.sqrt(sum((x - mean_count) ** 2 for x in counts) / len(counts))
    upper_bound = Fraction(2 ** n, n * math.log(n, 2) * math.log(math.log(n, 2), 2))

    conjecture_holds = all(count <= upper_bound + 3 * std_dev for count in counts)
    counterexample = "" if conjecture_holds else "mapping_undefined"

    return {
        "metric_name": metric_name,
        "metric_value": mean_count,
        "instances_tested": instances_tested,
        "n_max": max(40, n),
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2**i - 1 for i in range(5, 30)]
    
    results = []
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)

    mean_value = sum(result["metric_value"] for result in results) / len(results)
    std_dev = math.sqrt(sum((result["metric_value"] - mean_value) ** 2 for result in results) / len(results))
    support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)

    if all(result["conjecture_holds"] for result in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_dev} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_dev} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample='mapping_undefined' first_failing_seed={first_failing_seed}")