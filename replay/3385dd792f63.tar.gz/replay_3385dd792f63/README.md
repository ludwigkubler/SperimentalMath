# Replay package — entry 3385dd792f63

Conjecture: Noise-Stability Plateau at rho=1/3 Bounds DPLL Leaves on 3-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 09:18 UTC.
Pre-registration hash committed before this test ran: `4e6cd17a868e6b4f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
