# Replay package — entry cd37f3eec07b

Conjecture: Minimal Order of Quasi-Quadratic Forms Bounds Cumulative Proof Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 06:59 UTC.
Pre-registration hash committed before this test ran: `9f794bc80691911a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
