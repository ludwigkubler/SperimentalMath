# Replay package — entry cd21f13f8cbc

Conjecture: Gowers Uniformity Norm Gap in Read-Twice vs Read-Once BPs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 18:13 UTC.
Pre-registration hash committed before this test ran: `e9a9349e3b3dcad1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
