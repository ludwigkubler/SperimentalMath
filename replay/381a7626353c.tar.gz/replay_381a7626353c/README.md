# Replay package — entry 381a7626353c

Conjecture: Spectral Gap Conjecture for Tseitin Tensor Product Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 22:03 UTC.
Pre-registration hash committed before this test ran: `a3adee622d92ba0b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
