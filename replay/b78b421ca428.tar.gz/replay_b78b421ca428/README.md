# Replay package — entry b78b421ca428

Conjecture: Minimal Rank of Real Algebraic Curves Bounds AC⁰ Circuit Depth for Parity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 22:51 UTC.
Pre-registration hash committed before this test ran: `d01eed344210b53d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
