# Replay package — entry 30db37fc52cc

Conjecture: Minimal Order of Local Systems in Algebraic Topology vs. Frege Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 16:16 UTC.
Pre-registration hash committed before this test ran: `7ddcf141a14be4c5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
