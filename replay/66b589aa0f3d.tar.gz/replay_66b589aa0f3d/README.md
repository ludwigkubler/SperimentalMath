# Replay package — entry 66b589aa0f3d

Conjecture: Coxeter Inversion Spread of Barrington BPs Bounds NC^1 Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 04:47 UTC.
Pre-registration hash committed before this test ran: `6d79984b2bd3c6ce`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
