# Replay package — entry 2deb9c6539ac

Conjecture: Adjacency Spectrum Log-Discriminant Tracks Max-Cut SDP Slack

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 19:02 UTC.
Pre-registration hash committed before this test ran: `f17ba945e2ed47f8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
