# Replay package — entry 6a5108507f6d

Conjecture: Tropicalized Hodge Integrals and Sum-of-Squares Circuit Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 13:37 UTC.
Pre-registration hash committed before this test ran: `f4c47aadedd366a2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
