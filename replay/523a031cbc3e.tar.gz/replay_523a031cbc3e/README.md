# Replay package — entry 523a031cbc3e

Conjecture: Fatgraph Genus of Canonical Clause Ribbon Lower-Bounds Resolution Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 21:53 UTC.
Pre-registration hash committed before this test ran: `78e638801f9f940c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
