# Replay package — entry 7007040aabb5

Conjecture: Minimal Order of Quadratic Residues and Communication Complexity Rank Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 22:24 UTC.
Pre-registration hash committed before this test ran: `f7841372f55b27c3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
