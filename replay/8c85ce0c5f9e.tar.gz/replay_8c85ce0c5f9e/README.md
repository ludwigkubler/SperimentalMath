# Replay package — entry 8c85ce0c5f9e

Conjecture: Minimal Genus of Surfaces in Characteristic p Bounds Resolution Proof Size for k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 02:06 UTC.
Pre-registration hash committed before this test ran: `3ffe9556bdc198cd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
