import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_3_regular_graph(n):
        if n % 2 != 0 or n < 4:
            return None
        vertices = list(range(n))
        edges = []
        for i in range(n):
            for j in range(i + 1, n):
                if len(edges) == (n * (n - 1)) // 6:
                    break
                if random.choice([True, False]):
                    edges.append((i, j))
        return vertices, edges
    
    def compute_lambda_up(X_G):
        m = len(X_G)
        D = [[0] * m for _ in range(3)]
        for i in range(m):
            u, v = X_G[i]
            D[0][u], D[0][v] += 1
            D[1][i] += 2
            D[2][i] += 1
        
        L1 = [[D[2][i] - D[1][j] if (i // 3 == j // 3 and i % 3 != j % 3) else 0 for j in range(m)] for i in range(m)]
        
        # Compute eigenvalues of L1
        eigvals = []
        for i in range(m):
            v = [D[2][i] - D[1][j] if (i // 3 == j // 3 and i % 3 != j % 3) else 0 for j in range(m)]
            eigval = sum(v[j] * v[k] for j in range(m) for k in range(j + 1, m)) / (2 * sum(v[j]**2 for j in range(m)))
            eigvals.append(eigval)
        
        return min(eigvals)

    def dpll(G, c):
        stack = []
        backtrack_count = 0
        while True:
            if not stack:
                return backtrack_count
            
            u = next((v for v in G if c[v] == 'u'), None)
            if u is None:
                return backtrack_count
            
            stack.append(u)
            c[u] = '1'
            
            if all(c[v] != '0' for v in G):
                return backtrack_count
            
            for v in G:
                if c[v] == 'u':
                    c[v] = '0'
                    stack.append(v)
                    backtrack_count += 1
                    break
    
    n_values = [8, 10, 12, 14, 16, 18, 20]
    results = []
    
    for n in n_values:
        G = generate_3_regular_graph(n)
        if G is None:
            continue
        
        vertices, edges = G
        X_G = [(u, v) for u, v in edges]
        
        c = {v: 'u' for v in vertices}
        backtrack_count = dpll(G, c)
        
        lambda_up = compute_lambda_up(X_G)
        results.append({
            "n": n,
            "backtrack_count": backtrack_count,
            "lambda_up": lambda_up
        })
    
    if not results:
        return {
            "metric_name": "log2(backtrack_count)",
            "metric_value": 0.0,
            "instances_tested": 0,
            "conjecture_holds": False,
            "counterexample": "graph_generation_failed"
        }
    
    backtrack_counts = [r["backtrack_count"] for r in results]
    lambda_ups = [r["lambda_up"] for r in results]
    slopes = [(math.log2(b) - math.log2(a)) / (b - a) if b != a else float('inf') for a, b in zip(backtrack_counts[:-1], backtrack_counts[1:])]
    
    mean_slope = sum(slopes) / len(slopes)
    intercepts = [math.log2(b) - mean_slope * b for b in backtrack_counts]
    min_ratio = min(math.log2(b) / (lambda_up * math.sqrt(n)) for n, b, lambda_up in zip(results[0]["n"], results[0]["backtrack_count"], results[0]["lambda_up"]))
    
    return {
        "metric_name": "log2(backtrack_count)",
        "metric_value": mean_slope,
        "instances_tested": len(results),
        "conjecture_holds": mean_slope > 0 and min_ratio >= 0.05,
        "counterexample": "" if mean_slope > 0 else f"n={results[0]['n']}, backtrack_count={results[0]['backtrack_count']}, lambda_up={results[0]['lambda_up']}"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_slope = sum(r["metric_value"] for r in results) / len(results)
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_slope} std=0.0 support_fraction=1.0")
    elif any(r["n"] >= 18 and r["backtrack_count"] < 0.8 * (0.05 * r["lambda_up"] * math.sqrt(r["n"])) for r in results):
        first_failing_seed = next(r["seed"] for r in results if r["n"] >= 18 and r["backtrack_count"] < 0.8 * (0.05 * r["lambda_up"] * math.sqrt(r["n"])))
        print(f"RESULT: FALSIFIED counterexample='n≥18 backtrack_count too low' first_failing_seed={first_failing_seed}")
    else:
        print(f"RESULT: INCONCLUSIVE support_fraction={support_fraction}")