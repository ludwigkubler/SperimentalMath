# Replay package — entry c90ce4806deb

Conjecture: Minimal Order of Non-Crossing Partitions and Communication Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 04:34 UTC.
Pre-registration hash committed before this test ran: `4e94ed6adb6341b6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
