# Replay package — entry c497cb4d0173

Conjecture: Free Entropy Gap of Read-Twice BP Transition Matrices for IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 03:08 UTC.
Pre-registration hash committed before this test ran: `da3e24b77cc2970d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
