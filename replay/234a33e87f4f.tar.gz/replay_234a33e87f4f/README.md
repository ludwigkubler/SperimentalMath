# Replay package — entry 234a33e87f4f

Conjecture: Quantum Phase of Cubic Forms Bounds Resolution Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 23:24 UTC.
Pre-registration hash committed before this test ran: `76aa5903436abe59`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
