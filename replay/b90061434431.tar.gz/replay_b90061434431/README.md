# Replay package — entry b90061434431

Conjecture: Average Sensitivity of Clause-Indicator Function Bounds Resolution Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-24 17:19 UTC.
Pre-registration hash committed before this test ran: `936e918d30d5e8a2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
