# Replay package — entry 03f95437ce43

Conjecture: Minimal Tensor Product Rank of Quadratic Forms Bounds Frege Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 00:00 UTC.
Pre-registration hash committed before this test ran: `3da833fb620afeb3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
