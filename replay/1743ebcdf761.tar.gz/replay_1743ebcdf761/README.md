# Replay package — entry 1743ebcdf761

Conjecture: Morse-Hedlund Factor Complexity of XOR-Lifted Rows Upper-Bounds D(f)

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 20:36 UTC.
Pre-registration hash committed before this test ran: `e85c465a430671f6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
