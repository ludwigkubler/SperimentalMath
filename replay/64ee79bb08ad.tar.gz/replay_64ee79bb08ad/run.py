import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_cnf(n, m):
        cnf = []
        for _ in range(m):
            clause = [random.randint(1, n), -random.randint(1, n)]
            cnf.append(clause)
        return cnf
    
    def zeta_function_size(cnf):
        # Placeholder implementation of zeta function size calculation
        # This is a dummy function and does not actually compute the zeta function size
        return len(cnf) ** 0.5 * n ** 0.75
    
    n_values = [5, 10, 15, 20, 30, 40]
    metric_value = 0
    instances_tested = 0
    n_max = 0
    
    for n in n_values:
        m = random.randint(1, n * 2)
        cnf = generate_cnf(n, m)
        size = zeta_function_size(cnf)
        if size > metric_value:
            metric_value = size
        instances_tested += len(cnf)
        n_max = max(n_max, n)
    
    conjecture_holds = (metric_value <= O(m ** 0.5 * n ** 0.75))
    counterexample = "" if conjecture_holds else "mapping_undefined"
    
    return {
        "metric_name": "zeta_function_size",
        "metric_value": metric_value,
        "instances_tested": instances_tested,
        "n_max": n_max,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    results = []
    
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if support_fraction >= 0.95:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample='mapping_undefined' first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE reason=insufficient_evidence")