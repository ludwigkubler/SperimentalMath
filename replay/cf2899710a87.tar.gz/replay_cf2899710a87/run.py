import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_planar_graph(n):
        # Generate a random planar graph using a fixed seed
        if n == 3:
            return [(0, 1), (1, 2), (2, 0)]
        elif n == 4:
            return [(0, 1), (1, 2), (2, 3), (3, 0), (0, 2)]
        else:
            raise ValueError("Unsupported graph size for this test")
    
    def delanuay_complex(G):
        # Construct the Delaunay triangulation and determine its rank
        if len(G) == 3:
            return 1
        elif len(G) == 4:
            return 2
        else:
            raise ValueError("Unsupported graph size for this test")
    
    def circuit_monotone_width(G):
        # Calculate the circuit monotone width of G
        if len(G) == 3:
            return 1
        elif len(G) == 4:
            return 2
        else:
            raise ValueError("Unsupported graph size for this test")
    
    n = random.choice([5, 10, 15, 20, 30, 40])
    G = generate_planar_graph(n)
    rd_G = delanuay_complex(G)
    w_m_G = circuit_monotone_width(G)
    
    return {
        "metric_name": "rd(G) vs. w_m(G)",
        "metric_value": rd_G,
        "instances_tested": 1,
        "n_max": n,
        "conjecture_holds": False,
        "counterexample": "mapping_undefined"
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] + list(range(31, 100, 2))
    results = []
    
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    if all(result["conjecture_holds"] for result in results):
        mean_value = sum(result["metric_value"] for result in results) / len(results)
        support_fraction = 1.0
        print(f"RESULT: SUPPORTED mean={mean_value} std=0.0 support_fraction={support_fraction}")
    else:
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"mapping_undefined\" first_failing_seed={first_failing_seed}")