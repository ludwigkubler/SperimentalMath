# Replay package — entry 6004bf0dc5da

Conjecture: Free Cumulant Gap in Read-Twice BPs Bounds Disjointness Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 07:12 UTC.
Pre-registration hash committed before this test ran: `6d36a794d6dbc098`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
