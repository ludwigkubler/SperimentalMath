# Replay package — entry 0a0e5563b772

Conjecture: Minimal Frobenius Class Dimension and Communication Complexity Rank

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 13:01 UTC.
Pre-registration hash committed before this test ran: `f9990bddb720ba94`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
