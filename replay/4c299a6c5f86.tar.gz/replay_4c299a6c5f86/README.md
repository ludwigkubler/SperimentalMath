# Replay package — entry 4c299a6c5f86

Conjecture: Minimal Rank of Formal Groups Bounds Resolution Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 06:32 UTC.
Pre-registration hash committed before this test ran: `b196e8e79ed0c4e6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
