# Replay package — entry 7092cd304ad9

Conjecture: Minimal Local Ring Index and Circuit Monotone Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 16:12 UTC.
Pre-registration hash committed before this test ran: `c978fd83ee765752`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
