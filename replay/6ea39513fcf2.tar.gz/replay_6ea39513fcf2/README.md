# Replay package — entry 6ea39513fcf2

Conjecture: Torsion Points on Jacobians and Resolution Width of Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 10:09 UTC.
Pre-registration hash committed before this test ran: `fa03db9cbecee57c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
