# Replay package — entry cfc3432e06b6

Conjecture: Minimal Monodromy Group Order and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 15:56 UTC.
Pre-registration hash committed before this test ran: `4a150555543c20c3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
