# Replay package — entry e214b181a660

Conjecture: Minimal Tropical Motivic Rank of Affine Varieties and Circuit Satisfiability Threshold

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 14:54 UTC.
Pre-registration hash committed before this test ran: `9aa0fcb153d78ca2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
