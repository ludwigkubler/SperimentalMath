# Replay package — entry 4f10084edf2d

Conjecture: Minimal Order of Automorphism Groups over Graphs vs ACC⁰ Circuit Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 17:11 UTC.
Pre-registration hash committed before this test ran: `1b9e16fb28572268`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
