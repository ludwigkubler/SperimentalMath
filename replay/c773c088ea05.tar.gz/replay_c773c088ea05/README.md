# Replay package — entry c773c088ea05

Conjecture: Minimal Local Induction Dimension in Homological Algebra vs. Circuit Monotonicity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 09:25 UTC.
Pre-registration hash committed before this test ran: `76c4f4b7b2275b54`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
