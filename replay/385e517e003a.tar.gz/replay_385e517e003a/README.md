# Replay package — entry 385e517e003a

Conjecture: Average-Case SAT Hardness Linked to Finite Field Solution Counts

Verdict (original run): FALSIFIED

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-24 22:09 UTC.
Pre-registration hash committed before this test ran: `43d77fedc77cd991`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
