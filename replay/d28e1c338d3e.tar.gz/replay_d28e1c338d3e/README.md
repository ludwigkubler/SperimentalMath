# Replay package — entry d28e1c338d3e

Conjecture: Kronecker Coefficient Gap in Symmetric Powers of Permanent vs Determinant

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-13 06:42 UTC.
Pre-registration hash committed before this test ran: `cba025bd6ca88e5a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
