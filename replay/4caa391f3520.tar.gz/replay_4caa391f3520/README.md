# Replay package — entry 4caa391f3520

Conjecture: Minimal Index of Tropical Hodge Structure and Communication Complexity Rank

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 12:17 UTC.
Pre-registration hash committed before this test ran: `96a27f0449b9a752`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
