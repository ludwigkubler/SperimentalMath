# Replay package — entry 55efc5373ee4

Conjecture: Minimal Order of Cuspidal Subgroups and SAT Clause Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 23:31 UTC.
Pre-registration hash committed before this test ran: `95f55db7c2db5582`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
