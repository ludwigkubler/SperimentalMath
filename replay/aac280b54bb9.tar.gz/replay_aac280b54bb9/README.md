# Replay package — entry aac280b54bb9

Conjecture: Minimal Local Crossed Module Rank and DPLL Search Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 00:53 UTC.
Pre-registration hash committed before this test ran: `61ab0e7dacf51567`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
