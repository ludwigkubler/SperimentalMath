# Replay package — entry 9ff7d27e280f

Conjecture: Minimal Order of Noncommutative Tensor Power and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 06:43 UTC.
Pre-registration hash committed before this test ran: `f75c469222d93378`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
