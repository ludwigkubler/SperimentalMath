# Replay package — entry 03ecd63c2eb7

Conjecture: Minimal Rank of Tropical Curves vs Resolution Refutation Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 14:54 UTC.
Pre-registration hash committed before this test ran: `f656356e3c874662`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
