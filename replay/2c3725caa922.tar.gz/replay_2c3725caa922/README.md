# Replay package — entry 2c3725caa922

Conjecture: Minimal Ideal Generators and Resolution Proof Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-24 16:16 UTC.
Pre-registration hash committed before this test ran: `8bd9b3278c1498d9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
