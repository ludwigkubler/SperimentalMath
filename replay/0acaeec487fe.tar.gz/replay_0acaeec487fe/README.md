# Replay package — entry 0acaeec487fe

Conjecture: Minimal Rank of Brauer Groups Bounds XOR Circuit Weights via Linear Algebraic K-theory

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 20:10 UTC.
Pre-registration hash committed before this test ran: `da3e6d409c5308ce`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
