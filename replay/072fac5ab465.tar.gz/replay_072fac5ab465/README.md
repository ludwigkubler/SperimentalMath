# Replay package — entry 072fac5ab465

Conjecture: Eigenvalue Threshold in SOS Moment Matrices for ACC⁰ Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 05:29 UTC.
Pre-registration hash committed before this test ran: `a62ef084d80bb046`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
