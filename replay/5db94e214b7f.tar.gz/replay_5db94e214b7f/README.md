# Replay package — entry 5db94e214b7f

Conjecture: Minimal Monomial Degree vs. Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 02:39 UTC.
Pre-registration hash committed before this test ran: `25907fa004416f61`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
