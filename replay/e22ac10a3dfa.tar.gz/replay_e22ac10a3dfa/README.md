# Replay package — entry e22ac10a3dfa

Conjecture: Minimal Rank of Geometric Langlands Duality over Read-Twice BP Gate Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 05:45 UTC.
Pre-registration hash committed before this test ran: `4da26cd89f2c953b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
