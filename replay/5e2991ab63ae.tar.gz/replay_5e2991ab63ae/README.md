# Replay package — entry 5e2991ab63ae

Conjecture: Hypergeometric Function Moments Lower Bound for Circuit Depth of Frege Proofs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 14:12 UTC.
Pre-registration hash committed before this test ran: `68df8109e8d17b46`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
