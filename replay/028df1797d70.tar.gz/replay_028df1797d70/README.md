# Replay package — entry 028df1797d70

Conjecture: Ehrhart Polynomial Coefficient Sum Bounded by Resolution Proof Size for 3-SAT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 16:21 UTC.
Pre-registration hash committed before this test ran: `4b91b8fbf2202dc6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
