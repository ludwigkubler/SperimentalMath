# Replay package — entry cca077d3c64c

Conjecture: Tropical Max-Aggregation Monotonicity of MinimalFourierCoefficient under Pointwise Tropical Sum

Verdict (original run): FALSIFIED

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 22:20 UTC.
Pre-registration hash committed before this test ran: `e1768914450fedb7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
