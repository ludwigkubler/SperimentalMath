# Replay package — entry 501b089a21b9

Conjecture: Sprague-Grundy Game Value of CNF Bounds Tree-Frege Lines

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 14:25 UTC.
Pre-registration hash committed before this test ran: `a809f37c14bec8be`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
