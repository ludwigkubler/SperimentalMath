# Replay package — entry 1e87f5d63dae

Conjecture: Minimal Rank of Tropicalized Noncrossing Partitions vs BP_ReadTwice Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 09:40 UTC.
Pre-registration hash committed before this test ran: `290b1dc46b7f1ff6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
