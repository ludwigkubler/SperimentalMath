# Replay package — entry 06221fec8ebe

Conjecture: Hochster Betti Sum of Monotone f Lower-Bounds Log-Rank of IND-Lifted Matrix

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 10:04 UTC.
Pre-registration hash committed before this test ran: `77c02f8a008a85e7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
