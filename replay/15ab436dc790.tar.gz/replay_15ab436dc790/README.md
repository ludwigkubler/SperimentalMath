# Replay package — entry 15ab436dc790

Conjecture: Minimal Rank of Noncommutative Geometry States vs DPLL Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 19:29 UTC.
Pre-registration hash committed before this test ran: `a1f3c3a587c87b8a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
