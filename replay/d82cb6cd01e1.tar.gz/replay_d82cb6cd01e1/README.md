# Replay package — entry d82cb6cd01e1

Conjecture: Kronecker Coefficient Gap in Set Disjointness Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 23:12 UTC.
Pre-registration hash committed before this test ran: `a642f1b070dcce68`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
