# Replay package — entry bdb7e54036bd

Conjecture: Sublinear Slack in Forman-Ricci Submodularity Defect on Random Monotone DNF Pairs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 10:20 UTC.
Pre-registration hash committed before this test ran: `5a4035fe7e4d8158`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
