# Replay package — entry 5d43343b2472

Conjecture: Minimal Rank of Birational Geometry Bounds Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 21:23 UTC.
Pre-registration hash committed before this test ran: `0e5cdf1488528c78`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
