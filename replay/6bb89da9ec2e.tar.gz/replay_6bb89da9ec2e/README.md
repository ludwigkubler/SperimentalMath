# Replay package — entry 6bb89da9ec2e

Conjecture: Costas Displacement Coincidence Lower-Bounds AC⁰ Size for PARITY

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 02:01 UTC.
Pre-registration hash committed before this test ran: `0670d0ca56916df8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
