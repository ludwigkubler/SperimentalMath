# Replay package — entry 2cb1217ab7fd

Conjecture: Minimal Brauer Group Rank Correlation with Circuit Monotone Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 12:59 UTC.
Pre-registration hash committed before this test ran: `899e7255b9a650f0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
