# Replay package — entry c43f00dabeea

Conjecture: Mixer Profile and Communication Entropy Barrier

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 01:28 UTC.
Pre-registration hash committed before this test ran: `cb9c3cb5341e5801`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
