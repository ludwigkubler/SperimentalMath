# Replay package — entry 4cbcbdc0fbf7

Conjecture: Tropical Rank of Tseitin Incidence Matrix Bounds Resolution Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 15:58 UTC.
Pre-registration hash committed before this test ran: `61fa7b15bc3ef961`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
