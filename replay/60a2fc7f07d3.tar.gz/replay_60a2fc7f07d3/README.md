# Replay package — entry 60a2fc7f07d3

Conjecture: Minimal Automorphism Group Size and Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 17:09 UTC.
Pre-registration hash committed before this test ran: `c72da6547874dd97`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
