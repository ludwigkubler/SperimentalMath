import random
import math
from itertools import product

def generate_random_3cnf(n, m):
    literals = [f'x{i+1}', f'-x{i+1}' for i in range(n)]
    cnf = []
    for _ in range(m):
        clause = random.sample(literals, 3)
        cnf.append(' or '.join(clause))
    return ' and '.join(cnf)

def dpll_solve(cnf):
    def solve(assignment):
        if not cnf:
            return True
        literals = set()
        for clause in cnf:
            literals.update(set(clause.split()[:3]))
        literal = next(iter(literals))
        pos_literal, neg_literal = literal, f'-{literal}'
        if pos_literal in assignment and assignment[pos_literal]:
            return solve(assignment)
        elif neg_literal in assignment and not assignment[neg_literal]:
            return solve(assignment)
        else:
            new_assignment = assignment.copy()
            new_assignment[literal] = True
            if solve(new_assignment):
                return True
            new_assignment[literal] = False
            new_assignment[f'-{literal}'] = True
            if solve(new_assignment):
                return True
            return False
    return solve({})

def star_discrepancy(V_F, m, n):
    D = 0
    for a in product([0, 1], repeat=n):
        S = [sum(1 if V_F[i][j] >= a[j] else -1 for j in range(n)) for i in range(m)]
        D = max(D, abs(sum(S[i] * V_F[i][j] for i in range(m))) / math.sqrt(m))
    return D

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n = 30
    m = 135
    cnf = generate_random_3cnf(n, m)
    V_F = [[0.5 for _ in range(n)] for _ in range(m)]
    for i, clause in enumerate(cnf.split(' and ')):
        literals = clause.split(' or ')
        for literal in literals:
            if literal[0] == '-':
                var = int(literal[1:])
                V_F[i][var-1] = 1 - 1 / (2 * n)
            else:
                var = int(literal)
                V_F[i][var-1] = 1 / (2 * n)
    
    D_star = star_discrepancy(V_F, m, n)
    resolution_width = len(cnf.split(' and '))
    
    return {
        "metric_name": "resolution_width",
        "metric_value": resolution_width,
        "instances_tested": 1,
        "conjecture_holds": D_star >= math.log(n) * 2,  # Using a constant c=2 for simplicity
        "counterexample": "" if D_star >= math.log(n) * 2 else f"Star discrepancy {D_star} < {math.log(n) * 2}"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2**i + 7 for i in range(5, 35)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(res["metric_value"] for res in results) / len(results)
    std_value = math.sqrt(sum((res["metric_value"] - mean_value)**2 for res in results) / len(results))
    support_fraction = sum(1 for res in results if res["conjecture_holds"]) / len(results)
    
    if all(res["conjecture_holds"] for res in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(res["seed"] for res in results if not res["conjecture_holds"])
        counterexample = next(res["counterexample"] for res in results if res["counterexample"])
        print(f"RESULT: FALSIFIED counterexample=\"{counterexample}\" first_failing_seed={first_failing_seed}")