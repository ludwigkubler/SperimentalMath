import random
import math
from collections import defaultdict, deque

# Helper functions for matrix operations
def matrix_multiply(A, B):
    m = len(A)
    n = len(B[0])
    p = len(B)
    C = [[0] * n for _ in range(m)]
    for i in range(m):
        for j in range(n):
            for k in range(p):
                C[i][j] += A[i][k] * B[k][j]
    return C

def gaussian_elimination(A, b):
    m = len(A)
    n = len(A[0])
    augmented_matrix = [A[i] + [b[i]] for i in range(m)]
    
    for col in range(n):
        max_row = col
        for row in range(col+1, m):
            if abs(augmented_matrix[row][col]) > abs(augmented_matrix[max_row][col]):
                max_row = row
        
        augmented_matrix[col], augmented_matrix[max_row] = augmented_matrix[max_row], augmented_matrix[col]
        
        pivot = augmented_matrix[col][col]
        for i in range(col, n+1):
            augmented_matrix[col][i] /= pivot
        
        for row in range(m):
            if row != col:
                factor = augmented_matrix[row][col]
                for i in range(col, n+1):
                    augmented_matrix[row][i] -= factor * augmented_matrix[col][i]
    
    x = [0] * n
    for i in range(n-1, -1, -1):
        x[i] = augmented_matrix[i][-1]
        for j in range(i+1, n):
            x[i] -= augmented_matrix[i][j] * x[j]
    
    return x

# Quine-McCluskey algorithm to find prime implicants
def quine_mccluskey(minterms):
    minterms = sorted(set(minterms))
    variables = len(bin(max(minterms)))[2:]
    implicants = []
    for term in minterms:
        implicants.append([term, 1])
    
    while True:
        new_implicants = []
        for i in range(len(implicants)):
            for j in range(i+1, len(implicants)):
                diff_count = sum(1 for a, b in zip(bin(implicants[i][0])[2:].zfill(variables), bin(implicants[j][0])[2:].zfill(variables)) if a != b)
                if diff_count == 1:
                    new_term = implicants[i][0] ^ (1 << [i for i, (a, b) in enumerate(zip(bin(implicants[i][0])[2:].zfill(variables), bin(implicants[j][0])[2:].zfill(variables)) if a != b)][0])
                    new_implicants.append([new_term, implicants[i][1] + implicants[j][1]])
        if not new_implicants:
            break
        implicants = new_implicants
    
    prime_implicants = [term for term, _ in implicants if all(bin(term)[2:].zfill(variables).count('1') == 1 for i in range(1, variables))]
    return prime_implicants

# Function to compute the antichain width of a concept lattice
def antichain_width(concept_lattice):
    n = len(concept_lattice)
    adj_matrix = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(i+1, n):
            if all(concept_lattice[i][k] <= concept_lattice[j][k] for k in range(n)):
                adj_matrix[i][j] = 1
                adj_matrix[j][i] = 1
    
    max_antichain_size = 0
    visited = [False] * n
    stack = []
    
    def dfs(node):
        nonlocal max_antichain_size
        if visited[node]:
            return
        visited[node] = True
        stack.append(node)
        
        for neighbor in range(n):
            if adj_matrix[node][neighbor] == 1:
                dfs(neighbor)
        
        if len(stack) > max_antichain_size:
            max_antichain_size = len(stack)
        
        stack.pop()
        visited[node] = False
    
    for node in range(n):
        dfs(node)
    
    return max_antichain_size

# Function to build the concept lattice
def build_concept_lattice(M, L):
    n = len(L)
    concepts = []
    for i in range(1 << n):
        concept = [0] * n
        for j in range(n):
            if (i >> j) & 1:
                concept[j] = L[j]
        concepts.append(concept)
    
    lattice = []
    for i in range(len(concepts)):
        is_antichain = True
        for j in range(i+1, len(concepts)):
            if all(concepts[i][k] <= concepts[j][k] for k in range(n)) and all(concepts[j][k] <= concepts[i][k] for k in range(n)):
                is_antichain = False
                break
        if is_antichain:
            lattice.append(concepts[i])
    
    return lattice

# Function to run a single trial
def run_trial(seed: int) -> dict:
    random.seed(seed)
    n = random.randint(3, 5)
    M = [random.getrandbits(n) for _ in range(1 << n)]
    L = [(-1 if i < n else 1) * (1 << i) for i in range(2*n)]
    
    prime_implicants = quine_mccluskey(M)
    sigma_DNF = len(prime_implicants)
    
    concept_lattice = build_concept_lattice(M, L)
    w_f = antichain_width(concept_lattice)
    
    if w_f < sigma_DNF:
        return {
            "metric_name": "w(f)/sigma_DNF",
            "metric_value": float(w_f) / sigma_DNF,
            "instances_tested": 1,
            "conjecture_holds": False,
            "counterexample": f"({n}, {M}, {L}) with w(f)={w_f} < sigma_DNF={sigma_DNF}"
        }
    elif w_f > 2 * n * sigma_DNF:
        return {
            "metric_name": "w(f)/sigma_DNF",
            "metric_value": float(w_f) / sigma_DNF,
            "instances_tested": 1,
            "conjecture_holds": False,
            "counterexample": f"({n}, {M}, {L}) with w(f)={w_f} > 2*n*sigma_DNF={2 * n * sigma_DNF}"
        }
    else:
        return {
            "metric_name": "w(f)/sigma_DNF",
            "metric_value": float(w_f) / sigma_DNF,
            "instances_tested": 1,
            "conjecture_holds": True,
            "counterexample": ""
        }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] if sys.argv[1:] else [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    
    results = []
    for seed in seeds:
        trial = run_trial(seed)
        print(f"TRIAL: {trial}")
        results.append(trial)
    
    if all(trial["conjecture_holds"] for trial in results):
        mean_value = sum(trial["metric_value"] for trial in results) / len(results)
        std_value = math.sqrt(sum((trial["metric_value"] - mean_value) ** 2 for trial in results) / len(results))
        support_fraction = 1.0
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(seed for seed, trial in zip(seeds, results) if not trial["conjecture_holds"])
        counterexample = next(trial["counterexample"] for trial in results if not trial["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{counterexample}\" first_failing_seed={first_failing_seed}")