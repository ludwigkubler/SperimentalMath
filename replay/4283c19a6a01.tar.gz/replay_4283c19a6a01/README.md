# Replay package — entry 4283c19a6a01

Conjecture: Free Entropy Gap in Read-Twice Branching Programs for Inner Product Modulo 2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 15:30 UTC.
Pre-registration hash committed before this test ran: `2ad46557e8580399`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
