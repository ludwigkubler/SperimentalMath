# Replay package — entry 29a7a7350450

Conjecture: Minimal Order of Tropicalized Brauer Groups and Resolution Proof Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 23:09 UTC.
Pre-registration hash committed before this test ran: `bf416c35198721af`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
