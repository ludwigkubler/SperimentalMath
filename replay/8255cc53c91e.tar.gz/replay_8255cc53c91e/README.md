# Replay package — entry 8255cc53c91e

Conjecture: Finite Geometry Rank and ACC^0 Circuit Size for 3-SAT Instances

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 16:47 UTC.
Pre-registration hash committed before this test ran: `b881c5c32bfff70a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
