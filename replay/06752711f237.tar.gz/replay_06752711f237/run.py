import random
from fractions import Fraction
import math
import sys

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def gaussian_elimination(A, b):
        n = len(A)
        Augmented = [[A[i][j] for j in range(n)] + [b[i]] for i in range(n)]
        
        for i in range(n):
            max_row = i
            for k in range(i+1, n):
                if abs(Augmented[k][i]) > abs(Augmented[max_row][i]):
                    max_row = k
            
            Augmented[i], Augmented[max_row] = Augmented[max_row], Augmented[i]
            
            factor = Fraction(1, Augmented[i][i])
            for j in range(i, n+1):
                Augmented[i][j] *= factor
            
            for k in range(n):
                if k != i:
                    factor = Augmented[k][i]
                    for j in range(i, n+1):
                        Augmented[k][j] -= factor * Augmented[i][j]
        
        return [row[-1] for row in Augmented]

    def compute_genus(M):
        n = len(M)
        A = [[0]*n for _ in range(n)]
        b = [0]*n
        
        for i in range(n):
            for j in range(i+1, n):
                if M[i][j] == 1:
                    A[i][j] = -1
                    A[j][i] = -1
                    b[i] += 1
                    b[j] += 1
        
        try:
            x = gaussian_elimination(A, b)
        except ZeroDivisionError:
            return None
        
        genus = sum(x[i]**2 for i in range(n)) / 4
        return genus
    
    def generate_disjointness_matrix(n):
        M = [[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1, n):
                M[i][j] = random.randint(0, 1)
                M[j][i] = M[i][j]
        return M
    
    def communication_complexity(M):
        n = len(M)
        CC = 2 * sum(sum(row) for row in M) / (n * (n - 1))
        return CC
    
    instances_tested = 0
    total_metric_value = 0
    conjecture_holds = True
    counterexample = ""
    
    n_values = [5, 10, 15, 20, 30, 40]
    for n in n_values:
        for _ in range(5):  # Aim for at least 30 instances per seed
            M = generate_disjointness_matrix(n)
            CC = communication_complexity(M)
            
            if CC == 0:
                continue
            
            genus = compute_genus(M)
            if genus is None:
                counterexample = "mapping_undefined"
                conjecture_holds = False
                break
            
            metric_value = genus / math.log2(CC)
            total_metric_value += metric_value
            instances_tested += 1
    
    mean_metric_value = total_metric_value / instances_tested if instances_tested > 0 else None
    support_fraction = sum(1 for seed in range(30) if run_trial(seed)['conjecture_holds']) / 30
    
    return {
        "metric_name": "g(M)/log₂ CC(M)",
        "metric_value": mean_metric_value,
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    seeds = [int(s) for s in sys.argv[1:]] or list(range(2, 30*2 + 1, 2))  # Default to first 30 primes
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {{\"seed\": {seed}, \"metric_name\": \"{result['metric_name']}\", \"metric_value\": {result['metric_value']}, \"instances_tested\": {result['instances_tested']}, \"conjecture_holds\": {result['conjecture_holds']}, \"counterexample\": \"{result['counterexample']}\"}}")
        results.append(result)
    
    mean_metric_value = sum(r['metric_value'] for r in results if r['metric_value'] is not None) / len(results)
    support_fraction = sum(1 for r in results if r['conjecture_holds']) / len(results)
    
    if all(r['conjecture_holds'] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std=0.0 support_fraction={support_fraction}")
    elif any(not r['conjecture_holds'] for r in results) and any(r['counterexample'] != "mapping_undefined" for r in results):
        first_failing_seed = next(seed for seed, result in enumerate(results) if not result['conjecture_holds'])
        print(f"RESULT: FALSIFIED counterexample=\"{next(result['counterexample'] for result in results if result['counterexample'] != \"mapping_undefined\")}\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE mapping_undefined")