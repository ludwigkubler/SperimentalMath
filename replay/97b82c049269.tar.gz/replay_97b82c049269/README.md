# Replay package — entry 97b82c049269

Conjecture: SVD Participation Dispersion of Mid-Layer Lower-Bounds Read-Twice BPs for IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 08:40 UTC.
Pre-registration hash committed before this test ran: `db89fc8b8d1d3e0b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
