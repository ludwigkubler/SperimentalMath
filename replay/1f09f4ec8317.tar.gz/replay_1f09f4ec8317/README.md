# Replay package — entry 1f09f4ec8317

Conjecture: Irreducible Component Count Inversely Proportional to SOS Refutation Degree for 3-SAT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 22:03 UTC.
Pre-registration hash committed before this test ran: `a75cb595a4168354`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
