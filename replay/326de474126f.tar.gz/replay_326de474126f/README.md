# Replay package — entry 326de474126f

Conjecture: Minimal Weyl Character Degrees of Representation Theory vs GCT DET_PERM Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 06:09 UTC.
Pre-registration hash committed before this test ran: `912c4a44b60cde03`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
