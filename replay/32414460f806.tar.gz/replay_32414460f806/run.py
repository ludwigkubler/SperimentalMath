import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_3cnf(n, m):
        clauses = []
        for _ in range(m):
            clause = [random.randint(1, n), -random.randint(1, n)]
            if len(set(clause)) == 2:
                clauses.append(clause)
        return clauses

    def compute_minimal_index(clauses):
        # Simplified mapping to degree of a polynomial
        return len(clauses) ** 0.5

    def resolution_width(clauses):
        stack = []
        for clause in clauses:
            if not any(lit in stack for lit in clause):
                stack.append(clause)
            else:
                new_clauses = []
                for c1 in stack:
                    for c2 in clauses:
                        if len(set(c1 + c2)) == 3:
                            new_clause = [x for x in c1 + c2 if x not in c1 and x not in c2]
                            new_clauses.append(new_clause)
                stack.extend(new_clauses)
        return len(stack)

    n = random.randint(5, 40)
    m = random.randint(n, n * 3)
    cnf = generate_3cnf(n, m)
    
    minimal_index = compute_minimal_index(cnf)
    width = resolution_width(cnf)
    
    return {
        "metric_name": "minimal_index",
        "metric_value": minimal_index,
        "instances_tested": 1,
        "n_max": n,
        "conjecture_holds": minimal_index <= width + 5,
        "counterexample": ""
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113]
    results = []
    
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)

    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = (sum((r["metric_value"] - mean_value) ** 2 for r in results) / len(results)) ** 0.5
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)

    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    else:
        for r in results:
            if not r["conjecture_holds"]:
                print(f"RESULT: FALSIFIED counterexample=\"\" first_failing_seed={r['seed']}")
                break