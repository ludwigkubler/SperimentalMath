# Replay package — entry 4e48f12af009

Conjecture: Minimal Rank of Alexander-Griffiths Modules over Planar Graphs vs Resolution Proof Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 13:29 UTC.
Pre-registration hash committed before this test ran: `8f2f614d02bb9a67`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
