# Replay package — entry 2018fdeae7b9

Conjecture: Minimal Order of Brauer's Theorem and Circuit Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 07:08 UTC.
Pre-registration hash committed before this test ran: `3256fd8b7c78d36b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
