# Replay package — entry 7326a2042e6a

Conjecture: Minimal Order of Formal Group Representations and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 07:42 UTC.
Pre-registration hash committed before this test ran: `d7eac456a93cedb8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
