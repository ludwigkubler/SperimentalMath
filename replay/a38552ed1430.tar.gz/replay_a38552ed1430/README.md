# Replay package — entry a38552ed1430

Conjecture: Minimal Order of Brauer Groups and SAT Clause Subset Entropy Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 18:14 UTC.
Pre-registration hash committed before this test ran: `b712d7ea248b3ba6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
