# Replay package — entry c26787a56682

Conjecture: Real Rank of Karchmer-Wigderson Communication Matrices for AC⁰ PARITY

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-30 17:18 UTC.
Pre-registration hash committed before this test ran: `dc59e49cdb545b65`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
