# Replay package — entry 8dbbdbbc746a

Conjecture: Quantum Rank Lower Bounds for Disjointness Communication Matrices

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 01:08 UTC.
Pre-registration hash committed before this test ran: `ec42f098e1ee3ecc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
