# Replay package — entry d7cf4659c191

Conjecture: Minimal Order of Brauer Groups and Communication Complexity Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 14:33 UTC.
Pre-registration hash committed before this test ran: `4932783eb32e7958`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
