# Replay package — entry 938d297912a8

Conjecture: Real Rank of SOS Moment Matrices for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-30 21:28 UTC.
Pre-registration hash committed before this test ran: `73258fc30de59e94`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
