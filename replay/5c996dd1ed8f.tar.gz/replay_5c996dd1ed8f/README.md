# Replay package — entry 5c996dd1ed8f

Conjecture: Minimal Order of Affine Group Conjugacy Classes and Communication Complexity Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 05:27 UTC.
Pre-registration hash committed before this test ran: `71dba340a192ca29`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
