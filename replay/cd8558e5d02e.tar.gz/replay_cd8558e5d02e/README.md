# Replay package — entry cd8558e5d02e

Conjecture: Minimal Rank of Hodge Decomposition Moduli Spaces vs AC0 Circuit Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 05:34 UTC.
Pre-registration hash committed before this test ran: `a91e64adfd122917`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
