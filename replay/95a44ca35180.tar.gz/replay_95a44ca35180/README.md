# Replay package — entry 95a44ca35180

Conjecture: Coxeter Group Order Bounds Tree-Like Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 11:38 UTC.
Pre-registration hash committed before this test ran: `7b8212346ccd6d6e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
