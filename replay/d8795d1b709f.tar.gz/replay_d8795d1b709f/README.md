# Replay package — entry d8795d1b709f

Conjecture: Schur Coefficient Sum Ratio in Symmetric Powers of Permanent vs Determinant

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 20:40 UTC.
Pre-registration hash committed before this test ran: `a40e5afeae3eb0fd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
