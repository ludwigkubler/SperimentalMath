# Replay package — entry 52a971f74369

Conjecture: Protocol-Induced Covers on High-Asdim Gadget Lifts Require Exponential-in-Q(f) Multiplicity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-29 13:06 UTC.
Pre-registration hash committed before this test ran: `0b02c821cdd5a332`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
