import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_random_graph(n):
        graph = {i: [] for i in range(n)}
        edges = set()
        while len(edges) < n * (n - 1) // 2:
            u, v = random.sample(range(n), 2)
            if u != v and (u, v) not in edges and (v, u) not in edges:
                graph[u].append(v)
                graph[v].append(u)
                edges.add((u, v))
        return graph
    
    def tseitin_formula(graph):
        n = len(graph)
        literals = [f"x{i}" for i in range(n)]
        clauses = []
        
        # Base case
        for i in range(n):
            clauses.append([literals[2*i], literals[2*i+1]])
        
        # Implication rules
        for u in range(n):
            for v in graph[u]:
                clauses.append([-literals[2*u], literals[2*v]])
                clauses.append([-literals[2*u+1], -literals[2*v+1]])
                clauses.append([literals[2*u], literals[2*v+1]])
                clauses.append([literals[2*u+1], literals[2*v]])
        
        return literals, clauses
    
    def resolution_length(clauses):
        n = len(clauses)
        unit_clauses = {c[0] for c in clauses if len(c) == 1}
        resolvents = set()
        
        while True:
            new_resolvents = set()
            for i in range(n):
                for j in range(i+1, n):
                    if -clauses[i][0] in clauses[j]:
                        new_resolvent = [l for l in clauses[i] if l != -clauses[i][0]] + [l for l in clauses[j] if l != -clauses[i][0]]
                        new_resolvents.add(tuple(sorted(new_resolvent)))
                    elif -clauses[j][0] in clauses[i]:
                        new_resolvent = [l for l in clauses[i] if l != -clauses[j][0]] + [l for l in clauses[j] if l != -clauses[j][0]]
                        new_resolvents.add(tuple(sorted(new_resolvent)))
            if not new_resolvents:
                break
            resolvents.update(new_resolvents)
            unit_clauses.update({c[0] for c in new_resolvents if len(c) == 1})
        
        return len(resolvents)
    
    def asymptotic_dimension(graph):
        n = len(graph)
        for d in range(1, n+1):
            if all(len(set(graph[v] for v in graph if u not in graph[v])) >= d-1 for u in graph):
                return d
        return n
    
    n_values = [5, 10, 15, 20, 30, 40]
    total_length = 0
    instances_tested = 0
    
    for n in n_values:
        for _ in range(5):  # Ensure at least 30 instances per seed
            graph = generate_random_graph(n)
            d = asymptotic_dimension(graph)
            literals, clauses = tseitin_formula(graph)
            length = resolution_length(clauses)
            total_length += length
            instances_tested += 1
    
    mean_length = total_length / instances_tested
    conjecture_holds = mean_length >= 2 ** (0.5 * d) for d in range(1, n+1)
    
    return {
        "metric_name": "resolution_length",
        "metric_value": mean_length,
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": ""
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_length = sum(r["metric_value"] for r in results) / len(results)
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_length} std=0 support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE reason=insufficient_evidence")