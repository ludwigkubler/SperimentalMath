# Replay package — entry ff6e70f26d3c

Conjecture: Minimal Lattice Point Counting in Algebraic Geometry and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 22:42 UTC.
Pre-registration hash committed before this test ran: `c07dd127f48a64a1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
