# Replay package — entry 9e0cac4cfcf9

Conjecture: Tropical Convex Hull Dimension and ACC^0 Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-07 20:41 UTC.
Pre-registration hash committed before this test ran: `73a63ba2c26a6ad3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
