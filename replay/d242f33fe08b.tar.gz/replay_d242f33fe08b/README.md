# Replay package — entry d242f33fe08b

Conjecture: Separation of Bounded Arithmetic Theories via Proof System Strength

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 09:04 UTC.
Pre-registration hash committed before this test ran: `cebea81244d0d856`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
