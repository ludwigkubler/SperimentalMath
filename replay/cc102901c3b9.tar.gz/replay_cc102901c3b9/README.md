# Replay package — entry cc102901c3b9

Conjecture: Minimal Order of Birational Geometry Invariants Bounds Communication Complexity of AND-OR Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 00:54 UTC.
Pre-registration hash committed before this test ran: `66190de0e3ea8352`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
