import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_k_clique_circuit(n):
        # Generate a random k-clique circuit (simplified version for testing)
        return [random.randint(0, n-1) for _ in range(random.randint(2, 5))]
    
    def compute_automorphism_group_rank(circuit):
        # Simplified computation of automorphism group rank
        return len(set(circuit))
    
    n_values = [5, 10, 15, 20, 30, 40]
    ranks = []
    for n in n_values:
        for _ in range(5):  # Test with 5 instances per n
            circuit = generate_k_clique_circuit(n)
            rank = compute_automorphism_group_rank(circuit)
            ranks.append((n, rank))
    
    mean_rank = sum(rank for _, rank in ranks) / len(ranks)
    f_n = 1099511627776  # Example polynomial function for testing
    
    return {
        "metric_name": "Automorphism Group Rank",
        "metric_value": mean_rank,
        "instances_tested": len(ranks),
        "conjecture_holds": mean_rank >= f_n,
        "counterexample": "" if mean_rank >= f_n else f"n=40, rank={mean_rank}, f(n)={f_n}"
    }

if __name__ == "__main__":
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    results = []
    
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(result["metric_value"] for result in results) / len(results)
    std_value = math.sqrt(sum((result["metric_value"] - mean_value) ** 2 for result in results) / len(results))
    support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)
    
    if all(result["conjecture_holds"] for result in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next((result["seed"] for result in results if not result["conjecture_holds"]), None)
        print(f"RESULT: FALSIFIED counterexample=\"{result['counterexample']}\" first_failing_seed={first_failing_seed}")