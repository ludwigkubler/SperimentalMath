# Replay package — entry 23fb9df5b1a2

Conjecture: Effective-Resistance Diameter Lower-Bounds Tseitin Resolution Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 23:09 UTC.
Pre-registration hash committed before this test ran: `eaf778881616b20f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
