# Replay package — entry 8a4b5190ce3e

Conjecture: Schur-Weyl Duality Invariant for Monotone Permanent vs Determinant

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 13:33 UTC.
Pre-registration hash committed before this test ran: `8a09bb3e9b53638a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
