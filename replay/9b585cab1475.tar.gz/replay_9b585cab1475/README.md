# Replay package — entry 9b585cab1475

Conjecture: Free 4-Cumulant Excess Capped by Stable Rank Lower-Bounds R(DISJ)

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 23:39 UTC.
Pre-registration hash committed before this test ran: `e7e0862eb689a01a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
