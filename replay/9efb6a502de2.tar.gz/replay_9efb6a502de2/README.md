# Replay package — entry 9efb6a502de2

Conjecture: Minimal Modular Form Rank Correlation with SAT Clause Subset Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 00:12 UTC.
Pre-registration hash committed before this test ran: `5844cbbb2217759e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
