# Replay package — entry fc5757929a73

Conjecture: Combinatorial Discrepancy of NW Designs Predicts Generator Bias on Hard Truth Tables

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 21:46 UTC.
Pre-registration hash committed before this test ran: `18aa95790b715802`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
