# Replay package — entry e8bee6ae084a

Conjecture: Coxeter Group Enumeration of Boolean Function Entropy via Invariant Generators

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 23:30 UTC.
Pre-registration hash committed before this test ran: `d50a94545b6412a7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
