# Replay package — entry 86ccf8b95619

Conjecture: Coxeter Group Complexity of SAT Proof Trees via Reflection Posets

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 04:32 UTC.
Pre-registration hash committed before this test ran: `ac2f6a4411d19b8a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
