# Replay package — entry 64d4e5033f85

Conjecture: Minimal Rank of Geometric Quantization over Tseitin Circuit Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 14:05 UTC.
Pre-registration hash committed before this test ran: `98c831422746bb6a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
