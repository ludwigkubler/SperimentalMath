# Replay package — entry a6f2ec052ae4

Conjecture: Minimal Geometric Complexity and DPLL Proof Tree Height

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 06:06 UTC.
Pre-registration hash committed before this test ran: `5f8d9e3010efa0c9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
