# Replay package — entry a93328370e03

Conjecture: Minimal Rank of Twisted Tensor Product Representations over Tseitin Circuit Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 22:56 UTC.
Pre-registration hash committed before this test ran: `69088d0a7f471795`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
