import random
import itertools

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    n = 5  # Number of inputs
    m_values = [10, 20, 30, 40]  # Different numbers of clauses to test
    
    metric_name = "min_galois_representation_order"
    total_orders = []
    conjecture_holds = True
    counterexample = ""
    
    for m in m_values:
        circuit = generate_tseitin_circuit(n, m)
        G = construct_group_action(circuit)
        order = find_minimal_order(G)
        total_orders.append(order)
        
        expected_order = m ** 0.5
        if abs(order - expected_order) / expected_order > 0.2:
            conjecture_holds = False
            counterexample = f"m={m}, order={order}, expected={expected_order}"
    
    mean_value = sum(total_orders) / len(total_orders)
    std_value = (sum((x - mean_value) ** 2 for x in total_orders) / len(total_orders)) ** 0.5
    
    return {
        "metric_name": metric_name,
        "metric_value": mean_value,
        "instances_tested": len(m_values),
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

def generate_tseitin_circuit(n: int, m: int) -> list:
    inputs = [f"x{i}" for i in range(1, n + 1)]
    clauses = []
    
    # Generate literals and their negations
    literals = inputs + [f"~{x}" for x in inputs]
    
    # Generate random clauses
    for _ in range(m):
        clause = random.sample(literals, 2)
        if random.choice([True, False]):
            clause[0] = f"~{clause[0]}"
        if random.choice([True, False]):
            clause[1] = f"~{clause[1]}"
        clauses.append(clause)
    
    return inputs + clauses

def construct_group_action(circuit: list) -> set:
    inputs = circuit[:circuit.index(inputs[-1])]
    G = set()
    
    for perm in itertools.permutations(inputs):
        if is_valid_permutation(perm, circuit):
            G.add(perm)
    
    return G

def is_valid_permutation(perm: tuple, circuit: list) -> bool:
    inputs = circuit[:circuit.index(inputs[-1])]
    for clause in circuit[len(inputs):]:
        literals = [x.strip("~") for x in clause]
        if all(lit not in perm and f"~{lit}" not in perm for lit in literals):
            return False
    return True

def find_minimal_order(G: set) -> int:
    p = 2
    while True:
        found = False
        for g in G:
            if any(all((g[i] == j and g[j] != i) or (g[i] != j and g[j] == i) for i, j in enumerate(range(len(g))))) for g in G):
                found = True
                break
        if not found:
            return p
        p += 1

if __name__ == "__main__":
    import sys
    seeds = [int(x) for x in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    
    results = []
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    mean_value = sum(result["metric_value"] for result in results) / len(results)
    std_value = (sum((result["metric_value"] - mean_value) ** 2 for result in results) / len(results)) ** 0.5
    support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)
    
    if all(result["conjecture_holds"] for result in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(result["seed"] for result in results if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{results[0]['counterexample']}\" first_failing_seed={first_failing_seed}")