# Replay package — entry aae5d5a35296

Conjecture: Minimal Coxeter Group Order Bounds Tree-Like Resolution Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 18:40 UTC.
Pre-registration hash committed before this test ran: `ff14cd95d0e45e23`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
