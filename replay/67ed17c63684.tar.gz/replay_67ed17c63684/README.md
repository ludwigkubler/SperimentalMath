# Replay package — entry 67ed17c63684

Conjecture: p=3 Path-Family Modulus Lower-Bounds Tseitin Tree-Resolution

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 10:26 UTC.
Pre-registration hash committed before this test ran: `04e2619bfa74e099`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
