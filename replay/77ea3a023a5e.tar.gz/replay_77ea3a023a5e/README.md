# Replay package — entry 77ea3a023a5e

Conjecture: Avg-Case DPLL Depth Predicts Worst-Case Width via Quantile Lift

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 12:59 UTC.
Pre-registration hash committed before this test ran: `8522cd84ca7a9728`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
