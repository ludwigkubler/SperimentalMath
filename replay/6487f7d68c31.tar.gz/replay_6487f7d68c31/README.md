# Replay package — entry 6487f7d68c31

Conjecture: Doob Martingale Variance Gap Predicts Worst-Case DPLL Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 07:44 UTC.
Pre-registration hash committed before this test ran: `413a2b83a4a23823`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
