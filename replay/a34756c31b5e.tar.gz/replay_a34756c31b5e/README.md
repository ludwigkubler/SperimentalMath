# Replay package — entry a34756c31b5e

Conjecture: Minimal Diophantine Degree of Boolean Functions and SAT Clause Entropy Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 04:35 UTC.
Pre-registration hash committed before this test ran: `6dd4fe426cd9e7a2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
