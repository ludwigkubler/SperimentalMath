# Replay package — entry 23ccfd6d09c7

Conjecture: Minimal Order of ModularForms over Q(√-19) and Circuit Monotone Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 11:58 UTC.
Pre-registration hash committed before this test ran: `90e6b50a52f4d514`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
