# Replay package — entry 8a09bc5f4a1c

Conjecture: Schur-Weyl Decomposition Complexity of Symmetric Powers of Permanent vs Determinant

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 00:40 UTC.
Pre-registration hash committed before this test ran: `60a67d6e126354b6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
