# Replay package — entry 0c52dba75661

Conjecture: Minimal Order of Formal Language Free Monoids and SAT Clause Subset Entropy Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 10:50 UTC.
Pre-registration hash committed before this test ran: `13eae86263369b8c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
