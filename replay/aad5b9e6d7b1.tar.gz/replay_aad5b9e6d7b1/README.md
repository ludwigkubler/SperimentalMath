# Replay package — entry aad5b9e6d7b1

Conjecture: Free Entropy Gap in Read-Twice Branching Programs for IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-29 15:43 UTC.
Pre-registration hash committed before this test ran: `912a025032b708bb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
