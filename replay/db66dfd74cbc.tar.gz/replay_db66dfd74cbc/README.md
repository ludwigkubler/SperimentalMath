# Replay package — entry db66dfd74cbc

Conjecture: Minimal Order of Automorphism Groups of Affine Schemes and Circuit Monotone Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 19:32 UTC.
Pre-registration hash committed before this test ran: `a14495e2c780c3be`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
