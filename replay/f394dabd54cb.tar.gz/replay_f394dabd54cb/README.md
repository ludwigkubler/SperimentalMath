# Replay package — entry f394dabd54cb

Conjecture: Minimal Local Crossed Module Rank and Tseitin Formula Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 02:31 UTC.
Pre-registration hash committed before this test ran: `9447366ebd0b77c1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
