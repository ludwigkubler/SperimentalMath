# Replay package — entry 0cac01ce9ab0

Conjecture: NW-Design Restriction Dimension Separates Perm from Padded Det

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 04:25 UTC.
Pre-registration hash committed before this test ran: `202ac3d08e8f70f3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
