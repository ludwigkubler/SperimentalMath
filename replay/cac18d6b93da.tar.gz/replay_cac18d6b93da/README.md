# Replay package — entry cac18d6b93da

Conjecture: Minimal Rank of Quasi-Plurality Matrices vs Communication Complexity for Disjointness

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 11:04 UTC.
Pre-registration hash committed before this test ran: `582db75fa3562166`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
