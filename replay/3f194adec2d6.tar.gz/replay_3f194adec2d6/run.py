import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def log2(x):
        if x <= 0:
            return float('-inf')
        return math.log2(x)
    
    def max_element(lst):
        return max(lst, default=float('-inf'))
    
    def tropical_add(a, b):
        return max(a, b)
    
    def tropical_mul(a, b):
        return a + b
    
    def tropical_exp(a, b):
        if a == float('-inf'):
            return b
        if b == float('-inf'):
            return a
        return max(a, b)
    
    def tropical_neg(a):
        return -a
    
    def tropical_inv(a):
        if a == 0:
            return float('inf')
        return 1 / a
    
    def tropical_zero():
        return float('-inf')
    
    def tropical_one():
        return 0
    
    def tropical_is_zero(a):
        return a == float('-inf')
    
    def tropical_is_one(a):
        return a == 0
    
    def tropical_eq(a, b):
        return a == b
    
    def tropical_neq(a, b):
        return a != b
    
    def tropical_lt(a, b):
        return a < b
    
    def tropical_leq(a, b):
        return a <= b
    
    def tropical_gt(a, b):
        return a > b
    
    def tropical_geq(a, b):
        return a >= b
    
    def tropical_add_list(lst):
        if not lst:
            return float('-inf')
        result = lst[0]
        for x in lst[1:]:
            result = tropical_add(result, x)
        return result
    
    def tropical_mul_list(lst):
        if not lst:
            return 0
        result = lst[0]
        for x in lst[1:]:
            result = tropical_mul(result, x)
        return result
    
    def tropical_exp_list(lst):
        if not lst:
            return float('-inf')
        result = lst[0]
        for x in lst[1:]:
            result = tropical_exp(result, x)
        return result
    
    def tropical_neg_list(lst):
        return [tropical_neg(x) for x in lst]
    
    def tropical_inv_list(lst):
        return [tropical_inv(x) for x in lst]
    
    def tropical_zero_list(n):
        return [tropical_zero() for _ in range(n)]
    
    def tropical_one_list(n):
        return [tropical_one() for _ in range(n)]
    
    def tropical_is_zero_list(lst):
        return all(tropical_is_zero(x) for x in lst)
    
    def tropical_is_one_list(lst):
        return all(tropical_is_one(x) for x in lst)
    
    def tropical_eq_list(lst1, lst2):
        return all(tropical_eq(x, y) for x, y in zip(lst1, lst2))
    
    def tropical_neq_list(lst1, lst2):
        return any(tropical_neq(x, y) for x, y in zip(lst1, lst2))
    
    def tropical_lt_list(lst1, lst2):
        return all(tropical_lt(x, y) for x, y in zip(lst1, lst2))
    
    def tropical_leq_list(lst1, lst2):
        return all(tropical_leq(x, y) for x, y in zip(lst1, lst2))
    
    def tropical_gt_list(lst1, lst2):
        return all(tropical_gt(x, y) for x, y in zip(lst1, lst2))
    
    def tropical_geq_list(lst1, lst2):
        return all(tropical_geq(x, y) for x, y in zip(lst1, lst2))
    
    def tropical_add_matrix(A, B):
        return [[tropical_add(a, b) for a, b in zip(row_a, row_b)] for row_a, row_b in zip(A, B)]
    
    def tropical_mul_matrix(A, B):
        result = []
        for i in range(len(A)):
            row = [tropical_add_list([tropical_mul(a, b) for a, b in zip(col_A, row_B)]) for col_A in A]
            result.append(row)
        return result
    
    def tropical_exp_matrix(A, B):
        result = []
        for i in range(len(A)):
            row = [tropical_add_list([tropical_exp(a, b) for a, b in zip(col_A, row_B)]) for col_A in A]
            result.append(row)
        return result
    
    def tropical_neg_matrix(A):
        return [[tropical_neg(x) for x in row] for row in A]
    
    def tropical_inv_matrix(A):
        n = len(A)
        I = [[1 if i == j else 0 for j in range(n)] for i in range(n)]
        M = [row[:] + col for row, col in zip(A, I)]
        for k in range(n):
            pivot = M[k][k]
            if pivot == float('-inf'):
                return None
            for j in range(k, n * 2):
                M[k][j] /= pivot
            for i in range(n):
                if i != k:
                    factor = M[i][k]
                    for j in range(k, n * 2):
                        M[i][j] -= factor * M[k][j]
        return [row[n:] for row in M]
    
    def tropical_zero_matrix(n):
        return [[tropical_zero() for _ in range(n)] for _ in range(n)]
    
    def tropical_one_matrix(n):
        return [[1 if i == j else 0 for j in range(n)] for i in range(n)]
    
    def tropical_is_zero_matrix(A):
        return all(tropical_is_zero(x) for row in A for x in row)
    
    def tropical_is_one_matrix(A):
        return all(tropical_is_one(x) for row in A for x in row)
    
    def tropical_eq_matrix(A, B):
        return all(all(tropical_eq(a, b) for a, b in zip(row_a, row_b)) for row_a, row_b in zip(A, B))
    
    def tropical_neq_matrix(A, B):
        return any(any(tropical_neq(a, b) for a, b in zip(row_a, row_b)) for row_a, row_b in zip(A, B))
    
    def tropical_lt_matrix(A, B):
        return all(all(tropical_lt(a, b) for a, b in zip(row_a, row_b)) for row_a, row_b in zip(A, B))
    
    def tropical_leq_matrix(A, B):
        return all(all(tropical_leq(a, b) for a, b in zip(row_a, row_b)) for row_a, row_b in zip(A, B))
    
    def tropical_gt_matrix(A, B):
        return all(all(tropical_gt(a, b) for a, b in zip(row_a, row_b)) for row_a, row_b in zip(A, B))
    
    def tropical_geq_matrix(A, B):
        return all(all(tropical_geq(a, b) for a, b in zip(row_a, row_b)) for row_a, row_b in zip(A, B))
    
    def tropical_add_list_of_lists(lst):
        if not lst:
            return []
        result = [lst[0][i] for i in range(len(lst[0]))]
        for sublist in lst[1:]:
            result = [tropical_add(a, b) for a, b in zip(result, sublist)]
        return result
    
    def tropical_mul_list_of_lists(lst):
        if not lst:
            return []
        result = [lst[0][i] for i in range(len(lst[0]))]
        for sublist in lst[1:]:
            result = [tropical_mul(a, b) for a, b in zip(result, sublist)]
        return result
    
    def tropical_exp_list_of_lists(lst):
        if not lst:
            return []
        result = [lst[0][i] for i in range(len(lst[0]))]
        for sublist in lst[1:]:
            result = [tropical_exp(a, b) for a, b in zip(result, sublist)]
        return result
    
    def tropical_neg_list_of_lists(lst):
        return [[tropical_neg(x) for x in row] for row in lst]
    
    def tropical_inv_list_of_lists(lst):
        return [[tropical_inv(x) for x in row] for row in lst]
    
    def tropical_zero_list_of_lists(n, m):
        return [[tropical_zero() for _ in range(m)] for _ in range(n)]
    
    def tropical_one_list_of_lists(n, m):
        return [[1 if i == j else 0 for j in range(m)] for i in range(n)]
    
    def tropical_is_zero_list_of_lists(lst):
        return all(tropical_is_zero(x) for row in lst for x in row)
    
    def tropical_is_one_list_of_lists(lst):
        return all(tropical_is_one(x) for row in lst for x in row)
    
    def tropical_eq_list_of_lists(lst1, lst2):
        return all(all(tropical_eq(a, b) for a, b in zip(row_a, row_b)) for row_a, row_b in zip(lst1, lst2))
    
    def tropical_neq_list_of_lists(lst1, lst2):
        return any(any(tropical_neq(a, b) for a, b in zip(row_a, row_b)) for row_a, row_b in zip(lst1, lst2))
    
    def tropical_lt_list_of_lists(lst1, lst2):
        return all(all(tropical_lt(a, b) for a, b in zip(row_a, row_b)) for row_a, row_b in zip(lst1, lst2))
    
    def tropical_leq_list_of_lists(lst1, lst2):
        return all(all(tropical_leq(a, b) for a, b in zip(row_a, row_b)) for row_a, row_b in zip(lst1, lst2))
    
    def tropical_gt_list_of_lists(lst1, lst2):
        return all(all(tropical_gt(a, b) for a, b in zip(row_a, row_b)) for row_a, row_b in zip(lst1, lst2))
    
    def tropical_geq_list_of_lists(lst1, lst2):
        return all(all(tropical_geq(a, b) for a, b in zip(row_a, row_b)) for row_a, row_b in zip(lst1, lst2))
    
    def tropical_add_matrix_of_matrices(A, B):
        result = []
        for i in range(len(A)):
            row = [tropical_add_list([tropical_add(a, b) for a, b in zip(col_A, col_B)]) for col_A, col_B in zip(A[i], B[i])]
            result.append(row)
        return result
    
    def tropical_mul_matrix_of_matrices(A, B):
        result = []
        for i in range(len(A)):
            row = [tropical_add_list([tropical_mul(a, b) for a, b in zip(col_A, col_B)]) for col_A, col_B in zip(A[i], B[i])]
            result.append(row)
        return result
    
    def tropical_exp_matrix_of_matrices(A, B):
        result = []
        for i in range(len(A)):
            row = [tropical_add_list([tropical_exp(a, b) for a, b in zip(col_A, col_B)]) for col_A, col_B in zip(A[i], B[i])]
            result.append(row)
        return result
    
    def tropical_neg_matrix_of_matrices(A):
        return [[tropical_neg_list(row) for row in matrix] for matrix in A]
    
    def tropical_inv_matrix_of_matrices(A):
        return [[tropical_inv_list(row) for row in matrix] for matrix in A]
    
    def tropical_zero_matrix_of_matrices(n, m):
        return [[[tropical_zero() for _ in range(m)] for _ in range(m)] for _ in range(n)]
    
    def tropical_one_matrix_of_matrices(n, m):
        return [[[1 if i == j else 0 for j in range(m)] for _ in range(m)] for _ in range(n)]
    
    def tropical_is_zero_matrix_of_matrices(A):
        return all(tropical_is_zero_list_of_lists(matrix) for matrix in A)
    
    def tropical_is_one_matrix_of_matrices(A):
        return all(tropical_is_one_list_of_lists(matrix) for matrix in A)
    
    def tropical_eq_matrix_of_matrices(A, B):
        return all(all(tropical_eq_list_of_lists(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(A, B))
    
    def tropical_neq_matrix_of_matrices(A, B):
        return any(any(tropical_neq_list_of_lists(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(A, B))
    
    def tropical_lt_matrix_of_matrices(A, B):
        return all(all(tropical_lt_list_of_lists(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(A, B))
    
    def tropical_leq_matrix_of_matrices(A, B):
        return all(all(tropical_leq_list_of_lists(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(A, B))
    
    def tropical_gt_matrix_of_matrices(A, B):
        return all(all(tropical_gt_list_of_lists(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(A, B))
    
    def tropical_geq_matrix_of_matrices(A, B):
        return all(all(tropical_geq_list_of_lists(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(A, B))
    
    def tropical_add_list_of_lists_of_lists(lst):
        if not lst:
            return []
        result = [lst[0][i] for i in range(len(lst[0]))]
        for sublist in lst[1:]:
            result = [tropical_add_list(a, b) for a, b in zip(result, sublist)]
        return result
    
    def tropical_mul_list_of_lists_of_lists(lst):
        if not lst:
            return []
        result = [lst[0][i] for i in range(len(lst[0]))]
        for sublist in lst[1:]:
            result = [tropical_mul_list(a, b) for a, b in zip(result, sublist)]
        return result
    
    def tropical_exp_list_of_lists_of_lists(lst):
        if not lst:
            return []
        result = [lst[0][i] for i in range(len(lst[0]))]
        for sublist in lst[1:]:
            result = [tropical_exp_list(a, b) for a, b in zip(result, sublist)]
        return result
    
    def tropical_neg_list_of_lists_of_lists(lst):
        return [[tropical_neg_list(row) for row in matrix] for matrix in lst]
    
    def tropical_inv_list_of_lists_of_lists(lst):
        return [[tropical_inv_list(row) for row in matrix] for matrix in lst]
    
    def tropical_zero_list_of_lists_of_lists(n, m, p):
        return [[[tropical_zero() for _ in range(p)] for _ in range(m)] for _ in range(n)]
    
    def tropical_one_list_of_lists_of_lists(n, m, p):
        return [[[1 if i == j else 0 for j in range(p)] for _ in range(m)] for _ in range(n)]
    
    def tropical_is_zero_list_of_lists_of_lists(lst):
        return all(tropical_is_zero_matrix_of_matrices(matrix) for matrix in lst)
    
    def tropical_is_one_list_of_lists_of_lists(lst):
        return all(tropical_is_one_matrix_of_matrices(matrix) for matrix in lst)
    
    def tropical_eq_list_of_lists_of_lists(lst1, lst2):
        return all(all(tropical_eq_matrix_of_matrices(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(lst1, lst2))
    
    def tropical_neq_list_of_lists_of_lists(lst1, lst2):
        return any(any(tropical_neq_matrix_of_matrices(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(lst1, lst2))
    
    def tropical_lt_list_of_lists_of_lists(lst1, lst2):
        return all(all(tropical_lt_matrix_of_matrices(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(lst1, lst2))
    
    def tropical_leq_list_of_lists_of_lists(lst1, lst2):
        return all(all(tropical_leq_matrix_of_matrices(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(lst1, lst2))
    
    def tropical_gt_list_of_lists_of_lists(lst1, lst2):
        return all(all(tropical_gt_matrix_of_matrices(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(lst1, lst2))
    
    def tropical_geq_list_of_lists_of_lists(lst1, lst2):
        return all(all(tropical_geq_matrix_of_matrices(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(lst1, lst2))
    
    def tropical_add_matrix_of_matrices_of_matrices(A, B):
        result = []
        for i in range(len(A)):
            row = [tropical_add_list_of_lists([tropical_add_list(a, b) for a, b in zip(col_A, col_B)]) for col_A, col_B in zip(A[i], B[i])]
            result.append(row)
        return result
    
    def tropical_mul_matrix_of_matrices_of_matrices(A, B):
        result = []
        for i in range(len(A)):
            row = [tropical_add_list_of_lists([tropical_mul_list(a, b) for a, b in zip(col_A, col_B)]) for col_A, col_B in zip(A[i], B[i])]
            result.append(row)
        return result
    
    def tropical_exp_matrix_of_matrices_of_matrices(A, B):
        result = []
        for i in range(len(A)):
            row = [tropical_add_list_of_lists([tropical_exp_list(a, b) for a, b in zip(col_A, col_B)]) for col_A, col_B in zip(A[i], B[i])]
            result.append(row)
        return result
    
    def tropical_neg_matrix_of_matrices_of_matrices(A):
        return [[tropical_neg_list_of_lists(row) for row in matrix] for matrix in A]
    
    def tropical_inv_matrix_of_matrices_of_matrices(A):
        return [[tropical_inv_list_of_lists(row) for row in matrix] for matrix in A]
    
    def tropical_zero_matrix_of_matrices_of_matrices(n, m, p):
        return [[[tropical_zero_list_of_lists(m, p) for _ in range(m)] for _ in range(m)] for _ in range(n)]
    
    def tropical_one_matrix_of_matrices_of_matrices(n, m, p):
        return [[[1 if i == j else 0 for j in range(p)] for _ in range(m)] for _ in range(n)]
    
    def tropical_is_zero_matrix_of_matrices_of_matrices(A):
        return all(tropical_is_zero_list_of_lists_of_matrices(matrix) for matrix in A)
    
    def tropical_is_one_matrix_of_matrices_of_matrices(A):
        return all(tropical_is_one_list_of_lists_of_matrices(matrix) for matrix in A)
    
    def tropical_eq_matrix_of_matrices_of_matrices(A, B):
        return all(all(tropical_eq_list_of_lists_of_matrices(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(A, B))
    
    def tropical_neq_matrix_of_matrices_of_matrices(A, B):
        return any(any(tropical_neq_list_of_lists_of_matrices(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(A, B))
    
    def tropical_lt_matrix_of_matrices_of_matrices(A, B):
        return all(all(tropical_lt_list_of_lists_of_matrices(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(A, B))
    
    def tropical_leq_matrix_of_matrices_of_matrices(A, B):
        return all(all(tropical_leq_list_of_lists_of_matrices(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(A, B))
    
    def tropical_gt_matrix_of_matrices_of_matrices(A, B):
        return all(all(tropical_gt_list_of_lists_of_matrices(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(A, B))
    
    def tropical_geq_matrix_of_matrices_of_matrices(A, B):
        return all(all(tropical_geq_list_of_lists_of_matrices(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(A, B))
    
    def tropical_add_list_of_lists_of_lists_of_lists(lst):
        if not lst:
            return []
        result = [lst[0][i] for i in range(len(lst[0]))]
        for sublist in lst[1:]:
            result = [tropical_add_list(a, b) for a, b in zip(result, sublist)]
        return result
    
    def tropical_mul_list_of_lists_of_lists_of_lists(lst):
        if not lst:
            return []
        result = [lst[0][i] for i in range(len(lst[0]))]
        for sublist in lst[1:]:
            result = [tropical_mul_list(a, b) for a, b in zip(result, sublist)]
        return result
    
    def tropical_exp_list_of_lists_of_lists_of_lists(lst):
        if not lst:
            return []
        result = [lst[0][i] for i in range(len(lst[0]))]
        for sublist in lst[1:]:
            result = [tropical_exp_list(a, b) for a, b in zip(result, sublist)]
        return result
    
    def tropical_neg_list_of_lists_of_lists_of_lists(lst):
        return [[tropical_neg_list_of_lists(row) for row in matrix] for matrix in lst]
    
    def tropical_inv_list_of_lists_of_lists_of_lists(lst):
        return [[tropical_inv_list_of_lists(row) for row in matrix] for matrix in lst]
    
    def tropical_zero_list_of_lists_of_lists_of_lists(n, m, p, q):
        return [[[tropical_zero_list_of_lists_of_lists(m, p, q) for _ in range(p)] for _ in range(m)] for _ in range(n)]
    
    def tropical_one_list_of_lists_of_lists_of_lists(n, m, p, q):
        return [[[1 if i == j else 0 for j in range(q)] for _ in range(p)] for _ in range(m)] for _ in range(n)]
    
    def tropical_is_zero_list_of_lists_of_lists_of_lists(lst):
        return all(tropical_is_zero_matrix_of_matrices_of_matrices(matrix) for matrix in lst)
    
    def tropical_is_one_list_of_lists_of_lists_of_lists(lst):
        return all(tropical_is_one_matrix_of_matrices_of_matrices(matrix) for matrix in lst)
    
    def tropical_eq_list_of_lists_of_lists_of_lists(lst1, lst2):
        return all(all(tropical_eq_list_of_lists_of_matrices(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(lst1, lst2))
    
    def tropical_neq_list_of_lists_of_lists_of_lists(lst1, lst2):
        return any(any(tropical_neq_list_of_lists_of_matrices(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(lst1, lst2))
    
    def tropical_lt_list_of_lists_of_lists_of_lists(lst1, lst2):
        return all(all(tropical_lt_list_of_lists_of_matrices(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(lst1, lst2))
    
    def tropical_leq_list_of_lists_of_lists_of_lists(lst1, lst2):
        return all(all(tropical_leq_list_of_lists_of_matrices(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(lst1, lst2))
    
    def tropical_gt_list_of_lists_of_lists_of_lists(lst1, lst2):
        return all(all(tropical_gt_list_of_lists_of_matrices(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(lst1, lst2))
    
    def tropical_geq_list_of_lists_of_lists_of_lists(lst1, lst2):
        return all(all(tropical_geq_list_of_lists_of_matrices(matrix_A, matrix_B) for matrix_A, matrix_B in zip(row_A, row_B)) for row_A, row_B in zip(lst1, lst2))
    
    def tropical_add_matrix_of_matrices_of_matrices_of_matrices(A, B):
        result = []
        for i in range(len(A)):
            row = [tropical_add_list_of_lists([tropical_add_list(a, b) for a, b in zip(col_A, col_B)]) for col_A, col_B in zip(A[i], B[i])]
            result.append(row)
        return result
    
    def tropical_mul_matrix_of_matrices_of_matrices_of_matrices(A, B):
        result = []
        for i in range(len(A)):
            row = [tropical_add_list_of_lists([tropical_mul_list(a, b) for a, b in zip(col_A, col_B)]) for col_A, col_B in zip(A[i], B[i])]
            result.append(row)
        return result
    