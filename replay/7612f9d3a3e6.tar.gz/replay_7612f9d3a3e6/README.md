# Replay package — entry 7612f9d3a3e6

Conjecture: Minimal p-adic Order of Meromorphic Functions and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 00:19 UTC.
Pre-registration hash committed before this test ran: `40061436d945eadf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
