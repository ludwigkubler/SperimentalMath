# Replay package — entry 34d3f49fa5f1

Conjecture: Toric Polytope Facet Count and Resolution Width Scaling

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 11:20 UTC.
Pre-registration hash committed before this test ran: `d01d9f697524bb8e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
