# Replay package — entry ee20adc65b32

Conjecture: Minimal Rank of Tropicalized Graph Laplacians vs DPLL Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 22:15 UTC.
Pre-registration hash committed before this test ran: `cb5f4bacfe6ab6bb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
