# Replay package — entry 55903661e64a

Conjecture: Möbius Mass of Rectangle Poset Lower-Bounds D^cc

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 09:52 UTC.
Pre-registration hash committed before this test ran: `6db141f64279a717`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
