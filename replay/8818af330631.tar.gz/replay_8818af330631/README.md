# Replay package — entry 8818af330631

Conjecture: Free Cumulant Gap in Read-Twice BPs for 3-SAT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 23:54 UTC.
Pre-registration hash committed before this test ran: `dde6a2257101bee5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
