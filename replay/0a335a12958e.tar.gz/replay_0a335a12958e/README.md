# Replay package — entry 0a335a12958e

Conjecture: Minimal Rank of Geometric Entanglement vs Decision Tree Width for Monotone XOR Circuits

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 21:04 UTC.
Pre-registration hash committed before this test ran: `7401d3c18d8cec72`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
