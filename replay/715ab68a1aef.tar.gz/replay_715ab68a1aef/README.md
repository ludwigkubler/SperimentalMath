# Replay package — entry 715ab68a1aef

Conjecture: Spectral Gap Determines Tseitin Resolution Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 11:20 UTC.
Pre-registration hash committed before this test ran: `1d5d0ef2e4af6994`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
