# Replay package — entry 05788ae7f62f

Conjecture: Minimal Rank of Hodge Classes over Non-Archimedean Valuations vs Tseitin Formula Resolution Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 08:33 UTC.
Pre-registration hash committed before this test ran: `be6e2224effd0d36`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
