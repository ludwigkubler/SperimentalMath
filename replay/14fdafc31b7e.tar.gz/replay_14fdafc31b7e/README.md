# Replay package — entry 14fdafc31b7e

Conjecture: Selberg Log-Gas Rigidity Defect Bounds SOS-2 Max-CUT Gap

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 11:07 UTC.
Pre-registration hash committed before this test ran: `aa56ae9c9e7f0cfa`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
