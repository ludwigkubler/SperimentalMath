# Replay package — entry 2e386440ed69

Conjecture: Minimal Rank of Geometrically Defined Lattices vs. Quantum Circuit Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 20:09 UTC.
Pre-registration hash committed before this test ran: `fd1572f2c2a04301`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
