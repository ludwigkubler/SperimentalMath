# Replay package — entry 70f7934d1090

Conjecture: Minimal Order of Formal Power Series over Boolean Rings vs DPLL Search Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 02:17 UTC.
Pre-registration hash committed before this test ran: `da9f5c5881a7785f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
