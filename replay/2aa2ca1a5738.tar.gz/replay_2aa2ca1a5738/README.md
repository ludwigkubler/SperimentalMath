# Replay package — entry 2aa2ca1a5738

Conjecture: Minimal Symplectic Leaf Order Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 22:29 UTC.
Pre-registration hash committed before this test ran: `e7a74a9b1a12b8ef`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
