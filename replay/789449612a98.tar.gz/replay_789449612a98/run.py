import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_read_twice_bp(n):
        # Generate a random read-twice BP with n variables
        bp = {}
        for i in range(1, n + 1):
            bp[i] = {'inputs': [random.choice(range(1, n + 1))], 'output': random.randint(1, n)}
        return bp
    
    def tensor_product_rank(bp, n):
        # Compute the minimal noncommutative tensor product rank for a read-twice BP
        # This is a placeholder implementation; replace with actual computation
        return sum(len(bp[i]['inputs']) for i in range(1, n + 1))
    
    n = random.randint(5, 40)
    bp = generate_read_twice_bp(n)
    rank = tensor_product_rank(bp, n)
    
    conjectured_bound = n**2  # Placeholder polynomial bound
    
    return {
        "metric_name": "tensor_product_rank",
        "metric_value": rank,
        "instances_tested": 1,
        "conjecture_holds": rank <= conjectured_bound,
        "counterexample": "" if rank <= conjectured_bound else f"Rank {rank} exceeds bound {conjectured_bound}"
    }

if __name__ == "__main__":
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    results = []
    
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {{\"seed\": {seed}, **{trial_result}}}")
        results.append(trial_result)
    
    mean_rank = sum(result["metric_value"] for result in results) / len(results)
    support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)
    
    if all(result["conjecture_holds"] for result in results):
        print(f"RESULT: SUPPORTED mean={mean_rank} std=0.0 support_fraction=1.0")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_rank} std=0.0 support_fraction={support_fraction}")
    else:
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"Rank exceeds bound\" first_failing_seed={first_failing_seed}")