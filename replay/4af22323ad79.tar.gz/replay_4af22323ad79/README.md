# Replay package — entry 4af22323ad79

Conjecture: [c003b_cumulative_entropy/SC4#c15] Φ under a BAD elimination order (max-occurrence) exceeds Φ under min-occurrence by a factor growing in n (order-sensitivity of cumulative entropy).

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 13:53 UTC.
Pre-registration hash committed before this test ran: `2579c8942222bbf4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
