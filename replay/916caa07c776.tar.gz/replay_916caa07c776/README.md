# Replay package — entry 916caa07c776

Conjecture: Tensor-Amplified Asdim Forces Linear Communication Blow-up on Inner-Product Gadgets

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 10:39 UTC.
Pre-registration hash committed before this test ran: `98db1b6cf2d582ea`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
