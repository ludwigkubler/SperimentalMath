# Replay package — entry 39665084879a

Conjecture: Minimal Monomial Degree Invariant of Matroid Polynomials vs Permanent Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 20:40 UTC.
Pre-registration hash committed before this test ran: `a11ca845471dcb1c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
