# Replay package — entry 60871d321cb3

Conjecture: Minimal Rank of Quadratic Forms over SAT Instances Bounds Resolution Refutation Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 15:55 UTC.
Pre-registration hash committed before this test ran: `9ea12d32a5518f27`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
