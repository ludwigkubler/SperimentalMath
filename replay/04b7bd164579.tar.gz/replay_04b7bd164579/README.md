# Replay package — entry 04b7bd164579

Conjecture: Minimal Tropical Hermitian Rank vs Monotone KW Protocol Cost

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 04:20 UTC.
Pre-registration hash committed before this test ran: `8b6eba2a687eb4f4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
