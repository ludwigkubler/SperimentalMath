# Replay package — entry 614c06db4715

Conjecture: Gröbner Basis Step Count vs. Extended Frege Proof Length for 3-SAT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-13 06:23 UTC.
Pre-registration hash committed before this test ran: `8e260346e5573ec2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
