# Replay package — entry f396eea2e602

Conjecture: Minimal Hodge Dimension vs. SAT Clause Set Entropy Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 05:28 UTC.
Pre-registration hash committed before this test ran: `80ef7fe485aba909`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
