# Replay package — entry 92fd6d49bb0c

Conjecture: Minimal Rank of p-Adic L-Function Values vs DPLL Refutation Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 07:28 UTC.
Pre-registration hash committed before this test ran: `df7a750f865bebfd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
