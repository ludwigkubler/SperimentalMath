# Replay package — entry 019706cec8c4

Conjecture: Minimal Rank of Noncommutative Tensor Product Bounds DISJ CC_R

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 15:04 UTC.
Pre-registration hash committed before this test ran: `2da2488f6b68b24b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
