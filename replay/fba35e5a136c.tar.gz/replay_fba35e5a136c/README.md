# Replay package — entry fba35e5a136c

Conjecture: Grothendieck-Riemann-Roch Theorem and Resolution Tree Width for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 13:10 UTC.
Pre-registration hash committed before this test ran: `d231a45386fd892d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
