import random
import math

def generate_random_cnf(n, m):
    cnf = []
    for _ in range(m):
        clause = [random.randint(1, n) * (-1 if random.choice([True, False]) else 1)
                   for _ in range(random.randint(1, n))]
        cnf.append(clause)
    return cnf

def compute_k0_rank(cnf):
    n = max(abs(lit) for lit in sum(cnf, []))
    rank = sum(1 for clause in cnf if any(lit in clause for lit in [-i, i] for i in range(1, n+1)))
    return rank

def compute_correlation_coefficient(x, y):
    n = len(x)
    mean_x = sum(x) / n
    mean_y = sum(y) / n
    numerator = sum((x[i] - mean_x) * (y[i] - mean_y) for i in range(n))
    denominator = math.sqrt(sum((x[i] - mean_x)**2 for i in range(n))) * math.sqrt(sum((y[i] - mean_y)**2 for i in range(n)))
    return numerator / denominator if denominator != 0 else 0

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n_values = [5, 10, 15, 20, 30, 40]
    ranks = []
    complexities = []

    for n in n_values:
        cnf = generate_random_cnf(n, n * (n - 1) // 2)
        rank = compute_k0_rank(cnf)
        complexity = len(cnf)

        if rank is None or complexity is None:
            return {
                "metric_name": "K0 Rank vs Clause Set Complexity",
                "metric_value": None,
                "instances_tested": len(n_values),
                "n_max": n,
                "conjecture_holds": False,
                "counterexample": "mapping_undefined"
            }

        ranks.append(rank)
        complexities.append(complexity)

    correlation_coefficient = compute_correlation_coefficient(ranks, complexities)
    conjecture_holds = -0.7 < correlation_coefficient < 0.7

    return {
        "metric_name": "K0 Rank vs Clause Set Complexity",
        "metric_value": correlation_coefficient,
        "instances_tested": len(n_values),
        "n_max": max(n_values),
        "conjecture_holds": conjecture_holds,
        "counterexample": "" if conjecture_holds else f"Correlation coefficient: {correlation_coefficient}"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2**i + 3 for i in range(5, 30)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {{\"seed\": {seed}, ...{result}...}}")
        results.append(result)

    if all("conjecture_holds": True for result in results):
        mean_value = sum(result["metric_value"] for result in results) / len(results)
        std_value = math.sqrt(sum((result["metric_value"] - mean_value)**2 for result in results) / len(results))
        support_fraction = 1.0
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(result["conjecture_holds"] is False for result in results):
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{result['counterexample']}\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE")