# Replay package — entry 567149797f34

Conjecture: Symmetric Power Partition Dominance in Permanent vs Determinant

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 04:01 UTC.
Pre-registration hash committed before this test ran: `01b7f3c89ef7fa41`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
