# Replay package — entry 442fde4ed66c

Conjecture: Minimal Order of Quaternion Algebras Bounds Monotone Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 02:43 UTC.
Pre-registration hash committed before this test ran: `db45072b547871c3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
