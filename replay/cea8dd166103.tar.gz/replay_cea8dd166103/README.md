# Replay package — entry cea8dd166103

Conjecture: Minimal Geometric Entropy Correlation with SAT Clause Set Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 03:54 UTC.
Pre-registration hash committed before this test ran: `ce6dc9f2534751be`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
