# Replay package — entry c7c90e3a1f6a

Conjecture: Forman-Ricci Overlap-Gap of k-Clique Minterm DNF at v=10

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 10:15 UTC.
Pre-registration hash committed before this test ran: `d7bbf9e0c0015586`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
