# Replay package — entry 852aae70e60d

Conjecture: Minimal Rank of Tropicalized Tensor Products vs Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 22:34 UTC.
Pre-registration hash committed before this test ran: `c564dd7664d6ef16`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
