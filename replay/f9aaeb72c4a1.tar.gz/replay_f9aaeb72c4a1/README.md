# Replay package — entry f9aaeb72c4a1

Conjecture: Minimal Order of Affine Group Representations Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 12:39 UTC.
Pre-registration hash committed before this test ran: `e50fc0b2e5ccb07b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
