# Replay package — entry d4eec86b103f

Conjecture: Minimal Rank of Tropicalized Cohomology vs BP_ReadTwice Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 18:49 UTC.
Pre-registration hash committed before this test ran: `aa79646c0206a0ff`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
