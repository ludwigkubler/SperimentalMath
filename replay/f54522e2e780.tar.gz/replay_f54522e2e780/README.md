# Replay package — entry f54522e2e780

Conjecture: Real Radical Rank Bounds SOS Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 04:05 UTC.
Pre-registration hash committed before this test ran: `5e26d181c3fe59ea`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
