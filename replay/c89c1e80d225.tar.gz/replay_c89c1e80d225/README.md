# Replay package — entry c89c1e80d225

Conjecture: Standard Young Tableau Count Exponential Gap in Symmetric Power Decompositions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 22:50 UTC.
Pre-registration hash committed before this test ran: `fcc3b451ceec5f27`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
