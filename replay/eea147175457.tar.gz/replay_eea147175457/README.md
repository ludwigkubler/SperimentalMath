# Replay package — entry eea147175457

Conjecture: Free Entropy Distinguishes Read-Twice BPs from IP_2 Trivial Ones

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 09:46 UTC.
Pre-registration hash committed before this test ran: `aa8863f355b9ad77`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
