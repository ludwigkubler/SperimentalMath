# Replay package — entry f47dfc600029

Conjecture: Minimal Rank of Brauer Groups over Tseitin Circuit Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 04:14 UTC.
Pre-registration hash committed before this test ran: `7b5039ace1c18493`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
