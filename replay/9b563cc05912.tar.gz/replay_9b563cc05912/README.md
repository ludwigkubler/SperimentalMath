# Replay package — entry 9b563cc05912

Conjecture: Minimal Rank of Tropicalized K-Theory over Boolean Algebras vs AC0 Parity Circuit Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 06:22 UTC.
Pre-registration hash committed before this test ran: `2855436239f29567`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
