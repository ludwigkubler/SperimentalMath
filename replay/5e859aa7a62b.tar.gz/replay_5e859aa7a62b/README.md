# Replay package — entry 5e859aa7a62b

Conjecture: Minimal Tropical Symmetry Length and DPLL Proof Path Length Lower Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 06:58 UTC.
Pre-registration hash committed before this test ran: `9acd891d3e3c3ff9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
