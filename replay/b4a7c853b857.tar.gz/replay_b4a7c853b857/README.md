# Replay package — entry b4a7c853b857

Conjecture: SOS Degree Lower Bound via Matroid Polytope Dimension

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 16:28 UTC.
Pre-registration hash committed before this test ran: `73ce9fdc25432a41`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
