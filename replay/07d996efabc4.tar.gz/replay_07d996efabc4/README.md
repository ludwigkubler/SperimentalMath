# Replay package — entry 07d996efabc4

Conjecture: Minimal Symplectic Rank and K-Complexity of Polynomial Systems

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 05:57 UTC.
Pre-registration hash committed before this test ran: `4eb1614a845c396d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
