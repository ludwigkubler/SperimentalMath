# Replay package — entry ddb7308a1b57

Conjecture: Minimal p-adic Order of Formal Power Series and Circuit Entanglement Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 20:25 UTC.
Pre-registration hash committed before this test ran: `f82bfac03fd886fd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
