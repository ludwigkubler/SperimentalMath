# Replay package — entry 1bd98cba5be4

Conjecture: Minimal Rank of Birational Geometry Bounds Communication Complexity of DISJOINTNESS

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 22:21 UTC.
Pre-registration hash committed before this test ran: `ad8da27905bbb3f0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
