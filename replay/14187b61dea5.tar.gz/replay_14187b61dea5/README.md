# Replay package — entry 14187b61dea5

Conjecture: Orbit Closure Dimension Separation for Determinant vs Permanent

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 07:08 UTC.
Pre-registration hash committed before this test ran: `d5365964051931ed`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
