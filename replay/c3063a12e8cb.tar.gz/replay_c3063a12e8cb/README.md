# Replay package — entry c3063a12e8cb

Conjecture: Minimal Rank of Quadratic Forms vs Boolean Tensor Product Valuations

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 07:30 UTC.
Pre-registration hash committed before this test ran: `a1b7aa4ec29c2da6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
