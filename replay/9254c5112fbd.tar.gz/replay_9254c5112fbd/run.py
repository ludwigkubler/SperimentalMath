import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_truth_table(n):
        return [random.choice([0, 1]) for _ in range(2**n)]
    
    def truth_table_to_coxeter_order(truth_table):
        n = int(math.log2(len(truth_table)))
        # Simplified Coxeter group order calculation based on the number of variables
        return (n * (n + 1)) // 2
    
    def log_squared(n):
        return math.log2(n) ** 2
    
    instances_tested = 0
    total_ratio = 0.0
    n_max = 1
    
    for _ in range(30):  # Ensure at least 30 instances per seed
        n = random.randint(5, 40)
        if n > n_max:
            n_max = n
        
        truth_table = generate_truth_table(n)
        coxeter_order_val = truth_table_to_coxeter_order(truth_table)
        log2_n_squared = log_squared(n)
        
        instances_tested += 1
        total_ratio += coxeter_order_val / log2_n_squared
    
    mean_ratio = total_ratio / instances_tested
    conjecture_holds = 0.8 <= mean_ratio <= 1.2
    
    return {
        "metric_name": "mean_coxeter_order_over_log2n_squared",
        "metric_value": mean_ratio,
        "instances_tested": instances_tested,
        "n_max": n_max,
        "conjecture_holds": conjecture_holds,
        "counterexample": "" if conjecture_holds else "mapping_undefined"
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] or [2**i - 1 for i in range(5, 30)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_ratio = sum(r["metric_value"] for r in results) / len(results)
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_ratio} std=0.0 support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_ratio} std=0.0 support_fraction={support_fraction}")
    else:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample='mapping_undefined' first_failing_seed={first_failing_seed}")