# Replay package — entry e78d7cc91f22

Conjecture: Schur-Weyl Duality and Permanent vs Determinant Circuit Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 19:47 UTC.
Pre-registration hash committed before this test ran: `0fa2d2b97217ddff`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
