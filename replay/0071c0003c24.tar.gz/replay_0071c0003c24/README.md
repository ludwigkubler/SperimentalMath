# Replay package — entry 0071c0003c24

Conjecture: Communication Matrix Rank Lower Bounds ABP Size for Boolean Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 07:42 UTC.
Pre-registration hash committed before this test ran: `2887b1a5d77a132d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
