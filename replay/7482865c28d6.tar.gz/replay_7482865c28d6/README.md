# Replay package — entry 7482865c28d6

Conjecture: Monotone DNF Row Rank Lower Bound for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 23:39 UTC.
Pre-registration hash committed before this test ran: `f04ec4a7c5f6da4f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
