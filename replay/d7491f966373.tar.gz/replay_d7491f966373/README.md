# Replay package — entry d7491f966373

Conjecture: Minimal Local Index of GeometricALLY Enriched Group Actions Bounds Circuit Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 13:36 UTC.
Pre-registration hash committed before this test ran: `8985341a1b83fc5d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
