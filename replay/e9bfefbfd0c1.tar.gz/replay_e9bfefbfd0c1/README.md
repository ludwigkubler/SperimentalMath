# Replay package — entry e9bfefbfd0c1

Conjecture: Free Entropy Inverse Proportionality to Disjointness Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 00:51 UTC.
Pre-registration hash committed before this test ran: `672841dc47438257`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
