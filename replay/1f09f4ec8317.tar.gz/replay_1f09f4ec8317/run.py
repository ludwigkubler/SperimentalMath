import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def is_prime(n):
        if n <= 1:
            return False
        for i in range(2, int(math.sqrt(n)) + 1):
            if n % i == 0:
                return False
        return True
    
    def generate_3sat_instance(n):
        clauses = []
        for _ in range(n * 3):
            variables = random.sample(range(n), 3)
            clause = [f"x{v}" for v in variables] + ["1"]
            clauses.append(" + ".join(clause) + " = 0")
        return " & ".join(clauses)
    
    def gf2_polynomial_to_matrix(poly):
        n = len(poly)
        matrix = [[0] * (n + 1) for _ in range(n + 1)]
        for term in poly.split(" + "):
            if term == "1":
                continue
            variables = [int(v[1:]) for v in term.split("+") if v.startswith("x")]
            for i in variables:
                matrix[i][i] += 1
            for i in range(n):
                if i not in variables:
                    matrix[n][i] -= 1
        return matrix
    
    def gaussian_elimination(matrix):
        n = len(matrix)
        for i in range(n):
            max_row = i
            for j in range(i + 1, n):
                if abs(matrix[j][i]) > abs(matrix[max_row][i]):
                    max_row = j
            matrix[i], matrix[max_row] = matrix[max_row], matrix[i]
            factor = matrix[i][i]
            for j in range(n + 1):
                matrix[i][j] /= factor
            for j in range(n):
                if j != i:
                    factor = matrix[j][i]
                    for k in range(n + 1):
                        matrix[j][k] -= factor * matrix[i][k]
        return matrix
    
    def rank(matrix):
        n = len(matrix)
        row echelon_form = gaussian_elimination(matrix)
        rank = 0
        for i in range(n):
            if any(row[i] != 0 for row in row_echelon_form[:i+1]):
                rank += 1
        return rank
    
    def irreducible_components(poly):
        matrix = gf2_polynomial_to_matrix(poly)
        return rank(matrix)
    
    def sos_refutation_degree(poly):
        # Placeholder for actual SOS refutation degree calculation
        # This is a dummy implementation for demonstration purposes
        return len(poly.split(" + ")) - 1
    
    n = random.choice([5, 10, 15, 20, 30, 40])
    instance = generate_3sat_instance(n)
    components = irreducible_components(instance)
    degree = sos_refutation_degree(instance)
    
    if degree == 0:
        return {
            "metric_name": "irreducible_components",
            "metric_value": None,
            "instances_tested": 1,
            "conjecture_holds": False,
            "counterexample": "sos_refutation_degree_undefined"
        }
    
    metric_value = components / degree**2
    
    return {
        "metric_name": "irreducible_components",
        "metric_value": metric_value,
        "instances_tested": 1,
        "conjecture_holds": abs(metric_value - 1) < 0.1,  # Arbitrary tolerance
        "counterexample": ""
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2**i + 1 for i in range(5, 35)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    metric_values = [r["metric_value"] for r in results if r["metric_value"] is not None]
    support_fraction = sum(r["conjecture_holds"] for r in results) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={sum(metric_values)/len(metric_values):.2f} std={math.sqrt(sum((x - sum(metric_values)/len(metric_values))**2 for x in metric_values) / len(metric_values)):.2f} support_fraction=1.0")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={sum(metric_values)/len(metric_values):.2f} std={math.sqrt(sum((x - sum(metric_values)/len(metric_values))**2 for x in metric_values) / len(metric_values)):.2f} support_fraction={support_fraction:.2f}")
    else:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"mapping_undefined\" first_failing_seed={first_failing_seed}")