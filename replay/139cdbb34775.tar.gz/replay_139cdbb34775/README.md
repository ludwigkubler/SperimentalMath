# Replay package — entry 139cdbb34775

Conjecture: Bregman-Minc Permanent Defect Lower-Bounds SOS-2 Max-Cut Gap on Triangle-Free Cubic Graphs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 11:00 UTC.
Pre-registration hash committed before this test ran: `8dc75cf5c80b0837`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
