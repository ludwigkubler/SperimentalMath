# Replay package — entry a65db1164c92

Conjecture: Symmetric Tensor Rank Gap in Permanent vs Determinant Decompositions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 23:33 UTC.
Pre-registration hash committed before this test ran: `4469b4d56528f701`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
