# Replay package — entry 5e57ec20e58b

Conjecture: Minimal Local Indeterminacy in Quantum Information Geometry and Circuit Monotone Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 05:25 UTC.
Pre-registration hash committed before this test ran: `82017ef455aa425a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
