import random
import math

def generate_sat_instance(n):
    clauses = []
    for _ in range(2 * n):
        clause = [random.choice([-1, 1]) * (i + 1) for i in range(n)]
        clauses.append(clause)
    return clauses

def construct_quandle(clauses):
    quandle = {}
    for clause in clauses:
        key = tuple(sorted([abs(x) for x in clause]))
        if key not in quandle:
            quandle[key] = set()
        for i, x in enumerate(clause):
            for j, y in enumerate(clause):
                if i != j and (x > 0 and y < 0 or x < 0 and y > 0):
                    quandle[key].add((abs(x), abs(y)))
    return quandle

def order_of_quandle(quandle):
    visited = set()
    def dfs(node, path):
        if node in visited:
            return len(path)
        visited.add(node)
        max_length = 1
        for neighbor in quandle[node]:
            max_length = max(max_length, dfs(neighbor, path + [node]))
        visited.remove(node)
        return max_length
    order = 0
    for node in quandle:
        if node not in visited:
            order += dfs(node, [])
    return order

def clause_complexity(clauses):
    return len(clauses)

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n_values = [5, 10, 15, 20, 30, 40]
    quandle_orders = []
    clause complexities = []
    
    for n in n_values:
        clauses = generate_sat_instance(n)
        quandle = construct_quandle(clauses)
        quandle_order = order_of_quandle(quandle)
        clause_complexity_val = clause_complexity(clauses)
        
        quandle_orders.append(quandle_order)
        clause complexities.append(clause_complexity_val)
    
    correlation_coefficient = sum((x - mean_x) * (y - mean_y) for x, y in zip(quandle_orders, clause_complexities)) / math.sqrt(sum((x - mean_x) ** 2 for x in quandle_orders) * sum((y - mean_y) ** 2 for y in clause complexities))
    mean_quandle_order = sum(quandle_orders) / len(quandle_orders)
    
    return {
        "metric_name": "correlation_coefficient",
        "metric_value": correlation_coefficient,
        "instances_tested": len(n_values),
        "n_max": max(n_values),
        "conjecture_holds": correlation_coefficient >= 0.7 and all(quandle_order <= n ** (3/2) for quandle_order, n in zip(quandle_orders, n_values)),
        "counterexample": "" if correlation_coefficient >= 0.7 and all(quandle_order <= n ** (3/2) for quandle_order, n in zip(quandle_orders, n_values)) else "correlation_too_low"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [random.randint(1000, 9999) for _ in range(30)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_metric_value = sum(r["metric_value"] for r in results) / len(results)
    std_metric_value = math.sqrt(sum((r["metric_value"] - mean_metric_value) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_metric_value} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"correlation_too_low\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE reason=unknown")