# Replay package — entry 1e723876001a

Conjecture: Minimal Rank of Tropical Curves and Sum-of-Squares Refutation Size for CSP

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 22:36 UTC.
Pre-registration hash committed before this test ran: `a6accb37203b8e95`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
