# Replay package — entry 7cd5ecf3a0d3

Conjecture: Minimal Rank of Algebraic Curvature over Frege Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 01:59 UTC.
Pre-registration hash committed before this test ran: `e7435eac61e57e2e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
