# Replay package — entry 7170243452e1

Conjecture: Minimal Rank of Quantum Walks Bounds Communication Complexity for XOR

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 07:43 UTC.
Pre-registration hash committed before this test ran: `c77fdc3a924b8ca7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
