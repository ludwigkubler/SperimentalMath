# Replay package — entry 027f18151318

Conjecture: Minimal Rank of Geometric Loci vs ACC0 Circuit Lower Bounds for Explicit Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 04:44 UTC.
Pre-registration hash committed before this test ran: `d63fb28f2a403e58`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
