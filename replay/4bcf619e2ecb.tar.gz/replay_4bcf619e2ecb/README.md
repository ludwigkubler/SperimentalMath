# Replay package — entry 4bcf619e2ecb

Conjecture: vdW 3-AP Density of MAJ-Lifted NW Designs Tracks Overlap k

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 02:06 UTC.
Pre-registration hash committed before this test ran: `98bc2a96698abeae`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
