# Replay package — entry 91182392117e

Conjecture: Minimal Order of p-Adic Analytic Continuation and Frege Proof Length Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 22:06 UTC.
Pre-registration hash committed before this test ran: `e288f93e9e4f017e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
