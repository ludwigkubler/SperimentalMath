# Replay package — entry dca566675540

Conjecture: Edge Triangle-Corrected Forman-Ricci Sandwich for F*_v

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 10:38 UTC.
Pre-registration hash committed before this test ran: `a81c838e26aff17e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
