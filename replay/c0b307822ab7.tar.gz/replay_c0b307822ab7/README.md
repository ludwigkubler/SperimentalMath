# Replay package — entry c0b307822ab7

Conjecture: Minimal Number of Representations as Maximal Ideals in Algebraic Geometry vs. Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 23:39 UTC.
Pre-registration hash committed before this test ran: `f8683507081170d3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
