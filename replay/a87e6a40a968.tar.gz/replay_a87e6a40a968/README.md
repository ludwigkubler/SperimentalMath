# Replay package — entry a87e6a40a968

Conjecture: Minimal Geometric Entropy of Projective Varieties Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 06:16 UTC.
Pre-registration hash committed before this test ran: `dfb042c1f76faaa5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
