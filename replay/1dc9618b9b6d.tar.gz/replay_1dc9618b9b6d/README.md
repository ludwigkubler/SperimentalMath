# Replay package — entry 1dc9618b9b6d

Conjecture: Minimal Rank of Non-Archimedean Valuations over Boolean Circuit Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 14:26 UTC.
Pre-registration hash committed before this test ran: `703423c5b2155b4d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
