# Replay package — entry 7a849ca4e68c

Conjecture: Coxeter Group Enumeration Complexity of Boolean Function Entropy via Reflection Posets

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 04:05 UTC.
Pre-registration hash committed before this test ran: `26f9d63ce1447d1e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
