# Replay package — entry a5ea85d71db2

Conjecture: Minimal Rank of Schur Algebras Bounds Circuit Lower Bound for Linear Equations

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 19:12 UTC.
Pre-registration hash committed before this test ran: `861282d5791b2821`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
