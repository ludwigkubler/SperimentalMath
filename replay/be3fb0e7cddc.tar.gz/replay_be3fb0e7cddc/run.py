import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def gaussian_elimination(A):
        m, n = len(A), len(A[0])
        for i in range(m):
            max_row = i + max(range(i, m), key=lambda j: abs(A[j][i]))
            A[i], A[max_row] = A[max_row], A[i]
            for j in range(m):
                if i != j:
                    factor = A[j][i] / A[i][i]
                    for k in range(n):
                        A[j][k] -= factor * A[i][k]
        return A

    def rank(A):
        A = gaussian_elimination(A)
        return sum(1 for row in A if any(row))

    def boolean_circuit_weight(f, n):
        # Simplified model of a boolean circuit weight
        # This is a placeholder and should be replaced with actual circuit construction logic
        return 2 ** rank(f)

    def generate_polynomial(n):
        # Generate a random polynomial over the Boolean ring
        # This is a simplified model and should be replaced with actual polynomial generation logic
        return [[random.choice([0, 1]) for _ in range(n)] for _ in range(n)]

    n = random.randint(5, 40)
    f = generate_polynomial(n)
    rho_f = rank(f)
    circuit_weight = boolean_circuit_weight(f, n)

    if abs(rho_f - circuit_weight) > 3:
        return {
            "metric_name": "Rank vs Circuit Weight",
            "metric_value": rho_f,
            "instances_tested": 1,
            "conjecture_holds": False,
            "counterexample": f"rho(f)={rho_f}, circuit_weight={circuit_weight}"
        }
    else:
        return {
            "metric_name": "Rank vs Circuit Weight",
            "metric_value": rho_f,
            "instances_tested": 1,
            "conjecture_holds": True,
            "counterexample": ""
        }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3

    results = []
    for seed in seeds:
        result = run_trial(seed)
        results.append(result)
        print(f"TRIAL: {result}")

    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)

    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next((r["seed"] for r in results if not r["conjecture_holds"]), None)
        print(f"RESULT: FALSIFIED counterexample=\"{results[0]['counterexample']}\" first_failing_seed={first_failing_seed}")