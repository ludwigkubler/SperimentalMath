import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    # Generate a random Kähler manifold with dimension |M| ≤ 40
    M = random.randint(5, 40)
    
    # Compute the canonical bundle rank τ(K(M))
    # For simplicity, we use a dummy function that returns a value proportional to M
    tau_K_M = M
    
    # Generate an instance of the disjointness problem for |M| elements
    X = [random.randint(0, 1) for _ in range(M)]
    
    # Calculate the randomized communication complexity CC(DISJ_|M|)(R)
    # For simplicity, we use a dummy function that returns a value proportional to M^2
    cc_disj_M_R = M ** 2
    
    # Establish a correlation between τ(K(M)) and CC(DISJ_|M|)(R)
    metric_value = tau_K_M
    conjecture_holds = tau_K_M >= 1.5 * cc_disj_M_R
    counterexample = "" if conjecture_holds else "mapping_undefined"
    
    return {
        "metric_name": "tau_K_M",
        "metric_value": metric_value,
        "instances_tested": M,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    
    seeds = [int(s) for s in sys.argv[1:]] if sys.argv[1:] else list(range(2, 30))  # Default to first 29 prime numbers
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_metric_value = sum(r["metric_value"] for r in results) / len(results)
    std_metric_value = math.sqrt(sum((r["metric_value"] - mean_metric_value) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_metric_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_metric_value} support_fraction={support_fraction}")
    else:
        for r in results:
            if not r["conjecture_holds"]:
                counterexample = r["counterexample"]
                first_failing_seed = seed
                break
        
        print(f"RESULT: FALSIFIED counterexample=\"{counterexample}\" first_failing_seed={first_failing_seed}")