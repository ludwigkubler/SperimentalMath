# Replay package — entry 0225c947be1f

Conjecture: Minimal Order of Quasi-random Sequences and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 21:44 UTC.
Pre-registration hash committed before this test ran: `cb6c365a59be7af5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
