# Replay package — entry d552f6834fb0

Conjecture: Minimal Local Induction Dimension and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 14:45 UTC.
Pre-registration hash committed before this test ran: `08ac9c6702b42aeb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
