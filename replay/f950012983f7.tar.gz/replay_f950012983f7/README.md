# Replay package — entry f950012983f7

Conjecture: Minimal Order of p-Adic Differentials Bounds Cumulative Proof Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 05:18 UTC.
Pre-registration hash committed before this test ran: `f6e687f495b1b91a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
