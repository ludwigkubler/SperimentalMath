# Replay package — entry 4f38f3425417

Conjecture: Free Cumulant Sum Inversely Proportional to Disjointness Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-13 03:38 UTC.
Pre-registration hash committed before this test ran: `ed1ac72cf669e8d9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
