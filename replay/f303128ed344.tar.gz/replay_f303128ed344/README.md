# Replay package — entry f303128ed344

Conjecture: Minimal Alexander-Orlik-Solomon Complexity and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 00:54 UTC.
Pre-registration hash committed before this test ran: `91674378e79b8999`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
