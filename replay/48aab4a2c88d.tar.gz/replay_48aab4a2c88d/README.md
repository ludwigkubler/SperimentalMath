# Replay package — entry 48aab4a2c88d

Conjecture: Minimal Rank of Hodge Structure on Affine Schemes Bounds Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 01:56 UTC.
Pre-registration hash committed before this test ran: `90bbae095934f19c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
