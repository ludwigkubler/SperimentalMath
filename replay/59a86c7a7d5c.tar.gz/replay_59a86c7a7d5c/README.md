# Replay package — entry 59a86c7a7d5c

Conjecture: Generated Algebra Dimension of Layer Operators Bounds IP_2 Read-Twice BP

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 07:28 UTC.
Pre-registration hash committed before this test ran: `6f9b8b77eef5d178`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
