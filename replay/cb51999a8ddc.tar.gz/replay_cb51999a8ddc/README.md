# Replay package — entry cb51999a8ddc

Conjecture: Minimal Order of Diophantine Equivalence Classes and SAT Clause Subset Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 09:08 UTC.
Pre-registration hash committed before this test ran: `24582416d5e99e3d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
