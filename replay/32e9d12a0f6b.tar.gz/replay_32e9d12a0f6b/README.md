# Replay package — entry 32e9d12a0f6b

Conjecture: Minimal Geometric Langlands Index and Resolution Proof Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 16:56 UTC.
Pre-registration hash committed before this test ran: `f5cb6d62013969f0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
