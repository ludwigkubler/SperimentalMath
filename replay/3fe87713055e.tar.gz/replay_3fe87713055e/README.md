# Replay package — entry 3fe87713055e

Conjecture: Minimal Order of Quiver Representations and Frege Proof Length Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 16:52 UTC.
Pre-registration hash committed before this test ran: `cbcffe244126194a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
