# Replay package — entry ded464fb6192

Conjecture: Minimal Rank of Geometric Norms over Boolean Functions vs Decision Tree Path Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 16:48 UTC.
Pre-registration hash committed before this test ran: `9a604952b0b49d00`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
