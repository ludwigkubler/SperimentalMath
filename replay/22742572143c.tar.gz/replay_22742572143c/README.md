# Replay package — entry 22742572143c

Conjecture: Minimal Rank of Tropicalized Graph Cocomplexes vs ACC⁰ Circuit Threshold

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 14:27 UTC.
Pre-registration hash committed before this test ran: `ddd483f38945798e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
