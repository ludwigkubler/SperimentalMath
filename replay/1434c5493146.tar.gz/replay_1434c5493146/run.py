import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def gaussian_elimination(A):
        n = len(A)
        for i in range(n):
            max_row = i + max(range(i, n), key=lambda j: abs(A[j][i]))
            A[i], A[max_row] = A[max_row], A[i]
            for j in range(i + 1, n):
                factor = A[j][i] / A[i][i]
                for k in range(n):
                    A[j][k] -= factor * A[i][k]
        return A
    
    def matrix_multiply(A, B):
        n = len(A)
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                for k in range(n):
                    C[i][j] += A[i][k] * B[k][j]
        return C
    
    def matrix_power(A, k):
        n = len(A)
        result = [[0 if i != j else 1 for j in range(n)] for i in range(n)]
        while k > 0:
            if k % 2 == 1:
                result = matrix_multiply(result, A)
            A = matrix_multiply(A, A)
            k //= 2
        return result
    
    def noncommutative_fourier_transform(P):
        n = len(P)
        F = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                F[i][j] = matrix_power(P, i + j)[i][j]
        return F
    
    def coefficient_spread(F):
        coeffs = [abs(F[i][j]) for i in range(len(F)) for j in range(len(F))]
        return max(coeffs) - min(coeffs)
    
    n = random.randint(5, 40)
    P = [[random.random() for _ in range(n)] for _ in range(n)]
    F = noncommutative_fourier_transform(P)
    spread = coefficient_spread(F)
    
    is_trivial_bp = all(abs(P[i][j]) == (i == j) for i in range(n) for j in range(n))
    conjecture_holds = is_trivial_bp and spread >= n or not is_trivial_bp and spread <= math.log(len(P)**2)
    counterexample = "trivial" if is_trivial_bp else ""
    
    return {
        "metric_name": "coefficient_spread",
        "metric_value": spread,
        "instances_tested": 1,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(arg) for arg in sys.argv[1:]] or [2**i - 1 for i in range(5, 35)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value)**2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"trivial\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE mapping_undefined")