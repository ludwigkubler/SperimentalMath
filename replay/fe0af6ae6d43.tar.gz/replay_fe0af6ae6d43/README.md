# Replay package — entry fe0af6ae6d43

Conjecture: Apolar Span of Clause-Product Polynomial Bounds DPLL Leaves

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 15:25 UTC.
Pre-registration hash committed before this test ran: `96152a1d2f89e120`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
