# Replay package — entry e587ad36d438

Conjecture: Minimal Rank of Etale Cohomology over Satisfiability Symmetry Groups

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 17:17 UTC.
Pre-registration hash committed before this test ran: `15c69da3c7eeece6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
