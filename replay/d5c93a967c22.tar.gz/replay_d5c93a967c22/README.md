# Replay package — entry d5c93a967c22

Conjecture: Minimal Quadratic Entanglement and Communication Complexity Rank

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 18:35 UTC.
Pre-registration hash committed before this test ran: `7def97a8765150da`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
