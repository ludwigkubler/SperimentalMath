# Replay package — entry 1c5020ec3b8d

Conjecture: Minimal Rank of Geometric Loci vs. SAT Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 08:05 UTC.
Pre-registration hash committed before this test ran: `b983b4707dfc3d2b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
