# Replay package — entry 64023e1d5813

Conjecture: Moment Matrix Rank Inverse Proportional to SOS Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 06:33 UTC.
Pre-registration hash committed before this test ran: `825d9693c1ce48b6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
