# Replay package — entry 15ec19309767

Conjecture: Erdős–Koós Inequality and ACC⁰ Circuit Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 01:01 UTC.
Pre-registration hash committed before this test ran: `3762420b1fa4ef7e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
