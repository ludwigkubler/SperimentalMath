# Replay package — entry 3d31a9bd1776

Conjecture: Real Radical Containment in SOS Moment Matrices for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 09:32 UTC.
Pre-registration hash committed before this test ran: `d8c40363a28e05ca`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
