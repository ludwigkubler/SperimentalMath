# Replay package — entry b5cefcac0023

Conjecture: Specht Character Support Bounds Monotone Permanental Formula Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 09:45 UTC.
Pre-registration hash committed before this test ran: `837377149fb9254f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
