# Replay package — entry 8d576fc622f5

Conjecture: Hodge Decomposition Complexity for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 20:23 UTC.
Pre-registration hash committed before this test ran: `5b818138acc469c9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
