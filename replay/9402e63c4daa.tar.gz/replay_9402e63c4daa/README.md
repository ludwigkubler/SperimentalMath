# Replay package — entry 9402e63c4daa

Conjecture: Communication Matrix Rank and Decision Tree Depth in AC^0

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 11:47 UTC.
Pre-registration hash committed before this test ran: `241a1fcf6386d467`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
