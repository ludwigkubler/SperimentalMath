# Replay package — entry cd788e589284

Conjecture: Minimal Local Index of Tropical Curve Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 07:18 UTC.
Pre-registration hash committed before this test ran: `720b11629cf612be`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
