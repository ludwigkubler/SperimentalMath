# Replay package — entry b7a1982ba2ae

Conjecture: Minimal Rank of Quadratic Forms over Function Fields vs BP_ReadTwice Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 20:02 UTC.
Pre-registration hash committed before this test ran: `dec857fe515bc596`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
