# Replay package — entry cc8127953d91

Conjecture: Pullback monotonicity of coarse depth under coarse-Lipschitz reductions: a functoriality test for κ in CG-KW

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 19:34 UTC.
Pre-registration hash committed before this test ran: `51abd077f3b327e2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
