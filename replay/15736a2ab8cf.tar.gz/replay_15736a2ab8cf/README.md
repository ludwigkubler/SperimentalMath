# Replay package — entry 15736a2ab8cf

Conjecture: Hereditary Discrepancy of Clause-Variable Incidence Lower-Bounds Tree-Resolution Leaves

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 17:25 UTC.
Pre-registration hash committed before this test ran: `9564295d698f1976`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
