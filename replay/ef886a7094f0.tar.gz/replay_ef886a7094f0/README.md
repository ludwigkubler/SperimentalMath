# Replay package — entry ef886a7094f0

Conjecture: Sandpile-Group Order of Certificate Conflict Graph Lower-Bounds Q^dt

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 11:19 UTC.
Pre-registration hash committed before this test ran: `3868f434d3c1924e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
