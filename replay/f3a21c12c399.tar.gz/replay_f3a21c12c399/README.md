# Replay package — entry f3a21c12c399

Conjecture: Singular Value Gap in Read-Twice BPs for IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 21:00 UTC.
Pre-registration hash committed before this test ran: `2e27e4359e7862f7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
