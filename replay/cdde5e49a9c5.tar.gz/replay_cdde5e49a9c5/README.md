# Replay package — entry cdde5e49a9c5

Conjecture: Minimal Rank of Geometric Langlands Duality over Disjointness

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 01:36 UTC.
Pre-registration hash committed before this test ran: `18441e7e9582a408`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
