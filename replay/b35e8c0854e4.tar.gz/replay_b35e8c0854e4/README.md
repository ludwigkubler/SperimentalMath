# Replay package — entry b35e8c0854e4

Conjecture: Smallest Singular Value Inverse Proportional to SOS Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 16:48 UTC.
Pre-registration hash committed before this test ran: `d9b2cf5a4fdf4fe6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
