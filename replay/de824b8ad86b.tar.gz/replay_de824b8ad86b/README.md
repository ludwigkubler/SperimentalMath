# Replay package — entry de824b8ad86b

Conjecture: Minimal Order of Geometric Quantization and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 11:42 UTC.
Pre-registration hash committed before this test ran: `3cd292b3ac04bcc9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
