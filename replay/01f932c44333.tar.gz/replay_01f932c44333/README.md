# Replay package — entry 01f932c44333

Conjecture: Schur-Weyl Decomposition Entropy Gap for Permanent vs Determinant

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 23:56 UTC.
Pre-registration hash committed before this test ran: `65599e51afc88c89`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
