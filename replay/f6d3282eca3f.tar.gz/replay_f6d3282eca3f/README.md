# Replay package — entry f6d3282eca3f

Conjecture: Minimal p-adic Order of Formal Power Series and DPLL Proof Path Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 19:17 UTC.
Pre-registration hash committed before this test ran: `6b40ca0374d02910`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
