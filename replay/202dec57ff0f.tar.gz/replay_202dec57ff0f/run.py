import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_boolean_function(N):
        return [random.choice([0, 1]) for _ in range(2**N)]
    
    def compute_generality(phi_f):
        # Placeholder function to compute generality
        # This is a dummy implementation and should be replaced with actual logic
        return random.randint(1, N)
    
    def construct_circuit(f, N):
        # Placeholder function to construct circuit
        # This is a dummy implementation and should be replaced with actual logic
        return len(f)  # Simplified for demonstration
    
    results = []
    n_values = [5, 10, 15, 20, 30, 40]
    
    for N in n_values:
        f = generate_boolean_function(N)
        phi_f = compute_generality(f)
        depth = construct_circuit(f, N)
        
        results.append({
            "N": N,
            "f": f,
            "phi_f": phi_f,
            "depth": depth
        })
    
    if not results:
        return {
            "metric_name": "circuit_depth",
            "metric_value": 0.0,
            "instances_tested": 0,
            "n_max": 0,
            "conjecture_holds": False,
            "counterexample": "no_instances_generated"
        }
    
    total_depth = sum(result["depth"] for result in results)
    avg_depth = total_depth / len(results)
    n_max = max(result["N"] for result in results)
    
    return {
        "metric_name": "circuit_depth",
        "metric_value": avg_depth,
        "instances_tested": len(results),
        "n_max": n_max,
        "conjecture_holds": False,
        "counterexample": "mapping_undefined"
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] + list(range(31, 100))
    
    results = []
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        
        if not trial_result["conjecture_holds"]:
            results.append(trial_result)
    
    if all(result["conjecture_holds"] for result in results):
        mean_value = sum(result["metric_value"] for result in results) / len(results)
        support_fraction = 1.0
        print(f"RESULT: SUPPORTED mean={mean_value} std=0 support_fraction={support_fraction}")
    else:
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        counterexample = "mapping_undefined"
        print(f"RESULT: FALSIFIED counterexample=\"{counterexample}\" first_failing_seed={first_failing_seed}")