# Replay package — entry 51aafa940751

Conjecture: Frobenius Fourier Defect of Barrington AND_n PBP Trajectory

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 03:06 UTC.
Pre-registration hash committed before this test ran: `11c0ee3463fad10b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
