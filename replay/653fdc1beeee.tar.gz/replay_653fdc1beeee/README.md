# Replay package — entry 653fdc1beeee

Conjecture: Minimal Number of Galois Automorphisms vs. Circuit Weights

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 19:13 UTC.
Pre-registration hash committed before this test ran: `84a37bd85a2d5d0a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
