# Replay package — entry 9f377a5314c3

Conjecture: Minimal Index of Tropicalized Symplectic Leaves and DPLL Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 16:42 UTC.
Pre-registration hash committed before this test ran: `d1dc237f5e6021f2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
