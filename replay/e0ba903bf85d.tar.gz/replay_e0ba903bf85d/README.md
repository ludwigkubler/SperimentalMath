# Replay package — entry e0ba903bf85d

Conjecture: Braid Group Action on Boolean Circuit Automorphism Groups

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 16:09 UTC.
Pre-registration hash committed before this test ran: `2d634697ab1ef18d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
