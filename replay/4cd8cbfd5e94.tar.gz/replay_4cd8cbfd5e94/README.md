# Replay package — entry 4cd8cbfd5e94

Conjecture: Hilbert Series Complexity of Orbit Closures for Permanent vs Determinant

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 14:45 UTC.
Pre-registration hash committed before this test ran: `73b808c37ef3f825`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
