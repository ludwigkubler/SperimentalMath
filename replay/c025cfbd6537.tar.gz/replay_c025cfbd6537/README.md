# Replay package — entry c025cfbd6537

Conjecture: Minimal Rank of Geometric Entanglement vs Noncommutative Crossed Product TensorRank for k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 23:08 UTC.
Pre-registration hash committed before this test ran: `9216ff0d9a01c987`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
