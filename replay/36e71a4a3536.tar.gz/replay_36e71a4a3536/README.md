# Replay package — entry 36e71a4a3536

Conjecture: Minimal Rank of Tropical Topological Complexity Bounds Monotone Circuit Size for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 19:20 UTC.
Pre-registration hash committed before this test ran: `411cd64eac7faa5f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
