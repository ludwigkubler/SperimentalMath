# Replay package — entry f5c9b3eb3fcd

Conjecture: Minimal Order of Geometric Invariant Theory and Circuit Monotone Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 19:07 UTC.
Pre-registration hash committed before this test ran: `524074b7b4e65deb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
