# Replay package — entry 56039c424522

Conjecture: Spectral Norm of SOS Relaxation and Refutation Size in Random 3-SAT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 00:11 UTC.
Pre-registration hash committed before this test ran: `bf0bd2a2a70660dd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
