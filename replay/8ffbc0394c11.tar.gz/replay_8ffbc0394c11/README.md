# Replay package — entry 8ffbc0394c11

Conjecture: Minimal Rank of Geometric Langlands Duality over Polynomial Threshold Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 18:14 UTC.
Pre-registration hash committed before this test ran: `b89c9784e8a21fa2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
