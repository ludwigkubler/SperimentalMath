# Replay package — entry 9c6ddd093b59

Conjecture: Betti Number Exponential Lower Bound on Tseitin Resolution Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 17:36 UTC.
Pre-registration hash committed before this test ran: `246d5a2883073efc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
