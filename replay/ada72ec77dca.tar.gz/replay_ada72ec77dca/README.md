# Replay package — entry ada72ec77dca

Conjecture: Minimal Rank of Geometric Diophantine Sets Bounds Resolution Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 22:47 UTC.
Pre-registration hash committed before this test ran: `50cbe33d7091ae5e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
