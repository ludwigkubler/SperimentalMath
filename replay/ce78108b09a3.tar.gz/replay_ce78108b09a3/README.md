# Replay package — entry ce78108b09a3

Conjecture: Kahler Manifolds and Resolution Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 16:01 UTC.
Pre-registration hash committed before this test ran: `34d1561ac1158551`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
