# Replay package — entry cf52d7a98cd5

Conjecture: Invariant Space Dimension Gap in Permanent vs Determinant Tensor Powers

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 21:42 UTC.
Pre-registration hash committed before this test ran: `b387d9634450df2c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
