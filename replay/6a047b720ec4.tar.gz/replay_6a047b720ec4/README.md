# Replay package — entry 6a047b720ec4

Conjecture: Minimal Order of Representations over p-Adic Fields and Communication Complexity Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 12:48 UTC.
Pre-registration hash committed before this test ran: `0674505b3ef7739f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
