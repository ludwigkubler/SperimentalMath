# Replay package — entry 1d044099f097

Conjecture: Minimal Depth of Hodge Decomposition in Arithmetic Geometry Bounds Quantum Query Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 13:49 UTC.
Pre-registration hash committed before this test ran: `26f792ce4bd1dbd8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
