# Replay package — entry fb6cac2a7182

Conjecture: Symmetric Square Multiplicity Gap in Permanent vs Determinant Decompositions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 18:06 UTC.
Pre-registration hash committed before this test ran: `411e25e9f19c0976`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
