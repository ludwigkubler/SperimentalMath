# Replay package — entry 118fd4951a23

Conjecture: Median Half-Subgraph Separator Lower-Bounds Tseitin DPLL Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 10:32 UTC.
Pre-registration hash committed before this test ran: `cfdc54676ce9a356`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
