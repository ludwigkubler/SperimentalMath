# Replay package — entry d8441229b8b9

Conjecture: Minimal Hodge Index of Quasi-Clifford Algebras and Sum-of-Squares Refutation Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 01:05 UTC.
Pre-registration hash committed before this test ran: `2938f317ff494dd7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
