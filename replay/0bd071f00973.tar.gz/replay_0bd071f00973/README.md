# Replay package — entry 0bd071f00973

Conjecture: Trace-Norm Capacity Conjecture for Read-Twice BP Communication Matrices

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 10:06 UTC.
Pre-registration hash committed before this test ran: `b7697f732fe0d78b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
