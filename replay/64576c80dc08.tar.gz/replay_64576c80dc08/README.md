# Replay package — entry 64576c80dc08

Conjecture: Minimal Order of Tropicalized Quiver Representations and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 00:31 UTC.
Pre-registration hash committed before this test ran: `460b10551700e037`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
