# Replay package — entry 33ac9cdf1529

Conjecture: Mealy Automaticity Lower-Bounds Truth-Table Formula Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 02:14 UTC.
Pre-registration hash committed before this test ran: `acbe0a5c2b41fcf4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
