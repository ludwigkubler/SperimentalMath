# Replay package — entry 5fb5248dbecf

Conjecture: Euler Characteristic Invariant for Tseitin Formulas Correlates with Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 04:51 UTC.
Pre-registration hash committed before this test ran: `6ba11c4d653dc364`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
