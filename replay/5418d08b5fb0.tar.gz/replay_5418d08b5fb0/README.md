# Replay package — entry 5418d08b5fb0

Conjecture: Minimal Rank of Free Lie Algebras and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 14:33 UTC.
Pre-registration hash committed before this test ran: `8fb4e6a578e30deb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
