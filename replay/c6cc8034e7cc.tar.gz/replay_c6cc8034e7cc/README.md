# Replay package — entry c6cc8034e7cc

Conjecture: Algebraic K-Theory and DPLL Search Tree Diameter

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 20:13 UTC.
Pre-registration hash committed before this test ran: `36855936ec10e962`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
