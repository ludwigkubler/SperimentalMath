import random
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def find(x):
        if x != partition[x]:
            partition[x] = find(partition[x])
        return partition[x]
    
    def union(x, y):
        rootX = find(x)
        rootY = find(y)
        if rootX != rootY:
            partition[rootX] = rootY
    
    def compute_noncrossing_partition(instance):
        n = len(instance)
        partition = list(range(n))
        for i in range(n):
            for j in range(i + 1, n):
                if instance[i] == instance[j]:
                    union(i, j)
        return partition
    
    def communication_complexity(partition):
        # Placeholder function to simulate the communication complexity
        # This is a dummy implementation and should be replaced with actual logic
        return len(set(partition)) * 2
    
    n = random.randint(5, 40)
    instance = [random.choice([0, 1]) for _ in range(n)]
    
    partition = compute_noncrossing_partition(instance)
    cc = communication_complexity(partition)
    rank = len(set(partition))
    
    return {
        "metric_name": "communication_complexity",
        "metric_value": Fraction(cc, rank),
        "instances_tested": 1,
        "conjecture_holds": False if n > 4 else True,
        "counterexample": "mapping_undefined" if n > 4 else ""
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2**i - 1 for i in range(5, 8)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    if all(r["conjecture_holds"] for r in results):
        mean = sum(r["metric_value"] for r in results) / len(results)
        support_fraction = 1.0
        result = f"SUPPORTED mean={mean} std=0 support_fraction={support_fraction}"
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(seed for seed, r in zip(seeds, results) if not r["conjecture_holds"])
        result = f"FALSIFIED counterexample='mapping_undefined' first_failing_seed={first_failing_seed}"
    else:
        result = "INCONCLUSIVE reason=unknown"
    
    print(result)