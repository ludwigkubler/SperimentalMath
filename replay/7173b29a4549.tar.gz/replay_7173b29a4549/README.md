# Replay package — entry 7173b29a4549

Conjecture: Free Probability Invariant Bounds Communication Complexity of Disjointness

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 09:35 UTC.
Pre-registration hash committed before this test ran: `ee303623d7d01680`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
