# Replay package — entry 08881f411f0c

Conjecture: Sharply-Bounded Refutability Vanishes at 3-SAT Threshold

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 18:10 UTC.
Pre-registration hash committed before this test ran: `b16f7ab9bb0222a1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
