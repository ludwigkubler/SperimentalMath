# Replay package — entry d6670829838b

Conjecture: Minimal Local Index of K-theory over Function Fields vs Resolution Proof Width for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 18:50 UTC.
Pre-registration hash committed before this test ran: `b65f77c1e23d5fe6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
