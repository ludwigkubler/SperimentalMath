# Replay package — entry f9fb4170f33a

Conjecture: Minimal Diophantine Root Count and SAT Clause Set Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 22:10 UTC.
Pre-registration hash committed before this test ran: `e6db46a107f34c5b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
