# Replay package — entry f2bf4d9d679f

Conjecture: Minimal Local Index vs Communication Complexity Rank Variance Ratio

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 10:46 UTC.
Pre-registration hash committed before this test ran: `07a98d396aaef7b3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
