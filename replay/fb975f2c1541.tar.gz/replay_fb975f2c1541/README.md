# Replay package — entry fb975f2c1541

Conjecture: Minimal Hodge-Structure Dimension and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 14:48 UTC.
Pre-registration hash committed before this test ran: `e59ba83bd4c24af0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
