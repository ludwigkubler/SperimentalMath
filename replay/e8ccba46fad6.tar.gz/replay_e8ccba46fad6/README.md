# Replay package — entry e8ccba46fad6

Conjecture: Minimal Rank of Brauer Groups over Frege Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 09:12 UTC.
Pre-registration hash committed before this test ran: `acdef343e8d73b53`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
