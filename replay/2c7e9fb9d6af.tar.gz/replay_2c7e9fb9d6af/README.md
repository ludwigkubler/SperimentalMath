# Replay package — entry 2c7e9fb9d6af

Conjecture: Minimal Symmetry of Quiver Paths and Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 22:12 UTC.
Pre-registration hash committed before this test ran: `005fadbaa6156902`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
