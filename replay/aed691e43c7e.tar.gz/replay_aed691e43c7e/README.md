# Replay package — entry aed691e43c7e

Conjecture: Minimal Rank of Geometrically Hyperbolic Metric Spaces and Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 03:22 UTC.
Pre-registration hash committed before this test ran: `8ef044ee854e6ec9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
