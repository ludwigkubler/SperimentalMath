import random
import math
from itertools import combinations

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_bipartite_graph(n):
        A = [random.choice([0, 1]) for _ in range(n * n // 4)]
        B = [random.choice([0, 1]) for _ in range(n * n // 4)]
        adj_matrix = [[A[i * n + j] if i < n // 2 else B[(i - n // 2) * n + j] for j in range(n)] for i in range(n)]
        return adj_matrix
    
    def frobenius_representation_count(adj_matrix):
        n = len(adj_matrix)
        representations = set()
        for i, j in combinations(range(n), 2):
            if adj_matrix[i][j]:
                representations.add((i, j))
        return len(representations)
    
    def communication_complexity_rank_variance(adj_matrix):
        n = len(adj_matrix)
        rank = sum(sum(row) for row in adj_matrix) / (n * n)
        variance = sum((sum(row) - rank) ** 2 for row in adj_matrix) / (n * n)
        return variance
    
    n_max = 40
    instances_tested = 30
    metric_values = []
    
    for _ in range(instances_tested):
        n = random.randint(5, n_max)
        adj_matrix = generate_bipartite_graph(n)
        frobenius_count = frobenius_representation_count(adj_matrix)
        comm_rank_variance = communication_complexity_rank_variance(adj_matrix)
        
        if comm_rank_variance == 0:
            continue
        
        metric_values.append(frobenius_count / comm_rank_variance)
    
    if not metric_values:
        return {
            "metric_name": "Frobenius(G) / CommRankVar(G)",
            "metric_value": None,
            "instances_tested": instances_tested,
            "n_max": n_max,
            "conjecture_holds": False,
            "counterexample": "communication_complexity_rank_variance_zero"
        }
    
    mean = sum(metric_values) / len(metric_values)
    std_dev = math.sqrt(sum((x - mean) ** 2 for x in metric_values) / len(metric_values))
    support_fraction = sum(1 for v in metric_values if abs(v - mean) <= 0.05 * mean) / len(metric_values)
    
    return {
        "metric_name": "Frobenius(G) / CommRankVar(G)",
        "metric_value": mean,
        "instances_tested": instances_tested,
        "n_max": n_max,
        "conjecture_holds": support_fraction >= 0.8,
        "counterexample": ""
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_metric_value = sum(r["metric_value"] for r in results if r["metric_value"] is not None) / len(results)
    std_dev_metric_value = math.sqrt(sum((r["metric_value"] - mean_metric_value) ** 2 for r in results if r["metric_value"] is not None) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_dev_metric_value} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(s for s, r in zip(seeds, results) if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"not supported\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE reason=unknown")