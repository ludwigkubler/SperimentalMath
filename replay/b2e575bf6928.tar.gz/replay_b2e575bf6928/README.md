# Replay package — entry b2e575bf6928

Conjecture: Minimal Local Induction Ring Rank and SAT Clause Subset Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 20:57 UTC.
Pre-registration hash committed before this test ran: `8acc2645045b31f0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
