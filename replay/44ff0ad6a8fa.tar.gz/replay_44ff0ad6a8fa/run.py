import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def free_entropy_dimension(n):
        # Placeholder for actual computation
        return n  # Simplified for demonstration purposes
    
    def communication_complexity(n):
        # Placeholder for actual computation
        return n**2  # Simplified for demonstration purposes
    
    n = random.randint(5, 40)
    F_n = free_entropy_dimension(n)
    CC_DISJ_n = communication_complexity(n)
    
    ratio = CC_DISJ_n / F_n if F_n != 0 else float('inf')
    
    return {
        "metric_name": "Ratio of Communication Complexity to Free Entropy Dimension",
        "metric_value": ratio,
        "instances_tested": 1,
        "conjecture_holds": ratio >= 1.5 and ratio < 0.5,
        "counterexample": "" if ratio >= 1.5 else f"n={n}, CC_DISJ(n)={CC_DISJ_n}, F_n={F_n}"
    }

if __name__ == "__main__":
    seeds = [int(arg) for arg in sys.argv[1:]] or [2**i + 1 for i in range(30)]
    
    results = []
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    mean_ratio = sum(result["metric_value"] for result in results) / len(results)
    support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)
    
    if all(result["conjecture_holds"] for result in results):
        print(f"RESULT: SUPPORTED mean={mean_ratio} std=0.0 support_fraction={support_fraction}")
    elif support_fraction >= 0.95:
        print(f"RESULT: SUPPORTED mean={mean_ratio} std=0.0 support_fraction={support_fraction}")
    else:
        for result in results:
            if not result["conjecture_holds"]:
                counterexample = result["counterexample"]
                first_failing_seed = seed
                break
        
        print(f"RESULT: FALSIFIED counterexample=\"{counterexample}\" first_failing_seed={first_failing_seed}")