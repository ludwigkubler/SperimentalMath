# Replay package — entry c3adcbaf3152

Conjecture: Tropical Order of Tropical Curves Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 13:59 UTC.
Pre-registration hash committed before this test ran: `410ace1659ff8a6f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
