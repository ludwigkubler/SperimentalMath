# Replay package — entry e1fd91dfe319

Conjecture: Minimal Hodge Index of Affine Varieties over Boolean Ring vs DPLL Search Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 02:36 UTC.
Pre-registration hash committed before this test ran: `6c2c9f9f3f27bb45`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
