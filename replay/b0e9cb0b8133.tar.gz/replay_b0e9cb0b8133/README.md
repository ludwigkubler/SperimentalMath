# Replay package — entry b0e9cb0b8133

Conjecture: Minimal Rank of Quasi-group Representations vs DPLL Search Tree Width for k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 18:23 UTC.
Pre-registration hash committed before this test ran: `87fc7f4d5df9170a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
