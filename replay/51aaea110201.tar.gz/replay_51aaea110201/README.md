# Replay package — entry 51aaea110201

Conjecture: Minimal Geometric Entropy of Real Algebraic Curves vs. Decision Tree Height for k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 15:34 UTC.
Pre-registration hash committed before this test ran: `020fe7f5835f498e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
