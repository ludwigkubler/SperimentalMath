# Replay package — entry 4178ef46c68d

Conjecture: Minimal Generality of Noncommutative Algebras Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 04:21 UTC.
Pre-registration hash committed before this test ran: `1e5902ef2c5434aa`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
