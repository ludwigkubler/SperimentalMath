# Replay package — entry fa5c6768e062

Conjecture: Minimal Index of Tropicalized Topological Quantum Field Theories over Tseitin Circuit Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 00:38 UTC.
Pre-registration hash committed before this test ran: `2b6cd5e5d1f0cc22`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
