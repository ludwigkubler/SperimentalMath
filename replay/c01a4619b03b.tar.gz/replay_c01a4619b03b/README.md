# Replay package — entry c01a4619b03b

Conjecture: Coxeter Group Order Bounds Frege Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 06:39 UTC.
Pre-registration hash committed before this test ran: `3018c14838dadaf5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
