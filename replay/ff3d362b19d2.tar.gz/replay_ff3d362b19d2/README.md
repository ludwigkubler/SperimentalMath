# Replay package — entry ff3d362b19d2

Conjecture: Minimal Rank of Coxeter Group Representations vs Tseitin Formula Resolution Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 07:53 UTC.
Pre-registration hash committed before this test ran: `fa7e251ae0244346`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
