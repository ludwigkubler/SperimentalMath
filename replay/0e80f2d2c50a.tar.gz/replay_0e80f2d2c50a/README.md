# Replay package — entry 0e80f2d2c50a

Conjecture: Young-Flattening Rank Gap Lower-Bounds Padded-Permanent Border Rank

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 01:05 UTC.
Pre-registration hash committed before this test ran: `fc909a137e0f400a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
