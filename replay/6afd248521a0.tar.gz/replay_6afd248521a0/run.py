import random
import math
from fractions import Fraction

def generate_random_3_regular(n):
    if n % 2 != 0:
        return None  # Cannot form a 3-regular graph with an odd number of vertices
    
    G = set()
    while len(G) < n * 3 // 2:
        u, v = random.sample(range(n), 2)
        if (u, v) not in G and (v, u) not in G:
            G.add((u, v))
    
    return G

def is_3_regular(G):
    degree_count = [0] * n
    for u, v in G:
        degree_count[u] += 1
        degree_count[v] += 1
    
    return all(d == 3 for d in degree_count)

def project_to_unit_sphere(M):
    r = sum(sum(row) ** 2 for row in M) ** 0.5
    if r == 0:
        return M
    return [[M[i][j] / r for j in range(len(M[0]))] for i in range(len(M))]

def qr_with_shifts(A, shift):
    n = len(A)
    Q = [[Fraction(1) if i == j else Fraction(0) for j in range(n)] for i in range(n)]
    R = A
    for k in range(n - 1):
        v = [R[i][k] for i in range(k, n)]
        norm_v = sum(x ** 2 for x in v) ** 0.5
        e_k = [(Fraction(1) if i == k else Fraction(0)) for i in range(n)]
        u = [v[i] / norm_v - (sum(v[j] * Q[j][k] for j in range(k, n))) * e_k[k] for i in range(k, n)]
        Q_k = [[Fraction(1) if i == j else Fraction(0) for j in range(n)] for i in range(n)]
        Q_k[k][k] = u[0]
        Q_k[k + 1][k] = -u[1]
        Q_k[k][k + 1] = u[1]
        Q_k[k + 1][k + 1] = u[0]
        R = [[sum(Q[i][l] * R[l][j] for l in range(n)) for j in range(k, n)] for i in range(k, n)]
        A = [[sum(Q[i][l] * A[l][m] for l in range(n)) for m in range(n)] for i in range(n)]
    return Q, R

def compute_eigenvalues(M):
    n = len(M)
    Q, R = qr_with_shifts(M, 0)
    eigenvalues = [R[i][i] for i in range(n)]
    return eigenvalues

def compute_traces(M, k):
    n = len(M)
    trace = 0
    for i in range(n):
        for j in range(i + 1, n):
            trace += M[i][j] ** (2 * k)
    return trace

def generate_gw_gram_matrix(G, r):
    n = len(G)
    V = [[Fraction(1) / math.sqrt(n)] * n]
    for _ in range(r - 1):
        next_row = [sum(V[-1][i] * G[i][j] for i in range(n)) for j in range(n)]
        norm_next_row = sum(x ** 2 for x in next_row) ** 0.5
        V.append([x / norm_next_row for x in next_row])
    return [[sum(V[i][k] * V[j][l] for k in range(r)) for l in range(r)] for i in range(r)]

def compute_hankel_signature(M, n):
    w = [Fraction(1) if -1 + 1 / math.sqrt(n) < x < 1 - 1 / math.sqrt(n) else Fraction(0) for x in M]
    H = [[sum(M[i][j] ** (k + l) * w[k] * w[l] for k in range(n) for l in range(n)) for j in range(n)] for i in range(n)]
    return H

def compute_maxcut(G):
    n = len(G)
    maxcut = 0
    for mask in range(1, 2 ** n):
        cut_size = sum(1 for i in range(n) if (mask >> i) & 1)
        if cut_size == 0 or cut_size == n:
            continue
        cut_value = sum(G[i][j] for i in range(n) for j in range(i + 1, n) if ((i >> j) & 1) ^ ((j >> i) & 1))
        maxcut = max(maxcut, cut_value)
    return maxcut

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    n_values = [8, 10, 12, 14, 16, 18, 20, 25, 30, 35, 40]
    results = []
    for n in n_values:
        G = generate_random_3_regular(n)
        if G is None:
            continue
        
        r = math.ceil(math.sqrt(2 * n))
        M_G = generate_gw_gram_matrix(G, r)
        M_G = project_to_unit_sphere(M_G)
        
        eigenvalues = compute_eigenvalues(M_G)
        R_G = sum(1 for e in eigenvalues if -1 + 1 / math.sqrt(n) < e < 1 - 1 / math.sqrt(n))
        R_G_n = R_G / n
        
        H_G = compute_hankel_signature(eigenvalues, n)
        
        maxcut = compute_maxcut(G)
        UB_G = len(G) / 2 + n * max(eigenvalues) / 4
        SDP_ratio = <L_G, M_G> / (4 * UB_G)
        
        results.append({
            "metric_name": "R_G_n",
            "metric_value": R_G_n,
            "instances_tested": 1,
            "conjecture_holds": abs(R_G_n - c_star) <= 0.07 and SDP_ratio >= 0.878,
            "counterexample": ""
        })
    
    mean_R_G_n = sum(result["metric_value"] for result in results) / len(results)
    std_R_G_n = (sum((result["metric_value"] - mean_R_G_n) ** 2 for result in results) / len(results)) ** 0.5
    support_fraction = sum(1 for result in results if abs(result["metric_value"] - c_star) <= 0.07 and result["conjecture_holds"]) / len(results)
    
    return {
        "seed": seed,
        "mean_R_G_n": mean_R_G_n,
        "std_R_G_n": std_R_G_n,
        "support_fraction": support_fraction
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] if len(sys.argv) > 1 else [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_R_G_n = sum(result["mean_R_G_n"] for result in results) / len(results)
    std_R_G_n = (sum((result["mean_R_G_n"] - mean_R_G_n) ** 2 for result in results) / len(results)) ** 0.5
    support_fraction = sum(1 for result in results if abs(result["mean_R_G_n"] - c_star) <= 0.07 and result["support_fraction"] >= 0.85) / len(results)
    
    if support_fraction >= 0.85:
        print(f"RESULT: SUPPORTED mean={mean_R_G_n} std={std_R_G_n} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"SDP_ratio < 0.878\" first_failing_seed={first_failing_seed}")