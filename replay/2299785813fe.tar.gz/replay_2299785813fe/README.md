# Replay package — entry 2299785813fe

Conjecture: Minimal Tropical Derivative Rank Correlation with Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 12:00 UTC.
Pre-registration hash committed before this test ran: `145fa07af976c0d5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
