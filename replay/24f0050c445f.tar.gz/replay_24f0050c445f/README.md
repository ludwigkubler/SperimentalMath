# Replay package — entry 24f0050c445f

Conjecture: Real Radical Dimension Bounds SOS Refutation Degree for max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 19:52 UTC.
Pre-registration hash committed before this test ran: `f4b23241d53b0841`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
