# Replay package — entry 94c2421367c6

Conjecture: Tropicalized Brauer Groups and XOR-AND Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 08:38 UTC.
Pre-registration hash committed before this test ran: `141f62ef244fef67`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
