# Replay package — entry dd4c952aa3ea

Conjecture: Patience-Sort LIS of XOR-Lifted Row Permutations Bounds CC^D

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 09:23 UTC.
Pre-registration hash committed before this test ran: `b99755060f581512`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
