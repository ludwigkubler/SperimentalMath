# Replay package — entry 2746a7cbee6d

Conjecture: Multiplicity Gap in Symmetric Powers of Permanent vs Determinant Representations

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 15:45 UTC.
Pre-registration hash committed before this test ran: `9062ee40476a81db`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
