import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_boolean_circuit(n):
        if n == 1:
            return ([(0,)], 1)
        else:
            subcircuits = [generate_boolean_circuit(random.randint(2, n//2)) for _ in range(2)]
            gate = (random.choice(['AND', 'OR']), subcircuits[0][0], subcircuits[1][0])
            return (gate, max(subcircuits[0][1], subcircuits[1][1]) + 1)
    
    def compute_monotone_width(circuit):
        gate, depth = circuit
        if gate[0] == 'AND' or gate[0] == 'OR':
            width = 0
            for input in gate[2]:
                width += max(len(input) for input in input)
            return width + depth - 1
        else:
            return 1
    
    def compute_galois_group_order(circuit):
        # Placeholder function to simulate computing the Galois group order
        # This is a dummy implementation and should be replaced with actual computation
        gate, _ = circuit
        if gate[0] == 'AND' or gate[0] == 'OR':
            return 2 ** (len(gate[1]) - 1)
        else:
            return 1
    
    n = random.randint(5, 40)
    circuit = generate_boolean_circuit(n)
    monotone_width = compute_monotone_width(circuit)
    galois_group_order = compute_galois_group_order(circuit)
    
    if galois_group_order <= 0:
        return {
            "metric_name": "Galois Group Order",
            "metric_value": galois_group_order,
            "instances_tested": 1,
            "n_max": n,
            "conjecture_holds": False,
            "counterexample": "galois_group_order_non_positive"
        }
    
    expected_bound = monotone_width * 2
    if abs(galois_group_order - monotone_width) > expected_bound:
        return {
            "metric_name": "Galois Group Order",
            "metric_value": galois_group_order,
            "instances_tested": 1,
            "n_max": n,
            "conjecture_holds": False,
            "counterexample": f"Order {galois_group_order} is not within a factor of 2 from monotone width {monotone_width}"
        }
    
    return {
        "metric_name": "Galois Group Order",
        "metric_value": galois_group_order,
        "instances_tested": 1,
        "n_max": n,
        "conjecture_holds": True,
        "counterexample": ""
    }

if __name__ == "__main__":
    import sys
    seeds = [int(x) for x in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    
    results = []
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    if all(result["conjecture_holds"] for result in results):
        mean_value = sum(result["metric_value"] for result in results) / len(results)
        std_value = math.sqrt(sum((result["metric_value"] - mean_value) ** 2 for result in results) / len(results))
        support_fraction = 1.0
    else:
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        counterexample = next(result["counterexample"] for result in results if not result["conjecture_holds"])
        mean_value = sum(result["metric_value"] for result in results if result["conjecture_holds"]) / sum(1 for result in results if result["conjecture_holds"])
        std_value = math.sqrt(sum((result["metric_value"] - mean_value) ** 2 for result in results if result["conjecture_holds"])) / sum(1 for result in results if result["conjecture_holds"]))
        support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)
    
    print(f"RESULT: {'SUPPORTED' if all(result['conjecture_holds'] for result in results) else 'FALSIFIED'} mean={mean_value} std={std_value} support_fraction={support_fraction}")