# Replay package — entry 7c5ad65991c5

Conjecture: Roe-cohomological concentration: HX^1(X_f) vanishes for random f, separating natural-proof properties from κ

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 14:43 UTC.
Pre-registration hash committed before this test ran: `9c6efc5b7fa300d9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
