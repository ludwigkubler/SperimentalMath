# Replay package — entry 3e4b5c9a803c

Conjecture: Kronecker Coefficient Gap in Symmetric Powers of Permanent vs Determinant

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 14:19 UTC.
Pre-registration hash committed before this test ran: `7f0707a72a92c4e9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
