# Replay package — entry 529fc493278f

Conjecture: Minimal Rank of Free Entanglement Dimension over Disjointness Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 05:38 UTC.
Pre-registration hash committed before this test ran: `abe1000a480ed2cc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
