# Replay package — entry 46854c915af3

Conjecture: Minimal Genus of Tropical Curves Bounds Proof Entropy for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 12:14 UTC.
Pre-registration hash committed before this test ran: `24047bb7f8011250`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
