# Replay package — entry 843dea5d1c58

Conjecture: Minimal Order of Non-Crossing Partitions and Frege Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 00:02 UTC.
Pre-registration hash committed before this test ran: `6a4d9e62be812ff8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
