# Replay package — entry aa045d952985

Conjecture: Schatten p-Norm Lower Bound on Disjointness Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 01:59 UTC.
Pre-registration hash committed before this test ran: `b8364f476d65f1ac`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
