import random
import math
from fractions import Fraction
from itertools import combinations, product

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_random_graph(n):
        while True:
            edges = set()
            for u in range(n):
                for v in range(u + 1, n):
                    if random.random() < 0.5 and len(edges & {(u, w), (w, u) for w in range(n)}) == 0:
                        edges.add((u, v))
            G = {u: set(v for u, v in edges if u == u) for u in range(n)}
            if all(len(G[u]) >= 2 for u in range(n)) and max(len(path) for path in find_all_paths(G, n)) >= 5:
                return G
    
    def find_all_paths(G, n):
        paths = []
        for start in range(n):
            visited = [False] * n
            visited[start] = True
            stack = [(start, [start])]
            while stack:
                u, path = stack.pop()
                if len(path) >= 5:
                    paths.append(path)
                for v in G[u]:
                    if not visited[v]:
                        visited[v] = True
                        stack.append((v, path + [v]))
        return paths
    
    def tseitin_formula(G):
        n = len(G)
        literals = {u: f'x{u}' for u in range(n)}
        neg_literals = {u: f'-x{u}' for u in range(n)}
        clauses = []
        
        # Clause for each edge
        for u, v in G:
            clauses.append([literals[u], neg_literals[v]])
            clauses.append([neg_literals[u], literals[v]])
            clauses.append([neg_literals[u], neg_literals[v]])
        
        # Clause for each vertex
        for u in range(n):
            clauses.append([literals[u]] + [neg_literals[v] for v in G[u]])
        
        return clauses
    
    def gaussian_elimination(matrix):
        n = len(matrix)
        for i in range(n):
            max_row = i
            for j in range(i+1, n):
                if abs(matrix[j][i]) > abs(matrix[max_row][i]):
                    max_row = j
            matrix[i], matrix[max_row] = matrix[max_row], matrix[i]
            for j in range(i+1, n):
                factor = Fraction(matrix[j][i], matrix[i][i])
                for k in range(n + 1):
                    matrix[j][k] -= factor * matrix[i][k]
        return matrix
    
    def minimal_tropical_motivic_rank(cnf):
        n = len(cnf)
        matrix = [[0] * (n + 1) for _ in range(n)]
        for clause in cnf:
            for literal in clause:
                if literal[0] == '-':
                    u = int(literal[1:]) - 1
                    matrix[u][n] += 1
                else:
                    u = int(literal) - 1
                    matrix[n][u] += 1
        rank = sum(1 for row in gaussian_elimination(matrix) if any(row))
        return rank
    
    def communication_complexity_rank(cnf):
        n = len(cnf)
        matrix = [[0] * (n + 1) for _ in range(n)]
        for clause in cnf:
            for literal in clause:
                if literal[0] == '-':
                    u = int(literal[1:]) - 1
                    matrix[u][n] += 1
                else:
                    u = int(literal) - 1
                    matrix[n][u] += 1
        rank = sum(1 for row in gaussian_elimination(matrix) if any(row))
        return rank
    
    n = random.choice([5, 10, 15, 20, 30, 40])
    G = generate_random_graph(n)
    cnf = tseitin_formula(G)
    
    mtr = minimal_tropical_motivic_rank(cnf)
    ccr = communication_complexity_rank(cnf)
    
    if ccr == 0:
        return {
            "metric_name": "mtr_to_ccr_ratio",
            "metric_value": None,
            "instances_tested": 1,
            "n_max": n,
            "conjecture_holds": False,
            "counterexample": "CCR is zero, division by zero"
        }
    
    ratio = Fraction(mtr, ccr)
    return {
        "metric_name": "mtr_to_ccr_ratio",
        "metric_value": float(ratio),
        "instances_tested": 1,
        "n_max": n,
        "conjecture_holds": True if abs(ratio - mtr / ccr) <= 0.01 else False,
        "counterexample": ""
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    results = []
    
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {{\"seed\": {seed}, **trial_result}}")
        results.append(trial_result)
    
    if all(result["conjecture_holds"] for result in results):
        mean_value = sum(result["metric_value"] for result in results) / len(results)
        std_value = math.sqrt(sum((result["metric_value"] - mean_value) ** 2 for result in results) / len(results))
        support_fraction = 1.0
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(result["conjecture_holds"] is False for result in results):
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"mtr_to_ccr_ratio does not hold\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE no seeds supported the conjecture")