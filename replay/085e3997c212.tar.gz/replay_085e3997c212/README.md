# Replay package — entry 085e3997c212

Conjecture: [c003b_cumulative_entropy/SC6#c11] Φ(π)/proof_size (number of DP steps) is monotone increasing in n, i.e. per-step active weight grows (the 'shadow heavier than the body' claim).

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 13:41 UTC.
Pre-registration hash committed before this test ran: `8c47fd2918411e68`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
