# Replay package — entry 4e8f376b4353

Conjecture: Minimal Rank of Cocomplexes vs SAT Prover Time Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 22:59 UTC.
Pre-registration hash committed before this test ran: `faa1ba31c0ada7c8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
