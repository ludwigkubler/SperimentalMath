# Replay package — entry 2a5ba21c4ef6

Conjecture: Minimal Order of Symplectic Quotient and Communication Complexity Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 10:54 UTC.
Pre-registration hash committed before this test ran: `b4001f6a2b2ea8e4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
