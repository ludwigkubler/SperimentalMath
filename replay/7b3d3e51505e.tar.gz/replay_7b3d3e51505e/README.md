# Replay package — entry 7b3d3e51505e

Conjecture: Minimal Rank of Generalized Hypergeometric Series vs Resolution Proof Length for k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 16:54 UTC.
Pre-registration hash committed before this test ran: `cd31624c3614a89a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
