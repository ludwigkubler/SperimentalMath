# Replay package — entry 882661254bfb

Conjecture: Minimal Local Algebraic Geometric Rank and Resolution Proof Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 19:10 UTC.
Pre-registration hash committed before this test ran: `1da85b666815fb7f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
