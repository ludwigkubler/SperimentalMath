# Replay package — entry bc750201aaf2

Conjecture: Persistent H_0 Component Count of Sign-Quotient Row Set Caps Real Rank

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-29 00:40 UTC.
Pre-registration hash committed before this test ran: `5b190f5fef43d120`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
