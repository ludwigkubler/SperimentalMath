# Replay package — entry 1cc95e9decc4

Conjecture: Minimal Frobenius Norm of Binary Forms and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 18:28 UTC.
Pre-registration hash committed before this test ran: `38eddf046517d97a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
