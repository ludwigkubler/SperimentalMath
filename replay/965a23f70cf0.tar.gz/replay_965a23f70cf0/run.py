import random
import math
from collections import defaultdict

def generate_bp_transition_matrix(clauses, n, p):
    A = [[0] * (2**n) for _ in range(2**n)]
    for s in range(2**n):
        for t in range(2**n):
            if any((s >> (v-1) & 1) == (t >> (abs(v)-1) & 1)) or all((s >> (v-1) & 1) != (t >> (abs(v)-1) & 1)) for v in range(1, n+1)):
                A[s][t] = 1
    return A

def tropical_rank(A):
    m, n = len(A), len(A[0])
    rank = 0
    for i in range(m):
        if any(A[i][j] != 0 for j in range(n)):
            rank += 1
            for j in range(n):
                if A[i][j] != 0:
                    for k in range(m):
                        A[k][j] = min(A[k][j], A[k][i] + A[i][j])
    return rank

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n = 40
    p = 0.5
    instances_tested = 30
    total_rank = 0
    conjecture_holds = True
    counterexample = ""

    for _ in range(instances_tested):
        clauses = [[random.randint(1, n), random.choice([-1, 1]), random.randint(1, n), random.choice([-1, 1])] for _ in range(n)]
        A = generate_bp_transition_matrix(clauses, n, p)
        rank = tropical_rank(A)
        total_rank += rank
        if rank < 0.3 * n:
            conjecture_holds = False
            counterexample = f"Read-twice BP with rank {rank} < 0.3n"

    return {
        "metric_name": "tropical_rank",
        "metric_value": total_rank / instances_tested,
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2**i + 1 for i in range(5, 35)]
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)

    mean_rank = sum(r["metric_value"] for r in results) / len(results)
    std_rank = math.sqrt(sum((r["metric_value"] - mean_rank)**2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)

    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_rank:.4f} std={std_rank:.4f} support_fraction={support_fraction:.2f}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_rank:.4f} std={std_rank:.4f} support_fraction={support_fraction:.2f}")
    else:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{result['counterexample']}\" first_failing_seed={first_failing_seed}")