# Replay package — entry 21b5099f35a8

Conjecture: Coxeter Group Action Complexity and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 06:57 UTC.
Pre-registration hash committed before this test ran: `02e250349d3c8049`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
