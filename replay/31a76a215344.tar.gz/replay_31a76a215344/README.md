# Replay package — entry 31a76a215344

Conjecture: Minimal Number of Geometric Loci and DPLL Proof Depth Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 23:53 UTC.
Pre-registration hash committed before this test ran: `d6da60df00918ed0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
