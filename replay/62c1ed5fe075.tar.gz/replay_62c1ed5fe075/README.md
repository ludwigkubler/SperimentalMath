# Replay package — entry 62c1ed5fe075

Conjecture: Minimal Number of Noncommutative Crossed Products and Frege Proof Length Correlation via Hopf Algebroids

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 19:19 UTC.
Pre-registration hash committed before this test ran: `c2ceceac3f26b470`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
