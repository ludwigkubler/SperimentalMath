# Replay package — entry c10c070e26bd

Conjecture: Free Cumulant Excess of Laplacian Spectrum Bounds Max-Cut SoS-2 Gap

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 16:51 UTC.
Pre-registration hash committed before this test ran: `8ae6faf4003ddcbf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
