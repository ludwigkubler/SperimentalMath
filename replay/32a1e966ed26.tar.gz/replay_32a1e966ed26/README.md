# Replay package — entry 32a1e966ed26

Conjecture: Tropical Parseval Lower Bound on Discrepancy via Min-Coefficient Saturation

Verdict (original run): FALSIFIED

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 12:38 UTC.
Pre-registration hash committed before this test ran: `765a350a3556b5c0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
