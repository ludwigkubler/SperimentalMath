# Replay package — entry 97a360972c8e

Conjecture: Minimal Rank of Quandle Representations Bounds XOR Circuit Weights

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 15:31 UTC.
Pre-registration hash committed before this test ran: `a6d0b8aa035bcb1c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
