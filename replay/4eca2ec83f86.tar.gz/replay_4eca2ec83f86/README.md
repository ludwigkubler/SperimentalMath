# Replay package — entry 4eca2ec83f86

Conjecture: Free Entropy Gap in Read-Twice Branching Programs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 11:34 UTC.
Pre-registration hash committed before this test ran: `1a1b0187f6457f6c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
