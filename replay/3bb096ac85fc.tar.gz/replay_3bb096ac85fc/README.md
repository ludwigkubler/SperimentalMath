# Replay package — entry 3bb096ac85fc

Conjecture: Arithmetic Progression Invariance of Communication Complexity under Shifts

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 19:27 UTC.
Pre-registration hash committed before this test ran: `ed4d121450cb8889`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
