# Replay package — entry 66a7f7df2a8b

Conjecture: Plethysm Coefficient Gap in Symmetric Powers of Permanent Polynomials

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 06:49 UTC.
Pre-registration hash committed before this test ran: `247c1fc349f1f0d4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
