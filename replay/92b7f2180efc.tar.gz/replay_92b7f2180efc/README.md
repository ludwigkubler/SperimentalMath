# Replay package — entry 92b7f2180efc

Conjecture: Minimal Rank of Formal Power Series over Tropical Polynomial Ring Bounds Resolution Proof Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 14:03 UTC.
Pre-registration hash committed before this test ran: `d1130c852c0a95df`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
