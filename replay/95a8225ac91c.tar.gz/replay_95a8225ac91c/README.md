# Replay package — entry 95a8225ac91c

Conjecture: Minimal Order of Tropical Abelianizations and DPLL Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 11:33 UTC.
Pre-registration hash committed before this test ran: `c5b8a7be493e30dd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
