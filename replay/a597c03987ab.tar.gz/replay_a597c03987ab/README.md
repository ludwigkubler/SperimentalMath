# Replay package — entry a597c03987ab

Conjecture: Coxeter-Diagram Complexity of Frege Proofs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 21:54 UTC.
Pre-registration hash committed before this test ran: `35e0b84c777a14b3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
