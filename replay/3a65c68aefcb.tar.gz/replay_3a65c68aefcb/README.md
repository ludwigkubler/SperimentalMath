# Replay package — entry 3a65c68aefcb

Conjecture: Free Cumulant Norm Gap in Read-Twice BPs for IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-13 01:46 UTC.
Pre-registration hash committed before this test ran: `c3f586b91ac8ec84`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
