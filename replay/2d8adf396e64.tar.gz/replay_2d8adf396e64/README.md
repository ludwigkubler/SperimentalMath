# Replay package — entry 2d8adf396e64

Conjecture: Minimal Index of Tropicalized Quivers vs Resolution Proof Tree Diameter

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 07:43 UTC.
Pre-registration hash committed before this test ran: `f4a108c15a947b8d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
