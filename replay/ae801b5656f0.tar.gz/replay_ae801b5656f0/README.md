# Replay package — entry ae801b5656f0

Conjecture: Minimal Brauer-Induced Tensor Product Rank Correlation with Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 07:27 UTC.
Pre-registration hash committed before this test ran: `3f358129f0f843ed`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
