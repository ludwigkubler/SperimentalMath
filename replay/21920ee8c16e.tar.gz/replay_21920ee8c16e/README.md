# Replay package — entry 21920ee8c16e

Conjecture: PI-Degree Bounds ABP Size for CNF Characteristic Polynomials

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 05:39 UTC.
Pre-registration hash committed before this test ran: `73f3941503023013`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
