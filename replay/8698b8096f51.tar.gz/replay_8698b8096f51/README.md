# Replay package — entry 8698b8096f51

Conjecture: Minimal Rank of Hodge Theoretical Densities over Binary Decision Diagrams

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 22:03 UTC.
Pre-registration hash committed before this test ran: `36bfd4cbb3dbdbdb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
