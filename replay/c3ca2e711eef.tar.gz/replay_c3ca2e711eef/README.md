# Replay package — entry c3ca2e711eef

Conjecture: Polymatroid Rank Lower Bound for Monotone DNF Representing k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 01:18 UTC.
Pre-registration hash committed before this test ran: `e30f0693c3a81062`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
