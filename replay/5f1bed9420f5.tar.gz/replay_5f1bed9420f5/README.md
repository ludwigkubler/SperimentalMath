# Replay package — entry 5f1bed9420f5

Conjecture: Minimal Rank of Tropicalized Quantum States vs Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 21:33 UTC.
Pre-registration hash committed before this test ran: `f9a34c78c69bc074`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
