# Replay package — entry a3bdc2ad46fb

Conjecture: Minimal Rank of Birational Geometry Bounds ACC⁰ Circuit Monotonicity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 22:32 UTC.
Pre-registration hash committed before this test ran: `853739e5b064214f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
