# Replay package — entry 92a5e22e67c8

Conjecture: Minimal Rank of Hodge Decompositions in Algebraic Geometry vs. Monotone Circuit Lower Bounds for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 17:36 UTC.
Pre-registration hash committed before this test ran: `27a5f0d6f6481856`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
