# Replay package — entry ceaca8c608a7

Conjecture: Persistent Homology Barcodes and Communication Complexity of Boolean Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 01:44 UTC.
Pre-registration hash committed before this test ran: `adbcbf2e2f4c714e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
