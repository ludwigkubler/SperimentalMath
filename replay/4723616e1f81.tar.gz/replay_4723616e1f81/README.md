# Replay package — entry 4723616e1f81

Conjecture: Minimal Order of Tropicalized Classical Groups Bounds XOR-AND Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 20:12 UTC.
Pre-registration hash committed before this test ran: `fb266dc637f73b75`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
