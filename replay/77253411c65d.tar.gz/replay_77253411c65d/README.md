# Replay package — entry 77253411c65d

Conjecture: Lie-Stabilizer Dimension of Clause Cubic Bounds DPLL Leaves

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 12:19 UTC.
Pre-registration hash committed before this test ran: `4d70594aff1b1ddf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
