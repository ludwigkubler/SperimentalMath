# Replay package — entry b99dacf3b7fe

Conjecture: Eigenvalue Gap in SOS Moment Matrices for Max-CUT Approximation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 03:17 UTC.
Pre-registration hash committed before this test ran: `da4bc483f56da939`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
