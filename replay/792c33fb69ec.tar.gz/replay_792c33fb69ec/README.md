# Replay package — entry 792c33fb69ec

Conjecture: Tree-to-Dimension Tightness for MAJ_3: Optimal KW Protocols Yield Multiplicity-4 Covers of X_{MAJ_3}

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 06:34 UTC.
Pre-registration hash committed before this test ran: `cdcd5285551689fb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
