# Replay package — entry c1ed9b96b359

Conjecture: Minimal Rank of Tropicalized Sheaves vs DPLL Refutation Tree Diameter

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 08:28 UTC.
Pre-registration hash committed before this test ran: `a7a2b3a7d407c21f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
