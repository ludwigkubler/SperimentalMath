# Replay package — entry fcc13ae0d3f9

Conjecture: Tensor Rank Lower Bound on SOS Refutation Size for Symmetric CSPs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 17:49 UTC.
Pre-registration hash committed before this test ran: `e55a3c48bb150775`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
