# Replay package — entry 373395adc224

Conjecture: Minimal Order of Arithmetic Hierarchy invariants and Resolution Proof Length Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 02:04 UTC.
Pre-registration hash committed before this test ran: `f1e0a8b8be7b6e1d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
