# Replay package — entry 2111619f0a0d

Conjecture: Persistent Homology Total Persistence Inversely Proportional to Resolution Proof Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-13 05:57 UTC.
Pre-registration hash committed before this test ran: `3c596db9afdf3e64`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
