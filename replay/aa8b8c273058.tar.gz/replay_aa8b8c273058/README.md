# Replay package — entry aa8b8c273058

Conjecture: Minimal Index of Formal Language Automorphism Groups and SAT Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-12 06:57 UTC.
Pre-registration hash committed before this test ran: `2504cf7525b6d23a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
