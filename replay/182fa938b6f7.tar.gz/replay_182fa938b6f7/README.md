# Replay package — entry 182fa938b6f7

Conjecture: Minimal Number of Geometrically Independent Lattices Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 14:15 UTC.
Pre-registration hash committed before this test ran: `9fb2fd9dd1fde169`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
