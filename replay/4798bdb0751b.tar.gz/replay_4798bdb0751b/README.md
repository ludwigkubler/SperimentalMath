# Replay package — entry 4798bdb0751b

Conjecture: Integer Point Count in Solution Polytope Bounds Extended Frege Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 01:54 UTC.
Pre-registration hash committed before this test ran: `087ea90c77933746`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
