# Replay package — entry 09a04a4cd320

Conjecture: Minimal Rank of Geometric Entropy vs BP_ReadTwice Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 05:47 UTC.
Pre-registration hash committed before this test ran: `8ca04173037dc087`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
