# Replay package — entry 0b2c6955f48f

Conjecture: Minimal Symmetry Group Order in Graphs and Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 03:29 UTC.
Pre-registration hash committed before this test ran: `2bbb56f5c5fa6acc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
