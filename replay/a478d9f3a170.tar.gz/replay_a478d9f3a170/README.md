# Replay package — entry a478d9f3a170

Conjecture: Minimal Rank of Symplectic Leaves vs. Max-CUT Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 20:51 UTC.
Pre-registration hash committed before this test ran: `4f52ce880cff562f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
