# Replay package — entry 69f5c373041c

Conjecture: Minimal Local Gromov-Witten Invariant and MCSP Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 18:09 UTC.
Pre-registration hash committed before this test ran: `e63fc4c59683b55c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
