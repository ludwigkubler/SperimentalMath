# Replay package — entry 7ddc922145c6

Conjecture: Minimal Norm of Non-Arithmetic Curves Bounds Davis-Putnam Refutation Complexity for Small k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 04:24 UTC.
Pre-registration hash committed before this test ran: `cf3335d5cf4b52b1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
