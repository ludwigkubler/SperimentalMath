# Replay package — entry 5db94ffcbe67

Conjecture: Real Dimension of Parity-Constraint Variety Bounds AC⁰ Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 06:31 UTC.
Pre-registration hash committed before this test ran: `21f0bb7a9b7728f6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
