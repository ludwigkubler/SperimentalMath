# Replay package — entry 91a65d1478b1

Conjecture: Cross-Correlation Spectral Threshold and Communication Entropy Barrier

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 05:52 UTC.
Pre-registration hash committed before this test ran: `286fa7c9e0800f94`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
