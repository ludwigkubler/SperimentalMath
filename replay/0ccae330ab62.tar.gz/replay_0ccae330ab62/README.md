# Replay package — entry 0ccae330ab62

Conjecture: Newton Polytope Vertex Count Bounds SOS Rank for CSP Refutations

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 09:51 UTC.
Pre-registration hash committed before this test ran: `e658d88024368be6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
