# Replay package — entry e50c336911a7

Conjecture: Non-Commutative Rank of ACC^0 Circuits Bounded by Logarithmic Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-30 19:25 UTC.
Pre-registration hash committed before this test ran: `52a65fa5bee9b799`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
