# Replay package — entry 04c00d1d0cca

Conjecture: Litvinov-Maslov Entropy Bound 3β·log(n) for Tropical Doubling Defect

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 10:07 UTC.
Pre-registration hash committed before this test ran: `2d88fb78c156ecf4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
