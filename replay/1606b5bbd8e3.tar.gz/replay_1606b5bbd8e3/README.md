# Replay package — entry 1606b5bbd8e3

Conjecture: Minimal Rank of Quotient Groups over XOR-AND Tree Width Bounds Circuit Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 07:58 UTC.
Pre-registration hash committed before this test ran: `3c71039d132b05b7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
