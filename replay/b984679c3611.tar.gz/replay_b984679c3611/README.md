# Replay package — entry b984679c3611

Conjecture: Minimal Order of Quadratic Residues and SAT Clause Set Entropy Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 00:44 UTC.
Pre-registration hash committed before this test ran: `90f263cf8007e220`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
