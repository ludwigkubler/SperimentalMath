# Replay package — entry a877a6114db2

Conjecture: Tropical Hodge Norm Lower Bound for AC⁰ Parity Circuit Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 19:42 UTC.
Pre-registration hash committed before this test ran: `6160d6bf372ab772`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
