# Replay package — entry 2515221a101f

Conjecture: Plethysm Coefficient Exponential Gap in Symmetric Squares of Permutation Representations for Random CNFs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 22:01 UTC.
Pre-registration hash committed before this test ran: `7ec83c317baa7e88`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
