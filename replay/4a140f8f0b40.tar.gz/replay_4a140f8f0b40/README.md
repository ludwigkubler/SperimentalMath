# Replay package — entry 4a140f8f0b40

Conjecture: Minimal Rank of Graphical Virtual Knots over Tseitin Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 13:16 UTC.
Pre-registration hash committed before this test ran: `1d308a5cbce02990`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
