# Replay package — entry 223537333300

Conjecture: Kashin-Split Energy Gap Lower-Bounds Sign-Matrix Rigidity at Rank n/4

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 12:12 UTC.
Pre-registration hash committed before this test ran: `44acebec51fa75b7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
