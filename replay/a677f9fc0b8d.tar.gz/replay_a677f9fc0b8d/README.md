# Replay package — entry a677f9fc0b8d

Conjecture: Hook-Length Dim of Tseitin T-Join Partition Lower-Bounds Tree-Res

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 18:40 UTC.
Pre-registration hash committed before this test ran: `6b528a89c3e6ba1b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
