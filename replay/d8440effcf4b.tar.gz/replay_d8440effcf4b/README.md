# Replay package — entry d8440effcf4b

Conjecture: Tusnady 2-Box Discrepancy of Clause-Polarity Cloud Bounds DPLL Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 17:45 UTC.
Pre-registration hash committed before this test ran: `0449e10b78ef05b0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
