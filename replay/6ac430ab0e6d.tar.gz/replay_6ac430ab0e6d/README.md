# Replay package — entry 6ac430ab0e6d

Conjecture: Minimal Local Coherence Index and Communication Complexity Rank Variance Ratio

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 12:20 UTC.
Pre-registration hash committed before this test ran: `1c480126b6c5bc8a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
