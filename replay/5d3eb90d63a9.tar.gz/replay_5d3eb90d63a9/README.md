# Replay package — entry 5d3eb90d63a9

Conjecture: Minimal Rank of Cyclic Group Actions vs Read-Twice BP Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 23:41 UTC.
Pre-registration hash committed before this test ran: `df93a8b86cbd8957`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
