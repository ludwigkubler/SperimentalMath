# Replay package — entry 91a357f119e1

Conjecture: Tropicalized Hodge Diamond and Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 06:04 UTC.
Pre-registration hash committed before this test ran: `92c2ec9ec8ba4069`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
