# Replay package — entry 067281302248

Conjecture: Minimal Rank of Sheaves over Projective Schemes and Resolution Proof Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 06:18 UTC.
Pre-registration hash committed before this test ran: `cd18b1a64c87e675`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
