# Replay package — entry e006a48b37a7

Conjecture: Frobenius-Schur Indicator of Clause-Symmetry Group Predicts SAT Symmetry Breaking Cost

Verdict (original run): SUPPORTED

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-24 03:41 UTC.
Pre-registration hash committed before this test ran: `?`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
