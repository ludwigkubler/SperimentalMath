# Replay package — entry 3b8307405b8f

Conjecture: Discrete Morse Betti Growth in Resolution-Frege Triangle Complexes for PHP

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 19:08 UTC.
Pre-registration hash committed before this test ran: `079cf3640d98ff43`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
