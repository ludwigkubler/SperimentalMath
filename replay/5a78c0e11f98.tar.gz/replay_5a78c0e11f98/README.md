# Replay package — entry 5a78c0e11f98

Conjecture: Real Radical Dimension and SOS Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 20:58 UTC.
Pre-registration hash committed before this test ran: `c79b418a7eac18b9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
