# Replay package — entry 72f5d2e9bc93

Conjecture: Minimal Rank of Hodge Decomposition over Tseitin Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 14:11 UTC.
Pre-registration hash committed before this test ran: `b6368d0ae39e57b8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
