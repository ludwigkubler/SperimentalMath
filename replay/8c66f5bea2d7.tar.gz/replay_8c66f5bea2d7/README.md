# Replay package — entry 8c66f5bea2d7

Conjecture: Matroid Rank Gap in Monotone DNF for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 17:16 UTC.
Pre-registration hash committed before this test ran: `403ead459da0536a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
