# Replay package — entry 605bb4a498e3

Conjecture: Minimal Order of Quaternion Algebras vs Monotone Circuit Lower Bounds for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 07:34 UTC.
Pre-registration hash committed before this test ran: `48db7cdf26122f40`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
