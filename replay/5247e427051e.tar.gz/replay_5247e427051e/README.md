# Replay package — entry 5247e427051e

Conjecture: Minimal Rank of Symplectic Leaves vs Communication Complexity for k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 21:53 UTC.
Pre-registration hash committed before this test ran: `0c5697e3f3132240`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
