# Replay package — entry 503fd9190184

Conjecture: Minimal Tensor Rank of Classical Groups and BP_ReadTwice Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 04:27 UTC.
Pre-registration hash committed before this test ran: `8584d4acc85fe3ee`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
