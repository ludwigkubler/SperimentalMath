# Replay package — entry c260b301d24c

Conjecture: Coxeter Group Enumeration of Permutation Matrices for Circuit Width Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 23:51 UTC.
Pre-registration hash committed before this test ran: `d39d841d591156f3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
