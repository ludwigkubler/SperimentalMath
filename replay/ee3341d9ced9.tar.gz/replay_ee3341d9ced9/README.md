# Replay package — entry ee3341d9ced9

Conjecture: Minimal Rank of Tropicalized K-theory over p-adic Fields vs DPLL Search Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 10:12 UTC.
Pre-registration hash committed before this test ran: `7d616001985a25b5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
