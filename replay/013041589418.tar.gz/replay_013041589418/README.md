# Replay package — entry 013041589418

Conjecture: Minimal Rank of Algebraic Hodge Structure vs. DPLL Search Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 01:21 UTC.
Pre-registration hash committed before this test ran: `15beeecda28322fd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
