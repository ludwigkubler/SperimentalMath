# Replay package — entry 8e5f17afbbc5

Conjecture: Minimal Rank of Tropicalized Boolean Functions over p-adic Numbers vs AC0 Parity Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 18:30 UTC.
Pre-registration hash committed before this test ran: `e95b3a45efb4e741`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
