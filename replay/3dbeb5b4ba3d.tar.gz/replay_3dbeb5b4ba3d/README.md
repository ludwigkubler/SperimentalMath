# Replay package — entry 3dbeb5b4ba3d

Conjecture: Noncommutative Fourier Coefficient Norm Separates Read-Twice from Read-Once BPs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 00:21 UTC.
Pre-registration hash committed before this test ran: `2384bcfa0b06d9a8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
