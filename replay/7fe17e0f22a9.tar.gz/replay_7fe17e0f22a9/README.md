# Replay package — entry 7fe17e0f22a9

Conjecture: Seed Length of Nisan-Wigderson PRG from Finite Semifields

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-24 23:06 UTC.
Pre-registration hash committed before this test ran: `41f1b395c9a80762`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
