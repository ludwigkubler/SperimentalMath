# Replay package — entry 29dc0d4a7609

Conjecture: Plethysm Coefficient Inverse Proportional to Disjointness Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 13:41 UTC.
Pre-registration hash committed before this test ran: `dd76b725ad317046`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
