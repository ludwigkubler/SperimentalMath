# Replay package — entry 738bb754804a

Conjecture: Roe-trace pairing for Inner-Product realizes coarse depth κ ≥ log(R) and certifies a quadratic-log gap against random f

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 12:41 UTC.
Pre-registration hash committed before this test ran: `7fe056329997e21a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
