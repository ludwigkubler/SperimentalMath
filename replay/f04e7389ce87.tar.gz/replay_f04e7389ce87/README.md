# Replay package — entry f04e7389ce87

Conjecture: Minimal Rank of Geometric Quantization over Resolution Proof Trees

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 16:39 UTC.
Pre-registration hash committed before this test ran: `86fca4d6b796e097`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
