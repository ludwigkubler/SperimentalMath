# Replay package — entry 66b876365999

Conjecture: Non-Commutative Rank Gap in Read-Twice BPs for IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 14:27 UTC.
Pre-registration hash committed before this test ran: `259e5f26d98d2a3e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
