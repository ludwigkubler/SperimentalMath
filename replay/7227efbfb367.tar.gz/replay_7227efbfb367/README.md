# Replay package — entry 7227efbfb367

Conjecture: 2-Adic Cokernel Type of Sign Matrix Caps Randomized CC

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 01:51 UTC.
Pre-registration hash committed before this test ran: `d06742b46c4174d7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
