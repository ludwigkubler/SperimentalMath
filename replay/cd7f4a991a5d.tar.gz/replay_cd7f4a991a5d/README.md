# Replay package — entry cd7f4a991a5d

Conjecture: Bounded Arithmetic Proof Length and 3-SAT Tautology Resolution Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 05:04 UTC.
Pre-registration hash committed before this test ran: `d2f65820c9c2fcd2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
