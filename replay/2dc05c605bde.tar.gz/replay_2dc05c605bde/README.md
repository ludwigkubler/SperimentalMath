# Replay package — entry 2dc05c605bde

Conjecture: Minimal Hodge Diamond Dimension Bounds Tseitin Formula Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 11:09 UTC.
Pre-registration hash committed before this test ran: `46d2c1769ed1b153`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
