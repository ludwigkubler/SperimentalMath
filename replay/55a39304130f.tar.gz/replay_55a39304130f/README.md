# Replay package — entry 55a39304130f

Conjecture: Minimal Rank of Noncommutative Algebras and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 02:05 UTC.
Pre-registration hash committed before this test ran: `74c12c6f0fed951b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
