# Replay package — entry 57df64f85242

Conjecture: Tropical Tensor-Product Factorization of MinimalFourierCoefficient

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 21:31 UTC.
Pre-registration hash committed before this test ran: `259a25a20a2f3d01`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
