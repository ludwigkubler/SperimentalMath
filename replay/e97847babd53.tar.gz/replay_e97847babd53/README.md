# Replay package — entry e97847babd53

Conjecture: Free Cumulant Gap in Read-Twice Branching Programs for IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 06:11 UTC.
Pre-registration hash committed before this test ran: `b8c539877cecd932`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
