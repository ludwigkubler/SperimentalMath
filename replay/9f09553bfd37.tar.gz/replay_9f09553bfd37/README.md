# Replay package — entry 9f09553bfd37

Conjecture: Curto-Fialkow Hankel Defect Separates Read-Twice IP_2 BPs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 04:32 UTC.
Pre-registration hash committed before this test ran: `74c0bc0f71ba9796`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
