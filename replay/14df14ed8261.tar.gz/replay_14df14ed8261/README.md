# Replay package — entry 14df14ed8261

Conjecture: Bourgain-Tzafriri Sub-Column Spectral Excess Bounds DISJ CC_R

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 22:43 UTC.
Pre-registration hash committed before this test ran: `5477c33731799c0f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
