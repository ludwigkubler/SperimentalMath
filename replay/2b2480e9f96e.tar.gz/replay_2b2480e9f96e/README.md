# Replay package — entry 2b2480e9f96e

Conjecture: Minimal Rank of Lie Algebras Bounds DPLL Tree Depth for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 00:32 UTC.
Pre-registration hash committed before this test ran: `091ecd8fc23cd6f0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
