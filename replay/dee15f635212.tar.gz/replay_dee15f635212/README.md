# Replay package — entry dee15f635212

Conjecture: Clifford Algebroid Rank of SAT Dependency Graph Equals Resolution Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-24 11:21 UTC.
Pre-registration hash committed before this test ran: `6bbf504720c52733`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
