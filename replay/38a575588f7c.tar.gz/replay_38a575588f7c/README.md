# Replay package — entry 38a575588f7c

Conjecture: Schatten Stable Rank of Layer-Difference Stack Lower-Bounds RT-BP IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 22:48 UTC.
Pre-registration hash committed before this test ran: `c6b0f509fb34db89`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
