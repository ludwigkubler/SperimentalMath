# Replay package — entry 2567d2cf369b

Conjecture: Minimal Rank of Ehrhart Cohomology Bounds ACC⁰ Circuit Lower Bound for Linear Equations

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 19:38 UTC.
Pre-registration hash committed before this test ran: `a47172c5c7527c18`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
