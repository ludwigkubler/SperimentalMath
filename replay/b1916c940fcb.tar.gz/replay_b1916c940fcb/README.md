# Replay package — entry b1916c940fcb

Conjecture: Frobenius Trace Defect of Clause-Indicator Polynomial Lower-Bounds ACC^0[2] Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 17:25 UTC.
Pre-registration hash committed before this test ran: `93da3ff4beefb2a9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
