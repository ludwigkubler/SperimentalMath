# Replay package — entry 8f4860266324

Conjecture: Duality-Preserved Phase Cell Bound

Verdict (original run): FALSIFIED

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-30 22:29 UTC.
Pre-registration hash committed before this test ran: `74c0152e9009881c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
