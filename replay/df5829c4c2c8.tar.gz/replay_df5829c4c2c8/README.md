# Replay package — entry df5829c4c2c8

Conjecture: Minimal Rank of Free Probability Entanglement over Read-Twice BP Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 16:25 UTC.
Pre-registration hash committed before this test ran: `8328ca727cbab326`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
