import random
import math
from fractions import Fraction

def generate_random_graph(n):
    graph = []
    for i in range(n):
        for j in range(i + 1, n):
            if random.choice([True, False]):
                graph.append((i, j))
    return graph

def config_space(graph):
    n = len(graph)
    subgraphs = [set() for _ in range(2**n)]
    for subset in range(2**n):
        subgraph = {edge for edge in graph if all(edge[i] in (subset >> i) & 1 for i in range(n))}
        subgraphs[subset].update(subgraph)
    return max(len(subgraph) for subgraph in subgraphs)

def communication_complexity(graph):
    n = len(graph)
    subsets = [set() for _ in range(2**n)]
    for subset in range(2**n):
        for edge in graph:
            if any(edge[i] in (subset >> i) & 1 for i in range(n)):
                subsets[subset].add(edge)
    max_size = max(len(subset) for subset in subsets)
    return math.ceil(math.log(max_size, 2))

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n = random.choice([5, 10, 15, 20, 30, 40])
    graph = generate_random_graph(n)
    rank = config_space(graph)
    comm_complexity = communication_complexity(graph)
    ratio = Fraction(rank, comm_complexity) if comm_complexity != 0 else float('inf')
    return {
        "metric_name": "Rank/CommComplexityRatio",
        "metric_value": ratio,
        "instances_tested": 1,
        "conjecture_holds": ratio <= 1.5,
        "counterexample": "" if ratio <= 1.5 else f"n={n}, rank={rank}, comm_complexity={comm_complexity}"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or list(range(2, 30*31, 2))
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)

    if all("conjecture_holds": True for result in results):
        mean_ratio = sum(result["metric_value"] for result in results) / len(results)
        support_fraction = 1.0
        print(f"RESULT: SUPPORTED mean={mean_ratio} std=0.0 support_fraction={support_fraction}")
    else:
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        counterexample = next(result["counterexample"] for result in results if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{counterexample}\" first_failing_seed={first_failing_seed}")