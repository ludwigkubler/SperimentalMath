# Replay package — entry b295fec69486

Conjecture: Minimal Rank of Hodge Classes over Tropical Geometry vs Resolution Proof Length for Random k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 07:25 UTC.
Pre-registration hash committed before this test ran: `36ec9387e8315cf8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
