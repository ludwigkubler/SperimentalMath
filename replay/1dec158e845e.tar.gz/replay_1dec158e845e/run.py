import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_ac0_circuit(n, s):
        # Simplified AC⁰ circuit generation (not actual AC⁰)
        return [random.choice([0, 1]) for _ in range(s)]
    
    def symmetric_difference(f, g):
        return [x ^ y for x, y in zip(f, g)]
    
    def is_constant(lst):
        return all(x == lst[0] for x in lst)
    
    n_values = [5, 10, 15, 20, 30, 40]
    total_metric_value = 0
    instances_tested = 0
    
    for n in n_values:
        for _ in range(5):  # Test with 5 random AC⁰ circuits of size s up to n inputs
            s = random.randint(1, n)
            circuit = generate_ac0_circuit(n, s)
            metric_value = 0
            
            for g in itertools.product([0, 1], repeat=n):
                if is_constant(symmetric_difference(circuit, g)):
                    metric_value += 1
            
            total_metric_value += metric_value
            instances_tested += n
    
    mean_metric_value = Fraction(total_metric_value, instances_tested)
    conjecture_holds = all(mean_metric_value >= (math.log(n) ** 2 / s) for n in n_values for s in range(1, min(n, 40)))
    
    return {
        "metric_name": "symmetric_difference_divisor_degree",
        "metric_value": float(mean_metric_value),
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": "" if conjecture_holds else "mapping_undefined"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2**i - 1 for i in range(5, 30)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_metric_value = sum(r["metric_value"] for r in results) / len(results)
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std=0.0 support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(s for s, r in zip(seeds, results) if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample='mapping_undefined' first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE reason=mapping_undefined")