# Replay package — entry 8a61e47a0772

Conjecture: Minimal Hodge Degeneration Index and DPLL Search Tree Diameter

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 01:09 UTC.
Pre-registration hash committed before this test ran: `3fdb24b88c10c6cc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
