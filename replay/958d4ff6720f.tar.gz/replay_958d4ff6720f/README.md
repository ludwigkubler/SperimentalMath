# Replay package — entry 958d4ff6720f

Conjecture: Minimal Rank of Tropical Curves Bounds DPLL Search Tree Height

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 13:32 UTC.
Pre-registration hash committed before this test ran: `b406af993e0ba7ac`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
