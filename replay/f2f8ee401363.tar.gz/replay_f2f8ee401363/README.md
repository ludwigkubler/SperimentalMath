# Replay package — entry f2f8ee401363

Conjecture: Minimal Representation Rank of Matroids Associated with Boolean Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 03:47 UTC.
Pre-registration hash committed before this test ran: `0d13315490ffd239`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
