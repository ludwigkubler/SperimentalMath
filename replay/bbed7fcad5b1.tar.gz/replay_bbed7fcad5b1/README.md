# Replay package — entry bbed7fcad5b1

Conjecture: Minimal Local Ring Norm in p-adic Geometry and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 15:56 UTC.
Pre-registration hash committed before this test ran: `b79080d120efdc95`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
