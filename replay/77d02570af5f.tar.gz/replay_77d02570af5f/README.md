# Replay package — entry 77d02570af5f

Conjecture: Minimal Rank of Tropical Divisor Class Group and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 06:58 UTC.
Pre-registration hash committed before this test ran: `3566f294f721b8ce`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
