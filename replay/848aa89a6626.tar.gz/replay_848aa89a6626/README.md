# Replay package — entry 848aa89a6626

Conjecture: Sturmian Factor-Complexity Lower-Bounds DNF-MCSP Term Count

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 13:49 UTC.
Pre-registration hash committed before this test ran: `f4133adbbe2b6408`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
