# Replay package — entry bf0f9125257a

Conjecture: Real Stable Polynomial Degree Lower Bound for Max-CUT SOS

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 20:11 UTC.
Pre-registration hash committed before this test ran: `6a3dd181c31d21de`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
