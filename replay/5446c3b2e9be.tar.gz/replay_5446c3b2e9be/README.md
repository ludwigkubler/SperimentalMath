# Replay package — entry 5446c3b2e9be

Conjecture: Algebraic Topology of Boolean Functions in Resolution Proof Trees

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 18:06 UTC.
Pre-registration hash committed before this test ran: `ae4a2608f8a82378`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
