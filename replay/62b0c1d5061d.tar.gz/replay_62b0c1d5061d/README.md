# Replay package — entry 62b0c1d5061d

Conjecture: Sheaf Cohomology Euler Characteristic and Tseitin Resolution Proof Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 02:31 UTC.
Pre-registration hash committed before this test ran: `2b824f3b3876e34d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
