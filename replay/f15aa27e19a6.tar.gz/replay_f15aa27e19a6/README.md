# Replay package — entry f15aa27e19a6

Conjecture: Minimal Rank of Geometric Invariants in Boolean Lattices vs AC0 Parity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 16:28 UTC.
Pre-registration hash committed before this test ran: `0690497820beb097`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
