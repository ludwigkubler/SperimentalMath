# Replay package — entry 392e88f2ac49

Conjecture: Hypergeometric Function Moments and AC0 PARITY Circuit Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 15:47 UTC.
Pre-registration hash committed before this test ran: `30ecae38f23528bc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
