# Replay package — entry 4dc1555531ec

Conjecture: Minimal Rank of Formal Language Automorphism Groups Bounds AC0 Parity Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 02:00 UTC.
Pre-registration hash committed before this test ran: `6b16f70d351f77ed`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
