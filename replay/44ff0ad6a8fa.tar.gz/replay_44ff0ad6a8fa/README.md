# Replay package — entry 44ff0ad6a8fa

Conjecture: Free Probability Invariant Bounds Randomized Communication Complexity of Disjointness

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 02:57 UTC.
Pre-registration hash committed before this test ran: `70af21d26e5d2059`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
