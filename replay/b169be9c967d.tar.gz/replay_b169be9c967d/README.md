# Replay package — entry b169be9c967d

Conjecture: Knot Cohomology Invariant Bounds for Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 04:24 UTC.
Pre-registration hash committed before this test ran: `363658091c1f6cfb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
