# Replay package — entry 02a2f4e161dc

Conjecture: VC dimension of gadget row family tightly bounds lifted D^cc

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 10:22 UTC.
Pre-registration hash committed before this test ran: `d967702cbf848c57`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
