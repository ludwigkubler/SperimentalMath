# Replay package — entry a4eb91def0de

Conjecture: Minimal Rank of Lie Algebras in Tseitin Formulas Bounds Resolution Proof Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 06:03 UTC.
Pre-registration hash committed before this test ran: `06bc5cfc9b8d3a43`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
