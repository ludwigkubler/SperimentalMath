# Replay package — entry e87da145bc32

Conjecture: Noncommutative Algebraic Growth and Tseitin Resolution Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 00:30 UTC.
Pre-registration hash committed before this test ran: `5c23080df795dc84`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
