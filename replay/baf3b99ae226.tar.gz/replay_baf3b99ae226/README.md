# Replay package — entry baf3b99ae226

Conjecture: Minimal Nonnegative Rank of Matroid Expansion as Monotone Circuit Lower Bound for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 13:59 UTC.
Pre-registration hash committed before this test ran: `4272c7401c7dd989`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
