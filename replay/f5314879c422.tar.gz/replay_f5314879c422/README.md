# Replay package — entry f5314879c422

Conjecture: Minimal Order of Quasi-crystals and Circuit Entanglement Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 19:13 UTC.
Pre-registration hash committed before this test ran: `b9afb1f58c170f8c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
