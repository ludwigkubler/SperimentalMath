# Replay package — entry 149197523066

Conjecture: Discriminant Exponentiation Bounds SOS Refutation Degree for Random 3-SAT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 04:26 UTC.
Pre-registration hash committed before this test ran: `1a0f2e0a5e5030f9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
