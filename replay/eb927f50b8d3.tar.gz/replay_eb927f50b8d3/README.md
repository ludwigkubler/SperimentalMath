# Replay package — entry eb927f50b8d3

Conjecture: Average-Case DPLL Depth and Random Matrix Eigenvalues

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 02:49 UTC.
Pre-registration hash committed before this test ran: `7591ebd697797a8d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
