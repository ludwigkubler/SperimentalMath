# Replay package — entry e90d653a85bf

Conjecture: Forman-Ricci Regularity Bound Certifies Correct F*_v Minterms

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 10:51 UTC.
Pre-registration hash committed before this test ran: `6b8fbb906e9138c3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
