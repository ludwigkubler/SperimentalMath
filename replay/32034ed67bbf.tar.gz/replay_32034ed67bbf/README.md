# Replay package — entry 32034ed67bbf

Conjecture: Minimal Order of Quadratic Intersections Bounds Proof Entropy for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 05:48 UTC.
Pre-registration hash committed before this test ran: `ac96e17ba0c51883`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
