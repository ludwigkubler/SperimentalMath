import random
import math

def gaussian_elimination(A):
    m, n = len(A), len(A[0])
    for i in range(m):
        max_row = i + max(range(i, m), key=lambda r: abs(A[r][i]))
        A[i], A[max_row] = A[max_row], A[i]
        for j in range(n):
            if i != j:
                factor = A[j][i] / A[i][i]
                for k in range(n):
                    A[j][k] -= factor * A[i][k]
    return A

def matrix_multiplication(A, B):
    m, n, p = len(A), len(B), len(B[0])
    C = [[0] * p for _ in range(m)]
    for i in range(m):
        for j in range(p):
            for k in range(n):
                C[i][j] += A[i][k] * B[k][j]
    return C

def sos_refutation_degree(poly_system):
    m = len(poly_system)
    A = [[0] * (m + 1) for _ in range(m + 1)]
    for i in range(m):
        for j in range(i, m):
            term = poly_system[i][j]
            if term:
                A[i][j] += term
                A[j][i] += term
    A[m][m] = 1
    A = gaussian_elimination(A)
    rank = sum(1 for row in A if any(row))
    return rank

def run_trial(seed: int) -> dict:
    random.seed(seed)
    m = 16
    instances_tested = 30
    total_ratio = 0
    counterexample = ""
    
    for _ in range(instances_tested):
        poly_system = [[random.choice([0, 1]) for _ in range(m)] for _ in range(m)]
        refutation_degree = sos_refutation_degree(poly_system)
        ratio = refutation_degree / math.sqrt(m)
        total_ratio += ratio
    
    mean_ratio = total_ratio / instances_tested
    conjecture_holds = abs(mean_ratio - 1) <= 0.2
    
    return {
        "metric_name": "Ratio of Refutation Degree to sqrt(m)",
        "metric_value": mean_ratio,
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2**i - 1 for i in range(5, 30)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_ratio = sum(r["metric_value"] for r in results) / len(results)
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_ratio:.4f} std=0.0000 support_fraction=1.0000")
    elif any(not r["conjecture_holds"] for r in results) and support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_ratio:.4f} std=0.0000 support_fraction={support_fraction:.4f}")
    else:
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"\" first_failing_seed={first_failing_seed}")