# Replay package — entry 88b2482f7682

Conjecture: Semialgebraic Dimension Inverse Proportional to SOS Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 12:44 UTC.
Pre-registration hash committed before this test ran: `e42db50b52a2723a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
