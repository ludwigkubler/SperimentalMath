# Replay package — entry 007b80963b09

Conjecture: MST Persistence Entropy Lower-Bounds Log-Rank of Sign Matrices

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 11:03 UTC.
Pre-registration hash committed before this test ran: `995069bec73cbb55`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
