# Replay package — entry c0e5633d4884

Conjecture: Minimal Ehrhart Semigroup Rank and Frege Proof Complexity Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 03:04 UTC.
Pre-registration hash committed before this test ran: `1e98b3c986efa65a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
