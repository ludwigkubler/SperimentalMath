import random
import math
from collections import defaultdict

def NextClosure(K_f, (Min_f, Max_f)):
    n = len(Max_f)
    closure = set()
    for x in Min_f:
        closure.add(x)
    while True:
        new_closure = set()
        for y in Max_f:
            if all(x[i] == (y[0][i], y[1][i]) for i in range(n)):
                new_closure.add(y)
        if new_closure.issubset(closure):
            break
        closure.update(new_closure)
    return closure

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n = random.choice([4, 5, 6])
    implicants = [frozenset(random.sample(range(n), k)) for _ in range(2 + random.randint(0, 4))]
    f = {tuple(sorted(x)): all(i in x for i in y) for x in implicants for y in implicants}
    
    Min_f = set()
    Max_f = set()
    for x in product([0, 1], repeat=n):
        if all(f[x] == (i in x for i in range(n)) for i in range(n)):
            Min_f.add(x)
        if all(not f[x] == (i in x for i in range(n)) for i in range(n)):
            Max_f.add(x)
    
    K_f = (Min_f, Max_f)
    H = NextClosure(K_f, K_f)
    h_K_f = max(len(path) for path in longest_path(H))
    
    D_plus_f = monotone_kw_depth(f)
    
    conjecture_holds = D_plus_f >= math.ceil(math.log2(h_K_f))
    counterexample = "" if conjecture_holds else f"Counterexample found with n={n}, Min(f)={Min_f}, Max(f)={Max_f}"
    
    return {
        "metric_name": "KW Depth",
        "metric_value": D_plus_f,
        "instances_tested": 1,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

def monotone_kw_depth(f):
    n = len(next(iter(f)))
    memo = {}
    
    def dp(x, y):
        if (x, y) in memo:
            return memo[(x, y)]
        if x == y:
            return 0
        if not any(f[x] for i in range(n)):
            return float('inf')
        if all(f[x] for i in range(n)):
            return 1
        min_depth = float('inf')
        for i in range(n):
            if f[x][i]:
                new_y = y[:i] + (0,) + y[i+1:]
                min_depth = min(min_depth, dp(x, new_y) + 1)
            else:
                new_y = y[:i] + (1,) + y[i+1:]
                min_depth = min(min_depth, dp(x, new_y) + 1)
        memo[(x, y)] = min_depth
        return min_depth
    
    D_plus_f = float('inf')
    for x in product([0, 1], repeat=n):
        for y in product([0, 1], repeat=n):
            if all(f[x] == (i in x for i in range(n)) for i in range(n)):
                D_plus_f = min(D_plus_f, dp(x, y))
    return D_plus_f

def longest_path(graph):
    n = len(graph)
    dist = [[float('inf')] * n for _ in range(n)]
    for i in range(n):
        dist[i][i] = 0
    for u, v in graph:
        dist[u][v] = 1
    
    for k in range(n):
        for i in range(n):
            for j in range(n):
                if dist[i][k] + dist[k][j] < dist[i][j]:
                    dist[i][j] = dist[i][k] + dist[k][j]
    
    paths = []
    for start in range(n):
        path = [start]
        current = start
        while len(path) < n and dist[current][path[-1]] != float('inf'):
            next_node = None
            min_dist = float('inf')
            for neighbor in range(n):
                if neighbor not in path and dist[current][neighbor] + dist[neighbor][path[-1]] == dist[current][path[-1]]:
                    if dist[current][neighbor] < min_dist:
                        min_dist = dist[current][neighbor]
                        next_node = neighbor
            if next_node is None:
                break
            path.append(next_node)
            current = next_node
        paths.append(path)
    
    return paths

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2**i + 1 for i in range(5, 8)]
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value)**2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(s for s, r in zip(seeds, results) if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{r['counterexample']}\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE mapping_undefined")