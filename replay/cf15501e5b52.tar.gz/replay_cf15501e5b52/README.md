# Replay package — entry cf15501e5b52

Conjecture: Tropical Geometry of Boolean Lattices and Resolution Proof Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 06:56 UTC.
Pre-registration hash committed before this test ran: `1d03b1c467795080`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
