# Replay package — entry 6a507261ca55

Conjecture: Bakry-Émery Curvature Floor Lower-Bounds Tseitin Resolution Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 19:42 UTC.
Pre-registration hash committed before this test ran: `6344657d6fe0473d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
