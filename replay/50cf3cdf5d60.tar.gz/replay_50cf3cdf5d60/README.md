# Replay package — entry 50cf3cdf5d60

Conjecture: Minimal Diophantine Degree Correlation with Circuit Monotone Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 16:48 UTC.
Pre-registration hash committed before this test ran: `49d08e6292030850`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
