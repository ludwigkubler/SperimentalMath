# Replay package — entry bf2266d4894d

Conjecture: Minimal Order of Quadratic Forms and Circuit Monotone Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 20:04 UTC.
Pre-registration hash committed before this test ran: `4e12f287c4a599c0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
