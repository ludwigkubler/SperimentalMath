# Replay package — entry 17460b6d540e

Conjecture: Loomis-Whitney Marginal Defect of 3-XOR Solution Lattice Tracks SoS Refutation Threshold

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 22:35 UTC.
Pre-registration hash committed before this test ran: `e029575f2d63b326`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
