# Replay package — entry 96f06d91d088

Conjecture: Column-Subset Discrepancy Lower-Bounds Disjointness Protocol Tree Leaves

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-16 23:03 UTC.
Pre-registration hash committed before this test ran: `201e18fc436c5405`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
