# Replay package — entry d7def4893c78

Conjecture: Minimal Root Sum of Integer Polynomials and Frege Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 11:45 UTC.
Pre-registration hash committed before this test ran: `f599cf6b4033aaee`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
