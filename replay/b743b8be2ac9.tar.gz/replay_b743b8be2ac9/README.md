# Replay package — entry b743b8be2ac9

Conjecture: Minimal Local Coherence and DPLL Proof Path Length Lower Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 07:50 UTC.
Pre-registration hash committed before this test ran: `bcb0584c0f8bd0d4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
