# Replay package — entry 71df4ad88e5f

Conjecture: Minimal Local Defect Complexity of Affine Quotients vs Boolean Function Monomial Symmetry

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 06:11 UTC.
Pre-registration hash committed before this test ran: `dd8e7d3c3b337a1e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
