# Replay package — entry e1525ec3333f

Conjecture: Completely Bounded Norm Gap in Read-Twice BPs for IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 19:34 UTC.
Pre-registration hash committed before this test ran: `92ce72f79ed4c10a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
