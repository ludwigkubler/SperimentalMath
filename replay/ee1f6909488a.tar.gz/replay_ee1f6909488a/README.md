# Replay package — entry ee1f6909488a

Conjecture: Minimal Index of Noncommutative Symmetric Spaces and DPLL Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 09:42 UTC.
Pre-registration hash committed before this test ran: `52b9706ae6f3d852`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
