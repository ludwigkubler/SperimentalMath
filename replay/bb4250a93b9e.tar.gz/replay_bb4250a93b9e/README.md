# Replay package — entry bb4250a93b9e

Conjecture: Minimal Rank of Monodromy Representations vs Boolean Circuit Size for XOR-AND Networks

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 22:48 UTC.
Pre-registration hash committed before this test ran: `163fdf535c4e0150`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
