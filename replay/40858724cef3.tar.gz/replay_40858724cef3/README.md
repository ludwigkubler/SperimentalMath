# Replay package — entry 40858724cef3

Conjecture: Minimal Order of Algebraic Topology in Monomial Ideal Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 20:02 UTC.
Pre-registration hash committed before this test ran: `41546eb93d858d47`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
