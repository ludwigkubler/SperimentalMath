# Replay package — entry 468564150b95

Conjecture: Rank of Quantum Entanglement Tensor Bounds Communication Complexity for Max-Cut

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 20:41 UTC.
Pre-registration hash committed before this test ran: `b40647b10c65e85f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
