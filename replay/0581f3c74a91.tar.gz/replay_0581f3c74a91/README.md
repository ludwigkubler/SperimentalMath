# Replay package — entry 0581f3c74a91

Conjecture: Symmetric Polynomial Invariant Degree Bounds AC⁰ PARITY Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 08:38 UTC.
Pre-registration hash committed before this test ran: `8ce87d5adc399703`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
