# Replay package — entry a7d25b63a500

Conjecture: Minimal Order of Quaternionic Automorphism Groups and Circuit Entanglement Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 20:52 UTC.
Pre-registration hash committed before this test ran: `96eacc1d58c605ea`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
