# Replay package — entry 4ef03310cdd6

Conjecture: Minimal Lefschetz Finiteness and Frege Proof Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 00:56 UTC.
Pre-registration hash committed before this test ran: `3b3dbaece83980d2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
