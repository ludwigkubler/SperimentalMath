# Replay package — entry 9d3b5f3f6b3b

Conjecture: Minimal Cyclic Order and Resolution Proof Width Lower Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 06:25 UTC.
Pre-registration hash committed before this test ran: `b7f13f7c66c9247f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
