# Replay package — entry 93e2fe31dd48

Conjecture: Non-Abelian Harmonic Analysis and SOS Refutation Degree for CSPs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 01:05 UTC.
Pre-registration hash committed before this test ran: `0e7243ef883f0cff`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
