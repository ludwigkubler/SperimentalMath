# Replay package — entry eff6dec1e004

Conjecture: Maximum Fourier Coefficient Lower Bound via Sensitivity Scaling

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-07 21:18 UTC.
Pre-registration hash committed before this test ran: `639e9f7367d4c511`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
