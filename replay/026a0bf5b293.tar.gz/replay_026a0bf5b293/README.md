# Replay package — entry 026a0bf5b293

Conjecture: Minimal Rank of Tropical Derivatives vs Resolution Proof Length for XOR Tautologies

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 09:43 UTC.
Pre-registration hash committed before this test ran: `1c6c1e5cc2d08962`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
