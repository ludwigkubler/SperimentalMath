# Replay package — entry 261929f884e5

Conjecture: Arithmetic Hodge Index vs ACC⁰ Circuit Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 21:44 UTC.
Pre-registration hash committed before this test ran: `fc33477adc0a6e09`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
