import random
import math
from collections import defaultdict

def generate_random_matroid(n, p):
    A = [[random.choice([0, 1]) for _ in range(n)] for _ in range(n)]
    while not is_independent_set(A, n, p):
        A = [[random.choice([0, 1]) for _ in range(n)] for _ in range(n)]
    return A

def is_independent_set(A, n, p):
    for i in range(n):
        if any(all(B[j][k] == A[i][k] for k in range(i)) for j in range(i)):
            return False
    return True

def rank_of_matroid(A, n):
    I = []
    for i in range(n):
        if all(A[i][j] == 0 for j in range(i) if i != j):
            I.append(i)
    return len(I)

def simulate_disjointness_protocol(A, n):
    depth = 0
    queue = [set()]
    while queue:
        new_queue = []
        for s in queue:
            if len(s) == n:
                break
            for i in range(n):
                if i not in s and all(A[i][j] == A[j][i] for j in s):
                    new_queue.append(s | {i})
        depth += 1
        if not new_queue:
            return float('inf')
        queue = new_queue
    return depth

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n = 16
    p = 2
    A = generate_random_matroid(n, p)
    rank = rank_of_matroid(A, n)
    protocol_depth = simulate_disjointness_protocol(A, n)
    metric_value = protocol_depth / (rank * math.log2(n))
    conjecture_holds = metric_value >= 1
    counterexample = "" if conjecture_holds else f"Protocol depth {protocol_depth} < {rank * math.log2(n)}"
    return {
        "metric_name": "Communication Complexity",
        "metric_value": metric_value,
        "instances_tested": 1,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2**i + 1 for i in range(5, 30)]
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)

    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value)**2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)

    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{results[0]['counterexample']}\" first_failing_seed={first_failing_seed}")