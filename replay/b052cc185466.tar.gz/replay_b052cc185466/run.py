import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def is_prime(n):
        if n <= 1:
            return False
        for i in range(2, int(math.sqrt(n)) + 1):
            if n % i == 0:
                return False
        return True
    
    def generate_primes(count):
        primes = []
        num = 2
        while len(primes) < count:
            if is_prime(num):
                primes.append(num)
            num += 1
        return primes
    
    def gaussian_elimination(matrix):
        m, n = len(matrix), len(matrix[0])
        for i in range(m):
            max_row = i
            for j in range(i + 1, m):
                if abs(matrix[j][i]) > abs(matrix[max_row][i]):
                    max_row = j
            matrix[i], matrix[max_row] = matrix[max_row], matrix[i]
            if matrix[i][i] == 0:
                continue
            for j in range(n):
                matrix[i][j] /= matrix[i][i]
            for j in range(m):
                if i != j:
                    factor = matrix[j][i]
                    for k in range(n):
                        matrix[j][k] -= factor * matrix[i][k]
        return matrix
    
    def rank(matrix):
        m, n = len(matrix), len(matrix[0])
        row echelon_form = gaussian_elimination(matrix)
        rank = 0
        for i in range(m):
            if any(echelon_form[i][j] != 0 for j in range(n)):
                rank += 1
        return rank
    
    def generate_k_clique_cnf(n, k):
        clauses = []
        variables = list(range(1, n + 1))
        for i in range(k):
            clause = random.sample(variables, 2)
            clause.append(-random.choice(clause))
            clauses.append(clause)
        return clauses
    
    def matroid_rank_function(cnf, S):
        matrix = [[0] * (n + 1) for _ in range(n + 1)]
        for literal in cnf:
            if all(abs(literal[i]) not in S for i in range(2)):
                continue
            for i in range(2):
                var = abs(literal[i])
                matrix[var][var] += 1
                for j in range(i + 1, 2):
                    other_var = abs(literal[j])
                    matrix[var][other_var] -= 1
                    matrix[other_var][var] -= 1
        return rank(matrix)
    
    n = random.choice([5, 10, 15, 20, 30, 40])
    k = min(2, n // 2)
    cnf = generate_k_clique_cnf(n, k)
    S_size = math.ceil(math.sqrt(n))
    S = set(random.sample(range(1, n + 1), S_size))
    
    r_S = matroid_rank_function(cnf, S)
    min_elements = next(i for i in range(S_size, n + 1) if matroid_rank_function(cnf, set(range(1, i + 1))) >= r_S)
    
    conjecture_holds = min_elements == math.ceil(math.sqrt(n))
    counterexample = "" if conjecture_holds else f"min_elements={min_elements}, expected=math.ceil(math.sqrt({n}))={math.ceil(math.sqrt(n))}"
    
    return {
        "metric_name": "Minimum elements to achieve rank",
        "metric_value": min_elements,
        "instances_tested": 1,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(arg) for arg in sys.argv[1:]] or generate_primes(30)
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_metric_value = sum(r["metric_value"] for r in results) / len(results)
    std_metric_value = math.sqrt(sum((r["metric_value"] - mean_metric_value) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_metric_value} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(seed for seed, r in zip(seeds, results) if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{results[seeds.index(first_failing_seed)]['counterexample']}\" first_failing_seed={first_failing_seed}")
    else:
        print(f"RESULT: INCONCLUSIVE mapping_undefined")