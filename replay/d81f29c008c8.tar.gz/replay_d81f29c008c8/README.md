# Replay package — entry d81f29c008c8

Conjecture: Minimal Local Curvature of Metrics vs Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 00:49 UTC.
Pre-registration hash committed before this test ran: `33e7eff616f5d6ae`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
