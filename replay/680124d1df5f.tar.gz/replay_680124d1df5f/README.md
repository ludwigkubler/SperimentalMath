# Replay package — entry 680124d1df5f

Conjecture: Association Scheme Eigenvalue Inverse Proportional to ACC^0 Circuit Size for CNF Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 09:56 UTC.
Pre-registration hash committed before this test ran: `c3db8528810026ec`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
