import random
import math
from fractions import Fraction

def generate_3cnf(n, m):
    clauses = []
    for _ in range(m):
        clause = set(random.sample(range(1, n+1), 3))
        if len(clause) == 3:
            clauses.append(clause)
    return clauses

def noncrossing_partition(clauses, n):
    partition = {i: [] for i in range(1, n+1)}
    for clause in clauses:
        var = random.choice(list(clause))
        partition[var].append(clause)
    return partition

def complexity(partition, n):
    max_clauses_per_var = 0
    for var in range(1, n+1):
        if var in partition and len(partition[var]) > max_clauses_per_var:
            max_clauses_per_var = len(partition[var])
    return max_clauses_per_var

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n = 20
    m = 100
    clauses = generate_3cnf(n, m)
    partition = noncrossing_partition(clauses, n)
    metric_value = complexity(partition, n)
    instances_tested = 1
    conjecture_holds = False
    counterexample = ""
    
    if metric_value >= Fraction(m**(1/4) * n**(5/12), 1):
        conjecture_holds = True
    
    return {
        "metric_name": "complexity",
        "metric_value": metric_value,
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r['metric_value'] for r in results) / len(results)
    support_fraction = sum(1 for r in results if r['conjecture_holds']) / len(results)
    
    if all(r['conjecture_holds'] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std=0.0 support_fraction=1.0")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std=0.0 support_fraction={support_fraction}")
    else:
        for r in results:
            if not r['conjecture_holds']:
                counterexample = f"n={r['instances_tested']}, m={m}"
                break
        print(f"RESULT: FALSIFIED counterexample=\"{counterexample}\" first_failing_seed={seeds[results.index(r)]}")