# Replay package — entry 5de245e2396b

Conjecture: Hypergraph Matching Complexity for Monotone DNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 00:37 UTC.
Pre-registration hash committed before this test ran: `cac96d58855a56e1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
