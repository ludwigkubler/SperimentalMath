# Replay package — entry 15542d600c45

Conjecture: Hilbert-Compression Floor on Property-A Gadgets Forces α·Q(f) Multiplicity in Protocol Pullbacks

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 23:06 UTC.
Pre-registration hash committed before this test ran: `f8e94156323e988f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
