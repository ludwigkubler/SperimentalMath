# Replay package — entry 11f8ad7f3b4a

Conjecture: Minimal Order of Eta-Quotient and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 22:38 UTC.
Pre-registration hash committed before this test ran: `007a601c423ae164`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
