# Replay package — entry 62882a0995f5

Conjecture: [c003b_cumulative_entropy/SC6#c11] Φ(π)/proof_size (number of DP steps) is monotone increasing in n, i.e. per-step active weight grows (the 'shadow heavier than the body' claim).

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-15 07:01 UTC.
Pre-registration hash committed before this test ran: `fa27a8e92ae5f433`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
