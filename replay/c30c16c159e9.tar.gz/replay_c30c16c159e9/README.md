# Replay package — entry c30c16c159e9

Conjecture: Free Cumulant κ₄ of Disjointness Spectrum Lower-Bounds R(DISJ)

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-07 21:02 UTC.
Pre-registration hash committed before this test ran: `64ae81e2a5341a8b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
