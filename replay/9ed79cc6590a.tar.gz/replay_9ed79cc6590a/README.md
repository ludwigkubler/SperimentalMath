# Replay package — entry 9ed79cc6590a

Conjecture: Minimal Rank of Hodge Decomposition Modules and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 03:21 UTC.
Pre-registration hash committed before this test ran: `9c1f9aa99c1f1277`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
