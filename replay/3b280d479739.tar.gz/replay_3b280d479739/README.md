# Replay package — entry 3b280d479739

Conjecture: Gate-Cone Poset Mobius Value Lower-Bounds ACC0 Size for MOD-q

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 15:23 UTC.
Pre-registration hash committed before this test ran: `32640d3f7431f4a2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
