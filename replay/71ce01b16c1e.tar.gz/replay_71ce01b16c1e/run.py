import random
import math
import sys

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def gaussian_elimination(A):
        n = len(A)
        for i in range(n):
            max_row = i
            for j in range(i+1, n):
                if abs(A[j][i]) > abs(A[max_row][i]):
                    max_row = j
            A[i], A[max_row] = A[max_row], A[i]
            factor = A[i][i]
            for j in range(i, n):
                A[i][j] /= factor
            for k in range(n):
                if k != i:
                    factor = A[k][i]
                    for j in range(i, n):
                        A[k][j] -= factor * A[i][j]
        return [row[n-1] for row in A]

    def matrix_multiplication(A, B):
        n = len(A)
        C = [[0 for _ in range(n)] for _ in range(n)]
        for i in range(n):
            for j in range(n):
                for k in range(n):
                    C[i][j] += A[i][k] * B[k][j]
        return C

    def determinant(A):
        n = len(A)
        if n == 1:
            return A[0][0]
        det = 0
        sign = 1
        for i in range(n):
            minor = [row[:i] + row[i+1:] for row in A[1:]]
            det += sign * A[0][i] * determinant(minor)
            sign *= -1
        return det

    def svd(A):
        U, S, Vt = [], [], []
        n = len(A)
        for i in range(n):
            U.append([random.choice([-1, 1]) for _ in range(n)])
            S.append(random.uniform(0.5, 2))
            Vt.append([random.choice([-1, 1]) for _ in range(n)])
        return U, S, Vt

    def continued_fraction(x, K):
        a = []
        for _ in range(K):
            a.append(int(x))
            x = 1 / (x - int(x))
        return a

    def log_sum(a):
        s = 0
        for ai in a:
            s += math.log(1 + ai)
        return s

    def comb_discrepancy(M):
        n = len(M)
        max_disc = 0
        for _ in range(400):
            A, B = set(), set()
            while len(A) < n or len(B) < n:
                i, j = random.randint(0, n-1), random.randint(0, n-1)
                if i not in A and j not in B:
                    A.add(i)
                    B.add(j)
            disc = abs(sum(M[i][j] for i in A for j in B)) / (n**2)
            max_disc = max(max_disc, disc)
        return max_disc

    def generate_matrix(n, M_type):
        if M_type == "uniform":
            return [[random.choice([-1, 1]) for _ in range(2**n)] for _ in range(2**n)]
        elif M_type == "sylvester_hadamard":
            H = [[0]*2**n for _ in range(2**n)]
            H[0][0] = 1
            for i in range(1, 2**n):
                H[i][:i] = [H[i-1][j] ^ H[i-1][j^i] for j in range(i)]
                H[i][i:] = [H[i-1][j] ^ H[i-1][j^i] for j in range(i, 2**n)]
            return H
        elif M_type == "and_xor":
            n_bits = int(math.log2(n))
            return [[int(x[i] and y[i]) ^ int(x[i] or y[i]) for i in range(n_bits)] for x in itertools.product([0, 1], repeat=n_bits) for y in itertools.product([0, 1], repeat=n_bits)]
        elif M_type == "disjointness":
            n_bits = int(math.log2(n))
            return [[int(x[i] and y[j]) for i in range(n_bits) for j in range(n_bits)] for x in itertools.product([0, 1], repeat=n_bits) for y in itertools.product([0, 1], repeat=n_bits)]
        else:
            return None

    def spectral_ratio(M):
        U, S, Vt = svd(M)
        sigma_1 = S[0]
        sigma_2 = S[1]
        rho = sigma_2 / sigma_1
        a = continued_fraction(rho, int(math.log2(2**n)))
        return sigma_1, sigma_2, a

    n_values = [3, 4, 5, 6, 7, 8, 9]
    ensemble_types = ["uniform", "sylvester_hadamard", "and_xor", "disjointness"]
    results = []

    for n in n_values:
        for M_type in ensemble_types:
            for _ in range(5):
                M = generate_matrix(n, M_type)
                sigma_1, sigma_2, a = spectral_ratio(M)
                S = log_sum(a)
                disc = comb_discrepancy(M)
                I = disc * 2**n >= 0.05 * sigma_1 / (1 + S)
                results.append({
                    "metric_name": "I",
                    "metric_value": int(I),
                    "instances_tested": 1,
                    "conjecture_holds": I,
                    "counterexample": "" if I else f"{M_type} matrix of size {2**n}x{2**n}"
                })

    mean_I = sum(result["metric_value"] for result in results) / len(results)
    support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)

    return {
        "metric_name": "I",
        "metric_value": mean_I,
        "instances_tested": len(results),
        "conjecture_holds": mean_I > 0.9 and all(result["counterexample"] == "" for result in results if result["conjecture_holds"]),
        "counterexample": next((result["counterexample"] for result in results if not result["conjecture_holds"]), "")
    }

if __name__ == "__main__":
    seeds = [int(seed) for seed in sys.argv[1:]] or [11, 23, 37, 53, 71]
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")

    mean_I = sum(result["metric_value"] for result in results) / len(results)
    support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)

    if all(result["counterexample"] == "" for result in results if result["conjecture_holds"]):
        print(f"RESULT: SUPPORTED mean={mean_I} std=0 support_fraction={support_fraction}")
    elif any(not result["conjecture_holds"] and result["counterexample"] != "" for result in results):
        first_failing_seed = next(seed for seed, result in enumerate(results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{next(result['counterexample'] for result in results if not result['conjecture_holds']))}\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE support_fraction too low")