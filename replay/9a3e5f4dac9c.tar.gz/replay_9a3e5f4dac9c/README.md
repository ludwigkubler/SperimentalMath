# Replay package — entry 9a3e5f4dac9c

Conjecture: Minimal Rank of Tropicalized Permutation Matrices vs Quantum Circuit Depth for Clifford Group States

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 00:13 UTC.
Pre-registration hash committed before this test ran: `5c5580b8d6e5bf4e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
