# Replay package — entry be49a7bf101a

Conjecture: Minimal Rank of Algebraic K-Theory over Boolean Functions vs SOS Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 07:15 UTC.
Pre-registration hash committed before this test ran: `2535816b6818ea37`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
