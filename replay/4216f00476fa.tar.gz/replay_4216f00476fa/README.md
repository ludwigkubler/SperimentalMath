# Replay package — entry 4216f00476fa

Conjecture: Minimal Order of Algebraic Hodge Structures and Resolution Proof Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 11:02 UTC.
Pre-registration hash committed before this test ran: `753390403f4a5e1a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
