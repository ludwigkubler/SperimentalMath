# Replay package — entry 27cc4015a56b

Conjecture: 2-Torsion in Chow Group of Binary Clause Variety Bounds Resolution Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-24 01:06 UTC.
Pre-registration hash committed before this test ran: `?`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
