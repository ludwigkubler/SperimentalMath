# Replay package — entry 7b2b667cc100

Conjecture: Hypergeometric Function Rank of Boolean Functions Bounds Communication Complexity for XOR

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 11:46 UTC.
Pre-registration hash committed before this test ran: `8d733c7beeb59620`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
