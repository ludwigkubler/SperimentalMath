# Replay package — entry 1cc41088410f

Conjecture: Minimal Frobenius-Schur Index and Boolean Circuit Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 16:37 UTC.
Pre-registration hash committed before this test ran: `a39c6185e7e96a81`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
