import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_truth_table(n):
        return [[random.choice([0, 1]) for _ in range(2**n)] for _ in range(2**n)]
    
    def tensor_product(A, B):
        m, k = len(A), len(B[0])
        n = len(B)
        result = [[0] * (k * n) for _ in range(m * n)]
        for i in range(m):
            for j in range(n):
                for l in range(k):
                    result[i * n + j][l * n:(l + 1) * n] = [A[i][j] * B[j][l][k] for k in range(k)]
        return result
    
    def matrix_rank(matrix):
        m, n = len(matrix), len(matrix[0])
        rank = 0
        for i in range(m):
            if all(matrix[i][j] == 0 for j in range(n)):
                continue
            rank += 1
            for j in range(n):
                if matrix[i][j] != 0:
                    pivot = Fraction(matrix[i][j])
                    break
            for k in range(i + 1, m):
                factor = Fraction(matrix[k][j], pivot)
                for l in range(n):
                    matrix[k][l] -= factor * matrix[i][l]
        return rank
    
    def dpll_conversion_time(n):
        # Placeholder function to simulate conversion time
        # Replace this with actual DPLL conversion time calculation
        return random.randint(1, 100)
    
    n = random.choice([5, 10, 15, 20, 30, 40])
    truth_table = generate_truth_table(n)
    identity_matrix = [[1 if i == j else 0 for j in range(2**n)] for i in range(2**n)]
    tensor_prod = tensor_product(truth_table, identity_matrix)
    rank_value = matrix_rank(tensor_prod)
    conversion_time = dpll_conversion_time(n)
    
    return {
        "metric_name": "log_2(rank) vs log_t(DPLL)",
        "metric_value": math.log2(rank_value),
        "instances_tested": 1,
        "conjecture_holds": False,
        "counterexample": "mapping_undefined"
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] or [3, 7, 11, 13, 17, 19, 23, 29] * 4
    results = []
    
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_metric_value = sum(r["metric_value"] for r in results) / len(results)
    std_metric_value = math.sqrt(sum((r["metric_value"] - mean_metric_value) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_metric_value} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"mapping_undefined\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE reason=insufficient_evidence")