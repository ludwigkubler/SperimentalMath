import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_random_circuit(n):
        circuit = []
        for _ in range(2**n):
            gate = random.choice(['AND', 'OR'])
            inputs = [random.randint(0, 1) for _ in range(n)]
            circuit.append((gate, inputs))
        return circuit
    
    def calculate_entanglement_complexity(circuit):
        complexity = 0
        for gate, inputs in circuit:
            if gate == 'AND':
                complexity += sum(inputs)
            elif gate == 'OR':
                complexity += len([x for x in inputs if x == 1])
        return complexity
    
    def calculate_symplectic_form_degree(circuit):
        n = int(math.log2(len(circuit)))
        form = [[0] * n for _ in range(n)]
        for gate, inputs in circuit:
            for i in range(n):
                for j in range(i+1, n):
                    if gate == 'AND':
                        form[i][j] += inputs[i] & inputs[j]
                        form[j][i] += inputs[i] & inputs[j]
                    elif gate == 'OR':
                        form[i][j] += inputs[i] | inputs[j]
                        form[j][i] += inputs[i] | inputs[j]
        return sum(sum(row) for row in form)
    
    n = random.randint(5, 40)
    circuit = generate_random_circuit(n)
    entanglement_complexity = calculate_entanglement_complexity(circuit)
    symplectic_form_degree = calculate_symplectic_form_degree(circuit)
    
    return {
        "metric_name": "SymplecticFormDegree",
        "metric_value": symplectic_form_degree,
        "instances_tested": 1,
        "n_max": n,
        "conjecture_holds": symplectic_form_degree <= entanglement_complexity,
        "counterexample": "" if symplectic_form_degree <= entanglement_complexity else f"mfd(C)={symplectic_form_degree} > EntanglementComplexity(C)={entanglement_complexity}"
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] or [
        2, 3, 5, 7, 11, 13, 17, 19, 23, 29,
        31, 37, 41, 43, 47, 53, 59, 61, 67, 71,
        73, 79, 83, 89, 97, 101, 103, 107, 109, 113
    ]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"mfd(C) > EntanglementComplexity(C)\" first_failing_seed={first_failing_seed}")