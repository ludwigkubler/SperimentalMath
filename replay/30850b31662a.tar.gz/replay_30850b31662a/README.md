# Replay package — entry 30850b31662a

Conjecture: Jordan Algebra Rank Inverse Proportional to ABP Width for Symmetric Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 11:59 UTC.
Pre-registration hash committed before this test ran: `825ef6a618e8efc6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
