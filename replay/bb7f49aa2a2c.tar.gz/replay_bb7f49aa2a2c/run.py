import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    n = 30
    if n < 5 or n > 40:
        return {
            "metric_name": "minimal_rank",
            "metric_value": None,
            "instances_tested": 0,
            "conjecture_holds": False,
            "counterexample": "invalid_n"
        }
    
    # Generate a random boolean function with entropy H(f)
    num_vars = random.randint(1, n)
    f = [random.choice([0, 1]) for _ in range(2**num_vars)]
    h_f = -sum(p * math.log2(p) for p in (f.count(0)/len(f), f.count(1)/len(f))) if 0 not in (f.count(0), f.count(1)) else 0
    
    # Construct a minimal deterministic finite automaton (DFA) accepting the language defined by the function
    states = [{'q': 0, 'transitions': {}}]
    for i in range(len(f)):
        new_state = len(states)
        states.append({'q': new_state, 'transitions': {}})
        states[0]['transitions'][i] = new_state
    
    # Measure the number of states in each DFA
    num_states = len(states)
    
    # Compare it with 2^H(f)
    conjecture_holds = num_states <= 2**h_f
    
    return {
        "metric_name": "minimal_rank",
        "metric_value": num_states,
        "instances_tested": 1,
        "conjecture_holds": conjecture_holds,
        "counterexample": "" if conjecture_holds else f"Counterexample for H(f) = {h_f}, states = {num_states}"
    }

if __name__ == "__main__":
    seeds = [int(s) for s in sys.argv[1:]] or [2**i - 1 for i in range(5, 30)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value)**2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next((r["seed"] for r in results if not r["conjecture_holds"]), None)
        counterexample = next((r["counterexample"] for r in results if not r["conjecture_holds"]), "")
        print(f"RESULT: FALSIFIED counterexample=\"{counterexample}\" first_failing_seed={first_failing_seed}")