# Replay package — entry cd771dc62fac

Conjecture: Width-5 ABPs and NC¹ Circuit Simulation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-29 04:23 UTC.
Pre-registration hash committed before this test ran: `89c4e6d114e7f403`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
