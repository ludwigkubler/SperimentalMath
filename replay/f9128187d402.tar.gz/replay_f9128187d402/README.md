# Replay package — entry f9128187d402

Conjecture: Minimal Local Ring Unit Group Size and Communication Complexity Rank Correlation via Local Class Group

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 04:05 UTC.
Pre-registration hash committed before this test ran: `21fa2aeb8108f900`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
