# Replay package — entry c16c1134730f

Conjecture: Minimal Hodge Index of Tropical Curves and AC0 Circuit Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 21:50 UTC.
Pre-registration hash committed before this test ran: `b855c5f03b154d9a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
