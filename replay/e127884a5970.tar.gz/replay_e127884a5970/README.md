# Replay package — entry e127884a5970

Conjecture: Minimal Tropical Motivic Rank Bounds DPLL Refutation Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 07:37 UTC.
Pre-registration hash committed before this test ran: `1746931749dae4af`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
