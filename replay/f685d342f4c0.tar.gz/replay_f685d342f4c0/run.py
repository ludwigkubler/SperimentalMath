import random
import itertools
import math
import json

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def AND_2(x, y):
        return x and y
    
    def OR_2(x, y):
        return x or y
    
    def XOR_2(x, y):
        return x != y
    
    def MAJ_3(x, y, z):
        return (x + y + z) >= 2
    
    def MUX_3(x, y, z):
        return y if x else z
    
    def AND_3(x, y, z):
        return x and y and z
    
    functions = [AND_2, OR_2, XOR_2, MAJ_3, MUX_3, AND_3]
    
    def d_f(f, x, y):
        return math.ceil(math.log2(sum(1 for i in range(len(x)) if x[i] != y[i])))
    
    def asdim(X_f, d_f):
        n = len(X_f)
        k = 0
        while True:
            found = False
            for R in range(1, n + 1):
                colors = [None] * n
                used_colors = set()
                for i in range(n):
                    if colors[i] is None:
                        color = len(used_colors)
                        used_colors.add(color)
                        queue = [i]
                        while queue:
                            current = queue.pop()
                            if colors[current] is not None:
                                continue
                            colors[current] = color
                            for j in range(n):
                                if d_f(X_f[i], X_f[j]) <= R and colors[j] is None:
                                    queue.append(j)
                if len(used_colors) == k + 1:
                    found = True
                    break
            if not found:
                return k
            k += 1
    
    def coarse_product(X_f, d_f, X_g, d_g):
        n = len(X_f)
        m = len(X_g)
        X_fg = [tuple(x) for x in itertools.product(X_f, X_g)]
        d_fg = lambda (x1, y1), (x2, y2): max(d_f(x1, x2), d_g(y1, y2))
        return X_fg, d_fg
    
    results = []
    for f in functions:
        for g in functions:
            X_f = [tuple(f(*x) for x in itertools.product([0, 1], repeat=len(f.__code__.co_varnames))) for _ in range(2)]
            X_g = [tuple(g(*x) for x in itertools.product([0, 1], repeat=len(g.__code__.co_varnames))) for _ in range(2)]
            X_fg, d_fg = coarse_product(X_f, d_f, X_g, d_g)
            asdim_fg = asdim(X_fg, d_fg)
            asdim_f = asdim(X_f, d_f)
            asdim_g = asdim(X_g, d_g)
            slack = asdim_fg - asdim_f - asdim_g
            results.append((f.__name__, g.__name__, slack))
    
    total_slack = sum(slack for _, _, slack in results)
    min_slack = min(slack for _, _, slack in results)
    support_fraction = sum(1 for _, _, slack in results if slack >= -2) / len(results)
    
    return {
        "metric_name": "slack",
        "metric_value": total_slack,
        "instances_tested": len(results),
        "conjecture_holds": support_fraction >= 0.95 and min_slack == -2 and any(slack == 0 for _, _, slack in results if f.__name__ == "AND_2" and g.__name__ == "AND_2" or f.__name__ == "XOR_2" and g.__name__ == "XOR_2"),
        "counterexample": "" if support_fraction >= 0.95 and min_slack == -2 and any(slack == 0 for _, _, slack in results if f.__name__ == "AND_2" and g.__name__ == "AND_2" or f.__name__ == "XOR_2" and g.__name__ == "XOR_2") else "mapping_undefined"
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] if len(sys.argv) > 1 else [11, 23, 37, 53, 71]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {json.dumps(result)}")
        results.append(result)
    
    mean_slack = sum(r["metric_value"] for r in results) / len(results)
    std_dev = math.sqrt(sum((r["metric_value"] - mean_slack) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if support_fraction >= 0.95 and min(r["metric_value"] for r in results) == -2 and any(r["conjecture_holds"] for r in results if r["counterexample"] == "mapping_undefined"):
        print(f"RESULT: SUPPORTED mean={mean_slack} std={std_dev} support_fraction={support_fraction}")
    elif min(r["metric_value"] for r in results) < -2:
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"min_slack < -2\" first_failing_seed={first_failing_seed}")
    else:
        print(f"RESULT: INCONCLUSIVE support_fraction={support_fraction} min_slack={min(r['metric_value'] for r in results)}")