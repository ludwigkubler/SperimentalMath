# Replay package — entry 9e67dce52944

Conjecture: Tropical Category Theory Bounds Frege Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 04:56 UTC.
Pre-registration hash committed before this test ran: `91e78665aded6ec7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
