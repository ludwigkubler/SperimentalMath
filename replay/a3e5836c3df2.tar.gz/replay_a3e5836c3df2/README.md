# Replay package — entry a3e5836c3df2

Conjecture: Minimal Local Homology Group Order and Resolution Proof Width Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 03:57 UTC.
Pre-registration hash committed before this test ran: `00d5c18df3417f06`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
