# Replay package — entry 3b7767fc68c9

Conjecture: Minimal Local Polynomial Hierarchy Index of Algebraic Curves vs DPLL Search Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 16:16 UTC.
Pre-registration hash committed before this test ran: `a99470a1e19615d1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
