# Replay package — entry cc516e5580b9

Conjecture: Minimal Root Separability Correlation with Communication Complexity for Planar Graphs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 02:34 UTC.
Pre-registration hash committed before this test ran: `ebddc1975b91401f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
