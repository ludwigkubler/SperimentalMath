# Replay package — entry 6f03a4ee1c85

Conjecture: Minimal Rank of Hypergeometric Sequences Bounds Resolution Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 02:50 UTC.
Pre-registration hash committed before this test ran: `575998e2bc0480ab`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
