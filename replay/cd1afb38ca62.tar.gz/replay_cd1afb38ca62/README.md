# Replay package — entry cd1afb38ca62

Conjecture: Free Entropy Lower Bound on Disjointness Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 15:00 UTC.
Pre-registration hash committed before this test ran: `2115ca22be56d983`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
