# Replay package — entry 6da4aa8000e9

Conjecture: Minimal Order of Symmetric Tensors and Frege Proof Length Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 03:56 UTC.
Pre-registration hash committed before this test ran: `e3c9abf71d4acd30`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
