# Replay package — entry 8c033d7d8d83

Conjecture: Minimal Local Ring Unit Group Size and Communication Complexity Rank Correlation via Tropicalization

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 22:07 UTC.
Pre-registration hash committed before this test ran: `45fa33246340d7b8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
