# Replay package — entry 38826d199a13

Conjecture: Schur-Weyl Multiplicity Gap in Symmetric vs Antisymmetric Decompositions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 04:24 UTC.
Pre-registration hash committed before this test ran: `4ca4054ae4fdaaf5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
