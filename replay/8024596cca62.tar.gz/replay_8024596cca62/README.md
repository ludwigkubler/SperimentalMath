# Replay package — entry 8024596cca62

Conjecture: Minimal Number of Simplicial Complexes Associated with Boolean Functions Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 14:18 UTC.
Pre-registration hash committed before this test ran: `3d204b9ab7c7d0c6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
