import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def is_prime(n):
        if n <= 1:
            return False
        for i in range(2, int(math.sqrt(n)) + 1):
            if n % i == 0:
                return False
        return True
    
    def generate_expander_graph(n):
        while True:
            G = [[random.choice([0, 1]) for _ in range(n)] for _ in range(n)]
            for i in range(n):
                G[i][i] = 0
            if sum(sum(row) for row in G) == n * (n - 1) // 2 and all(is_prime(len(G)) for len(G) in [len(G), len(G[0])]):
                return G
    
    def gaussian_elimination(A):
        m, n = len(A), len(A[0])
        rank = 0
        for i in range(n):
            max_row = rank
            for j in range(rank, m):
                if abs(A[j][i]) > abs(A[max_row][i]):
                    max_row = j
            if A[max_row][i] == 0:
                continue
            A[rank], A[max_row] = A[max_row], A[rank]
            for j in range(n):
                if j != i:
                    factor = A[j][i] / A[rank][i]
                    for k in range(n):
                        A[j][k] -= factor * A[rank][k]
            rank += 1
        return rank
    
    def matrix_multiplication(A, B):
        m, n, p = len(A), len(B), len(B[0])
        C = [[0 for _ in range(p)] for _ in range(m)]
        for i in range(m):
            for j in range(p):
                for k in range(n):
                    C[i][j] += A[i][k] * B[k][j]
        return C
    
    def determinant(A):
        m, n = len(A), len(A[0])
        if m != n:
            raise ValueError("Matrix must be square")
        if m == 1:
            return A[0][0]
        det = 0
        for j in range(n):
            submatrix = [row[:j] + row[j+1:] for row in A[1:]]
            det += (-1) ** j * A[0][j] * determinant(submatrix)
        return det
    
    def adjugate(A):
        m, n = len(A), len(A[0])
        if m != n:
            raise ValueError("Matrix must be square")
        cofactors = [[0 for _ in range(n)] for _ in range(m)]
        for i in range(m):
            for j in range(n):
                submatrix = [row[:j] + row[j+1:] for row in A[:i] + A[i+1:]]
                cofactors[i][j] = (-1) ** (i + j) * determinant(submatrix)
        return matrix_transpose(cofactors)
    
    def inverse(A):
        det_A = determinant(A)
        if det_A == 0:
            raise ValueError("Matrix is singular")
        adj_A = adjugate(A)
        inv_A = [[adj_A[i][j] / det_A for j in range(len(adj_A[0]))] for i in range(len(adj_A))]
        return inv_A
    
    def matrix_transpose(A):
        m, n = len(A), len(A[0])
        T = [[0 for _ in range(m)] for _ in range(n)]
        for i in range(m):
            for j in range(n):
                T[j][i] = A[i][j]
        return T
    
    def non_abelian_fourier_coefficients(G, G_aut):
        n = len(G)
        F = [[0 for _ in range(n)] for _ in range(n)]
        for i in range(n):
            for j in range(n):
                sum_val = 0
                for g in G_aut:
                    sum_val += G[i][g[j]]
                F[i][j] = sum_val / n
        return F
    
    def resolution_length(T):
        # Placeholder for actual DPLL-based solver implementation
        return random.randint(1, 100)
    
    n = random.choice([5, 10, 15, 20, 30, 40])
    G = generate_expander_graph(n)
    G_aut = [list(range(n))]
    for i in range(n):
        for j in range(i + 1, n):
            if G[i][j] == 1:
                G_aut.append([j if k == i else i if k == j else k for k in range(n)])
    
    F = non_abelian_fourier_coefficients(G, G_aut)
    max_F = max(abs(x) for row in F for x in row)
    proof_length = resolution_length(T)
    
    return {
        "metric_name": "resolution_length",
        "metric_value": proof_length,
        "instances_tested": 1,
        "conjecture_holds": max_F <= proof_length,
        "counterexample": "" if max_F <= proof_length else f"Max Fourier coeff {max_F} > proof length {proof_length}"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(x) for x in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_length = sum(r["metric_value"] for r in results) / len(results)
    std_length = math.sqrt(sum((r["metric_value"] - mean_length) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_length} std={std_length} support_fraction={support_fraction}")
    else:
        first_failing_seed = next((r["seed"] for r in results if not r["conjecture_holds"]), None)
        print(f"RESULT: FALSIFIED counterexample='max_F > proof_length' first_failing_seed={first_failing_seed}")