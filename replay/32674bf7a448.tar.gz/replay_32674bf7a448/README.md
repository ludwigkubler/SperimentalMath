# Replay package — entry 32674bf7a448

Conjecture: Minimal Order of Lie Algebroid Dimensions and Circuit Lower Bounds for k-CLIQUE Inclusion

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 11:25 UTC.
Pre-registration hash committed before this test ran: `89d191e687852251`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
