# Replay package — entry d65dad9a5357

Conjecture: Minimal Tropical p-Adic Rank and SAT Proof Size Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 01:41 UTC.
Pre-registration hash committed before this test ran: `0ac28cc2db4865e2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
