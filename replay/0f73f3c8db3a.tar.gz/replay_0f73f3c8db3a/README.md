# Replay package — entry 0f73f3c8db3a

Conjecture: Real Radical Dimension and Disjointness Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 16:55 UTC.
Pre-registration hash committed before this test ran: `2c5c1031f8804dd1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
