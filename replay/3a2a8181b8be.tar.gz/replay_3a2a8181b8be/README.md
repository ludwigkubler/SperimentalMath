# Replay package — entry 3a2a8181b8be

Conjecture: Minimal Rank of Tropicalized Noncommutative Geometry Bounds Boolean Circuit Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 12:46 UTC.
Pre-registration hash committed before this test ran: `6fd4249676976cc5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
