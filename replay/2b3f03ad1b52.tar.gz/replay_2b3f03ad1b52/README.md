# Replay package — entry 2b3f03ad1b52

Conjecture: Schur Coefficient Density Inverse Proportional to Frege Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 03:10 UTC.
Pre-registration hash committed before this test ran: `0d3b68b07bcd5ca9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
