# Replay package — entry 29a5335efcbb

Conjecture: Chang Spectrum Dimension of Wire-Source DFS Labels Bounds ACC^0[2] for MOD_3

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 06:21 UTC.
Pre-registration hash committed before this test ran: `746b34c859e3c530`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
