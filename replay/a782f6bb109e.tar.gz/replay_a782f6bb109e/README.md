# Replay package — entry a782f6bb109e

Conjecture: Minimal Rank of Hodge Decomposition Modules over Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 11:19 UTC.
Pre-registration hash committed before this test ran: `9d4998032f14f02d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
