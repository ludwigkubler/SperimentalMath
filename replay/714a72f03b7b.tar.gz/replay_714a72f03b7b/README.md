# Replay package — entry 714a72f03b7b

Conjecture: Minimal Rank of Brauer Groups over Boolean Rings vs Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 02:24 UTC.
Pre-registration hash committed before this test ran: `3b1c3e6ae7794b9a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
