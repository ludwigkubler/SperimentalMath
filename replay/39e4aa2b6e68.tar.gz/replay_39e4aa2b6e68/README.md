# Replay package — entry 39e4aa2b6e68

Conjecture: Minimal Rank of Quaternionic Kähler Forms over Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 06:03 UTC.
Pre-registration hash committed before this test ran: `93fc8f5f69fd15b1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
