# Replay package — entry 9bf36053ab4b

Conjecture: Real Rank of Communication Matrix Bounds AC⁰ Circuit Size for PARITY

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 22:18 UTC.
Pre-registration hash committed before this test ran: `72485c6fab04d87c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
