# Replay package — entry 86fc235d2aba

Conjecture: Matroid Rank Deficit in Monotone DNF Depth for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 13:48 UTC.
Pre-registration hash committed before this test ran: `041dec4c32820998`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
