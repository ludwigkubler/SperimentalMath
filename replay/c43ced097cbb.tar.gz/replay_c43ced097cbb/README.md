# Replay package — entry c43ced097cbb

Conjecture: Minimal Symmetric Function Rank and Communication Complexity Rank Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 13:08 UTC.
Pre-registration hash committed before this test ran: `621ceecc6de408ac`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
