# Replay package — entry fa1c8602fb55

Conjecture: Minimal Order of Noncommutative Integral Points and Frege Proof Depth Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 23:29 UTC.
Pre-registration hash committed before this test ran: `5d84693b8fdb49b7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
