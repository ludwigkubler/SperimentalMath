# Replay package — entry 68475aeb9000

Conjecture: SOS Degree Lower Bound via Real Rank of Moment Matrix for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 11:44 UTC.
Pre-registration hash committed before this test ran: `125459e7abae0b4b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
