# Replay package — entry 19e716713324

Conjecture: Minimal Order of Semigroup Generators and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 20:13 UTC.
Pre-registration hash committed before this test ran: `498a8514f7ba4934`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
