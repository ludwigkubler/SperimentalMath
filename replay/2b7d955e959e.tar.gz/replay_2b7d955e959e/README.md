# Replay package — entry 2b7d955e959e

Conjecture: Young Tableau Count Exponential Gap in Disjointness Communication Matrices

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 01:20 UTC.
Pre-registration hash committed before this test ran: `72bf5bf044080e6d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
