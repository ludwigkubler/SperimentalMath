# Replay package — entry dbaf5e8ccbe1

Conjecture: Beck-Fiala Slack of Clause-Variable Hypergraph Bounds DPLL Leaves

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 23:24 UTC.
Pre-registration hash committed before this test ran: `36859e1f258b7cca`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
