# Replay package — entry 7dbdb07b5da5

Conjecture: Minimal Local Chromatic Number Correlation with Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 03:54 UTC.
Pre-registration hash committed before this test ran: `9c7614e94a7cc5b0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
