# Replay package — entry e91c2e26d686

Conjecture: Euler Characteristic of Order Complex Bounds Disjointness Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 14:02 UTC.
Pre-registration hash committed before this test ran: `23b29e6b21f00516`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
