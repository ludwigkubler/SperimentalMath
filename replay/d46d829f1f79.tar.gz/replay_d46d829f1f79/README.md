# Replay package — entry d46d829f1f79

Conjecture: Sandpile-Group 2-Rank Lower-Bounds Tseitin DPLL Tree Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 06:55 UTC.
Pre-registration hash committed before this test ran: `54be4654cf68400e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
