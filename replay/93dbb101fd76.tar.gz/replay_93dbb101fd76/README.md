# Replay package — entry 93dbb101fd76

Conjecture: Minimal Local Cross Section Rank and Proof Entropy in Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 07:46 UTC.
Pre-registration hash committed before this test ran: `7a6f190f549947be`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
