# Replay package — entry 250c806b0e11

Conjecture: Noncommutative Fourier Norm Inverse Proportional to Disjointness Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 16:11 UTC.
Pre-registration hash committed before this test ran: `eee49155abb015ae`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
