# Replay package — entry 289b9bdc2257

Conjecture: Polymatroid Rank Gap in Monotone DNF Depth for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-07 22:09 UTC.
Pre-registration hash committed before this test ran: `3e92add9ecb0546d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
