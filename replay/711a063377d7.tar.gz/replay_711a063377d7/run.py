import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def factorial(n):
        if n == 0 or n == 1:
            return 1
        result = 1
        for i in range(2, n + 1):
            result *= i
        return result
    
    def geometric_phase_rank(n):
        # Placeholder function to compute the geometric phase rank
        # This is a dummy implementation and should be replaced with actual logic
        return random.randint(1, 2**(n//4))
    
    def communication_complexity(rank):
        return 2**(n/4 * min(factorial(i) * math.log(1/i), math.log(t))) if rank > 0 else float('inf')
    
    n = random.choice([5, 10, 15, 20, 30, 40])
    t = random.uniform(1, 100)
    rank = geometric_phase_rank(n)
    cc = communication_complexity(rank)
    
    return {
        "metric_name": "Communication Complexity",
        "metric_value": cc,
        "instances_tested": 1,
        "conjecture_holds": rank <= 2**(n/4 * min(factorial(i) * math.log(1/i), math.log(t))) for i in range(1, n+1),
        "counterexample": "" if rank <= 2**(n/4 * min(factorial(i) * math.log(1/i), math.log(t))) else f"Rank {rank} exceeds bound"
    }

if __name__ == "__main__":
    seeds = [int(arg) for arg in sys.argv[1:]] or [random.randint(1, 1000) for _ in range(30)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {{\"seed\": {seed}, \"metric_name\": \"{result['metric_name']}\", \"metric_value\": {result['metric_value']}, \"instances_tested\": {result['instances_tested']}, \"conjecture_holds\": {result['conjecture_holds']}, \"counterexample\": \"{result['counterexample']}\"}}")
        results.append(result)
    
    mean = sum(r['metric_value'] for r in results) / len(results)
    std_dev = math.sqrt(sum((r['metric_value'] - mean)**2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r['conjecture_holds']) / len(results)
    
    if all(r['conjecture_holds'] for r in results):
        print(f"RESULT: SUPPORTED mean={mean} std={std_dev} support_fraction={support_fraction}")
    elif any(not r['conjecture_holds'] for r in results):
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result['conjecture_holds'])
        print(f"RESULT: FALSIFIED counterexample=\"Rank exceeds bound\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE mapping_undefined")