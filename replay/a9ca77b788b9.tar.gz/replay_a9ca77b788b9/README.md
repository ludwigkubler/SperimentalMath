# Replay package — entry a9ca77b788b9

Conjecture: Minimal Free Probability Entropy for BP_ReadTwice Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 05:18 UTC.
Pre-registration hash committed before this test ran: `22935dc469556798`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
