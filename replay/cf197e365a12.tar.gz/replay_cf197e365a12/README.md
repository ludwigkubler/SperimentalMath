# Replay package — entry cf197e365a12

Conjecture: Minimal Rank of Noncommutative Crossed Products over Function Fields vs Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 19:12 UTC.
Pre-registration hash committed before this test ran: `48452cfe7067d375`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
