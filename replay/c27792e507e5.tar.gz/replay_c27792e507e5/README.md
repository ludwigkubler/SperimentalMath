# Replay package — entry c27792e507e5

Conjecture: SOS Moment Matrix Rank and Max-CUT Approximation Ratio

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 11:29 UTC.
Pre-registration hash committed before this test ran: `7f6fcf52135c6485`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
