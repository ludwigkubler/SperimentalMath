# Replay package — entry 365eb9daf7bd

Conjecture: Minimal Hodge Norm and Frege Proof Length Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 22:32 UTC.
Pre-registration hash committed before this test ran: `931e4ff8473bdae0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
