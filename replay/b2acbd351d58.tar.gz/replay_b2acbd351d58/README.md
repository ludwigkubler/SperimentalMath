# Replay package — entry b2acbd351d58

Conjecture: Minimal Rank of Tropical Curves and Resolution Refutation Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 12:25 UTC.
Pre-registration hash committed before this test ran: `f095d2192679b107`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
