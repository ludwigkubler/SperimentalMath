# Replay package — entry cd84f3cc2ccf

Conjecture: Minimal Rank of Noncommutative Hopf Algebras over Boolean Functions vs Sum-of-Squares Approximation Ratio for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 11:17 UTC.
Pre-registration hash committed before this test ran: `034f7f83d062e7ae`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
