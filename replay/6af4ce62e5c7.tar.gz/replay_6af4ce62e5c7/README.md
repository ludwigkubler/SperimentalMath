# Replay package — entry 6af4ce62e5c7

Conjecture: Minimal Rank of Symplectic Leaves vs. Circuit Lower Bounds for k-CNF Tautologies

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 20:17 UTC.
Pre-registration hash committed before this test ran: `925614702e1e8d49`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
