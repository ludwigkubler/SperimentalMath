# Replay package — entry 82d57e0eb431

Conjecture: Minimal Local Cohomology Group Order and DPLL Proof Path Length Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 06:29 UTC.
Pre-registration hash committed before this test ran: `d1c13222d2dcebc0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
