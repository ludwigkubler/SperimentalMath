import random
import math

def generate_random_circuit(n_inputs, depth):
    if depth == 1:
        return [f'x{i}' for i in range(n_inputs)]
    
    left = generate_random_circuit(n_inputs, depth - 1)
    right = generate_random_circuit(n_inputs, depth - 1)
    
    return [f'({l} & {r})' for l in left] + [f'({l} | {r})' for l in right]

def compute_clause_set(circuit):
    if isinstance(circuit, str):
        return set([circuit])
    else:
        clause_set = set()
        for part in circuit:
            clause_set.update(compute_clause_set(part))
        return clause_set

def cohomological_construction(clause_set):
    # Simplified version of the cohomological construction
    # This is a placeholder and should be replaced with actual computation
    return len(clause_set)

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    results = []
    for n_inputs in [5, 10, 15, 20, 30, 40]:
        for _ in range(5):
            circuit = generate_random_circuit(n_inputs, depth=random.randint(1, 10))
            clause_set = compute_clause_set(circuit)
            grothendieck_order = cohomological_construction(clause_set)
            depth = random.randint(1, 10)
            
            results.append({
                "n": n_inputs,
                "depth": depth,
                "grothendieck_order": grothendieck_order
            })
    
    if not results:
        return {
            "metric_name": "Grothendieck Order vs Depth",
            "metric_value": None,
            "instances_tested": 0,
            "n_max": 0,
            "conjecture_holds": False,
            "counterexample": "No circuits generated"
        }
    
    metric_values = [r["grothendieck_order"] for r in results]
    n_max = max(r["n"] for r in results)
    conjecture_holds = all(grothendieck_order <= depth**3 for grothendieck_order, depth in zip(metric_values, [r["depth"] for r in results]))
    
    return {
        "metric_name": "Grothendieck Order vs Depth",
        "metric_value": sum(metric_values) / len(metric_values),
        "instances_tested": len(results),
        "n_max": n_max,
        "conjecture_holds": conjecture_holds,
        "counterexample": "" if conjecture_holds else "First failing instance"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(arg) for arg in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
    
    results = []
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    if all(r["conjecture_holds"] for r in results):
        mean_value = sum(r["metric_value"] for r in results) / len(results)
        support_fraction = 1.0
        print(f"RESULT: SUPPORTED mean={mean_value} std=0 support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(seed for seed, r in zip(seeds, results) if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"First failing instance\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE mapping_undefined")