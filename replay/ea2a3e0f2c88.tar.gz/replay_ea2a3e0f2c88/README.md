# Replay package — entry ea2a3e0f2c88

Conjecture: Spectral Radius of Vertex Contraction Graph Controls Tseitin Resolution Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-29 21:06 UTC.
Pre-registration hash committed before this test ran: `6a55ccf35defab90`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
