# Replay package — entry 58d7474b72d0

Conjecture: Minimal Rank of Formal Groups and DPLL Search Tree Height

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 03:55 UTC.
Pre-registration hash committed before this test ran: `4474dcccc1b57f20`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
