# Replay package — entry 899798ef1440

Conjecture: Minimal Order of p-Adic Groups over Boolean Function Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 06:44 UTC.
Pre-registration hash committed before this test ran: `97a510f39e6ef8c6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
