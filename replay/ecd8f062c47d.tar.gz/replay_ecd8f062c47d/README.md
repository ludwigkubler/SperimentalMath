# Replay package — entry ecd8f062c47d

Conjecture: Free Cumulant Sum Bounded by Disjointness Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 01:18 UTC.
Pre-registration hash committed before this test ran: `83d43c94d7a5bc11`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
