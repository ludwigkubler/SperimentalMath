# Replay package — entry 15062ae34be4

Conjecture: Minimal Rank of Tropical Curves in Affine Geometry vs Sum-of-Squares Hierarchy Approximation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 09:51 UTC.
Pre-registration hash committed before this test ran: `e20f3ab4a4cfb71d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
