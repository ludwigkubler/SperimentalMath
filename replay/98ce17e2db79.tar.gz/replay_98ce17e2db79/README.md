# Replay package — entry 98ce17e2db79

Conjecture: Convex Hull Facet Count and Resolution Proof Size

Verdict (original run): FALSIFIED

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-24 13:08 UTC.
Pre-registration hash committed before this test ran: `d603d1f321a75f3e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
