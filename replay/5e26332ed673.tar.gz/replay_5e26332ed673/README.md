# Replay package — entry 5e26332ed673

Conjecture: Plethysm Coefficient Exponential Gap in Symmetric Powers of Permanent Matrices

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 17:34 UTC.
Pre-registration hash committed before this test ran: `f16229da3009cee1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
