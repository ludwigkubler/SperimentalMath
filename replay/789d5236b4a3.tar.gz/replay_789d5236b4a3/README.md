# Replay package — entry 789d5236b4a3

Conjecture: Minimal Symmetric Function Rank and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 07:25 UTC.
Pre-registration hash committed before this test ran: `b9df7c107733edb7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
