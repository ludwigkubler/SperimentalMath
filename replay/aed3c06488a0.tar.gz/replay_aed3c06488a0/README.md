# Replay package — entry aed3c06488a0

Conjecture: Noncommutative Norm Gap in Read-Twice Branching Programs for IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 18:36 UTC.
Pre-registration hash committed before this test ran: `7fc2026e3491c975`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
