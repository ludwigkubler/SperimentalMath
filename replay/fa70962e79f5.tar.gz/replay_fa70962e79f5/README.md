# Replay package — entry fa70962e79f5

Conjecture: Matroid Rank Bounded by Nisan-Wigderson Seed Length for 3-SAT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 02:14 UTC.
Pre-registration hash committed before this test ran: `3c5b26976af504a7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
