# Replay package — entry 85456eaeedc3

Conjecture: Minimal Symplectic Invariant and SOS Hierarchy Approximation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 09:04 UTC.
Pre-registration hash committed before this test ran: `9bfcf8f1abdb9988`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
