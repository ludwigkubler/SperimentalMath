# Replay package — entry 923c457c4dd2

Conjecture: Hypergraph Treewidth Inverse Proportional to DPLL Tree Size for Random 3-CNFs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 16:43 UTC.
Pre-registration hash committed before this test ran: `eb8687a79dd70a6d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
