# Replay package — entry e9a4c4604cb3

Conjecture: Dual Code Minimum Distance Bounds Nisan-Wigderson Seed Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 15:05 UTC.
Pre-registration hash committed before this test ran: `66ec8bf3dea45b21`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
