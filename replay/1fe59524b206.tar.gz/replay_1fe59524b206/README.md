# Replay package — entry 1fe59524b206

Conjecture: Real Algebraic Geometry of Polynomial Systems Bounds DPLL Refutation Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 01:53 UTC.
Pre-registration hash committed before this test ran: `70d08bade9f91378`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
