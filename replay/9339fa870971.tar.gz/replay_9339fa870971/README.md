# Replay package — entry 9339fa870971

Conjecture: Minimal Rank of Tropicalized K-Theory over Sipser Function Computation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 06:15 UTC.
Pre-registration hash committed before this test ran: `b123865c0a3fb1cd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
