# Replay package — entry 4314593e4995

Conjecture: Minimal Local Cohomology Rank in Affine Geometry and DPLL Search Tree Diameter

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 03:43 UTC.
Pre-registration hash committed before this test ran: `ff1c443ae25495c6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
