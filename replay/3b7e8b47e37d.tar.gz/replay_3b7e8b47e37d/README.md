# Replay package — entry 3b7e8b47e37d

Conjecture: Minimal Tropical Hodge Diamond Width and Communication Complexity Rank Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 07:34 UTC.
Pre-registration hash committed before this test ran: `0261e0922ec8874b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
