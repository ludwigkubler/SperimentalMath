# Replay package — entry 0a2cc1665148

Conjecture: Minimal Rank of Kneser Graphs Bounds Monotone Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 15:55 UTC.
Pre-registration hash committed before this test ran: `01ed274eb8a35477`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
