# Replay package — entry 99773cf419c5

Conjecture: Matroid Rank Separation in Read-Twice Branching Programs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 13:41 UTC.
Pre-registration hash committed before this test ran: `9fafe6c00c2061b0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
