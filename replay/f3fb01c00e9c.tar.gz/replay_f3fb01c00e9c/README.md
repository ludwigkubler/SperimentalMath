# Replay package — entry f3fb01c00e9c

Conjecture: Minimal Root Separability of Algebraic Curves and MA^cc Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 18:46 UTC.
Pre-registration hash committed before this test ran: `536e25f64bf77f6e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
