# Replay package — entry f80b49afa542

Conjecture: Minimal Geometric Entropy Correlation with Frege Proof Size via Morse Theory

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 06:31 UTC.
Pre-registration hash committed before this test ran: `e6feb5030e8917b4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
