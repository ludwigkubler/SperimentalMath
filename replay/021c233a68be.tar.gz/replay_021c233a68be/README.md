# Replay package — entry 021c233a68be

Conjecture: Quantum Entanglement as Tensor Product Rank vs BP_ReadTwice Circuit Threshold

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 09:28 UTC.
Pre-registration hash committed before this test ran: `8791d914e31e5c72`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
