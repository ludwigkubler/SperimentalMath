# Replay package — entry 3b16f00f529a

Conjecture: Minimal Symmetric Braid Group Order and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 23:25 UTC.
Pre-registration hash committed before this test ran: `3a6f89aba10dae70`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
