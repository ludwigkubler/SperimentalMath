# Replay package — entry caf74685e1fc

Conjecture: Minimal Symplectic Rank Bounds Resolution Proof Width for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 07:11 UTC.
Pre-registration hash committed before this test ran: `0b6f3e6c588d7ab4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
