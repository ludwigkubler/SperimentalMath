# Replay package — entry 2f367d15ae54

Conjecture: Legendre-Fenchel Involution Conjecture: Discrepancy Invariance under Double Tropical Fourier Transform

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 21:43 UTC.
Pre-registration hash committed before this test ran: `11454e83a705d445`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
