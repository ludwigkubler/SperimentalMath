# Replay package — entry a687b7685342

Conjecture: Forman-Ricci Negative-Edge Count Lower-Bounds Tseitin DPLL Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 11:22 UTC.
Pre-registration hash committed before this test ran: `46969f981dbd2ab1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
