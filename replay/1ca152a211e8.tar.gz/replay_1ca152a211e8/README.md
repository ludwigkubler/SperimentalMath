# Replay package — entry 1ca152a211e8

Conjecture: Moment Matrix Eigenvalue Decay and SOS Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 21:37 UTC.
Pre-registration hash committed before this test ran: `30077bb800294b26`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
