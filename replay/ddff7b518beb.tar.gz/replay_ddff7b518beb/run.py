import random
import math
from fractions import Fraction

def generate_cnf(n, m):
    cnf = []
    for _ in range(m):
        clause = [random.choice([-1, 1]) * (i + 1) for i in range(n)]
        if all(c == 0 for c in clause):
            clause[random.randint(0, n - 1)] = random.choice([-1, 1])
        cnf.append(clause)
    return cnf

def algebraic_stochastic_order(cnf):
    n = len(cnf[0])
    assignments = [tuple(random.choices([0, 1], k=n)) for _ in range(2**n)]
    
    def evaluate_cnf(assignments, cnf):
        results = []
        for assignment in assignments:
            result = 1
            for clause in cnf:
                if all((assignment[i-1] == 0 and c > 0) or (assignment[i-1] == 1 and c < 0) for i, c in enumerate(clause)):
                    result *= -1
            results.append(result)
        return results
    
    results_pos = evaluate_cnf(assignments, cnf)
    results_neg = evaluate_cnf([(1 - a) for a in assignment] for assignment in assignments], cnf)
    
    alpha_F = sum([results_pos[i] * results_neg[i] for i in range(len(results_pos))]) / len(results_pos)
    return alpha_F

def resolution_width(cnf):
    n = len(cnf[0])
    clauses = {tuple(clause) for clause in cnf}
    queue = list(clauses)
    literals_seen = set()
    
    while queue:
        literal = random.choice(list(literals_seen))
        new_clauses = []
        for clause in queue:
            if literal in clause:
                continue
            if -literal in clause:
                return len(queue)
            new_clause = [l for l in clause if l != -literal]
            if new_clause and tuple(new_clause) not in clauses:
                new_clauses.append(tuple(new_clause))
        queue.extend(new_clauses)
        literals_seen.add(literal)
    
    return len(queue)

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n = random.choice([5, 10, 15, 20, 30, 40])
    m = random.randint(2 * n, 3 * n)
    cnf = generate_cnf(n, m)
    
    alpha_F = algebraic_stochastic_order(cnf)
    t_F = resolution_width(cnf)
    
    return {
        "metric_name": "algebraic_stochastic_order",
        "metric_value": alpha_F,
        "instances_tested": 1,
        "conjecture_holds": t_F <= (4/3)**alpha_F * n,
        "counterexample": ""
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2**i + 1 for i in range(5, 8)]
    
    results = []
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    if all(result["conjecture_holds"] for result in results):
        mean_value = sum(result["metric_value"] for result in results) / len(results)
        support_fraction = 1.0
        print(f"RESULT: SUPPORTED mean={mean_value} std=0.0 support_fraction={support_fraction}")
    else:
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        counterexample = "mapping_undefined"
        print(f"RESULT: FALSIFIED counterexample=\"{counterexample}\" first_failing_seed={first_failing_seed}")