# Replay package — entry 1ddc1ab64b19

Conjecture: Minimal Frobenius Index and SAT Clause Subset Complexity Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 21:21 UTC.
Pre-registration hash committed before this test ran: `b0c645f8a8a7912d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
