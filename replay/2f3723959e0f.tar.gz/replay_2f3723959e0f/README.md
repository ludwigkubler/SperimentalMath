# Replay package — entry 2f3723959e0f

Conjecture: Minimal Index of Lie Algebroid Pairs and Circuit Monotone Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 17:14 UTC.
Pre-registration hash committed before this test ran: `183b94f9bfee2bba`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
