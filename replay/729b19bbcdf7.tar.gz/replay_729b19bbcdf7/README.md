# Replay package — entry 729b19bbcdf7

Conjecture: Diophantine Approximation Bound on Resolution Proof Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 18:56 UTC.
Pre-registration hash committed before this test ran: `31f5a0becf000cb7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
