# Replay package — entry ea928ad95433

Conjecture: Minimal Ehrhart Quotient Correlation with Frege Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 15:52 UTC.
Pre-registration hash committed before this test ran: `dcbebccd62811c78`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
