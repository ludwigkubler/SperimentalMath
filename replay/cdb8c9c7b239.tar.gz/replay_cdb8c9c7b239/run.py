import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_boolean_function(n):
        return [random.choice([0, 1]) for _ in range(2**n)]
    
    def communication_complexity_rank(f):
        n = len(f)
        rank = 0
        for i in range(n):
            for j in range(i+1, n):
                if f[i] != f[j]:
                    rank += 1
        return rank
    
    def galois_group_order(f):
        n = len(f)
        G = []
        for i in range(2**n):
            if all((f[(i >> j) & 1] == f[(i >> (j+1)) & 1]) for j in range(n)):
                G.append(i)
        return len(G)
    
    def gaussian_elimination(A, b):
        n = len(A)
        A_b = [row + [b[i]] for i, row in enumerate(A)]
        for i in range(n):
            if A_b[i][i] == 0:
                for j in range(i+1, n):
                    if A_b[j][i] != 0:
                        A_b[i], A_b[j] = A_b[j], A_b[i]
                        break
                else:
                    return None
            pivot = A_b[i][i]
            for j in range(n):
                A_b[i][j] /= pivot
            b[i] /= pivot
            for j in range(n):
                if j != i and A_b[j][i] != 0:
                    factor = A_b[j][i]
                    for k in range(n+1):
                        A_b[j][k] -= factor * A_b[i][k]
        return [row[-1] for row in A_b]
    
    def matrix_multiplication(A, B):
        n = len(A)
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                for k in range(n):
                    C[i][j] += A[i][k] * B[k][j]
        return C
    
    def determinant(A):
        n = len(A)
        if n == 1:
            return A[0][0]
        det = 0
        for j in range(n):
            submatrix = [row[:j] + row[j+1:] for row in A[1:]]
            det += (-1) ** j * A[0][j] * determinant(submatrix)
        return det
    
    def inverse(A):
        n = len(A)
        det_A = determinant(A)
        if det_A == 0:
            return None
        adjoint = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                submatrix = [row[:j] + row[j+1:] for row in A[:i] + A[i+1:]]
                cofactor = determinant(submatrix)
                adjoint[i][j] = (-1) ** (i+j) * cofactor
        return matrix_multiplication(adjoint, [[1/det_A] * n for _ in range(n)])
    
    def galois_field_elements():
        elements = [0, 1]
        while len(elements) < 2**n:
            new_element = sum(random.choice(elements) for _ in range(2)) % 2
            if new_element not in elements:
                elements.append(new_element)
        return elements
    
    def galois_field_multiplication(a, b):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, B)
        return C[a][b]
    
    def galois_field_division(a, b):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_B = inverse(B)
        if inv_B is None:
            return None
        C = matrix_multiplication(A, inv_B)
        return C[a][b]
    
    def galois_field_inverse(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[1/a] * n for _ in range(n)])
        return C[a]
    
    def galois_field_power(a, k):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[a**k] * n for _ in range(n)])
        return C[a]
    
    def galois_field_sqrt(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[a**0.5] * n for _ in range(n)])
        return C[a]
    
    def galois_field_log(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[math.log(a)] * n for _ in range(n)])
        return C[a]
    
    def galois_field_exp(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[math.exp(a)] * n for _ in range(n)])
        return C[a]
    
    def galois_field_sin(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[math.sin(a)] * n for _ in range(n)])
        return C[a]
    
    def galois_field_cos(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[math.cos(a)] * n for _ in range(n)])
        return C[a]
    
    def galois_field_tan(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[math.tan(a)] * n for _ in range(n)])
        return C[a]
    
    def galois_field_cot(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[math.cot(a)] * n for _ in range(n)])
        return C[a]
    
    def galois_field_sec(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[math.sec(a)] * n for _ in range(n)])
        return C[a]
    
    def galois_field_csc(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[math.csc(a)] * n for _ in range(n)])
        return C[a]
    
    def galois_field_atan(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[math.atan(a)] * n for _ in range(n)])
        return C[a]
    
    def galois_field_acot(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[math.acot(a)] * n for _ in range(n)])
        return C[a]
    
    def galois_field_asec(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[math.asec(a)] * n for _ in range(n)])
        return C[a]
    
    def galois_field_acsc(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[math.acsc(a)] * n for _ in range(n)])
        return C[a]
    
    def galois_field_sinh(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[math.sinh(a)] * n for _ in range(n)])
        return C[a]
    
    def galois_field_cosh(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[math.cosh(a)] * n for _ in range(n)])
        return C[a]
    
    def galois_field_tanh(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[math.tanh(a)] * n for _ in range(n)])
        return C[a]
    
    def galois_field_coth(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[math.coth(a)] * n for _ in range(n)])
        return C[a]
    
    def galois_field_sech(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[math.sech(a)] * n for _ in range(n)])
        return C[a]
    
    def galois_field_csch(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[math.csch(a)] * n for _ in range(n)])
        return C[a]
    
    def galois_field_asinh(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[math.asinh(a)] * n for _ in range(n)])
        return C[a]
    
    def galois_field_acosh(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[math.acosh(a)] * n for _ in range(n)])
        return C[a]
    
    def galois_field_atanh(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[math.atanh(a)] * n for _ in range(n)])
        return C[a]
    
    def galois_field_acoth(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                A[i][j] = (i + j) % n
                B[i][j] = (i * j) % n
        inv_A = inverse(A)
        if inv_A is None:
            return None
        C = matrix_multiplication(inv_A, [[math.acoth(a)] * n for _ in range(n)])
        return C[a]
    
    def galois_field_asech(a):
        n = len(galois_field_elements())
        A = [[0] * n for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):