# Replay package — entry 59e64be32210

Conjecture: Minimal Rank of Alexander Modules over Circuit Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 07:07 UTC.
Pre-registration hash committed before this test ran: `45224092651a43fb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
