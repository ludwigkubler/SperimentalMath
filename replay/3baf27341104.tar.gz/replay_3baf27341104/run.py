import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_boolean_function(n):
        return [random.choice([0, 1]) for _ in range(2**n)]
    
    def construct_quasi_projective_variety(f):
        # Simplified construction using polynomial degree
        return len(f)
    
    def communication_complexity(n):
        # Simulated complexity based on function size
        return n
    
    n = random.randint(5, 40)  # Sweep through different sizes
    f = generate_boolean_function(n)
    min_rank = construct_quasi_projective_variety(f)
    comm_complexity = communication_complexity(n)
    
    metric_name = "communication_complexity"
    metric_value = comm_complexity
    instances_tested = 1
    conjecture_holds = abs(metric_value - 2**min_rank) <= 0.1 * 2**min_rank
    counterexample = "" if conjecture_holds else f"Discrepancy: {metric_value} != 2^{min_rank}"
    
    return {
        "metric_name": metric_name,
        "metric_value": metric_value,
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    seeds = [int(arg) for arg in sys.argv[1:]] or [2**i - 1 for i in range(5, 30)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(res["metric_value"] for res in results) / len(results)
    std_value = math.sqrt(sum((res["metric_value"] - mean_value)**2 for res in results) / len(results))
    support_fraction = sum(1 for res in results if res["conjecture_holds"]) / len(results)
    
    if all(res["conjecture_holds"] for res in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not res["conjecture_holds"] for res in results) and support_fraction >= 0.8:
        first_failing_seed = next(res["seed"] for res in results if not res["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"Discrepancy\" first_failing_seed={first_failing_seed}")
    else:
        print(f"RESULT: INCONCLUSIVE support_fraction={support_fraction}")