# Replay package — entry 8c38c25676b5

Conjecture: Minimal Order of Hypergeometric Functions Bounds Circuit Size of k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 22:42 UTC.
Pre-registration hash committed before this test ran: `594fde30a4a550a1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
