# Replay package — entry 6ed500f4644b

Conjecture: Minimal Betti Number of Knots and DPLL Search Tree Diameter

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 05:47 UTC.
Pre-registration hash committed before this test ran: `f7c2c772d510dea4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
