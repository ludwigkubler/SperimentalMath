# Replay package — entry 76c4f54f8fcf

Conjecture: Plethysm Coefficient Inverse Proportionality to SOS Refutation Size for Symmetric CSPs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 02:24 UTC.
Pre-registration hash committed before this test ran: `0de45cf36fa71c58`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
