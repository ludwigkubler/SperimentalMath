# Replay package — entry a510fd856726

Conjecture: Roe-Skeleton Spectral Gap Forces Multiplicity in Protocol-Induced Covers on Small-Diameter Gadget Lifts

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 14:45 UTC.
Pre-registration hash committed before this test ran: `868dbbafafa3af6f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
