# Replay package — entry bba09a0a4ff8

Conjecture: Galois Concept Lattice Height Lower-Bounds Monotone KW Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 10:25 UTC.
Pre-registration hash committed before this test ran: `ef7007ff988f48a7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
