# Replay package — entry 0fbb8bed1078

Conjecture: Minimal Order of Group Representations and Frege Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 09:22 UTC.
Pre-registration hash committed before this test ran: `8d235bb81e5632ce`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
