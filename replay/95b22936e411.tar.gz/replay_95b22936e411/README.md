# Replay package — entry 95b22936e411

Conjecture: Minimal Automorphism Group Rank of Lie Algebras vs. Monotone Circuit Lower Bounds for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 12:20 UTC.
Pre-registration hash committed before this test ran: `eaa970b152fe1059`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
