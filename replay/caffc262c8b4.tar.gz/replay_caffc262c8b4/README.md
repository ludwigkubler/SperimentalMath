# Replay package — entry caffc262c8b4

Conjecture: Minimal Rank of Quasi-Group Representations and Circuit Weights Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 12:12 UTC.
Pre-registration hash committed before this test ran: `57f22762fa1719f3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
