# Replay package — entry 6227dd6720d4

Conjecture: Lovász-Theta of Term-Conflict Graph Bounds Monotone k-CLIQUE DNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 16:26 UTC.
Pre-registration hash committed before this test ran: `38184f59704aa41d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
