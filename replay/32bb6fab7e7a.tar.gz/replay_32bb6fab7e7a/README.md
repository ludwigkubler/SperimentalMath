# Replay package — entry 32bb6fab7e7a

Conjecture: Minimal Rank of Tropicalized Lie Algebroids Bounds AC0 Parity Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 22:09 UTC.
Pre-registration hash committed before this test ran: `bc132be20fb1f791`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
