# Replay package — entry c17dbbc1f0ee

Conjecture: Minimal Rank of Geometric Langlands Sheaves Bounds BP Read-Twice Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 14:10 UTC.
Pre-registration hash committed before this test ran: `aa2fb3e3c5ed31d2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
