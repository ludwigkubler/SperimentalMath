# Replay package — entry 9990a30cf746

Conjecture: Minimal Rank of Tropical Differentials vs AC0 Parity Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 05:12 UTC.
Pre-registration hash committed before this test ran: `9b317c785671d80d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
