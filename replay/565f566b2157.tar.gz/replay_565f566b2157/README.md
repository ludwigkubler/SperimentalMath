# Replay package — entry 565f566b2157

Conjecture: Minimal Order of Automorphic Lattices Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 20:36 UTC.
Pre-registration hash committed before this test ran: `78b160534c976eba`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
