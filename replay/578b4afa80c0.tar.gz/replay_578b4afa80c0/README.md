# Replay package — entry 578b4afa80c0

Conjecture: Protocol-Induced Covers on Tensor-Powered Girth Gadgets Exhibit Logarithmic Multiplicity Growth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-29 07:23 UTC.
Pre-registration hash committed before this test ran: `04263c57a8ae5079`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
