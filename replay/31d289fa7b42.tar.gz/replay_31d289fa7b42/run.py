import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_tseitin_formula(n, delta):
        variables = list(range(1, n + 1))
        clauses = []
        
        for var in variables:
            clause = [random.choice([-1, 1]) * var]
            for _ in range(delta - 1):
                other_var = random.choice(variables)
                if other_var != var:
                    clause.append(random.choice([-1, 1]) * other_var)
            clauses.append(clause)
        
        return variables, clauses
    
    def tseitin_formula_to_graph(variables, clauses):
        graph = {var: set() for var in variables}
        
        for i, clause in enumerate(clauses):
            for j in range(len(clause)):
                for k in range(j + 1, len(clause)):
                    var1 = abs(clause[j])
                    var2 = abs(clause[k])
                    graph[var1].add(-var2)
                    graph[-var1].add(var2)
        
        return graph
    
    def quantum_group_cohomology_rank(graph):
        n = len(graph)
        adjacency_matrix = [[0] * n for _ in range(n)]
        
        for var, neighbors in graph.items():
            index = abs(var) - 1
            for neighbor in neighbors:
                if neighbor > 0:
                    adjacency_matrix[index][abs(neighbor) - 1] += 1
        
        # Gaussian elimination to find the rank of the matrix
        row echelon_form = [row[:] for row in adjacency_matrix]
        rank = n
        
        for i in range(n):
            pivot_row = next((j for j in range(i, n) if echelon_form[j][i] != 0), None)
            if pivot_row is None:
                rank -= 1
                continue
            
            # Swap rows to put the pivot at the current position
            echelon_form[i], echelon_form[pivot_row] = echelon_form[pivot_row], echelon_form[i]
            
            # Make all entries below the pivot zero
            for j in range(i + 1, n):
                factor = echelon_form[j][i] / echelon_form[i][i]
                for k in range(n):
                    echelon_form[j][k] -= factor * echelon_form[i][k]
        
        return rank
    
    def resolution_proof_length(clauses):
        # Simplified DPLL solver to estimate proof length
        stack = []
        assignment = {}
        
        def dpll():
            if not clauses:
                return 0
            
            unit_clause = next((c for c in clauses if len(c) == 1), None)
            if unit_clause:
                literal = unit_clause[0]
                assignment[abs(literal)] = literal > 0
                clauses = [c for c in clauses if literal not in c and -literal not in c]
                return dpll()
            
            var = next((v for v in range(1, len(variables) + 1) if v not in assignment), None)
            stack.append((-var, assignment.copy()))
            assignment[var] = True
            clauses = [c for c in clauses if var not in c and -var not in c]
            proof_length = dpll()
            if proof_length is not None:
                return proof_length + 1
            
            stack.pop()
            assignment[var] = False
            clauses.append([-var])
            proof_length = dpll()
            if proof_length is not None:
                return proof_length + 1
            
            stack.pop()
            return None
        
        return dpll()
    
    n = random.randint(5, 40)
    delta = random.randint(2, 5)
    variables, clauses = generate_tseitin_formula(n, delta)
    graph = tseitin_formula_to_graph(variables, clauses)
    rank = quantum_group_cohomology_rank(graph)
    proof_length = resolution_proof_length(clauses)
    
    metric_name = "minimal_rank"
    metric_value = rank
    instances_tested = 1
    conjecture_holds = rank >= 2 ** (math.log(n / delta, 2) ** 2)
    counterexample = "" if conjecture_holds else f"n={n}, delta={delta}, rank={rank}"
    
    return {
        "metric_name": metric_name,
        "metric_value": metric_value,
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    
    seeds = [int(s) for s in sys.argv[1:]] if len(sys.argv) > 1 else list(range(2, 30)) + [101, 103, 107, 109]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_metric_value = sum(r["metric_value"] for r in results) / len(results)
    std_metric_value = math.sqrt(sum((r["metric_value"] - mean_metric_value) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_metric_value} support_fraction={support_fraction}")
    elif sum(1 for r in results if not r["conjecture_holds"]) / len(results) >= 0.2:
        first_failing_seed = next(i for i, r in enumerate(results) if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{results[first_failing_seed]['counterexample']}\" first_failing_seed={seeds[first_failing_seed]}")
    else:
        print("RESULT: INCONCLUSIVE insufficient_support")