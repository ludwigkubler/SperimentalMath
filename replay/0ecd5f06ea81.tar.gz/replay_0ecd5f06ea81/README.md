# Replay package — entry 0ecd5f06ea81

Conjecture: Operator-SoS 4-Trace Gap Lower-Bounds Blocks-Order Read-Twice BP for IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 02:59 UTC.
Pre-registration hash committed before this test ran: `238621f6d8b52a30`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
