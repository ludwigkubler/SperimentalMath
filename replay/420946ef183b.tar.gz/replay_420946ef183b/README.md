# Replay package — entry 420946ef183b

Conjecture: Cubical Betti Sum of Implicant Complex Lower-Bounds DNF-MCSP

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 12:47 UTC.
Pre-registration hash committed before this test ran: `27646652b756baaf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
