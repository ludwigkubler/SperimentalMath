# Replay package — entry bfd46d5091f2

Conjecture: Minimal Rank of Multivariate Continued Fractions Bounds Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 09:58 UTC.
Pre-registration hash committed before this test ran: `bdee6c804b0007c6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
