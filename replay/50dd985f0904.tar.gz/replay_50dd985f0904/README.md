# Replay package — entry 50dd985f0904

Conjecture: Free Entropy Lower Bound on Disjointness Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 14:30 UTC.
Pre-registration hash committed before this test ran: `5823b2599d2ffc30`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
