# Replay package — entry 86590a3e84b8

Conjecture: Minimal Local Dimension of Coxeter Groups Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 10:00 UTC.
Pre-registration hash committed before this test ran: `3543635b47279fd8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
