# Replay package — entry eb6e20bf88b0

Conjecture: Minimal Order of Quasi-Crystalline Sheaves and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 22:56 UTC.
Pre-registration hash committed before this test ran: `162cc82b80605ce7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
