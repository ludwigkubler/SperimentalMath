# Replay package — entry 59b7022cf20c

Conjecture: Minimal Tropical Hodge Structure Rank and DPLL Proof Path Length Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 21:55 UTC.
Pre-registration hash committed before this test ran: `4ab360cf0985c1b7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
