# Replay package — entry 4a4f69a6f8ba

Conjecture: Minimal Geometric Entropy of Riemann Surfaces and SOS Max-CUT Approximation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 19:37 UTC.
Pre-registration hash committed before this test ran: `573594a69bdbbe81`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
