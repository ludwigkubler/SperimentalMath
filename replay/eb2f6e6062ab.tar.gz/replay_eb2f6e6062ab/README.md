# Replay package — entry eb2f6e6062ab

Conjecture: Betti Number Bound via SOS Rank for 3-SAT Solution Spaces

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 09:41 UTC.
Pre-registration hash committed before this test ran: `b47220a0a0eeb6d5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
