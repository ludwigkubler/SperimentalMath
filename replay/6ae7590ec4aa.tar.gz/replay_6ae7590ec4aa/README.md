# Replay package — entry 6ae7590ec4aa

Conjecture: Plünnecke-Ruzsa Doubling of Constraint Vectors Lower-Bounds SoS Degree for 3-XOR

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 09:45 UTC.
Pre-registration hash committed before this test ran: `8f4a584b1b1a5787`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
