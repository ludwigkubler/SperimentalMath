# Replay package — entry 4ab417bc1c0b

Conjecture: Additive Energy Inverse Proportional to Disjointness Discrepancy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 22:42 UTC.
Pre-registration hash committed before this test ran: `cfa278f8b763698c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
