# Replay package — entry 73fc92f4685f

Conjecture: Minimal Rank of Quasi-Boolean Homology vs Resolution Proof Length for CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 16:37 UTC.
Pre-registration hash committed before this test ran: `5530d03c891de8e4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
