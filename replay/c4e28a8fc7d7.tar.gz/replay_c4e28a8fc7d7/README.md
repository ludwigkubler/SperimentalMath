# Replay package — entry c4e28a8fc7d7

Conjecture: Submodular Measure on Monotone DNF for k-CLIQUE Approximation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 05:13 UTC.
Pre-registration hash committed before this test ran: `67b22fc81f538d3a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
