# Replay package — entry b2165620672d

Conjecture: Minimal Order of Kähler Forms and Communication Complexity Rank Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 19:02 UTC.
Pre-registration hash committed before this test ran: `6b4762733872bed9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
