# Replay package — entry 1202733ea286

Conjecture: Minimal Hodge Index in Configuration Space and Communication Complexity Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 10:17 UTC.
Pre-registration hash committed before this test ran: `2e9c6dcd4a0184bc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
