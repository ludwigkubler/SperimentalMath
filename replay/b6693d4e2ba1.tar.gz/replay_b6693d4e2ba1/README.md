# Replay package — entry b6693d4e2ba1

Conjecture: Minimal Alexander-Brandt Index and Communication Complexity Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 23:07 UTC.
Pre-registration hash committed before this test ran: `d434902b3e96762c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
