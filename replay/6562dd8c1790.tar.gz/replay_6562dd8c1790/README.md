# Replay package — entry 6562dd8c1790

Conjecture: Coxeter Group Rank and Monomial Ideal Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 11:05 UTC.
Pre-registration hash committed before this test ran: `d8226b84ef808406`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
