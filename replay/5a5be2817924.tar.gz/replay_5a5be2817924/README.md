# Replay package — entry 5a5be2817924

Conjecture: Minimal Frobenius-Schur Indicator Correlation with Frege Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 11:07 UTC.
Pre-registration hash committed before this test ran: `7c819ec346a6db12`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
