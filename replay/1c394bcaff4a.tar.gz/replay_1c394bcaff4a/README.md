# Replay package — entry 1c394bcaff4a

Conjecture: Moment-Matrix Rank Deficit in Max-CUT Approximation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 13:36 UTC.
Pre-registration hash committed before this test ran: `d3b7d3b2cbbb6867`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
