# Replay package — entry 381d7c01268f

Conjecture: Arithmetic Degree of Affine Scheme Invariant Under Tropicalization Bound by Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 10:32 UTC.
Pre-registration hash committed before this test ran: `065721ff11472f6d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
