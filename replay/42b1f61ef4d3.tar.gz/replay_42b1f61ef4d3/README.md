# Replay package — entry 42b1f61ef4d3

Conjecture: Minimal Number of Automorphism Group Orbits and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 13:31 UTC.
Pre-registration hash committed before this test ran: `6fcab90139cc3007`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
