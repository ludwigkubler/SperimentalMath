# Replay package — entry 7b586ef6ce8f

Conjecture: Minimal Eta-Invariant Correlation with Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 02:07 UTC.
Pre-registration hash committed before this test ran: `f71210dc1f5dd8db`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
