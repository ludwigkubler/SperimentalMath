# Replay package — entry e51ec8114266

Conjecture: Minimal Rank of Kähler Forms Bounds Tseitin Formula Proof Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 12:01 UTC.
Pre-registration hash committed before this test ran: `940d9165e4cf17ae`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
