# Replay package — entry ea1ddd12f289

Conjecture: Minimal Local Indeterminacy in Algebraic Topology and Communication Complexity Rank

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 11:00 UTC.
Pre-registration hash committed before this test ran: `58732f272a5360ba`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
