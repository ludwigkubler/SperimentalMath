# Replay package — entry 4b350284c454

Conjecture: Minimal Hodge Index of Tropicalized Boolean Functions Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 07:22 UTC.
Pre-registration hash committed before this test ran: `e836c383330f9149`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
