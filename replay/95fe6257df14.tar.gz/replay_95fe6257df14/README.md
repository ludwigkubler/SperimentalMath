# Replay package — entry 95fe6257df14

Conjecture: Minimal Order of Noncommutative K-theory and Resolution Proof Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 19:17 UTC.
Pre-registration hash committed before this test ran: `43b3c2d8e2766ea5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
