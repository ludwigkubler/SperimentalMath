# Replay package — entry 30e19fb24406

Conjecture: Coxeter Group Enumeration Complexity of Boolean Circuit Thresholds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 17:37 UTC.
Pre-registration hash committed before this test ran: `0a766760525f15a8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
