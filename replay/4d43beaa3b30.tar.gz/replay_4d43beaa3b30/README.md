# Replay package — entry 4d43beaa3b30

Conjecture: Real Polynomial Approximation Degree Lower Bound for AC⁰ Circuits Computing PARITY

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 06:45 UTC.
Pre-registration hash committed before this test ran: `cb42e9aefc878120`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
