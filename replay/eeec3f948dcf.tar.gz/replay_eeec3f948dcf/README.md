# Replay package — entry eeec3f948dcf

Conjecture: Decision Tree Depth and Communication Complexity via Lifting

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 00:11 UTC.
Pre-registration hash committed before this test ran: `98c49723d2fe2600`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
