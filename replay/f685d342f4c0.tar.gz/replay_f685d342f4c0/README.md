# Replay package — entry f685d342f4c0

Conjecture: Coarse-dimensional KRW direct sum: asdim is sub-additive under block composition

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 16:44 UTC.
Pre-registration hash committed before this test ran: `7a6eac3d592428f8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
