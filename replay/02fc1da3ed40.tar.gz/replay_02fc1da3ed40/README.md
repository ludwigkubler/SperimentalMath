# Replay package — entry 02fc1da3ed40

Conjecture: Minimal Local Indeterminacy in Algebraic Topology and Communication Matrix Rank

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 15:54 UTC.
Pre-registration hash committed before this test ran: `a59232f6d9e29e2a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
