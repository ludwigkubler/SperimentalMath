# Replay package — entry 18df83a46e71

Conjecture: Conway Temperature Bounds Tree-Resolution Width for 3-SAT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 06:17 UTC.
Pre-registration hash committed before this test ran: `4dfada06c2e95171`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
