# Replay package — entry 836f6e0c3d72

Conjecture: Real Rank of Moment Matrix Bounded by SOS Refutation Degree for CSPs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 14:42 UTC.
Pre-registration hash committed before this test ran: `8c44f02afc69fc40`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
