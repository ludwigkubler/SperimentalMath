# Replay package — entry 8aa9e8182cf1

Conjecture: Coxeter Group Representation Invariant vs DPLL Search Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 12:30 UTC.
Pre-registration hash committed before this test ran: `271e644c34457249`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
