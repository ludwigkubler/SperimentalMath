# Replay package — entry d6ceec40f3c8

Conjecture: Minimal Root System Length Bounds Tseitin Resolution Proofs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 08:46 UTC.
Pre-registration hash committed before this test ran: `373640b756ca609d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
