# Replay package — entry e4e1438304f5

Conjecture: Minimal Rank of Algebraic Stacks over Boolean Function Output Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 05:30 UTC.
Pre-registration hash committed before this test ran: `3bf91c28c8dff563`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
