# Replay package — entry b84510964185

Conjecture: Symmetric Group Character Discrepancy Lower Bound for Matrix Rigidity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 09:04 UTC.
Pre-registration hash committed before this test ran: `d7f06c75617dc98d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
