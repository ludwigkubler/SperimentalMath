# Replay package — entry a361f1435486

Conjecture: Minimal Rank of Quadratic Forms over Tropical Semirings vs Monotone Circuit Size for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 01:29 UTC.
Pre-registration hash committed before this test ran: `892b09dd8d006a90`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
