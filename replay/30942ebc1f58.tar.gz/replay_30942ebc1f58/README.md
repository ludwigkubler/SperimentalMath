# Replay package — entry 30942ebc1f58

Conjecture: Minimal Order of Sheaves over Affine Schemes and SAT Clause Subset Entropy Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 04:39 UTC.
Pre-registration hash committed before this test ran: `8a5c5cbb7a68fd4a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
