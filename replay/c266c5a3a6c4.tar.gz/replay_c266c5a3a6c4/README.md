# Replay package — entry c266c5a3a6c4

Conjecture: Minimal Rank of Integer-Lattice Homology and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 08:12 UTC.
Pre-registration hash committed before this test ran: `a35853b214e660e2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
