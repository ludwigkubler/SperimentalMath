# Replay package — entry e14f176e4ef1

Conjecture: Tropical Self-Convolution Doubling Law for MinimalFourierCoefficient

Verdict (original run): FALSIFIED

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 20:32 UTC.
Pre-registration hash committed before this test ran: `a69e0ff611763248`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
