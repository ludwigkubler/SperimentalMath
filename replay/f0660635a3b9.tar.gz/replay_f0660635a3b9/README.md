# Replay package — entry f0660635a3b9

Conjecture: Minimal Rank of Hodge Decomposition vs ACC⁰ Circuit Weights

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 16:25 UTC.
Pre-registration hash committed before this test ran: `fce2a5b8f478c1c9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
