# Replay package — entry 0bb43dada997

Conjecture: Tropical Convex Hull Extreme Points Lower Bound for ACC^0 Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 00:08 UTC.
Pre-registration hash committed before this test ran: `7a50d2a41b434d66`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
