# Replay package — entry 1ae8691b7cfd

Conjecture: Polymatroid Spectral Gap of Monotone DNFs Detects k-Cliques

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 19:16 UTC.
Pre-registration hash committed before this test ran: `b70e9d081d57b85b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
