# Replay package — entry 5ee62d63ba3c

Conjecture: Gromov 4-Point δ of XOR-Lifted Row Metric Bounds DT Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 10:01 UTC.
Pre-registration hash committed before this test ran: `abb3e7499f7f8a25`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
