# Replay package — entry be7b7e974a78

Conjecture: Minimal Local Index and Frege Proof Depth Correlation for k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 05:55 UTC.
Pre-registration hash committed before this test ran: `1561304bd42a91ca`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
