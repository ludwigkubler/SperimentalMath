# Replay package — entry 7d81194403f3

Conjecture: Fourier Coefficient Decay Implies SOS Degree Lower Bound for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 12:27 UTC.
Pre-registration hash committed before this test ran: `a2baf9273904eff5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
