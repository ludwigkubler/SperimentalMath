# Replay package — entry f781296ddc7c

Conjecture: Pseudoexpectation Spectral Gap Lower-Bounds SoS Refutation Degree on 3-XOR

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 22:55 UTC.
Pre-registration hash committed before this test ran: `46bc6d9f4e0c6198`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
