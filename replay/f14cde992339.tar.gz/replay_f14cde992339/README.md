# Replay package — entry f14cde992339

Conjecture: Minimal Number of Automorphism Groups and SAT Clause Set Complexity Correlation via Group Cohomology

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 00:04 UTC.
Pre-registration hash committed before this test ran: `1392923a8236868d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
