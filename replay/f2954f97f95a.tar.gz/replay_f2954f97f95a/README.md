# Replay package — entry f2954f97f95a

Conjecture: Minimal Order of Brauer Groups and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 18:07 UTC.
Pre-registration hash committed before this test ran: `85a1f1e364e7a611`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
