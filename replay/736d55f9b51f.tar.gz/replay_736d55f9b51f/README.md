# Replay package — entry 736d55f9b51f

Conjecture: Free Entropy of Disjointness Matrix Eigenvalues Bounds Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 01:45 UTC.
Pre-registration hash committed before this test ran: `e1cc8bfb9025f236`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
