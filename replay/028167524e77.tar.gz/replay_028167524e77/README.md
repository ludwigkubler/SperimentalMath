# Replay package — entry 028167524e77

Conjecture: Matroid Rank and Karchmer-Wigderson Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 05:07 UTC.
Pre-registration hash committed before this test ran: `f41a7073beb11c2b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
