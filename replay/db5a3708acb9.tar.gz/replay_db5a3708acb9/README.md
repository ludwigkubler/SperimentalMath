# Replay package — entry db5a3708acb9

Conjecture: Minimal L^p Norm of Quadratic Forms Bounds Resolution Proof Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 03:32 UTC.
Pre-registration hash committed before this test ran: `89acfd8c4758b293`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
