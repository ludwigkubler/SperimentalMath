# Replay package — entry 3dd7d5ee43a7

Conjecture: Real Stable Polynomial Coefficient Sum and AC⁰ PARITY Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-07 19:29 UTC.
Pre-registration hash committed before this test ran: `1ab165bccb39c9e9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
