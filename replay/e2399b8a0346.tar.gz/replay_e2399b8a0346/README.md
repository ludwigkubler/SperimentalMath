# Replay package — entry e2399b8a0346

Conjecture: Minimal Rank of Noncrossing Partitions vs Disjunctive Normal Form Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 06:20 UTC.
Pre-registration hash committed before this test ran: `eb64d39682f7677c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
