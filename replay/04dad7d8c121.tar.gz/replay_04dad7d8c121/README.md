# Replay package — entry 04dad7d8c121

Conjecture: Minimal Number of Hodge Classes and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 22:59 UTC.
Pre-registration hash committed before this test ran: `3d6c2dbb352c4aa5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
