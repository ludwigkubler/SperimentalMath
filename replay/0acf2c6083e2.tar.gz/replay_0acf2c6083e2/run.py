import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    n = 10  # Start with a small size and increase if needed
    M = [[random.randint(0, 1) for _ in range(n)] for _ in range(n)]
    
    def matrix_dilation(M):
        I = [[1 if i == j else 0 for j in range(n)] for i in range(n)]
        D = []
        for row in M:
            new_row = [x * n for x in row]
            D.append(new_row)
        return D
    
    def noncommutative_Lp_norm(M, p):
        if p == 1:
            norm = max(sum(abs(x) for x in row) for row in M)
        elif p == float('inf'):
            norm = max(max(row) for row in M)
        else:
            norm = (sum(sum(abs(x)**p for x in row) for row in M))**(1/p)
        return norm
    
    D = matrix_dilation(M)
    norm_D = noncommutative_Lp_norm(D, math.log(n))
    
    metric_value = norm_D / math.sqrt(n)
    conjecture_holds = metric_value >= 0.1 * math.sqrt(n)
    counterexample = "" if conjecture_holds else "mapping_undefined"
    
    return {
        "metric_name": "noncommutative_Lp_norm",
        "metric_value": metric_value,
        "instances_tested": 1,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2**i - 1 for i in range(5, 35)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = (sum((r["metric_value"] - mean_value)**2 for r in results) / len(results))**0.5
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value:.4f} std={std_value:.4f} support_fraction={support_fraction:.2f}")
    else:
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"mapping_undefined\" first_failing_seed={first_failing_seed}")