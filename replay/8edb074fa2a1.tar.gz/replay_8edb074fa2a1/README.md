# Replay package — entry 8edb074fa2a1

Conjecture: Symmetric Tensor Rank Gap in Permanent vs Determinant Decompositions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 22:28 UTC.
Pre-registration hash committed before this test ran: `a08160299055ec2c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
