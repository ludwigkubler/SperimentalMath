# Replay package — entry 5167cdc13e84

Conjecture: Spectral Concentration of Moment Matrices in Max-CUT SOS Hierarchy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 21:59 UTC.
Pre-registration hash committed before this test ran: `c57d7a13661baabc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
