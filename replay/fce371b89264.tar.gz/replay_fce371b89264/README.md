# Replay package — entry fce371b89264

Conjecture: Minimal Topological Entropy of Curves and Frege Proof Depth Correlation via Frobenius Theory

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 03:21 UTC.
Pre-registration hash committed before this test ran: `0f8965f7362dadda`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
