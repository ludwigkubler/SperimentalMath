# Replay package — entry 4ae228116ef7

Conjecture: Minimal Rank of Hodge Integrals over Boolean Satisfiability Solvable Instances

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 14:22 UTC.
Pre-registration hash committed before this test ran: `51c613554c117e37`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
