# Replay package — entry abd1d41a3c37

Conjecture: Minimal Rank of Configuration Space Cohomology over Disjointness Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 07:36 UTC.
Pre-registration hash committed before this test ran: `0246efa75fd11c51`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
