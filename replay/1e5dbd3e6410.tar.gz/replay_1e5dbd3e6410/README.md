# Replay package — entry 1e5dbd3e6410

Conjecture: Hodge Index vs Resolution Proof Tree Diameter

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 04:37 UTC.
Pre-registration hash committed before this test ran: `264942c998ac40ce`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
