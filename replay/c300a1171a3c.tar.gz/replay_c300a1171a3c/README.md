# Replay package — entry c300a1171a3c

Conjecture: SOS Integrality Gap and Secant Variety Dimension for Polynomial CSPs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-29 06:32 UTC.
Pre-registration hash committed before this test ran: `6392381aab7569a8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
