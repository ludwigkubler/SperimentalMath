# Replay package — entry be3fb0e7cddc

Conjecture: Minimal Rank of Generalized Polynomials vs Boolean Circuit Weights

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 04:07 UTC.
Pre-registration hash committed before this test ran: `adbc109431422c0a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
