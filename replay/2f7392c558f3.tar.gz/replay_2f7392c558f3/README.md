# Replay package — entry 2f7392c558f3

Conjecture: Graphical Real Root Count Bounds Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 09:13 UTC.
Pre-registration hash committed before this test ran: `302df30b4a91c8a5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
