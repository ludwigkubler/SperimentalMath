# Replay package — entry c708ecff77fa

Conjecture: Coxeter Group Action Spectrum and AC⁰ Parity Circuit Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 11:07 UTC.
Pre-registration hash committed before this test ran: `83a033e78b9a2b63`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
