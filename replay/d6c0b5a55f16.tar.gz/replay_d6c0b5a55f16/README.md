# Replay package — entry d6c0b5a55f16

Conjecture: Minimal Lefschetz Finiteness and Boolean Circuit Monotone Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 23:52 UTC.
Pre-registration hash committed before this test ran: `68295d51a4508bad`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
