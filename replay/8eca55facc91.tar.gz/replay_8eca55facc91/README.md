# Replay package — entry 8eca55facc91

Conjecture: Minimal Rank of Hypergeometric Series Coefficients over Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 08:49 UTC.
Pre-registration hash committed before this test ran: `95a7977167f7fb83`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
