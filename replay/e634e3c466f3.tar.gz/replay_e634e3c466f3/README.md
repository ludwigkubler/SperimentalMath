# Replay package — entry e634e3c466f3

Conjecture: Minimal Rank of Tropicalized Deligne-Lusztig Polynomials over XOR-AND Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 15:29 UTC.
Pre-registration hash committed before this test ran: `bd04c8f4399cdfed`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
