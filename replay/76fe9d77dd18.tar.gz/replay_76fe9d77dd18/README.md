# Replay package — entry 76fe9d77dd18

Conjecture: Euler Characteristic vs Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 05:01 UTC.
Pre-registration hash committed before this test ran: `3e1d2014d15af4c2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
