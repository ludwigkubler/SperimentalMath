# Replay package — entry 21c70b173bfc

Conjecture: Minimal Root Count of Integer Polynomials and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 14:16 UTC.
Pre-registration hash committed before this test ran: `a301b96835fd022c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
