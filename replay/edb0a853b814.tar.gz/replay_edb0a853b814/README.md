# Replay package — entry edb0a853b814

Conjecture: Minimal Root Count of Meromorphic Functions and Communication Complexity Rank Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 20:47 UTC.
Pre-registration hash committed before this test ran: `90930c8449cb8355`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
