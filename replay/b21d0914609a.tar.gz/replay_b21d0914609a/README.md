# Replay package — entry b21d0914609a

Conjecture: Minimal Rank of Symplectic Leaves vs Communication Complexity for XOR-AND Networks

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 17:29 UTC.
Pre-registration hash committed before this test ran: `fa0bcada1f39bd0f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
