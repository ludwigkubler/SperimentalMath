# Replay package — entry 95c0d42afb3f

Conjecture: Littlewood-Richardson Coefficient Asymmetry in Permanent vs Determinant Decompositions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 18:20 UTC.
Pre-registration hash committed before this test ran: `615103dda1caee02`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
