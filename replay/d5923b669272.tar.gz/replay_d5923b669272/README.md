# Replay package — entry d5923b669272

Conjecture: Minimal Local Index in Algebraic Topology and Circuit Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 10:13 UTC.
Pre-registration hash committed before this test ran: `7fb23e4a07e205e1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
