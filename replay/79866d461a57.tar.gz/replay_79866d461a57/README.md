# Replay package — entry 79866d461a57

Conjecture: Minimal Lattice Orbit Diameter and Circuit Entanglement Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 12:14 UTC.
Pre-registration hash committed before this test ran: `b3271128d944a3f4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
