# Replay package — entry 7bf54c49f3e6

Conjecture: Minimal Frobenius Norm of Polynomial Representations and Circuit Monotone Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 15:27 UTC.
Pre-registration hash committed before this test ran: `5ddaaaa4d71a057c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
