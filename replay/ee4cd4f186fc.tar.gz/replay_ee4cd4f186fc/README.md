# Replay package — entry ee4cd4f186fc

Conjecture: Plethysm Multiplicity Gap in Symmetric Powers of Permanent vs Determinant

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 13:26 UTC.
Pre-registration hash committed before this test ran: `d6fe79b3612d6141`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
