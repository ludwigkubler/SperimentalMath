# Replay package — entry 864710710971

Conjecture: Minimal Rank of Tropical Curves Bounds Monomial Ideal Complexity for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 23:20 UTC.
Pre-registration hash committed before this test ran: `09ae5d58a5684f46`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
