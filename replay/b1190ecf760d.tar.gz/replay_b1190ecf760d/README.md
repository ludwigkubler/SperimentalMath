# Replay package — entry b1190ecf760d

Conjecture: Automorphism Group Conjugacy Classes and Resolution Width of Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 21:23 UTC.
Pre-registration hash committed before this test ran: `23ac8800f7e52276`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
