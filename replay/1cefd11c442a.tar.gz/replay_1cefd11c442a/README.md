# Replay package — entry 1cefd11c442a

Conjecture: Minimal Rank of Quasi-Monte Carlo Sequences Bounds Tseitin Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 15:48 UTC.
Pre-registration hash committed before this test ran: `9623dd53cb6c85dd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
