# Replay package — entry 3879740384b2

Conjecture: Minimal Rank of Twisted Differential Forms Bounds ACC^0 Circuit Monotonicity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 04:56 UTC.
Pre-registration hash committed before this test ran: `ae2be5398d6f12c2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
