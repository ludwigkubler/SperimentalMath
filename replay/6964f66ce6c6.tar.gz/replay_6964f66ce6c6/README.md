# Replay package — entry 6964f66ce6c6

Conjecture: Minimal Number of Integral Points in Quadratic Forms and SAT Clause Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 17:49 UTC.
Pre-registration hash committed before this test ran: `271f9fb62db5035b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
