# Replay package — entry 5fc15b60077d

Conjecture: Coxeter-Weyl Group Action on Boolean Circuit Tensor Rank

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 14:05 UTC.
Pre-registration hash committed before this test ran: `1b97f44b74ac3662`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
