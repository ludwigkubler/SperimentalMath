# Replay package — entry fcdff37e3de9

Conjecture: Real Radical Dimension Inverse Proportionality to SOS Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 05:41 UTC.
Pre-registration hash committed before this test ran: `4d7b6b18ab9d86c6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
