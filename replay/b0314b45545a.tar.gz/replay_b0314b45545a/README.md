# Replay package — entry b0314b45545a

Conjecture: Expander Modulus Bounds Tseitin Proof Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 16:11 UTC.
Pre-registration hash committed before this test ran: `995924a74a959420`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
