import random
import math
from fractions import Fraction

def gaussian_elimination(A):
    m, n = len(A), len(A[0])
    for i in range(m):
        # Find pivot row
        max_row = i
        for j in range(i+1, m):
            if abs(A[j][i]) > abs(A[max_row][i]):
                max_row = j
        A[i], A[max_row] = A[max_row], A[i]
        
        # Eliminate below the pivot
        factor = A[i][i]
        for j in range(n):
            A[i][j] /= factor
        
        for j in range(i+1, m):
            factor = A[j][i]
            for k in range(n):
                A[j][k] -= factor * A[i][k]
    return A

def rank(A):
    rref = gaussian_elimination(A)
    rank = 0
    for row in rref:
        if any(row):
            rank += 1
    return rank

def generate_kcnf(n, k):
    variables = list(range(1, n+1))
    clauses = []
    for _ in range(k):
        clause = random.sample(variables, random.randint(1, n))
        clause.append(-random.choice(clause))  # Ensure at least one negated variable
        clauses.append(clause)
    return clauses

def communication_complexity(F):
    n = len(F[0])
    delta = sum(1 for clause in F if all(x in clause or -x in clause for x in range(1, n+1))) / (2**n)
    return max(n, math.log(1/delta))

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n_values = [5, 10, 15, 20, 30, 40]
    results = []
    
    for n in n_values:
        F = generate_kcnf(n, n)
        A = [[0] * (n+1) for _ in range(n+1)]
        
        # Construct the twisted K-theory matrix
        for clause in F:
            for x in clause:
                if x > 0:
                    A[x][x] += 1
                else:
                    A[-x][-x] -= 1
        
        tk_rank = rank(A)
        cc = communication_complexity(F)
        
        results.append({
            "n": n,
            "tk_rank": tk_rank,
            "cc": cc,
            "conjecture_holds": tk_rank <= n**(0.5 + 1e-6) and cc >= min(n, math.log(1/0.01))
        })
    
    metric_value = sum(result["tk_rank"] for result in results)
    instances_tested = len(results)
    conjecture_holds = all(result["conjecture_holds"] for result in results)
    counterexample = "" if conjecture_holds else "Counterexample found"
    
    return {
        "metric_name": "twisted_k_theory_rank",
        "metric_value": metric_value,
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value)**2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"First failing seed\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE reason=unknown")