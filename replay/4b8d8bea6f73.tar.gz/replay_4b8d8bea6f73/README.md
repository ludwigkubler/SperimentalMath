# Replay package — entry 4b8d8bea6f73

Conjecture: Dual-VC Dimension of KW Conflict Family Bounds Formula Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 18:40 UTC.
Pre-registration hash committed before this test ran: `9881f66da9ae8419`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
