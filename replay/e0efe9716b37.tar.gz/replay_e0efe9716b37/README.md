# Replay package — entry e0efe9716b37

Conjecture: Fourier Coefficient Sum Separation for Read-Twice Branching Programs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 15:54 UTC.
Pre-registration hash committed before this test ran: `11e9e6284ee1d201`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
