# Replay package — entry 1aaaed379c87

Conjecture: Eulerian Descent Entropy Separates Perm from Padded Det_m

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 23:46 UTC.
Pre-registration hash committed before this test ran: `97dfac35a71e13c0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
