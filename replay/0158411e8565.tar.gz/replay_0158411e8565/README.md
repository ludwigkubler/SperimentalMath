# Replay package — entry 0158411e8565

Conjecture: Minimal Rank of tropicalized Birkhoff polytopes bounds Monotone k-CLIQUE Proofs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 11:53 UTC.
Pre-registration hash committed before this test ran: `0656c34c9edc31c9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
