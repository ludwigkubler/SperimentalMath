# Replay package — entry 3e215381ba21

Conjecture: Minimal Rank of Noncrossed Products Bounds BP Read-Twice Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 23:03 UTC.
Pre-registration hash committed before this test ran: `320dd3f78147b8f1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
