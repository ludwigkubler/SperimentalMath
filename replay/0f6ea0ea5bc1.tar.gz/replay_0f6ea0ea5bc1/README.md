# Replay package — entry 0f6ea0ea5bc1

Conjecture: Erdős-Szekeres Theorem Based Lower Bound for Resolution Length on Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 13:00 UTC.
Pre-registration hash committed before this test ran: `30ef52bfa10b8dbe`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
