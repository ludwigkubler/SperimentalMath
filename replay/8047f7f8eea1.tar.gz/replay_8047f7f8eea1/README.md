# Replay package — entry 8047f7f8eea1

Conjecture: Block-Composition Sub-Additivity of Coarse Depth κ via the Roe-Trace Pairing

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 01:39 UTC.
Pre-registration hash committed before this test ran: `2fe09bf387006c65`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
