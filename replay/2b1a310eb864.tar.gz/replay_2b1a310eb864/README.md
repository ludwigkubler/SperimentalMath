# Replay package — entry 2b1a310eb864

Conjecture: Minimal Number of Quaternionic Kähler Manifolds and SAT Clause Subset Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 11:36 UTC.
Pre-registration hash committed before this test ran: `cf7584c0a30d6526`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
