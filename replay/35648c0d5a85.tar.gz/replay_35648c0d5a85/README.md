# Replay package — entry 35648c0d5a85

Conjecture: Minimal Rank of Quasi-vertex-Descent Trees over Tseitin Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 14:26 UTC.
Pre-registration hash committed before this test ran: `c46d283c986580f1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
