# Replay package — entry 1f65a5eb95d6

Conjecture: Irreducible Component Count Bounds Circuit Complexity for CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 02:01 UTC.
Pre-registration hash committed before this test ran: `09846e05980412dc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
