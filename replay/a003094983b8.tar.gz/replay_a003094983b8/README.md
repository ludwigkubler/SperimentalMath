# Replay package — entry a003094983b8

Conjecture: Minimal Local System Rank and Resolution Proof Width Lower Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 00:17 UTC.
Pre-registration hash committed before this test ran: `7e2d81e5504bee9f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
