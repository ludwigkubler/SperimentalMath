# Replay package — entry 4ca114e86209

Conjecture: Minimal Quadratic Residue Representation and Communication Complexity Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 23:43 UTC.
Pre-registration hash committed before this test ran: `4528c3bd75f507ba`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
