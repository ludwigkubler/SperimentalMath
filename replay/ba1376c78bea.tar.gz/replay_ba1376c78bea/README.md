# Replay package — entry ba1376c78bea

Conjecture: Minimal Rank of Algebraic K-Theory Groups vs DPLL Refutation Tree Diameter

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 08:36 UTC.
Pre-registration hash committed before this test ran: `f98afd11b0cebc9b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
