# Replay package — entry c99c02cb9842

Conjecture: Hook-Length Ratio Bounds Monotone Circuit Size for Permanent

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 21:10 UTC.
Pre-registration hash committed before this test ran: `e319ec3d9b3dd0b8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
