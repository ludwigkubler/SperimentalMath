# Replay package — entry edb6cb52515b

Conjecture: Minimal Rank of Geometric Invariants in Algebraic Topology vs Frege Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 09:56 UTC.
Pre-registration hash committed before this test ran: `8ee48283d4445d74`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
