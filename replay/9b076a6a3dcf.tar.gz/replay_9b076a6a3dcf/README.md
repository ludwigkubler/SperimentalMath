# Replay package — entry 9b076a6a3dcf

Conjecture: Minimal Galois Group Action on Tensor Products and Boolean Circuit Monotone Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 13:53 UTC.
Pre-registration hash committed before this test ran: `0202f286e90877a0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
