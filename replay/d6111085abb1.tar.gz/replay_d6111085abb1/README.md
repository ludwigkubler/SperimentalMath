# Replay package — entry d6111085abb1

Conjecture: Minimal Order of Non-Semisimple Jordan Algebras Bounds Frege Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 06:19 UTC.
Pre-registration hash committed before this test ran: `8d70c3796cc99fa5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
