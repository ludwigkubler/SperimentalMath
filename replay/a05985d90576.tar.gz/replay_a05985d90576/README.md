# Replay package — entry a05985d90576

Conjecture: Bounded Cross-Correlation Flow Implies Sublinear Kolmogorov Flow in Ergodic Circuits

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 00:54 UTC.
Pre-registration hash committed before this test ran: `c95081f5b273e45b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
