# Replay package — entry 812ab278de1e

Conjecture: Dual Matroid Rank Bounded by Karchmer-Wigderson Protocol Cost

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 20:00 UTC.
Pre-registration hash committed before this test ran: `71789124ea1b0754`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
