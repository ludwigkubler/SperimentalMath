# Replay package — entry bff6969c1719

Conjecture: Legendre-Symbol Partial-Sum Anomaly Excludes ACC^0

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 08:01 UTC.
Pre-registration hash committed before this test ran: `17dd48d3e05d8a2a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
