# Replay package — entry a205b849f8ac

Conjecture: Minimal Local Coherence Rank Correlation with Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 02:29 UTC.
Pre-registration hash committed before this test ran: `a3f0d8079c6b263f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
