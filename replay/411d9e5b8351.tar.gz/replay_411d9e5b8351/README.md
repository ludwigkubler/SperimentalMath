# Replay package — entry 411d9e5b8351

Conjecture: Noncrossing Partition Tree Heights and AC^0 Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 20:09 UTC.
Pre-registration hash committed before this test ran: `ac9a8daf11064f07`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
