# Replay package — entry 38af6bb29bd0

Conjecture: Minimal Hodge Norm and Frege Proof Length Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 20:57 UTC.
Pre-registration hash committed before this test ran: `380bf247a478072c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
