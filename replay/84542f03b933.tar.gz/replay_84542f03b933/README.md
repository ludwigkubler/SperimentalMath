# Replay package — entry 84542f03b933

Conjecture: Minimal Free Entanglement of Read-Twice BP Versus Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 01:01 UTC.
Pre-registration hash committed before this test ran: `f6e0c5a2a6652d3e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
