# Replay package — entry 3f765a1f3567

Conjecture: Minimal Root Separation of Polynomials over Number Fields vs AC0 Parity Threshold

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 08:51 UTC.
Pre-registration hash committed before this test ran: `5e4356276d53e1ba`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
