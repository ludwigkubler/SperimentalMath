# Replay package — entry f4b220239417

Conjecture: Minimal Rank of Hodge Structures over Read-Twice Branching Programs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 13:42 UTC.
Pre-registration hash committed before this test ran: `28c845b22e9a02f7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
