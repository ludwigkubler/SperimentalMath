# Replay package — entry 9e53bb193a1d

Conjecture: Minimal Rank of Tropicalized Group Representations over Randomized Circuit Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 10:57 UTC.
Pre-registration hash committed before this test ran: `cdbb17bd377a8054`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
