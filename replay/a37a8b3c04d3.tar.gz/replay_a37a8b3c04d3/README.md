# Replay package — entry a37a8b3c04d3

Conjecture: Minimal Gromov-Wasserstein Distance and DPLL Proof Path Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 16:14 UTC.
Pre-registration hash committed before this test ran: `b4eb77f0e04157f9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
