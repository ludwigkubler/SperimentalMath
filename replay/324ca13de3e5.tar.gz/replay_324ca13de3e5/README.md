# Replay package — entry 324ca13de3e5

Conjecture: Non-Abelian Fourier Coefficient Gap Bounds Disjointness Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 01:53 UTC.
Pre-registration hash committed before this test ran: `e686b135455817fd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
