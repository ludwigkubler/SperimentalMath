# Replay package — entry 5f31edc102c7

Conjecture: Minimal Rank of Tropicalized Weyl Group Orbits over Resolution Proof Trees

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 05:06 UTC.
Pre-registration hash committed before this test ran: `0f61254ad323f4dd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
