# Replay package — entry 15ba35b6f920

Conjecture: Minimal Order of Monomial Ideals and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 21:59 UTC.
Pre-registration hash committed before this test ran: `22d16ff663cc4da8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
