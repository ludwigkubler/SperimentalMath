# Replay package — entry ea45b50069b0

Conjecture: Minimal Tensor Rank of Algebraic Curves over Function Fields vs Exponential Depth of Frege Proofs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 14:24 UTC.
Pre-registration hash committed before this test ran: `0ad0012fda833572`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
