# Replay package — entry 1be25b6973e0

Conjecture: Riemann Zeta Function Regularization and Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 08:37 UTC.
Pre-registration hash committed before this test ran: `ea2515cfcc9871c3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
