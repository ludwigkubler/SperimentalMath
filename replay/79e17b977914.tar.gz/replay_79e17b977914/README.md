# Replay package — entry 79e17b977914

Conjecture: Minimal Index of Algebraic Coadjointness and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 14:25 UTC.
Pre-registration hash committed before this test ran: `18381ccc572cf5a4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
