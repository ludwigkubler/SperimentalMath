import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_random_graph(n):
        edges = set()
        for i in range(n):
            for j in range(i + 1, n):
                if random.random() < 0.5:
                    edges.add((i, j))
        return edges
    
    def gaussian_elimination(A):
        m, n = len(A), len(A[0])
        rank = 0
        for i in range(n):
            max_row = rank
            for j in range(rank, m):
                if abs(A[j][i]) > abs(A[max_row][i]):
                    max_row = j
            if A[max_row][i] == 0:
                continue
            A[rank], A[max_row] = A[max_row], A[rank]
            for j in range(n):
                if j != i:
                    factor = A[j][i] / A[rank][i]
                    for k in range(n):
                        A[j][k] -= factor * A[rank][k]
            rank += 1
        return rank
    
    def compute_tutte_polynomial(G, x, y):
        n = len(G)
        M = [[0] * (n + 2) for _ in range(n + 2)]
        M[0][0], M[0][1], M[1][0] = 1, -x, -y
        for u, v in G:
            M[u+1][v+1], M[v+1][u+1] = 1, 1
        
        return gaussian_elimination(M)
    
    def min_rank(G):
        n = len(G)
        max_edges = n * (n - 1) // 2
        for k in range(1, max_edges + 1):
            for edges in itertools.combinations(G, k):
                if len(edges) == k:
                    M = [[0] * (k + 2) for _ in range(k + 2)]
                    M[0][0], M[0][1], M[1][0] = 1, -x, -y
                    for u, v in edges:
                        M[u+1][v+1], M[v+1][u+1] = 1, 1
                    if gaussian_elimination(M) == k + 2:
                        return k + 2
        return max_edges
    
    n = random.randint(5, 40)
    G = generate_random_graph(n)
    x, y = random.uniform(-10, 10), random.uniform(-10, 10)
    
    ν_G = min_rank(G)
    circuit_size = compute_tutte_polynomial(G, x, y)
    
    return {
        "metric_name": "circuit_size",
        "metric_value": circuit_size,
        "instances_tested": 1,
        "conjecture_holds": circuit_size >= 2 ** ν_G,
        "counterexample": "" if circuit_size >= 2 ** ν_G else f"Graph with n={n}, ν(G)={ν_G}, circuit_size={circuit_size}"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [random.randint(2, 1000000) for _ in range(30)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{results[0]['counterexample']}\" first_failing_seed={first_failing_seed}")