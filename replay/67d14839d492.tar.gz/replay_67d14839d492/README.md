# Replay package — entry 67d14839d492

Conjecture: Second Eigenvalue Inverse Proportional to Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 08:44 UTC.
Pre-registration hash committed before this test ran: `423b020fa375dfef`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
