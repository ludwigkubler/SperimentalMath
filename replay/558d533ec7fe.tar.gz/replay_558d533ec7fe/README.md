# Replay package — entry 558d533ec7fe

Conjecture: Minimal Rank of Generalized Permutation Patterns vs Determinant Permutation Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 08:40 UTC.
Pre-registration hash committed before this test ran: `6c789dd116e53c1d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
