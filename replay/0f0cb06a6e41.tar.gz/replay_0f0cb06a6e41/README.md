# Replay package — entry 0f0cb06a6e41

Conjecture: Algebraic Degree of Tseitin Variety and Resolution Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 00:03 UTC.
Pre-registration hash committed before this test ran: `83c59b592476c81e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
