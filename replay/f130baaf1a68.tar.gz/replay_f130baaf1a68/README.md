# Replay package — entry f130baaf1a68

Conjecture: Minimal Local Dimension of Semigroups and Read-Twice BP Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 06:37 UTC.
Pre-registration hash committed before this test ran: `7b483c0ebc7f77fe`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
