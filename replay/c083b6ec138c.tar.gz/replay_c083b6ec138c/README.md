# Replay package — entry c083b6ec138c

Conjecture: Minimal Local Index in Algebraic Topology and Resolution Proof Width Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 01:12 UTC.
Pre-registration hash committed before this test ran: `cf2bc29b562adb8e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
