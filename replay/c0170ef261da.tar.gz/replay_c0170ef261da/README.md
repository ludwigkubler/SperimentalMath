# Replay package — entry c0170ef261da

Conjecture: RSK Shape Concentration Separates Permanent from Padded Determinant

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 17:28 UTC.
Pre-registration hash committed before this test ran: `87e6db3e38b07513`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
