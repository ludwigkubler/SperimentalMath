# Replay package — entry 435b8dbdc1a0

Conjecture: Minimal Rank of Cocomorphic Groupoid over SAT Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 07:40 UTC.
Pre-registration hash committed before this test ran: `d747f287d818dd64`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
