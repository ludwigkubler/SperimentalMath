# Replay package — entry be45483362ed

Conjecture: Real Rank of Depth-3 AC⁰ Circuits for PARITY is Ω(log n)

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 16:11 UTC.
Pre-registration hash committed before this test ran: `c38fb9c8874ea133`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
