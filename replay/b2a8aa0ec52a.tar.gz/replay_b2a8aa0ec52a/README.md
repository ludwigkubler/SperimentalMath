# Replay package — entry b2a8aa0ec52a

Conjecture: Minimal Rank of Tropical Motivic Theory and DPLL Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 15:36 UTC.
Pre-registration hash committed before this test ran: `6d455c1ee6a08c0c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
