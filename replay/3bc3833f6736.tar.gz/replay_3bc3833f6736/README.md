# Replay package — entry 3bc3833f6736

Conjecture: Minimal Rank of Quantum Entropy over Frege Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 19:34 UTC.
Pre-registration hash committed before this test ran: `f07d21e1994e7af4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
