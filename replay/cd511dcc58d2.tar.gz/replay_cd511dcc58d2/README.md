# Replay package — entry cd511dcc58d2

Conjecture: Minimal Order of Groupoid Cocycles and DPLL Proof Length Ratio

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 23:40 UTC.
Pre-registration hash committed before this test ran: `b3a7724c0fd5a094`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
