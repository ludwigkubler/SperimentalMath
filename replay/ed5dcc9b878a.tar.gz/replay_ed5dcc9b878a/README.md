# Replay package — entry ed5dcc9b878a

Conjecture: Quadratic Form Rank Inverse Proportional to SOS Refutation Degree for GF(2) Systems

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 19:47 UTC.
Pre-registration hash committed before this test ran: `a94bac2e01bc0904`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
