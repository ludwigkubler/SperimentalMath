# Replay package — entry cf4edcf8020e

Conjecture: Minimal Rank of Tropical Curves over Tropical Curves vs Resolution Proof Size for k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 06:32 UTC.
Pre-registration hash committed before this test ran: `3f09c93914ee474c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
