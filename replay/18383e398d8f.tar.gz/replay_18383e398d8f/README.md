# Replay package — entry 18383e398d8f

Conjecture: Minimal Order of Symplectic Leaves vs. DPLL Search Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 17:54 UTC.
Pre-registration hash committed before this test ran: `e5db230e7cbbb25b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
