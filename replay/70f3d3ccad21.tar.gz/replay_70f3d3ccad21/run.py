import random
import math
from itertools import product

def generate_disj_instance(n):
    return [random.choice([0, 1]) for _ in range(n)]

def monte_carlo_volume(n, samples=100000):
    volume = 0
    for _ in range(samples):
        point = [random.random() for _ in range(n)]
        if all(point[i] + point[j] <= 1 for i, j in product(range(n), repeat=2)):
            volume += 1
    return volume / samples

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n = 40
    instances_tested = 30
    total_volume = 0
    
    for _ in range(instances_tested):
        instance = generate_disj_instance(n)
        volume = monte_carlo_volume(n)
        if volume == 0:
            return {
                "metric_name": "log(V(n))",
                "metric_value": None,
                "instances_tested": instances_tested,
                "conjecture_holds": False,
                "counterexample": "volume_is_zero"
            }
        total_volume += volume
    
    average_volume = total_volume / instances_tested
    communication_complexity = n
    
    if communication_complexity >= math.log(average_volume):
        conjecture_holds = True
        counterexample = ""
    else:
        conjecture_holds = False
        counterexample = f"communication_complexity={communication_complexity}, log(V(n))={math.log(average_volume)}"
    
    return {
        "metric_name": "log(V(n))",
        "metric_value": math.log(average_volume),
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2**i - 1 for i in range(5, 30)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results if r["metric_value"] is not None) / len(results)
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std=0.0 support_fraction=1.0")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std=0.0 support_fraction={support_fraction}")
    else:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{result['counterexample']}\" first_failing_seed={first_failing_seed}")