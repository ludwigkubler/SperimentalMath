# Replay package — entry f2de4e8b6500

Conjecture: Minimal Rank of Affine Representations in Representation Theory × Monotone Circuit Lower Bounds for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 02:00 UTC.
Pre-registration hash committed before this test ran: `dd0be282599b096f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
