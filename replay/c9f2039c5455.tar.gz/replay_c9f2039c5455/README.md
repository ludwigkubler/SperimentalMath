# Replay package — entry c9f2039c5455

Conjecture: Minimal Rank of Quantum discord in Entangled States vs BP_ReadTwice Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 04:50 UTC.
Pre-registration hash committed before this test ran: `0636ebe246888d54`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
