# Replay package — entry f849016d205f

Conjecture: Real Rank of Clause-Indicator Polynomial Bounds ACC^0 Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 20:52 UTC.
Pre-registration hash committed before this test ran: `86917e90072b0a30`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
