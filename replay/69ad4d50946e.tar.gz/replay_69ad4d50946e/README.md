# Replay package — entry 69ad4d50946e

Conjecture: Sandpile-Group Order of Lifted IP Bipartite Graph Bounds Decision Tree Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 07:15 UTC.
Pre-registration hash committed before this test ran: `f90b33c3075b08f3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
