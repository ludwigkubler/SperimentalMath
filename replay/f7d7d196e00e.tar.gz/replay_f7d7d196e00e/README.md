# Replay package — entry f7d7d196e00e

Conjecture: Minimal Rank of Algebraic Curves Bounds Tree-like Resolution Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 20:09 UTC.
Pre-registration hash committed before this test ran: `d0f3b71b0b347daf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
