# Replay package — entry 07a8996922c9

Conjecture: Minimal Order of Quasi-symmetric Designs and Resolution Proof Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 23:33 UTC.
Pre-registration hash committed before this test ran: `ce388821cc05647c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
