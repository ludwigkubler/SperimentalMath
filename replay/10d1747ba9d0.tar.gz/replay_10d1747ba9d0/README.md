# Replay package — entry 10d1747ba9d0

Conjecture: Minimal Brauer Group Order vs Boolean Circuit Threshold for Modular Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 07:05 UTC.
Pre-registration hash committed before this test ran: `735fff73a1d97330`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
