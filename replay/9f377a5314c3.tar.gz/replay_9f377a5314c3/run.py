import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def resolution_width(formula):
        if ' and ' not in formula:
            return 1
        left, right = formula.split(' and ', 1)
        return max(resolution_width(left), resolution_width(right)) + 1
    
    def generate_formula(n):
        if n == 0:
            return random.choice(['True', 'False'])
        else:
            op = random.choice(['and', 'or'])
            left = generate_formula(n - 1)
            right = generate_formula(n - 1)
            return f'({left} {op} {right})'
    
    def tropical_index(formula):
        if formula == 'True':
            return 0
        elif formula == 'False':
            return math.inf
        else:
            left, op, right = formula[1:-2].split(' ')
            if op == 'and':
                return max(tropical_index(left), tropical_index(right))
            elif op == 'or':
                return min(tropical_index(left), tropical_index(right))
    
    n_max = 0
    instances_tested = 0
    total_metric_value = 0.0
    conjecture_holds = True
    counterexample = ""
    
    for n in [5, 10, 15, 20, 30, 40]:
        if n > n_max:
            n_max = n
        
        for _ in range(5):
            formula = generate_formula(n)
            w_phi = resolution_width(formula)
            t_index = tropical_index(formula)
            
            instances_tested += 1
            total_metric_value += abs(t_index - w_phi) / w_phi
            
            if abs(t_index - w_phi) > 0.5 * w_phi:
                conjecture_holds = False
                counterexample = f"Formula: {formula}, T-index: {t_index}, W-phi: {w_phi}"
    
    mean_metric_value = total_metric_value / instances_tested
    
    return {
        "metric_name": "Tropical Index vs Resolution Width Ratio",
        "metric_value": mean_metric_value,
        "instances_tested": instances_tested,
        "n_max": n_max,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    if len(sys.argv) > 1:
        seeds = [int(s) for s in sys.argv[1:]]
    else:
        primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113]
        seeds = random.sample(primes, min(30, len(primes)))
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_metric_value = sum(r["metric_value"] for r in results) / len(results)
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std=0.0 support_fraction=1.0")
    elif sum(1 for r in results if not r["conjecture_holds"]) / len(results) >= 0.8:
        print(f"RESULT: FALSIFIED counterexample=\"{results[next(i for i, r in enumerate(results) if not r['conjecture_holds'])['counterexample']}\") first_failing_seed={seeds[next(i for i, r in enumerate(results) if not r['conjecture_holds'])]}")
    else:
        print(f"RESULT: INCONCLUSIVE support_fraction={support_fraction}")