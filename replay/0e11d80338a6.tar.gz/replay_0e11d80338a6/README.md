# Replay package — entry 0e11d80338a6

Conjecture: Minimal Ehrhart Rank and SAT Clause Depth Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 17:22 UTC.
Pre-registration hash committed before this test ran: `20ffcbadb6ae4d8d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
