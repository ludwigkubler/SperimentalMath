# Replay package — entry 9558054da357

Conjecture: Minimal Rank of Eichler Coefficients vs SAT Proof Count

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 03:46 UTC.
Pre-registration hash committed before this test ran: `6255c8063c4a15ac`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
