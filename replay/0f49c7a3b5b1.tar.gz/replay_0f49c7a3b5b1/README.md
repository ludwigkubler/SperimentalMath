# Replay package — entry 0f49c7a3b5b1

Conjecture: Minimal Geometric Entropy of Graphs and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 16:22 UTC.
Pre-registration hash committed before this test ran: `c012bb9dc3742c31`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
