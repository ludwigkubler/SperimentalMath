# Replay package — entry e5ec85752d00

Conjecture: Minimal Rank of Noncommutative Representations and Circuit Monotone Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 16:30 UTC.
Pre-registration hash committed before this test ran: `fa3fceabf81aac84`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
