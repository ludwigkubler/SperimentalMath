import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def gaussian_elimination(A):
        rows, cols = len(A), len(A[0])
        for i in range(rows):
            max_row = i + A[i:].index(max(abs(row[j]) for row in A[i:], key=lambda x: abs(x[j])) * (1 if j % 2 == 0 else -1)) - i
            A[i], A[max_row] = A[max_row], A[i]
            factor = A[i][j]
            for k in range(cols):
                A[i][k] /= factor
            for l in range(rows):
                if l != i:
                    factor = A[l][j]
                    for m in range(cols):
                        A[l][m] -= factor * A[i][m]
        return A
    
    def construct_K_group(n):
        # Construct a random matrix A of size n x n
        A = [[random.randint(0, 1) for _ in range(n)] for _ in range(n)]
        
        # Perform Gaussian elimination to find the rank
        rank = gaussian_elimination(A)
        
        return rank
    
    def compute_minimal_rank(K_group):
        rank = sum(1 for row in K_group if any(row[j] != 0 for j in range(len(row))))
        return rank
    
    n_values = [5, 10, 15, 20, 30, 40]
    results = []
    
    for n in n_values:
        K_group = construct_K_group(n)
        minimal_rank = compute_minimal_rank(K_group)
        results.append(minimal_rank)
    
    mean_rank = sum(results) / len(results)
    std_dev = math.sqrt(sum((x - mean_rank) ** 2 for x in results) / len(results))
    
    conjecture_holds = all(0.5 * math.log(n) <= rank <= 2 * math.log(n) and rank <= n**2 for n, rank in zip(n_values, results))
    counterexample = "" if conjecture_holds else f"n={n}, rank={rank}"
    
    return {
        "metric_name": "minimal_rank",
        "metric_value": mean_rank,
        "instances_tested": len(results),
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    
    seeds = [int(s) for s in sys.argv[1:]] if sys.argv[1:] else [2**i - 1 for i in range(5, 30)]
    
    results = []
    
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result["metric_value"])
    
    mean_d = sum(results) / len(results)
    std_dev = math.sqrt(sum((x - mean_d) ** 2 for x in results) / len(results))
    support_fraction = sum(1 for r in results if all(0.5 * math.log(n) <= r <= 2 * math.log(n) and r <= n**2 for n, rank in zip(n_values, [r] * len(n_values)))) / len(results)
    
    if support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_d} std={std_dev} support_fraction={support_fraction}")
    elif any(not r <= n**2 for n, r in zip(n_values, results)):
        first_failing_seed = seeds[results.index(next(r for n, r in zip(n_values, results) if not r <= n**2))]
        print(f"RESULT: FALSIFIED counterexample=\"n={n}, rank={r}\" first_failing_seed={first_failing_seed}")
    else:
        print(f"RESULT: INCONCLUSIVE reason=insufficient_support_fraction support_fraction={support_fraction}")