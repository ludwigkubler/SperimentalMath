# Replay package — entry f5fad29c0f85

Conjecture: Additive Energy Threshold Excludes ACC⁰ Circuits for Sipser Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 05:29 UTC.
Pre-registration hash committed before this test ran: `7ef3e2f587077165`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
