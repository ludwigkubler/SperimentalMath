# Replay package — entry bdccddeb6c38

Conjecture: Minimal Rank of Macdonald Polynomials Bounds Exponential Time Hypothesis for Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 07:37 UTC.
Pre-registration hash committed before this test ran: `cd564af87fc7e478`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
