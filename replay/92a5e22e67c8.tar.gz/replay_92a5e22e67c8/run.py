import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    # Generate a random symmetric space S with known cohomology ring
    n = random.randint(5, 40)
    H = {i: random.randint(1, n) for i in range(n)}
    
    # Compute the minimal rank of the Hodge decomposition
    rank = sum(H.values())
    
    # Find a monotone circuit that computes k-CLIQUE on a complete graph with n vertices
    k = random.randint(2, min(n - 1, 5))
    circuit_size = (n choose k) + k
    
    return {
        "metric_name": "Minimal Rank(H^*(S))",
        "metric_value": rank,
        "instances_tested": 1,
        "conjecture_holds": rank >= 1.5 * median(rank) and circuit_size >= 1.5 * median(circuit_size),
        "counterexample": ""
    }

def median(lst):
    n = len(lst)
    sorted_lst = sorted(lst)
    if n % 2 == 0:
        return (sorted_lst[n // 2 - 1] + sorted_lst[n // 2]) / 2
    else:
        return sorted_lst[n // 2]

if __name__ == "__main__":
    seeds = [int(arg) for arg in sys.argv[1:]] or [random.randint(1, 1000) for _ in range(30)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    rank_values = [r["metric_value"] for r in results if r["conjecture_holds"]]
    circuit_size_values = [r["metric_value"] for r in results if r["conjecture_holds"]]
    
    if len(rank_values) == 0 or len(circuit_size_values) == 0:
        print("RESULT: INCONCLUSIVE insufficient_data")
    else:
        rank_mean = sum(rank_values) / len(rank_values)
        circuit_size_mean = sum(circuit_size_values) / len(circuit_size_values)
        
        if rank_mean >= 1.5 * median(rank_values) and circuit_size_mean >= 1.5 * median(circuit_size_values):
            print(f"RESULT: SUPPORTED mean={rank_mean} std={math.sqrt(sum((x - rank_mean) ** 2 for x in rank_values) / len(rank_values))} support_fraction=1")
        else:
            print("RESULT: FALSIFIED counterexample=\"median_condition_not_met\" first_failing_seed=<s>")