# Replay package — entry 380021e4eaf7

Conjecture: Minimal Rank of Grothendieck-Suslin Classes over Boolean Formulae with Fixed Tree-width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 00:32 UTC.
Pre-registration hash committed before this test ran: `488fd2abe7cf85d1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
