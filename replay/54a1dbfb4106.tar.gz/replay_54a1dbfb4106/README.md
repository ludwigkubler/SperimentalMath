# Replay package — entry 54a1dbfb4106

Conjecture: Polarized Hodge Structures on k-CLIQUE Instances Bound Resolution Proofs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 18:50 UTC.
Pre-registration hash committed before this test ran: `0fc3c0478240cbe0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
