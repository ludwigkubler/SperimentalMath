# Replay package — entry f85f16ebd8a3

Conjecture: Minimal Symplectic Form Rank and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 20:02 UTC.
Pre-registration hash committed before this test ran: `ad7389d4f0f886d2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
