# Replay package — entry 97faaad75eed

Conjecture: Minimal Rank of Tropical Curves Bounds AC⁰ Parity Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 12:48 UTC.
Pre-registration hash committed before this test ran: `32298fe48bd13a57`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
