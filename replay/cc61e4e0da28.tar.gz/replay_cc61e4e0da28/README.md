# Replay package — entry cc61e4e0da28

Conjecture: Plethysm Coefficient Gap in Homogeneous Polynomial Decompositions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 03:39 UTC.
Pre-registration hash committed before this test ran: `6750a6ab650657c3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
