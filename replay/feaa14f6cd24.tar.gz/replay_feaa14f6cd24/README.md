# Replay package — entry feaa14f6cd24

Conjecture: Minimal Rank of Tropicalized Dihedral Groups vs AC0 Circuit Weights

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 08:58 UTC.
Pre-registration hash committed before this test ran: `b019b711fc4276e1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
