# Replay package — entry 4ece9dd54998

Conjecture: Minimal Index of Lie Algebra Representations and DPLL Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 15:16 UTC.
Pre-registration hash committed before this test ran: `229ae2f9813cdb16`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
