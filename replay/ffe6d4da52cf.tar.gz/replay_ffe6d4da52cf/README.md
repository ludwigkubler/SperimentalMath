# Replay package — entry ffe6d4da52cf

Conjecture: Prime Density in Arithmetic Progressions and Seed Length of Nisan-Wigderson PRGs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 07:37 UTC.
Pre-registration hash committed before this test ran: `fa9739ba909bd214`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
