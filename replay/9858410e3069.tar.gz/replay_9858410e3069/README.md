# Replay package — entry 9858410e3069

Conjecture: Free Entropy Gap in Read-Twice BP Transition Matrices

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 04:50 UTC.
Pre-registration hash committed before this test ran: `42134c6568a89445`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
