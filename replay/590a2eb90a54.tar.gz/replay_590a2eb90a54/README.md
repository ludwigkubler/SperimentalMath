# Replay package — entry 590a2eb90a54

Conjecture: Minimal Number of Braided Monoidal Categories and Resolution Proof Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 08:12 UTC.
Pre-registration hash committed before this test ran: `ae9a14edb9d13b0f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
