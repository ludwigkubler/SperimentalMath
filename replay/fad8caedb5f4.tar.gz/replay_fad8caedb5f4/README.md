# Replay package — entry fad8caedb5f4

Conjecture: Minimal Number of Simplicial Generators for Boolean Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 22:26 UTC.
Pre-registration hash committed before this test ran: `1f20bf1b1bbc35dc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
