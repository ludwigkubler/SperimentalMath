# Replay package — entry f61b226b5cec

Conjecture: Free Cumulant Sum Lower Bounded by Communication Complexity of DISJOINTNESS

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-13 08:49 UTC.
Pre-registration hash committed before this test ran: `273d2b255da54282`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
