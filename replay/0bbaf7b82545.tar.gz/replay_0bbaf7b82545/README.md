# Replay package — entry 0bbaf7b82545

Conjecture: Minimal Rank of Kähler Curvature Forms vs AC0 Parity Circuit Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 08:07 UTC.
Pre-registration hash committed before this test ran: `692c0a652383a50d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
