# Replay package — entry 5abd13d9b3b5

Conjecture: Matroid Rank and Extended Frege Proof Size for Tautologies

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 08:19 UTC.
Pre-registration hash committed before this test ran: `a6e0604811bc52b1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
