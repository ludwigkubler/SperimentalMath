# Replay package — entry 7593b5483592

Conjecture: Minimal Index of Algebraic Stacks over Boolean Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 12:39 UTC.
Pre-registration hash committed before this test ran: `b6f4f87584f4d4cc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
