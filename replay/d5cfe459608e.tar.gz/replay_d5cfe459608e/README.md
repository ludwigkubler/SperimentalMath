# Replay package — entry d5cfe459608e

Conjecture: Minimal Order of Non-Abelian Automorphism Groups and Communication Complexity Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 09:30 UTC.
Pre-registration hash committed before this test ran: `9713d213dfa2c2d1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
