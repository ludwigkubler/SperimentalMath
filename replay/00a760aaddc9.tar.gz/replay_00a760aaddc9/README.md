# Replay package — entry 00a760aaddc9

Conjecture: Minimal Representation Rank of Quivers and SAT Clause Subset Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 09:07 UTC.
Pre-registration hash committed before this test ran: `be56d9279cc4727a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
