# Replay package — entry a56d096468e6

Conjecture: Minimal Root Separation of Matrix pencils and BP_ReadTwice Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 15:35 UTC.
Pre-registration hash committed before this test ran: `9f99a1fbd063685a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
