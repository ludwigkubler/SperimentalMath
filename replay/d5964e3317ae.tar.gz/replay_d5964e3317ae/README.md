# Replay package — entry d5964e3317ae

Conjecture: Minimal Local System Rank Correlation with Resolution Proof Width via Symplectic Geometry

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 01:21 UTC.
Pre-registration hash committed before this test ran: `8bd2c99f678b45ae`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
