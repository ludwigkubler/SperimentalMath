# Replay package — entry 7e47a7fc5f53

Conjecture: Minimal Order of Affine Plane Curve Intersection Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 04:55 UTC.
Pre-registration hash committed before this test ran: `066f350f2ddf4aaf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
