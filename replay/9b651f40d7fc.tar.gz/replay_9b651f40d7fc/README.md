# Replay package — entry 9b651f40d7fc

Conjecture: Schur Coefficient Exponential Gap in Symmetric Squares of Permutation Representations for Random CNFs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 06:41 UTC.
Pre-registration hash committed before this test ran: `5d58422078dd9b87`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
