# Replay package — entry b2e399685d5e

Conjecture: Minimal Rank of Twisted Poincaré Duality Groups Bounds DPLL Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 03:58 UTC.
Pre-registration hash committed before this test ran: `cd8fd4f4bf7d2365`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
