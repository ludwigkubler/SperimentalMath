# Replay package — entry 939c9435791b

Conjecture: Minimal Symmetric Tensor Norm and AC0 Parity Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 00:43 UTC.
Pre-registration hash committed before this test ran: `ca8d97a0d5cf1b94`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
