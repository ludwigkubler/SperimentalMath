# Replay package — entry 4552a9ccc679

Conjecture: Minimal Hodge Weight of Differential Forms and Circuit Depth Lower Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 13:39 UTC.
Pre-registration hash committed before this test ran: `9aa0f082e99db199`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
