# Replay package — entry 708bb68681ed

Conjecture: Quantum Deformation of Boolean Circuit Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 20:03 UTC.
Pre-registration hash committed before this test ran: `a2d485302d95767c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
