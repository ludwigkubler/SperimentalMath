# Replay package — entry 6a7b621fe48d

Conjecture: Minimal Rank of Schur-Weyl Duality in Matrix Factorizations vs Determinant Circuit Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 00:58 UTC.
Pre-registration hash committed before this test ran: `826bbfe5aa2886d6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
