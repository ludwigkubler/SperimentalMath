# Replay package — entry ca450fbce567

Conjecture: Algebraic Topology Invariants and Boolean Circuit Monotonicity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 00:23 UTC.
Pre-registration hash committed before this test ran: `2ceaa1e8f3aa1434`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
