# Replay package — entry e0a281e76e21

Conjecture: Minimal Frobenius-Schur Indicator and Boolean Circuit Entropy Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 08:53 UTC.
Pre-registration hash committed before this test ran: `b894dd72d4576a20`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
