# Replay package — entry 0cd4474a55dc

Conjecture: Minimal Rank of Tropicalized Brauer Groups over DPLL Search Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 12:22 UTC.
Pre-registration hash committed before this test ran: `58f818df1bdb1373`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
