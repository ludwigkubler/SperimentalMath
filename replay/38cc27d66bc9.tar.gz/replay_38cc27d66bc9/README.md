# Replay package — entry 38cc27d66bc9

Conjecture: Minimal Order of Tropical Monomial Ideals and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 08:22 UTC.
Pre-registration hash committed before this test ran: `c5e4846886f2949f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
