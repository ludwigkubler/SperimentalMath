# Replay package — entry b6a5c0845f16

Conjecture: Minimal Symplectic Volume of Affine Varieties and Resolution Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 02:05 UTC.
Pre-registration hash committed before this test ran: `bf51594478a1b995`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
