# Replay package — entry d220fd2b61a8

Conjecture: Minimal Quadratic Residue Representation Correlation with Frege Proof Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 04:18 UTC.
Pre-registration hash committed before this test ran: `5fcaeff75251ef8f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
