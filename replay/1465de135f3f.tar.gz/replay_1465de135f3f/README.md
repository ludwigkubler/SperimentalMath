# Replay package — entry 1465de135f3f

Conjecture: Minimal Rank of Noncrossed Product K-Theory Bounds DPLL Tree Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 00:51 UTC.
Pre-registration hash committed before this test ran: `fc26c1bb8922a1c3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
