# Replay package — entry b782e0cb2c69

Conjecture: Betti Number Sum Lower Bound for SOS Max-CUT Degree

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 08:33 UTC.
Pre-registration hash committed before this test ran: `58d07240164e3995`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
