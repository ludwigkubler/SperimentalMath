# Replay package — entry 2905aa033f8a

Conjecture: Fundamental Group Rank Inverse Proportional to Resolution Proof Size for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 05:05 UTC.
Pre-registration hash committed before this test ran: `8f9a3369884e2ec8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
