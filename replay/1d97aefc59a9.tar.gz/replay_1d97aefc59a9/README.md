# Replay package — entry 1d97aefc59a9

Conjecture: Minimal Lattice Point Coverage in Integer Programming and DPLL Search Tree Diameter

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 22:49 UTC.
Pre-registration hash committed before this test ran: `019a377735162951`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
