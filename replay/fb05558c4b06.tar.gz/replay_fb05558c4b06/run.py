import random
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def gromov_wasserstein_distance(X, Y):
        n = len(X)
        D = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(i + 1, n):
                d_ij = sum((X[i][k] - X[j][k]) ** 2 for k in range(len(X[i]))) ** 0.5
                D[i][j] = D[j][i] = d_ij
        return D

    def communication_complexity_rank(D):
        n = len(D)
        rank = 0
        for i in range(n):
            for j in range(i + 1, n):
                if D[i][j] > 0:
                    rank += 1
        return rank
    
    def min_order(X):
        D = gromov_wasserstein_distance(X, X)
        return sum(D[i][j] for i in range(len(D)) for j in range(i + 1, len(D))) / (len(D) * (len(D) - 1))
    
    n = random.randint(5, 30)
    X = [[random.random() for _ in range(n)] for _ in range(n)]
    min_order_X = min_order(X)
    rank_X = communication_complexity_rank(gromov_wasserstein_distance(X, X))
    
    return {
        "metric_name": "min_order",
        "metric_value": min_order_X,
        "instances_tested": 1,
        "n_max": n,
        "conjecture_holds": abs(min_order_X - rank_X) <= 3,
        "counterexample": ""
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] if len(sys.argv) > 1 else [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    results = []
    
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {{\"seed\": {seed}, \"metric_name\": \"{result['metric_name']}\", \"metric_value\": {result['metric_value']}, \"instances_tested\": {result['instances_tested']}, \"n_max\": {result['n_max']}, \"conjecture_holds\": {result['conjecture_holds']}, \"counterexample\": \"{result['counterexample']}\"}}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = (sum((r["metric_value"] - mean_value) ** 2 for r in results) / len(results)) ** 0.5
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results) and support_fraction >= 0.8:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE insufficient evidence")