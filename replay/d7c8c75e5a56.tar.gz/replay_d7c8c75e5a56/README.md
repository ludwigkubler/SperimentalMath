# Replay package — entry d7c8c75e5a56

Conjecture: Minimal Rank of Noncommutative Polynomial Representations and SAT Clause Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 11:28 UTC.
Pre-registration hash committed before this test ran: `a953eb7b1db30889`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
