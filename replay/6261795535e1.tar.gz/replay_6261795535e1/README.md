# Replay package — entry 6261795535e1

Conjecture: Minimal Hodge Decomposition Dimension and Communication Complexity Rank

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 16:18 UTC.
Pre-registration hash committed before this test ran: `b0c4b99d86a6fe0b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
