# Replay package — entry d6e65f983582

Conjecture: Hypergeometric Function Moments Bound ACC Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 12:16 UTC.
Pre-registration hash committed before this test ran: `bacd0145be6a3215`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
