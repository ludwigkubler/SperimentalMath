# Replay package — entry 3a07d26e01c1

Conjecture: Minimal Rank of plethysm coefficients in the symmetric group representation vs permutation circuit threshold

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 14:57 UTC.
Pre-registration hash committed before this test ran: `c9f9ad46074118b0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
