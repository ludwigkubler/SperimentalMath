# Replay package — entry f9268bf85309

Conjecture: Slice Rank of Layer-Variable Tensor Lower-Bounds Read-Twice BP Size for IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 01:14 UTC.
Pre-registration hash committed before this test ran: `a86eb3994d9fa519`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
