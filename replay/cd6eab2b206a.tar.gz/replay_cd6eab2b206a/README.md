# Replay package — entry cd6eab2b206a

Conjecture: Hook-Length Weighted Stability Ratio in Plethysm Coefficients vs Monotone Permanent vs Determinant Separation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 17:40 UTC.
Pre-registration hash committed before this test ran: `7565c8e460e8c416`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
