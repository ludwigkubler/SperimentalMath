# Replay package — entry 031bb9df960f

Conjecture: Hilbert Cube Diameter Invariant for Tree-like Resolution Proof Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 08:31 UTC.
Pre-registration hash committed before this test ran: `2d19d01dfd847f10`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
