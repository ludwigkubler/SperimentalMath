# Replay package — entry 55152203cbbd

Conjecture: Minimal Local Index of Etale Cohomology Bounds SAT Clause Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 13:45 UTC.
Pre-registration hash committed before this test ran: `2c120143a8b1675b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
