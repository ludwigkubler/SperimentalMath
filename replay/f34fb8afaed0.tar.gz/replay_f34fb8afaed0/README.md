# Replay package — entry f34fb8afaed0

Conjecture: Minimal Order of Groupoid Automorphism Groups and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 03:32 UTC.
Pre-registration hash committed before this test ran: `dd78838a5e86445d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
