# Replay package — entry c2da2c902c14

Conjecture: Kronecker Coefficient Asymmetry in Symmetric Tensor Decompositions for Permanent vs Determinant

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-07 22:58 UTC.
Pre-registration hash committed before this test ran: `5c702ef57a6b683c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
