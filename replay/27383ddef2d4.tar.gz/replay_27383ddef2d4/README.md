# Replay package — entry 27383ddef2d4

Conjecture: Minimal p-Adic Order of Boolean Functions and AC0 Circuit Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 23:27 UTC.
Pre-registration hash committed before this test ran: `fcacc3024582b686`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
