# Replay package — entry eb40b656e3e8

Conjecture: Minimal Index of Geometric Langlands Duals and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 05:31 UTC.
Pre-registration hash committed before this test ran: `b3d7ed341f34808b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
