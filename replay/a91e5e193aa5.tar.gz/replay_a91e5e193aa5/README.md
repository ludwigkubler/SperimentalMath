# Replay package — entry a91e5e193aa5

Conjecture: Minimal Hodge Decomposition Rank vs. DPLL Proof Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 08:45 UTC.
Pre-registration hash committed before this test ran: `2f030374c5060dd9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
