# Replay package — entry 1620c2565d7f

Conjecture: Symmetric Group Character Eigenvalue Lower Bound on SOS Refutation Degree

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 06:00 UTC.
Pre-registration hash committed before this test ran: `63cd00e2ffb57043`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
