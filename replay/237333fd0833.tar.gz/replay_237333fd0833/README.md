# Replay package — entry 237333fd0833

Conjecture: Tropical Geometric Langlands Duality and AC0 Circuit Size for XOR Tautologies

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 11:57 UTC.
Pre-registration hash committed before this test ran: `321e5cc977b3c3f1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
