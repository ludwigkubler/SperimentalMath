# Replay package — entry 36ff10223572

Conjecture: Minimal Rank of Toric Varieties over Boolean Functions vs Monotone Circuit Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 10:04 UTC.
Pre-registration hash committed before this test ran: `dd782e290eb64c20`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
