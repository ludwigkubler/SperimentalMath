# Replay package — entry b8db94f3d548

Conjecture: Minimal Rank of Geometric Langlands Duality Modules over Function Fields vs Tseitin Formula Resolution Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 16:58 UTC.
Pre-registration hash committed before this test ran: `30599738bab633e1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
