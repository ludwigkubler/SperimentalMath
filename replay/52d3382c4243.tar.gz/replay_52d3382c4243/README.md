# Replay package — entry 52d3382c4243

Conjecture: Walsh-Code Antichain Width of NW Designs Bounds PRG Linear Bias

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 14:54 UTC.
Pre-registration hash committed before this test ran: `3b9035fd14022b58`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
