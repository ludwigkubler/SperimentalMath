# Replay package — entry ddfbed2a2c60

Conjecture: Minimal Order of Formal Groups and Communication Complexity Rank Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 05:38 UTC.
Pre-registration hash committed before this test ran: `a052a258a8f2838b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
