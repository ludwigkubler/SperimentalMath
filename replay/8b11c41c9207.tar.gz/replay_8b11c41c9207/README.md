# Replay package — entry 8b11c41c9207

Conjecture: Dual Code Distance Lower Bound for Tseitin Refutations

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-29 03:54 UTC.
Pre-registration hash committed before this test ran: `a56c2ca7d88dcb00`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
