# Replay package — entry 5ea7fdc16e4d

Conjecture: Minimal Rank of Free Entropy over Graphs vs Distinguishing Tensor Width for BP_ReadTwice

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 06:58 UTC.
Pre-registration hash committed before this test ran: `eb1616d953638854`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
