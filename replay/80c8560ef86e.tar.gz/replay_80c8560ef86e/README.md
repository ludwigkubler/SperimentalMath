# Replay package — entry 80c8560ef86e

Conjecture: Real Rank of Coefficient Matrices for AC⁰ PARITY Circuits

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 06:41 UTC.
Pre-registration hash committed before this test ran: `132f8bda10b5e4df`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
