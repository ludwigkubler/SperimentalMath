# Replay package — entry b0db61a19b33

Conjecture: Minimal Rank of Tropicalized Quandle Representations over Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 09:23 UTC.
Pre-registration hash committed before this test ran: `4512f58980aa1f88`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
