# Replay package — entry 40591186a3ea

Conjecture: Plethysm Coefficient Gap in Permanent vs Determinant Decompositions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 01:34 UTC.
Pre-registration hash committed before this test ran: `c495be0631aa1f56`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
