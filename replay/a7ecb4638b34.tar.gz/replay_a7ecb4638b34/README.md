# Replay package — entry a7ecb4638b34

Conjecture: Grothendieck-Teichmüller Group Action Count and MCSP Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 14:07 UTC.
Pre-registration hash committed before this test ran: `d3b1d6d1533266d9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
