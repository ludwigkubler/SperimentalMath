# Replay package — entry 07adb7ccfd88

Conjecture: Minimal Geometric Entanglement and SAT Clause Set Complexity Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 07:33 UTC.
Pre-registration hash committed before this test ran: `798360d4cf7b6c76`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
