# Replay package — entry 499b999bfe8f

Conjecture: Minimal Coherence Length of Braided Categories and SAT Clause Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 11:22 UTC.
Pre-registration hash committed before this test ran: `b2c1784487286dd1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
