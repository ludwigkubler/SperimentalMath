# Replay package — entry ee97068481df

Conjecture: Toric Variety Degree Inverse to SOS Refutation Degree for 3-SAT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-13 04:58 UTC.
Pre-registration hash committed before this test ran: `17379fd5d036f555`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
