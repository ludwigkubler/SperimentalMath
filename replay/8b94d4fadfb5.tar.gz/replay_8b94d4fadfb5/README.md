# Replay package — entry 8b94d4fadfb5

Conjecture: Minimal Rank of Tropicalized Divisors over Planar Curves vs BP_ReadTwice Tensor Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 07:49 UTC.
Pre-registration hash committed before this test ran: `ab8be782be0379e3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
