import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_ac0_parity_circuit(n):
        return [random.choice([0, 1]) for _ in range(2**n)]
    
    def compute_noncommutative_differential_form(circuit):
        # Placeholder function to simulate computation
        return sum(circuit) % 2
    
    n = random.randint(5, 40)
    circuit = generate_ac0_parity_circuit(n)
    rank = compute_noncommutative_differential_form(circuit)
    
    c = 1
    if rank < c * math.log(n):
        return {
            "metric_name": "Minimal Rank of Noncommutative Differential Form",
            "metric_value": rank,
            "instances_tested": 1,
            "conjecture_holds": False,
            "counterexample": f"c={c} too small"
        }
    else:
        return {
            "metric_name": "Minimal Rank of Noncommutative Differential Form",
            "metric_value": rank,
            "instances_tested": 1,
            "conjecture_holds": True,
            "counterexample": ""
        }

if __name__ == "__main__":
    seeds = [int(arg) for arg in sys.argv[1:]] or [random.getrandbits(32) for _ in range(30)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value)**2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next((r["seed"] for r in results if not r["conjecture_holds"]), None)
        print(f"RESULT: FALSIFIED counterexample=\"c too small\" first_failing_seed={first_failing_seed}")