# Replay package — entry cc2d7e2bed97

Conjecture: Free Cumulant Gap in Read-Twice BPs for IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 19:40 UTC.
Pre-registration hash committed before this test ran: `cad22781e79aec85`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
