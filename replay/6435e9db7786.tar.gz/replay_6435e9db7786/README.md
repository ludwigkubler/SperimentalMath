# Replay package — entry 6435e9db7786

Conjecture: Hypergeometric Function Moments and Communication Complexity of XOR

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 17:42 UTC.
Pre-registration hash committed before this test ran: `53fa201c34013d23`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
