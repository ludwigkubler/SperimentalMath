# Replay package — entry c4e28e9508f6

Conjecture: Halton Star-Discrepancy of Clause-Sign Embedding Bounds DPLL Leaves

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 03:49 UTC.
Pre-registration hash committed before this test ran: `fb449892ce6181e0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
