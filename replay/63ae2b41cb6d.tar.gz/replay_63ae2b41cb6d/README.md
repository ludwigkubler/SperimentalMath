# Replay package — entry 63ae2b41cb6d

Conjecture: Real Stable Polynomial Root Count Separation for Monotone DNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 21:12 UTC.
Pre-registration hash committed before this test ran: `a6926cdd45a35b67`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
