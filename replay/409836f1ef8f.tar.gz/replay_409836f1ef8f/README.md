# Replay package — entry 409836f1ef8f

Conjecture: Minimal Order of Quadratic Forms and DPLL Search Tree Diameter Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 17:06 UTC.
Pre-registration hash committed before this test ran: `aeabcedebde7531b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
