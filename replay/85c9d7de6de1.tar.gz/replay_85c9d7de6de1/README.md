# Replay package — entry 85c9d7de6de1

Conjecture: Minimal Geometric Entropy Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 04:55 UTC.
Pre-registration hash committed before this test ran: `b5ccf9e3f3c961f1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
