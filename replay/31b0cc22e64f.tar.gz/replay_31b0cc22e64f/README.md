# Replay package — entry 31b0cc22e64f

Conjecture: Minimal Local Index of Hodge Decomposition vs ACC⁰ Circuit Lower Bound Proven by Sipser Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 17:14 UTC.
Pre-registration hash committed before this test ran: `239bd234d567aa73`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
