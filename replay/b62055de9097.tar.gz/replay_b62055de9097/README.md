# Replay package — entry b62055de9097

Conjecture: Minimal Rank of Tensor Product Coefficients over Boolean Functions vs DPLL Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 22:23 UTC.
Pre-registration hash committed before this test ran: `573274207f41bec2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
