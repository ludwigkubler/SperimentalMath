# Replay package — entry 83786f5593a2

Conjecture: Minimal Rank of Group Representations over Boolean Functions vs Boolean Function Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 14:15 UTC.
Pre-registration hash committed before this test ran: `910935ad7aa1c296`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
