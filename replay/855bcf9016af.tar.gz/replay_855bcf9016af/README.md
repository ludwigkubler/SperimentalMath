# Replay package — entry 855bcf9016af

Conjecture: Minimal Rank of Monomial Ideals over Graph Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 09:33 UTC.
Pre-registration hash committed before this test ran: `c40086798c6973af`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
