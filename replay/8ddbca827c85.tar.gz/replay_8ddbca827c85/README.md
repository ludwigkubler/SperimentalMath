# Replay package — entry 8ddbca827c85

Conjecture: Network Reliability Deficit Lower-Bounds Tseitin Resolution

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 08:22 UTC.
Pre-registration hash committed before this test ran: `e13b39df5938e5b5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
