# Replay package — entry 2243c6c24ab3

Conjecture: Lyndon Factor Count Separates MOD_3 from Depth-2 ACC^0[2]

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 10:31 UTC.
Pre-registration hash committed before this test ran: `61494d3b9bd642da`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
