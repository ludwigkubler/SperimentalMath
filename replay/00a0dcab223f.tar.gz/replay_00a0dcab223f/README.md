# Replay package — entry 00a0dcab223f

Conjecture: Minimal Rank of Hodge Decomposition Bounds Resolution Refutation Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 15:28 UTC.
Pre-registration hash committed before this test ran: `9ee1ad2bc3ce3ad1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
