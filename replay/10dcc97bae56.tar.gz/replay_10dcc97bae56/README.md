# Replay package — entry 10dcc97bae56

Conjecture: Algebraic K-Theory Rank and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 08:58 UTC.
Pre-registration hash committed before this test ran: `94f366dcb059cc2e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
