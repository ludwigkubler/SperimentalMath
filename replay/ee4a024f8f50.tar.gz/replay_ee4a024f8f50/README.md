# Replay package — entry ee4a024f8f50

Conjecture: Minimal Generators of Tropical Curves in Tseitin Formulas Bound Proof Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 12:11 UTC.
Pre-registration hash committed before this test ran: `bc15da60807eb608`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
