# Replay package — entry 6d8543b7feed

Conjecture: Minimal Rank of Symplectic Matrices Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 12:36 UTC.
Pre-registration hash committed before this test ran: `26ae3b6197908a8a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
