# Replay package — entry aba72d8e95aa

Conjecture: Dimension of Variety from Tautology Ideal Bounds EF Proof Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 00:39 UTC.
Pre-registration hash committed before this test ran: `023f635035cc7ea1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
