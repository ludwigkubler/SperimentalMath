# Replay package — entry 1229a848f3d3

Conjecture: Minimal Rank of Tropicalized p-Adic Differentials vs ACC⁰ Function Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 02:37 UTC.
Pre-registration hash committed before this test ran: `d62c035e32903196`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
