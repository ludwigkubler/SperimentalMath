# Replay package — entry 7e57991f294f

Conjecture: Tropical Circuit Weight Profile Complexity Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 16:36 UTC.
Pre-registration hash committed before this test ran: `be25527ee8dc6ab4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
