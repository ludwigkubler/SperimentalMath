import random
import math
from fractions import Fraction
from itertools import combinations

def generate_circuit(n):
    circuit = []
    for i in range(n):
        gate_type = random.choice(['AND', 'OR'])
        inputs = sorted(random.sample(range(i), random.randint(1, i)))
        circuit.append((gate_type, inputs))
    return circuit

def monotone_width(circuit):
    n = len(circuit)
    if n == 0:
        return 0
    max_width = 0
    for i in range(n):
        width = 0
        for j in range(i + 1, n):
            if all(circuit[j][1][k] <= circuit[i][1][k] for k in range(len(circuit[i][1]))):
                width += 1
        max_width = max(max_width, width)
    return max_width

def minimal_local_indeterminacy(circuit):
    n = len(circuit)
    if n == 0:
        return 0
    indeterminacy = 0
    for i in range(n):
        for j in range(i + 1, n):
            if circuit[j][1].issubset(circuit[i][1]):
                indeterminacy += 1
    return indeterminacy

def run_trial(seed: int) -> dict:
    random.seed(seed)
    results = []
    for _ in range(30):  # Ensure at least 30 instances per seed
        n = random.choice([5, 10, 15, 20, 30, 40])
        circuit = generate_circuit(n)
        w_mon = monotone_width(circuit)
        lind = minimal_local_indeterminacy(circuit)
        results.append((w_mon, lind))
    if not results:
        return {
            "metric_name": "correlation_coefficient",
            "metric_value": None,
            "instances_tested": 0,
            "n_max": 0,
            "conjecture_holds": False,
            "counterexample": "mapping_undefined"
        }
    w_m = [w for w, _ in results]
    l_r = [l for _, l in results]
    n_max = max(n for _, _ in results)
    correlation_coefficient = sum((w - (sum(w_m) / len(w_m))) * (l - (sum(l_r) / len(l_r))) for w, l in results) / (len(results) * math.sqrt(sum((w - (sum(w_m) / len(w_m))) ** 2 for w in w_m)) * sum((l - (sum(l_r) / len(l_r))) ** 2 for l in l_r)))
    mean_lind = sum(l_r) / len(l_r)
    conjecture_holds = correlation_coefficient >= 0.8 and abs(mean_lind / (sum(w_m) / len(w_m)) - 1) <= 0.5
    return {
        "metric_name": "correlation_coefficient",
        "metric_value": correlation_coefficient,
        "instances_tested": len(results),
        "n_max": n_max,
        "conjecture_holds": conjecture_holds,
        "counterexample": "" if conjecture_holds else "not_enough_data"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113]
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    if all(r["conjecture_holds"] for r in results):
        mean_value = sum(r["metric_value"] for r in results) / len(results)
        std_value = math.sqrt(sum((r["metric_value"] - mean_value) ** 2 for r in results) / len(results))
        support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample='not_enough_data' first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE insufficient_data")