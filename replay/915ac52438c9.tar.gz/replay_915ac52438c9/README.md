# Replay package — entry 915ac52438c9

Conjecture: Minimal Degree of Hodge Filters Bounds Approximation Ratio for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 15:11 UTC.
Pre-registration hash committed before this test ran: `a6171cf1dd257a0c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
