# Replay package — entry 1ff40078e7c7

Conjecture: Minimal Hodge Module Rank and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 11:39 UTC.
Pre-registration hash committed before this test ran: `5cb9061d83ba3902`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
