# Replay package — entry e8d775b04736

Conjecture: Minimal Rank of Quantum Entropy over XOR-AND Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 22:08 UTC.
Pre-registration hash committed before this test ran: `a67bebad73542b31`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
