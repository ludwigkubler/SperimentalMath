# Replay package — entry e4ade026c001

Conjecture: Hodge Decomposition and Resolution Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 19:27 UTC.
Pre-registration hash committed before this test ran: `1508f085be8576cc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
