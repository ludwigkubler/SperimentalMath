# Replay package — entry 6d2c2dd0519a

Conjecture: Minimal Rank of Quadratic Reciprocity over Tseitin Resolution Trees Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 06:40 UTC.
Pre-registration hash committed before this test ran: `8d72b8395a8fd5a8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
