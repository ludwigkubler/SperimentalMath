# Replay package — entry 432931f4b53b

Conjecture: Minimal Rank of Quasi-Plurality Matrices vs SAT Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 09:52 UTC.
Pre-registration hash committed before this test ran: `672d5246214443ca`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
