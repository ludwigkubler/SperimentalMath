# Replay package — entry bbbb59358a8f

Conjecture: Minimal Rank of Motivic Integration over XOR-AND Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 05:20 UTC.
Pre-registration hash committed before this test ran: `5a9628eb1148aba9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
