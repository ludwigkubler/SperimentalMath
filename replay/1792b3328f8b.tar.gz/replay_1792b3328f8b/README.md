# Replay package — entry 1792b3328f8b

Conjecture: Tropical Representation Rank of Boolean Functions Bounds AC⁰ Parity Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 02:56 UTC.
Pre-registration hash committed before this test ran: `57ae43ec015a43bd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
