# Replay package — entry 6fe510ed8267

Conjecture: Minimal Rank of Quadratic Forms over Noncommutative Algebras vs BP_ReadTwice Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 16:28 UTC.
Pre-registration hash committed before this test ran: `bffba1b6f9a01dd1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
