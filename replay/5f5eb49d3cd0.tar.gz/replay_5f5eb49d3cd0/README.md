# Replay package — entry 5f5eb49d3cd0

Conjecture: Minimal Rank of Betti Numbers in Knot Theory vs DPLL Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 22:00 UTC.
Pre-registration hash committed before this test ran: `59e6f330cd7b03d1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
