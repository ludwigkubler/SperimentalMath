# Replay package — entry b01f827fc041

Conjecture: Width-Bounded Module Dimension in Barrington's Branching Programs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-30 07:49 UTC.
Pre-registration hash committed before this test ran: `81aaf7a0978a6e32`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
