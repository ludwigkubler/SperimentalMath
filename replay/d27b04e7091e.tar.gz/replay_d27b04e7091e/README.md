# Replay package — entry d27b04e7091e

Conjecture: Symmetric Power Rank Gap in Permanent vs Determinant Polynomials

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 05:35 UTC.
Pre-registration hash committed before this test ran: `dfa9735e1a8b3c42`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
