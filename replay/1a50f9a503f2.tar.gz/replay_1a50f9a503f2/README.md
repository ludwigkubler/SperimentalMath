# Replay package — entry 1a50f9a503f2

Conjecture: Minimal Order of Representation Theory over SAT Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 12:47 UTC.
Pre-registration hash committed before this test ran: `24e68273cf48d386`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
