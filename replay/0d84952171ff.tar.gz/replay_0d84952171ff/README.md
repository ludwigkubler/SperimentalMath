# Replay package — entry 0d84952171ff

Conjecture: Minimal Rank of Noncommutative Differential Geometry over Boolean Algebras vs Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 04:36 UTC.
Pre-registration hash committed before this test ran: `efc40e62928900a8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
