# Replay package — entry db0af409ad39

Conjecture: Coxeter Group Enumeration of Boolean Function Entropy via Invariant Generators Bounds Circuit Satisfiability Time

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 02:22 UTC.
Pre-registration hash committed before this test ran: `19f79a7dc855d705`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
