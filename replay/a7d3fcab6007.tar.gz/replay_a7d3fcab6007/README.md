# Replay package — entry a7d3fcab6007

Conjecture: Minimal Order of Quaternionic Representations and Communication Rank Growth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 07:00 UTC.
Pre-registration hash committed before this test ran: `2bd01718b9fe9910`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
