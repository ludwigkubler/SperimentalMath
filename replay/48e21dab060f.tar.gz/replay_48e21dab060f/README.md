# Replay package — entry 48e21dab060f

Conjecture: Minimal Order of Pseudorandom Permutation Groups Bounds ACC⁰ Lower Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 17:40 UTC.
Pre-registration hash committed before this test ran: `103779b46dee3b8e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
