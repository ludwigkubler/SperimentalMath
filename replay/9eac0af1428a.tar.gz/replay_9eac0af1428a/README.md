# Replay package — entry 9eac0af1428a

Conjecture: Minimal p-Adic Order Correlation with Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 01:15 UTC.
Pre-registration hash committed before this test ran: `d22ad5ea217f2e55`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
