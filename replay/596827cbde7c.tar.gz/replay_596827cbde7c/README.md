# Replay package — entry 596827cbde7c

Conjecture: Dismantlability Core of Clause-Sharing Graph Bounds Tree-Res Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 19:09 UTC.
Pre-registration hash committed before this test ran: `9d19da734d84be9a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
