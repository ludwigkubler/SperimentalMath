# Replay package — entry 6afd248521a0

Conjecture: Sturm Real-Root Count of GW Moment Matrix Bounds Max-CUT Slack

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 19:45 UTC.
Pre-registration hash committed before this test ran: `0806e6b00ff9e70d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
