# Replay package — entry 0d739d960283

Conjecture: Minimal Rank of Tropicalized Lie Group Actions Bounds Quantum Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 06:02 UTC.
Pre-registration hash committed before this test ran: `5112283417191232`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
