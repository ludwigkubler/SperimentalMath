# Replay package — entry e9b8de6819ff

Conjecture: Minimal Tropical Hodge Dimension and Circuit Depth Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 21:52 UTC.
Pre-registration hash committed before this test ran: `70dc1ce87b925553`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
