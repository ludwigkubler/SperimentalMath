# Replay package — entry 10350f5e2ac2

Conjecture: Finite Geometry Line Count Bounds EF Proof Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 00:09 UTC.
Pre-registration hash committed before this test ran: `aaaea276829e8375`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
