# Replay package — entry 63e0e3f43696

Conjecture: SoS Cone-Gram Stable Rank Caps AC⁰ Depth-d Size for PARITY

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 00:39 UTC.
Pre-registration hash committed before this test ran: `be86a764f1f3c1f1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
