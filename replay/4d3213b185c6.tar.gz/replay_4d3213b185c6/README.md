# Replay package — entry 4d3213b185c6

Conjecture: Minimal Rank of Differential Forms and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 18:41 UTC.
Pre-registration hash committed before this test ran: `16379a1a8c5b4613`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
