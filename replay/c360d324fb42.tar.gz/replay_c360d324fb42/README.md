# Replay package — entry c360d324fb42

Conjecture: Critical Simplices in Discrete Morse Theory Bound Tseitin Resolution Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 02:01 UTC.
Pre-registration hash committed before this test ran: `84d523f8b583328b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
