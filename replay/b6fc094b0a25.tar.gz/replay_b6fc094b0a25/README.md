# Replay package — entry b6fc094b0a25

Conjecture: Sidon B_2-Witness Failure of ACC⁰[2] for Sipser via MOD-Gate Outputs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 17:00 UTC.
Pre-registration hash committed before this test ran: `2e6b25c40f23eb66`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
