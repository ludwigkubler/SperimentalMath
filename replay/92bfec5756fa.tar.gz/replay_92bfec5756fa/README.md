# Replay package — entry 92bfec5756fa

Conjecture: Minimal Order of Affine Geometry and SAT Clause Subset Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 11:17 UTC.
Pre-registration hash committed before this test ran: `6d1c1052fa122680`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
