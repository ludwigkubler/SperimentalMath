# Replay package — entry 2f471259c7d3

Conjecture: Minimal Rank of Tropicalized Cohomology Groups over Branching Programs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 21:29 UTC.
Pre-registration hash committed before this test ran: `c7d15f0292d21ff7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
