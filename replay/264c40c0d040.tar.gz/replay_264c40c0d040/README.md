# Replay package — entry 264c40c0d040

Conjecture: Coboundary-Vanishing Threshold: HX^1 Triviality Below the Diameter-to-Depth Ratio for Parity-on-a-Tree

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 03:39 UTC.
Pre-registration hash committed before this test ran: `71a9e7de2d29d92a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
