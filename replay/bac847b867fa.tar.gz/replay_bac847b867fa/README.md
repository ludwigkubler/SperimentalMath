# Replay package — entry bac847b867fa

Conjecture: Operator Norm Separation for Read-Twice Branching Programs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 13:14 UTC.
Pre-registration hash committed before this test ran: `9a3a44f3356b7336`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
