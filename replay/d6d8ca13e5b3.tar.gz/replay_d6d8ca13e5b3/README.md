# Replay package — entry d6d8ca13e5b3

Conjecture: Persistent Homology Barcode Length Bounds Tseitin Resolution Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 18:18 UTC.
Pre-registration hash committed before this test ran: `812a888ab622b8a9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
