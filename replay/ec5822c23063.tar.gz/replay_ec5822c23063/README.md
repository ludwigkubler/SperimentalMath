# Replay package — entry ec5822c23063

Conjecture: Minimal Rank of K-Theory over Frege Proof Trees

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 21:53 UTC.
Pre-registration hash committed before this test ran: `98098ccf418035e4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
