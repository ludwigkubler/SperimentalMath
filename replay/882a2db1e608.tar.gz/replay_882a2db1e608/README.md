# Replay package — entry 882a2db1e608

Conjecture: Noncommutative Fourier Coefficient Inversion in Greater-Than Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 04:30 UTC.
Pre-registration hash committed before this test ran: `a4c5db2d61d99c56`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
