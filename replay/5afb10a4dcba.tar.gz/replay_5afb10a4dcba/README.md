# Replay package — entry 5afb10a4dcba

Conjecture: Minimal Tropical Hodge Index and Resolution Proof Width Lower Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 06:29 UTC.
Pre-registration hash committed before this test ran: `4c658b25be4ce915`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
