# Replay package — entry 03c6c412c5f0

Conjecture: Minimal Hodge Index Correlation with Communication Complexity Rank

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 16:20 UTC.
Pre-registration hash committed before this test ran: `7e4a6cdd2573bf9c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
