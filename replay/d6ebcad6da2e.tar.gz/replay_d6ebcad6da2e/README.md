# Replay package — entry d6ebcad6da2e

Conjecture: Minimal Order of Diophantine Equations Bounds EXPTIME-Space Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 19:44 UTC.
Pre-registration hash committed before this test ran: `f2a4c7c11081b011`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
