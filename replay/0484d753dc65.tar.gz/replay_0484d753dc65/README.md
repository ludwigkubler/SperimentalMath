# Replay package — entry 0484d753dc65

Conjecture: Minimal Rank of Noncrossed Products Bounds Communication Complexity for Max-Cut

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 00:03 UTC.
Pre-registration hash committed before this test ran: `5cc79e50b67ac9e8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
