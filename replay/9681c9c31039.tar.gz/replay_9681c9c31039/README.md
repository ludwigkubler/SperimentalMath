# Replay package — entry 9681c9c31039

Conjecture: Minimal Root Separation of Quaternion Algebras vs. AC0 Parity Threshold

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 12:16 UTC.
Pre-registration hash committed before this test ran: `e87cfec12fe72001`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
