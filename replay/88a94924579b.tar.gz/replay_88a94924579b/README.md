# Replay package — entry 88a94924579b

Conjecture: Minimal Rank of Tropical Hodge Decomposition Bounds DPLL Refutation Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 14:53 UTC.
Pre-registration hash committed before this test ran: `fa5d7edef87d4210`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
