# Replay package — entry bb503edce1c2

Conjecture: Haar-Wavelet Star-Discrepancy of Sign Matrix Lower-Bounds Rigidity at Rank n/2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 14:18 UTC.
Pre-registration hash committed before this test ran: `c4cd5c5f7b5fe205`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
