# Replay package — entry e36dca15c87b

Conjecture: Minimal Geometric Entropy Correlation with Communication Rank Growth in Planar Graphs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 03:15 UTC.
Pre-registration hash committed before this test ran: `24f1e2e3a44dc2ae`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
