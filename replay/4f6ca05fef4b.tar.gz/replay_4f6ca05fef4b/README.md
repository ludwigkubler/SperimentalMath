# Replay package — entry 4f6ca05fef4b

Conjecture: Convex Hull Surface Area and Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 10:34 UTC.
Pre-registration hash committed before this test ran: `a867e7c6d08bf81a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
