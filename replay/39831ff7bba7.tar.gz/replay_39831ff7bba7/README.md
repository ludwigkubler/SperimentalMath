# Replay package — entry 39831ff7bba7

Conjecture: Minimal Order of Eta-Invariant and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 01:00 UTC.
Pre-registration hash committed before this test ran: `9a69cd25eb6b5d76`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
