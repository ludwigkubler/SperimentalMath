import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def p_adic_order(x, p):
        if x == 0:
            return float('inf')
        order = 0
        while x % p == 0:
            x //= p
            order += 1
        return order
    
    def communication_complexity_rank(n):
        # Placeholder function for actual computation
        return random.randint(1, n)
    
    def minimal_order_in_l_function(c_n):
        # Placeholder function for actual computation
        return random.uniform(0.5, c_n)
    
    def alpha(c_n):
        # Placeholder function for actual computation
        return 2 * math.log(c_n)
    
    results = []
    for n in range(5, 41, 5):  # Sweep through n ∈ {5,10,15,20,30,40}
        c_n = communication_complexity_rank(n)
        order = minimal_order_in_l_function(c_n)
        if order < alpha(c_n) / 2:
            return {
                "metric_name": "alpha(c_n)",
                "metric_value": alpha(c_n),
                "instances_tested": 1,
                "n_max": n,
                "conjecture_holds": False,
                "counterexample": f"Order {order} < alpha({c_n}) / 2"
            }
        results.append((c_n, order))
    
    if len(results) < 30:
        return {
            "metric_name": "alpha(c_n)",
            "metric_value": None,
            "instances_tested": len(results),
            "n_max": max(n for n, _ in results),
            "conjecture_holds": False,
            "counterexample": "Insufficient instances tested"
        }
    
    c_ns = [c_n for c_n, _ in results]
    orders = [order for _, order in results]
    mean_alpha_c_n = sum(c_ns) / len(c_ns)
    std_alpha_c_n = math.sqrt(sum((x - mean_alpha_c_n) ** 2 for x in c_ns) / len(c_ns))
    
    correlation_coefficient = sum((c_ns[i] - mean_alpha_c_n) * (orders[i] - mean_alpha_c_n) for i in range(len(c_ns))) / (len(c_ns) * std_alpha_c_n * std_alpha_c_n)
    
    return {
        "metric_name": "alpha(c_n)",
        "metric_value": correlation_coefficient,
        "instances_tested": len(results),
        "n_max": max(n for n, _ in results),
        "conjecture_holds": abs(correlation_coefficient) > 0.7,
        "counterexample": ""
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] or [2**i - 1 for i in range(5, 31)]
    
    results = []
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    mean_metric_value = sum(result["metric_value"] for result in results if result["metric_value"] is not None) / len(results)
    std_metric_value = math.sqrt(sum((result["metric_value"] - mean_metric_value) ** 2 for result in results if result["metric_value"] is not None) / len(results))
    support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)
    
    if all(result["conjecture_holds"] for result in results):
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_metric_value} support_fraction={support_fraction}")
    elif any(not result["conjecture_holds"] for result in results) and support_fraction >= 0.8:
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE insufficient_data")