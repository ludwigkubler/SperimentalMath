# Replay package — entry 91c080437dbf

Conjecture: Minimal Order of Monomial Ideals and Communication Complexity Rank Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 21:42 UTC.
Pre-registration hash committed before this test ran: `d51e7c3f71a46fcb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
