# Replay package — entry af099c803fe0

Conjecture: Minimal Index of p-Adic Topological Entropy and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 16:31 UTC.
Pre-registration hash committed before this test ran: `567863b4d2e23061`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
