# Replay package — entry c93b44a7d21e

Conjecture: Kronecker Coefficient Non-Zero Threshold for Permanent-Complete SAT Instances

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 15:10 UTC.
Pre-registration hash committed before this test ran: `55cf2f25b47d7e4f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
