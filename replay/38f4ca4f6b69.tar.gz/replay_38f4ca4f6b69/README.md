# Replay package — entry 38f4ca4f6b69

Conjecture: Minimal Alexander-Orlik-Solomon Complexity and SAT Clause Depth Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 05:11 UTC.
Pre-registration hash committed before this test ran: `1ef6715649fa6576`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
