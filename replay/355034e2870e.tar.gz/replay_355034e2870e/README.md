# Replay package — entry 355034e2870e

Conjecture: Minimal Symplectic Form Rank Correlation with Frege Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 04:07 UTC.
Pre-registration hash committed before this test ran: `24379acedd57b0d5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
