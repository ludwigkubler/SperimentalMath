# Replay package — entry f7987e007c77

Conjecture: Minimal Rank of Graph Cocomplexes vs Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 12:46 UTC.
Pre-registration hash committed before this test ran: `f939ff25839608a3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
