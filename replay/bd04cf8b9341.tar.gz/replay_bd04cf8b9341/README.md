# Replay package — entry bd04cf8b9341

Conjecture: Free Cumulant Sum Gap in Read-Twice BP Transition Matrices

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 18:31 UTC.
Pre-registration hash committed before this test ran: `5d37db9889836344`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
