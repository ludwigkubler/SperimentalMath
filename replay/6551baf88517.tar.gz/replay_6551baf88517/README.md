# Replay package — entry 6551baf88517

Conjecture: Minimal Index of Automorphism Groups in Quiver Representations Bounds Frege Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 14:32 UTC.
Pre-registration hash committed before this test ran: `c1056832fdccebe2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
