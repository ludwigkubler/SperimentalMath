# Replay package — entry a58cbdcb6e05

Conjecture: Non-Backtracking Spectral Gap Bounds Tseitin Resolution Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-16 21:44 UTC.
Pre-registration hash committed before this test ran: `c0722d24bc746643`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
