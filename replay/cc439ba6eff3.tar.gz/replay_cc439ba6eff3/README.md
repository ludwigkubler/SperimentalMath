# Replay package — entry cc439ba6eff3

Conjecture: Minimal Geometric Entropy of Toric Varieties vs. Sum-of-Squares Hierarchy Degree

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 12:53 UTC.
Pre-registration hash committed before this test ran: `5e8922c3917920fd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
