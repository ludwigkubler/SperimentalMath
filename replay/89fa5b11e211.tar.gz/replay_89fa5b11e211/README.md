# Replay package — entry 89fa5b11e211

Conjecture: [c003b_cumulative_entropy/SC1#c24] Under min-occurrence DP elimination, Φ(π) grows super-linearly in n on 3-regular Tseitin (log-log slope > 1). Measure the exponent.

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 16:59 UTC.
Pre-registration hash committed before this test ran: `02e40831938c0fa9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
