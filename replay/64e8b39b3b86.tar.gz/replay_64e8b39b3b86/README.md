# Replay package — entry 64e8b39b3b86

Conjecture: Minimal Rank of tropicalized symmetric functions bounds Monotone Circuit Size for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 01:50 UTC.
Pre-registration hash committed before this test ran: `5f212b822deffd15`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
