# Replay package — entry 95d8ba0e68c2

Conjecture: Minimal Rank of Quaternionic Representations in Boolean Algebras vs XOR-AND Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 18:54 UTC.
Pre-registration hash committed before this test ran: `c5fd7f10a605a055`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
