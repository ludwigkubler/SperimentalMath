# Replay package — entry 91d0da41df90

Conjecture: Minimal Rank of Tropicalized Quasi-Monte Carlo Sequences over Tseitin Circuit Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 01:19 UTC.
Pre-registration hash committed before this test ran: `81feb93885d86be3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
