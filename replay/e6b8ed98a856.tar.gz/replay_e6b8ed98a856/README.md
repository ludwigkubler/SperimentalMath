# Replay package — entry e6b8ed98a856

Conjecture: Krull Dimension Lower Bounds SOS Refutation Degree for 3-SAT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 08:45 UTC.
Pre-registration hash committed before this test ran: `db1368baaa1003b1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
