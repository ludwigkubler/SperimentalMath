# Replay package — entry 95e73bab9487

Conjecture: Minimal Representation Rank of Quantum States and DPLL Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 18:21 UTC.
Pre-registration hash committed before this test ran: `fad736324e8d9003`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
