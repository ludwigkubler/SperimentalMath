# Replay package — entry fa2807b81283

Conjecture: Minimal Hodge Decomposition Rank and Resolution Proof Width Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 07:59 UTC.
Pre-registration hash committed before this test ran: `2affd587945da009`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
