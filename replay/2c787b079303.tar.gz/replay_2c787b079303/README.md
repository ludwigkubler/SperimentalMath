# Replay package — entry 2c787b079303

Conjecture: Minimal Local Cohomology in p-Adic Analysis and Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 01:56 UTC.
Pre-registration hash committed before this test ran: `0d537ab13ab9bf64`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
