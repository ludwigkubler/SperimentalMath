import random
from math import log2, ceil

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n_values = [2, 4, 8]
    total_entropy = 0
    instances_tested = 0
    n_max = 0
    
    for n in n_values:
        D = ceil(log2(n + 1))
        if D == 0: continue
        
        # Generate all possible boolean circuits with depth D
        def generate_circuits(depth, inputs):
            if depth == 0:
                return [inputs]
            circuits = []
            for i in range(1 << len(inputs)):
                circuit = []
                for j in range(len(inputs)):
                    if (i >> j) & 1:
                        circuit.append('NOT ' + inputs[j])
                    else:
                        circuit.append(inputs[j])
                circuits.extend(generate_circuits(depth - 1, circuit))
            return circuits
        
        circuits = generate_circuits(D, [f'x{i}' for i in range(n)])
        
        for circuit in circuits:
            # Calculate the output lattice of the circuit
            def evaluate(circuit):
                if 'NOT ' in circuit:
                    subcircuit = circuit.replace('NOT ', '')
                    return {1 - evaluate(subcircuit)}
                else:
                    inputs = [int(x) for x in circuit.split()]
                    return set(inputs)
            
            output_lattice = evaluate(circuit)
            entropy = len(output_lattice) * log2(len(output_lattice))
            total_entropy += entropy
            instances_tested += 1
            n_max = max(n_max, n)
    
    mean_entropy = total_entropy / instances_tested if instances_tested > 0 else 0
    
    c = 0.5  # Example constant for the lower bound
    conjecture_holds = mean_entropy >= c * log2(n + D) for n in n_values and D == ceil(log2(n + 1))
    
    counterexample = "" if conjecture_holds else "mean_entropy < c * log2(n + D)"
    
    return {
        "metric_name": "topological entropy",
        "metric_value": mean_entropy,
        "instances_tested": instances_tested,
        "n_max": n_max,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] if len(sys.argv) > 1 else [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    results = []
    
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = (sum((r["metric_value"] - mean_value) ** 2 for r in results) / len(results)) ** 0.5
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{r['counterexample']}\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE reason=unknown")