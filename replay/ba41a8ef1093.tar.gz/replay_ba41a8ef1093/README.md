# Replay package — entry ba41a8ef1093

Conjecture: Minimal Index of Modular Forms over Function Fields and Circuit Monotone Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 21:23 UTC.
Pre-registration hash committed before this test ran: `4aebbc59620785b7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
