# Replay package — entry 71ce01b16c1e

Conjecture: Continued Fraction Depth of Spectral Ratio Bounds Discrepancy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 00:31 UTC.
Pre-registration hash committed before this test ran: `d201a96275cda6b3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
