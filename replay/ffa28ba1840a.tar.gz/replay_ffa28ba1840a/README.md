# Replay package — entry ffa28ba1840a

Conjecture: Fourier Entropy-Communication Complexity Conjecture for 3-CNF Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 11:50 UTC.
Pre-registration hash committed before this test ran: `22b37ee829a685ee`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
