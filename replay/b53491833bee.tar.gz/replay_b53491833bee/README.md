# Replay package — entry b53491833bee

Conjecture: Minimal Symmetric Entropy of Root Lattices and SAT Clause Subset Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 03:03 UTC.
Pre-registration hash committed before this test ran: `053c4790c7195f4e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
