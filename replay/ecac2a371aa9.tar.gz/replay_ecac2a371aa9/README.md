# Replay package — entry ecac2a371aa9

Conjecture: Minimal Affine Root Count Correlation with Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 22:43 UTC.
Pre-registration hash committed before this test ran: `7add7315fcf3ff90`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
