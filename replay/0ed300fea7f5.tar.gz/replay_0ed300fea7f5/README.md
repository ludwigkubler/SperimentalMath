# Replay package — entry 0ed300fea7f5

Conjecture: Minimal Symplectic Volume and Frege Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 12:31 UTC.
Pre-registration hash committed before this test ran: `8e2cdad287a60b89`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
