# Replay package — entry 71a6dbf6983b

Conjecture: Minimal Local Induction Ring Rank and Communication Complexity Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 23:11 UTC.
Pre-registration hash committed before this test ran: `19045bb1b3da86ad`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
