# Replay package — entry 4d473e78494e

Conjecture: Matroid Rank and Minimal Circuit Size for Boolean Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 03:07 UTC.
Pre-registration hash committed before this test ran: `9131010fa8b587c9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
