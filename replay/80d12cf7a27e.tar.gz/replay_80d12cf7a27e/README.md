# Replay package — entry 80d12cf7a27e

Conjecture: Cyclic Burnside Orbit Count Lower-Bounds AC⁰ Size for PARITY

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 00:49 UTC.
Pre-registration hash committed before this test ran: `9216b43f4897dd13`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
