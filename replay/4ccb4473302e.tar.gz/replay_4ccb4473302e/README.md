# Replay package — entry 4ccb4473302e

Conjecture: Logarithmic Saturation Gap of Forman-Ricci μ above v/4 for F*_v

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 10:44 UTC.
Pre-registration hash committed before this test ran: `08e45c9db257b0ff`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
