# Replay package — entry 099409f8803b

Conjecture: Minimal Rank of Schur-Weyl Tensor Product over Monomial Ideal Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 11:20 UTC.
Pre-registration hash committed before this test ran: `39ca65de6c08a532`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
