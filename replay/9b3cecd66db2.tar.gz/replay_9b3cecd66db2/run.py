import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_k_cnf(n, m):
        variables = list(range(1, n + 1))
        clauses = []
        for _ in range(m):
            clause = [random.choice(variables) for _ in range(random.randint(1, n))]
            if random.choice([True, False]):
                clause = [-v for v in clause]
            clauses.append(clause)
        return variables, clauses

    def resolution_proof_complexity(variables, clauses):
        # Simplified version of resolution proof complexity calculation
        # This is a placeholder and should be replaced with an actual algorithm
        return len(clauses) * 2

    def quandle_rank(variables, clauses):
        # Placeholder for quandle rank calculation
        # This is a placeholder and should be replaced with an actual algorithm
        return random.randint(1, 50)

    n = random.choice([5, 10, 15, 20, 30, 40])
    m = random.randint(n, 2 * n)
    variables, clauses = generate_k_cnf(n, m)
    
    alpha_nm = resolution_proof_complexity(variables, clauses)
    rank_q = quandle_rank(variables, clauses)
    
    return {
        "metric_name": "Quandle Rank",
        "metric_value": rank_q,
        "instances_tested": 1,
        "conjecture_holds": rank_q == alpha_nm,
        "counterexample": f"Mean rank {rank_q} does not match resolution complexity {alpha_nm}" if rank_q != alpha_nm else ""
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_d = sum(r["metric_value"] for r in results) / len(results)
    std_dev = math.sqrt(sum((r["metric_value"] - mean_d) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_d} std={std_dev} support_fraction={support_fraction}")
    elif support_fraction >= 0.9:
        print(f"RESULT: SUPPORTED mean={mean_d} std={std_dev} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{r['counterexample']}\" first_failing_seed={first_failing_seed}")