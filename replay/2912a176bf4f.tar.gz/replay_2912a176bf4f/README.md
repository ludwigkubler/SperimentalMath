# Replay package — entry 2912a176bf4f

Conjecture: Minimal Rank of plethysm coefficients in algebraic combinatorics vs permanent circuit size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 19:25 UTC.
Pre-registration hash committed before this test ran: `1fd6858bd55843f4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
