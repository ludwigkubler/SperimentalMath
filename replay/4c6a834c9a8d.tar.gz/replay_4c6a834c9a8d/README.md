# Replay package — entry 4c6a834c9a8d

Conjecture: Minimal Index of Quaternionic Automorphism Groups and SAT Clause Set Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 09:09 UTC.
Pre-registration hash committed before this test ran: `c009908dc8e7875a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
