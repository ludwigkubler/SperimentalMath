# Replay package — entry 0d3096c1b61c

Conjecture: Minimal Order of Automorphism Groups and Tseitin Formula Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 08:21 UTC.
Pre-registration hash committed before this test ran: `32972c3482075c01`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
