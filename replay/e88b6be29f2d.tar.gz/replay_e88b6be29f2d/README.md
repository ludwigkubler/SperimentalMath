# Replay package — entry e88b6be29f2d

Conjecture: Minimal Rank of Algebraic Cycles in the Moduli Space Bounds Resolution Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 16:22 UTC.
Pre-registration hash committed before this test ran: `aa48e28201366551`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
