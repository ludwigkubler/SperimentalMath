# Replay package — entry 0aa52fbea438

Conjecture: Minimal Representation Rank and Coxeter System Index of Boolean Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 08:38 UTC.
Pre-registration hash committed before this test ran: `c7b9d1b8bd3e0d0e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
