# Replay package — entry 646e1beeca20

Conjecture: SOS Rank and Complete Intersection Dimension

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 04:34 UTC.
Pre-registration hash committed before this test ran: `70933c5edb9c23f6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
