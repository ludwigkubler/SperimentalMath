# Replay package — entry fd3bce7f9971

Conjecture: Minimal Index of Grothendieck-Frey-Inselberg Diversify Sequence Bounds Davis-Putnam Refutation Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 05:55 UTC.
Pre-registration hash committed before this test ran: `3af3a6279ebca0bf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
