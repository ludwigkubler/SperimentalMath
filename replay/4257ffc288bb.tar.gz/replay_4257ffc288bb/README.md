# Replay package — entry 4257ffc288bb

Conjecture: Tropicalized Homology Groups of Knots vs BP_ReadTwice Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 06:19 UTC.
Pre-registration hash committed before this test ran: `8c70fd26bc1b8fe1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
