# Replay package — entry d74487fc5c34

Conjecture: Minimal Lefschetz Number and Circuit Entanglement Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 01:28 UTC.
Pre-registration hash committed before this test ran: `3ce5639de13c90a9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
