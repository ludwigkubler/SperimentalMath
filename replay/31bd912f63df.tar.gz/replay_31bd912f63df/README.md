# Replay package — entry 31bd912f63df

Conjecture: Minimal Order of Formal Groups and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 04:01 UTC.
Pre-registration hash committed before this test ran: `53892f1a70f1887f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
