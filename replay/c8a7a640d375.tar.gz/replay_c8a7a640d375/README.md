# Replay package — entry c8a7a640d375

Conjecture: Hypercontractive Laplacian-Spectrum Flatness Bounds Spectral SOS Max-Cut Ratio

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 16:22 UTC.
Pre-registration hash committed before this test ran: `d752374825016f37`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
