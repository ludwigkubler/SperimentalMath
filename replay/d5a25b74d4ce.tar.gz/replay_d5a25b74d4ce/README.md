# Replay package — entry d5a25b74d4ce

Conjecture: Minimal Tropical Discriminant for k-CLIQUE Monotone Circuit Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 04:37 UTC.
Pre-registration hash committed before this test ran: `9bfb79f46fb486fb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
