# Replay package — entry 1b6d2c2ffe68

Conjecture: Minimal Rank of Symplectic Leaves Bounds DPLL Search Tree Height

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 23:25 UTC.
Pre-registration hash committed before this test ran: `6159df356fc673a5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
