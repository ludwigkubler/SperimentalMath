# Replay package — entry 324cadb0fb5c

Conjecture: Minimal Rank of Quadratic Forms vs Communication Complexity for k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 05:56 UTC.
Pre-registration hash committed before this test ran: `2f65ac30e478b240`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
