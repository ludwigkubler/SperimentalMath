# Replay package — entry d44d4d3f750f

Conjecture: Minimal Order of Local Fields and SAT Instance Diameter

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 12:41 UTC.
Pre-registration hash committed before this test ran: `bce32a2bf058111a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
