# Replay package — entry 5fe5db0b9a9e

Conjecture: Minimal Rank of Hodge Structure over Tropical Varieties vs AC⁰ PARITY Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 23:07 UTC.
Pre-registration hash committed before this test ran: `05724738f510212b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
