# Replay package — entry bc84c13f7232

Conjecture: Automorphic L-Function Invariant for SAT Clause Density

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 19:59 UTC.
Pre-registration hash committed before this test ran: `499928151e194710`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
