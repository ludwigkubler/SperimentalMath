# Replay package — entry 7d70057c2c91

Conjecture: Minimal Hyperbolic Volume of Graphs and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 08:24 UTC.
Pre-registration hash committed before this test ran: `57c82dd5f6943c4a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
