# Replay package — entry 9152edf3c7fc

Conjecture: Herbrand-Disjunction Length of PHP Bounds Tree-Resolution Leaves

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 22:52 UTC.
Pre-registration hash committed before this test ran: `ebe3f0a57930278f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
