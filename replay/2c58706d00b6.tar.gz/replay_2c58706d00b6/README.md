# Replay package — entry 2c58706d00b6

Conjecture: Minimal Exponent of Hodge Decomposition vs Resolution Refutation Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 13:11 UTC.
Pre-registration hash committed before this test ran: `141c0faeb0f114c4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
