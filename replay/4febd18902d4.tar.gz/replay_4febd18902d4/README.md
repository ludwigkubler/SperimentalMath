# Replay package — entry 4febd18902d4

Conjecture: Hilbert Function Leading Coefficient Distinguishes Read-Twice from Read-Once BPs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 06:21 UTC.
Pre-registration hash committed before this test ran: `9386310757721b77`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
