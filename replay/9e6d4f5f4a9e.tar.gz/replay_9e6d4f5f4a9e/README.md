# Replay package — entry 9e6d4f5f4a9e

Conjecture: Minimal Rank of Formal Power Series vs DPLL Proof Width for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 23:31 UTC.
Pre-registration hash committed before this test ran: `496db6564c71e504`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
