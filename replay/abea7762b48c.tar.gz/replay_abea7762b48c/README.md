# Replay package — entry abea7762b48c

Conjecture: Minimal Rank of Hodge Classes vs Randomized Communication Complexity for Disjointness

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 07:01 UTC.
Pre-registration hash committed before this test ran: `3d7ab932262495b8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
