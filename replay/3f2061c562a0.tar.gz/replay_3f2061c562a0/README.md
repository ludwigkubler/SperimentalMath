# Replay package — entry 3f2061c562a0

Conjecture: Minimal Rank of Hodge Structures over Boolean Functions vs DPLL Refutation Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 15:49 UTC.
Pre-registration hash committed before this test ran: `f67967ac8d6d106b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
