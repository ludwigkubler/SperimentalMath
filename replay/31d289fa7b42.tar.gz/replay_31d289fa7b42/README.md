# Replay package — entry 31d289fa7b42

Conjecture: Minimal Rank of Quantum Group Cohomology vs Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 22:26 UTC.
Pre-registration hash committed before this test ran: `87a3731d6007f32a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
