# Replay package — entry 1a5be3baec68

Conjecture: Hadamard-Code Distance Defect Predicts NW-PRG Distinguisher Advantage

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 10:22 UTC.
Pre-registration hash committed before this test ran: `bfd373d0560cbe6e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
