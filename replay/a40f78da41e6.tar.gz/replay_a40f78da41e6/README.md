# Replay package — entry a40f78da41e6

Conjecture: Plethysm Coefficient Gap in Monotone Circuit Complexity for Permanent vs Determinant

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 15:49 UTC.
Pre-registration hash committed before this test ran: `be8222c7c0701bd5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
