# Replay package — entry 8383796bbc60

Conjecture: Minimal Rank of Schur-Weyl Tensor Product Representations vs DPLL Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 22:23 UTC.
Pre-registration hash committed before this test ran: `f00570cb221c9814`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
