# Replay package — entry b22241903f08

Conjecture: Star Discrepancy of Clause-Vectors Lower-Bounds Resolution Width for Random 3-SAT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-29 23:43 UTC.
Pre-registration hash committed before this test ran: `af78e45aafd6b5cf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
