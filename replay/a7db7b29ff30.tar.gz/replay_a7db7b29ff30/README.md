# Replay package — entry a7db7b29ff30

Conjecture: Positivstellensatz Rank Deficiency in Max-CUT SOS Relaxations

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 05:45 UTC.
Pre-registration hash committed before this test ran: `17b5d003e5b65181`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
