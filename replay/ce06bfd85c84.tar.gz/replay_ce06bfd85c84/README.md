# Replay package — entry ce06bfd85c84

Conjecture: Minimal Rank of Noncrossing Partitions vs Tree-width of Resolution Proofs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 19:39 UTC.
Pre-registration hash committed before this test ran: `c27f2743ff328032`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
