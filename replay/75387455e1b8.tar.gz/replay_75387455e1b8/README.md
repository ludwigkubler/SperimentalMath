# Replay package — entry 75387455e1b8

Conjecture: Polymatroid Rank Inverse Proportionality to SOS Refutation Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 14:14 UTC.
Pre-registration hash committed before this test ran: `5ac1008440d91363`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
