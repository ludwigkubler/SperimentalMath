# Replay package — entry 5176ee0eb621

Conjecture: Minimal Tropical Rank of Graph Automorphism Groups and Circuit Size Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 13:45 UTC.
Pre-registration hash committed before this test ran: `dfd777dd1917a49b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
