# Replay package — entry 8c4ea325b38d

Conjecture: Minimal Rank of Formal Contexts vs AC0 Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 02:09 UTC.
Pre-registration hash committed before this test ran: `c1fa677a4ee55864`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
