# Replay package — entry 141266783ffe

Conjecture: Seed Length of Nisan-Wigderson PRG Bounded by Minimal Linear Approximation Count

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 13:02 UTC.
Pre-registration hash committed before this test ran: `e7bc6b48489664da`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
