# Replay package — entry 6c145b195a2e

Conjecture: Arithmetic Hodge Index and Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 15:44 UTC.
Pre-registration hash committed before this test ran: `9dbaabf43d88a38a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
