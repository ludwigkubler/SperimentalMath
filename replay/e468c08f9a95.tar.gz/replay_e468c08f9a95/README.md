# Replay package — entry e468c08f9a95

Conjecture: Minimal Hodge Index of Affine Varieties vs SOS Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 05:30 UTC.
Pre-registration hash committed before this test ran: `e47ff97396f4df1a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
