# Replay package — entry 2f193a8b2209

Conjecture: Signed-Support L_inf Discrepancy Bounds Bottom Fan-In for AC0 PARITY

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 08:06 UTC.
Pre-registration hash committed before this test ran: `c41cded4b8e091a1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
