# Replay package — entry bc2ea1f29a82

Conjecture: Minimal Rank of Symmetric Functions over Tseitin Resolution Trees Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 06:25 UTC.
Pre-registration hash committed before this test ran: `6ddc1c832c67cdae`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
