# Replay package — entry 6ead43796693

Conjecture: Continued-Fraction Spike of Truth-Table Rational Caps DNF_min

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 16:32 UTC.
Pre-registration hash committed before this test ran: `875c07296398840f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
