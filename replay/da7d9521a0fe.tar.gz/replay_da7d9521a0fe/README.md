# Replay package — entry da7d9521a0fe

Conjecture: Minimal Rank of Quotient Groups over Frege Proof Trees

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 18:35 UTC.
Pre-registration hash committed before this test ran: `805ac4a7e78d019a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
