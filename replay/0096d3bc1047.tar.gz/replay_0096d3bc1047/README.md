# Replay package — entry 0096d3bc1047

Conjecture: Minimal p-Adic Cohomology and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 23:15 UTC.
Pre-registration hash committed before this test ran: `b3fff0d7f96bed05`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
