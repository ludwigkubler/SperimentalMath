# Replay package — entry 954a5c8e8ffd

Conjecture: Tutte Polynomial Evaluation Bounded by Monotone k-CLIQUE Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 01:05 UTC.
Pre-registration hash committed before this test ran: `1e3bc00a50d93df2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
