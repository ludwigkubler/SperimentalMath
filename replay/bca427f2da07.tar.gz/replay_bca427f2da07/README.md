# Replay package — entry bca427f2da07

Conjecture: Algebraic Topology of Persistent Homology vs. Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 04:39 UTC.
Pre-registration hash committed before this test ran: `73ee5287fa899a3f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
