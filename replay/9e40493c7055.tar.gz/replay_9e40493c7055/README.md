# Replay package — entry 9e40493c7055

Conjecture: Minimal Local Homology Rank Bounds Tree-like Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 04:07 UTC.
Pre-registration hash committed before this test ran: `3895312bd5ee5b73`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
