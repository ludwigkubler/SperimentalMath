# Replay package — entry 14ea4abead64

Conjecture: Minimal Rank of Geometric Quantization Spaces vs ACC⁰ Circuit Weights

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 12:26 UTC.
Pre-registration hash committed before this test ran: `dc70360d081a5c03`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
