# Replay package — entry 2f7cf0867b85

Conjecture: Asymptotic Dimension and Tseitin Resolution Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 08:47 UTC.
Pre-registration hash committed before this test ran: `9deda73b591d6058`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
