# Replay package — entry 65341f910458

Conjecture: Minimal Entanglement Tensor Rank vs BP_ReadTwice Circuit Threshold

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 22:19 UTC.
Pre-registration hash committed before this test ran: `5336b0b14e56f676`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
