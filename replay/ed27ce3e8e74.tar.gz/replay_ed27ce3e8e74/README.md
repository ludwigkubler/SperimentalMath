# Replay package — entry ed27ce3e8e74

Conjecture: Minimal Local Homology Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 23:44 UTC.
Pre-registration hash committed before this test ran: `8d39a927aa006ef9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
