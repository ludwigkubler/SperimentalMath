# Replay package — entry 663ad7573f57

Conjecture: Minimal Quaternionic Root Count Correlation with DPLL Search Tree Diameter

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 11:13 UTC.
Pre-registration hash committed before this test ran: `786bf17d940214c5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
