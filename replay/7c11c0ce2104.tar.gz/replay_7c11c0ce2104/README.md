# Replay package — entry 7c11c0ce2104

Conjecture: Minimal Rank of Quantum Logarithm over Tseitin Clauses vs Resolution Refutation Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 18:50 UTC.
Pre-registration hash committed before this test ran: `43a44468f5eebc8c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
