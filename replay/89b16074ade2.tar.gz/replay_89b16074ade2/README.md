# Replay package — entry 89b16074ade2

Conjecture: Minimal Order of Geometric Invariant Theory Bounds Exponential Time Hypothesis for Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 01:57 UTC.
Pre-registration hash committed before this test ran: `e42d6e15c2b1a0da`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
