# Replay package — entry 1ecdbd4e7f62

Conjecture: Minimal Index of Diophantine Equivalence and Resolution Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 18:40 UTC.
Pre-registration hash committed before this test ran: `14c20a9e17eb03d1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
