# Replay package — entry 2e8d45b4630c

Conjecture: Minimal Rank of Ramanujan Sums Bounds Quantifier Depth for Monadic Second-Order Logic

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 14:50 UTC.
Pre-registration hash committed before this test ran: `436422452a94276d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
