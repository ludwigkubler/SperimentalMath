# Replay package — entry 8616e6c721a4

Conjecture: Tropical Analytic Rank and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 04:19 UTC.
Pre-registration hash committed before this test ran: `69bd56807875db2f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
