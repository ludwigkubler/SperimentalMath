# Replay package — entry 2ff20261e6db

Conjecture: Minimal Order of Automorphism Groups and Communication Complexity via Noncommutative Geometry Invariants

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 11:01 UTC.
Pre-registration hash committed before this test ran: `7b65bdc68e8f7061`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
