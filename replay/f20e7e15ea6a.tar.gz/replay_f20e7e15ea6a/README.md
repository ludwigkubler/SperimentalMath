# Replay package — entry f20e7e15ea6a

Conjecture: Minimal Local Coherence Rank Correlation with Resolution Proof Width via Sheaf Theory

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 03:31 UTC.
Pre-registration hash committed before this test ran: `1618bcab5a51940b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
