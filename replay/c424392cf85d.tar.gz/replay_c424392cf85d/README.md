# Replay package — entry c424392cf85d

Conjecture: Minimal Rank of Tropicalized Hodge Structures Bounds Resolution Refutation Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 14:44 UTC.
Pre-registration hash committed before this test ran: `dc78502bf0b4e7c9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
