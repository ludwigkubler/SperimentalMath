import random
import math
import itertools

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_instance(n, m):
        clauses = []
        for _ in range(m):
            clause = [random.randint(-n, n) for _ in range(random.randint(1, n))]
            clauses.append(clause)
        return clauses
    
    def hermitian_matrix(clauses, n):
        A = [[0] * (2*n) for _ in range(2*n)]
        for clause in clauses:
            for lit in clause:
                row, col = abs(lit)-1, 2*(abs(lit)-1)
                if lit > 0:
                    A[row][col] += 1
                else:
                    A[row][col+1] += 1
        return A
    
    def geometric_entropy(A):
        eigenvalues = power_method(A, 100)  # Power method to find the largest eigenvalue
        H = -sum(eigenvalue * math.log2(eigenvalue) for eigenvalue in eigenvalues if eigenvalue > 0)
        return H
    
    def power_method(matrix, max_iter=100):
        n = len(matrix)
        v = [random.random() for _ in range(n)]
        v /= sum(v)
        
        for _ in range(max_iter):
            Av = matrix @ v
            Av /= sum(Av)
            v = Av
        
        return Av
    
    def delta_phi(clauses, n):
        assignments = list(itertools.product([-1, 1], repeat=n))
        valid_assignments = [assignment for assignment in assignments if all(lit * assignment[abs(lit)-1] >= 0 for lit in clauses)]
        return len(valid_assignments)
    
    def is_square(matrix):
        n = len(matrix)
        return all(len(row) == n for row in matrix)
    
    def normalize(matrix):
        n = len(matrix)
        norm = sum(sum(abs(x) for x in row) for row in matrix)
        return [[x / norm for x in row] for row in matrix]
    
    def multiply(A, B):
        n = len(A)
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                for k in range(n):
                    C[i][j] += A[i][k] * B[k][j]
        return C
    
    def transpose(matrix):
        n = len(matrix)
        return [[matrix[j][i] for j in range(n)] for i in range(n)]
    
    def inverse(matrix):
        n = len(matrix)
        I = [[1 if i == j else 0 for j in range(n)] for i in range(n)]
        Aaug = [row + col for row, col in zip(matrix, I)]
        
        for i in range(n):
            max_row = max(range(i, n), key=lambda r: abs(Aaug[r][i]))
            if Aaug[max_row][i] == 0:
                return None  # Singular matrix
            Aaug[i], Aaug[max_row] = Aaug[max_row], Aaug[i]
            
            for j in range(n):
                Aaug[i][j] /= Aaug[i][i]
            
            for k in range(n):
                if k != i:
                    factor = Aaug[k][i]
                    for j in range(2*n):
                        Aaug[k][j] -= factor * Aaug[i][j]
        
        return [row[n:] for row in Aaug]
    
    def norm(matrix):
        n = len(matrix)
        return math.sqrt(sum(sum(x**2 for x in row) for row in matrix))
    
    def normalize_rows(matrix):
        n = len(matrix)
        return [[x / sum(row) if sum(row) != 0 else 0 for x in row] for row in matrix]
    
    def normalize_columns(matrix):
        n = len(matrix)
        return [[x / sum(col) if sum(col) != 0 else 0 for col in zip(*matrix)] for row in matrix]
    
    def is_diagonalizable(matrix):
        n = len(matrix)
        eigenvalues, eigenvectors = diagonalize(matrix)
        return all(eigenvalue == eigenvector[0] for eigenvalue, eigenvector in zip(eigenvalues, eigenvectors))
    
    def diagonalize(matrix):
        n = len(matrix)
        A = normalize(matrix)
        Q = identity(n)
        T = copy(A)
        
        for i in range(n-1):
            if abs(T[i+1][i]) > 1e-10:
                c = (T[i][i] - T[i+1][i+1]) / (2 * T[i+1][i])
                s = math.sqrt(1 + c**2)
                c /= s
                s /= s
                
                Q_i = identity(n)
                Q_i[i][i] = c
                Q_i[i+1][i+1] = c
                Q_i[i][i+1] = -s
                Q_i[i+1][i] = s
                
                T_i = copy(T)
                T_i[i][i] = T_i[i][i] * c**2 + 2 * T_i[i][i+1] * c * s + T_i[i+1][i+1] * s**2
                T_i[i][i+1] = (T_i[i][i] - T_i[i+1][i+1]) * c * s + (T_i[i][i+1] + T_i[i+1][i+1]) * c**2
                T_i[i+1][i] = T_i[i][i+1]
                T_i[i+1][i+1] = -T_i[i][i+1] * s**2 + 2 * T_i[i][i+1] * c * s + T_i[i+1][i+1] * c**2
                
                Q = multiply(Q, Q_i)
                T = multiply(multiply(Q_i, T), transpose(Q_i))
        
        eigenvalues = [T[i][i] for i in range(n)]
        eigenvectors = [Q[:, i] for i in range(n)]
        
        return eigenvalues, eigenvectors
    
    def identity(n):
        return [[1 if i == j else 0 for j in range(n)] for i in range(n)]
    
    def copy(matrix):
        n = len(matrix)
        return [[matrix[i][j] for j in range(n)] for i in range(n)]
    
    def random_instance(n, m):
        clauses = []
        for _ in range(m):
            clause = [random.randint(-n, n) for _ in range(random.randint(1, n))]
            clauses.append(clause)
        return clauses
    
    def hermitian_matrix(clauses, n):
        A = [[0] * (2*n) for _ in range(2*n)]
        for clause in clauses:
            for lit in clause:
                row, col = abs(lit)-1, 2*(abs(lit)-1)
                if lit > 0:
                    A[row][col] += 1
                else:
                    A[row][col+1] += 1
        return A
    
    def geometric_entropy(A):
        eigenvalues = power_method(A, 100)  # Power method to find the largest eigenvalue
        H = -sum(eigenvalue * math.log2(eigenvalue) for eigenvalue in eigenvalues if eigenvalue > 0)
        return H
    
    def power_method(matrix, max_iter=100):
        n = len(matrix)
        v = [random.random() for _ in range(n)]
        v /= sum(v)
        
        for _ in range(max_iter):
            Av = matrix @ v
            Av /= sum(Av)
            v = Av
        
        return Av
    
    def delta_phi(clauses, n):
        assignments = list(itertools.product([-1, 1], repeat=n))
        valid_assignments = [assignment for assignment in assignments if all(lit * assignment[abs(lit)-1] >= 0 for lit in clauses)]
        return len(valid_assignments)
    
    def is_square(matrix):
        n = len(matrix)
        return all(len(row) == n for row in matrix)
    
    def normalize(matrix):
        n = len(matrix)
        norm = sum(sum(abs(x) for x in row) for row in matrix)
        return [[x / norm for x in row] for row in matrix]
    
    def multiply(A, B):
        n = len(A)
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                for k in range(n):
                    C[i][j] += A[i][k] * B[k][j]
        return C
    
    def transpose(matrix):
        n = len(matrix)
        return [[matrix[j][i] for j in range(n)] for i in range(n)]
    
    def inverse(matrix):
        n = len(matrix)
        I = [[1 if i == j else 0 for j in range(n)] for i in range(n)]
        Aaug = [row + col for row, col in zip(matrix, I)]
        
        for i in range(n):
            max_row = max(range(i, n), key=lambda r: abs(Aaug[r][i]))
            if Aaug[max_row][i] == 0:
                return None  # Singular matrix
            Aaug[i], Aaug[max_row] = Aaug[max_row], Aaug[i]
            
            for j in range(n):
                Aaug[i][j] /= Aaug[i][i]
            
            for k in range(n):
                if k != i:
                    factor = Aaug[k][i]
                    for j in range(2*n):
                        Aaug[k][j] -= factor * Aaug[i][j]
        
        return [row[n:] for row in Aaug]
    
    def norm(matrix):
        n = len(matrix)
        return math.sqrt(sum(sum(x**2 for x in row) for row in matrix))
    
    def normalize_rows(matrix):
        n = len(matrix)
        return [[x / sum(row) if sum(row) != 0 else 0 for x in row] for row in matrix]
    
    def normalize_columns(matrix):
        n = len(matrix)
        return [[x / sum(col) if sum(col) != 0 else 0 for col in zip(*matrix)] for row in matrix]
    
    def is_diagonalizable(matrix):
        n = len(matrix)
        eigenvalues, eigenvectors = diagonalize(matrix)
        return all(eigenvalue == eigenvector[0] for eigenvalue, eigenvector in zip(eigenvalues, eigenvectors))
    
    def diagonalize(matrix):
        n = len(matrix)
        A = normalize(matrix)
        Q = identity(n)
        T = copy(A)
        
        for i in range(n-1):
            if abs(T[i+1][i]) > 1e-10:
                c = (T[i][i] - T[i+1][i+1]) / (2 * T[i+1][i])
                s = math.sqrt(1 + c**2)
                c /= s
                s /= s
                
                Q_i = identity(n)
                Q_i[i][i] = c
                Q_i[i+1][i+1] = c
                Q_i[i][i+1] = -s
                Q_i[i+1][i] = s
                
                T_i = copy(T)
                T_i[i][i] = T_i[i][i] * c**2 + 2 * T_i[i][i+1] * c * s + T_i[i+1][i+1] * s**2
                T_i[i][i+1] = (T_i[i][i] - T_i[i+1][i+1]) * c * s + (T_i[i][i+1] + T_i[i+1][i+1]) * c**2
                T_i[i+1][i] = T_i[i][i+1]
                T_i[i+1][i+1] = -T_i[i][i+1] * s**2 + 2 * T_i[i][i+1] * c * s + T_i[i+1][i+1] * c**2
                
                Q = multiply(Q, Q_i)
                T = multiply(multiply(Q_i, T), transpose(Q_i))
        
        eigenvalues = [T[i][i] for i in range(n)]
        eigenvectors = [Q[:, i] for i in range(n)]
        
        return eigenvalues, eigenvectors
    
    def identity(n):
        return [[1 if i == j else 0 for j in range(n)] for i in range(n)]
    
    def copy(matrix):
        n = len(matrix)
        return [[matrix[i][j] for j in range(n)] for i in range(n)]
    
    def random_instance(n, m):
        clauses = []
        for _ in range(m):
            clause = [random.randint(-n, n) for _ in range(random.randint(1, n))]
            clauses.append(clause)
        return clauses
    
    def hermitian_matrix(clauses, n):
        A = [[0] * (2*n) for _ in range(2*n)]
        for clause in clauses:
            for lit in clause:
                row, col = abs(lit)-1, 2*(abs(lit)-1)
                if lit > 0:
                    A[row][col] += 1
                else:
                    A[row][col+1] += 1
        return A
    
    def geometric_entropy(A):
        eigenvalues = power_method(A, 100)  # Power method to find the largest eigenvalue
        H = -sum(eigenvalue * math.log2(eigenvalue) for eigenvalue in eigenvalues if eigenvalue > 0)
        return H
    
    def power_method(matrix, max_iter=100):
        n = len(matrix)
        v = [random.random() for _ in range(n)]
        v /= sum(v)
        
        for _ in range(max_iter):
            Av = matrix @ v
            Av /= sum(Av)
            v = Av
        
        return Av
    
    def delta_phi(clauses, n):
        assignments = list(itertools.product([-1, 1], repeat=n))
        valid_assignments = [assignment for assignment in assignments if all(lit * assignment[abs(lit)-1] >= 0 for lit in clauses)]
        return len(valid_assignments)
    
    def is_square(matrix):
        n = len(matrix)
        return all(len(row) == n for row in matrix)
    
    def normalize(matrix):
        n = len(matrix)
        norm = sum(sum(abs(x) for x in row) for row in matrix)
        return [[x / norm for x in row] for row in matrix]
    
    def multiply(A, B):
        n = len(A)
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                for k in range(n):
                    C[i][j] += A[i][k] * B[k][j]
        return C
    
    def transpose(matrix):
        n = len(matrix)
        return [[matrix[j][i] for j in range(n)] for i in range(n)]
    
    def inverse(matrix):
        n = len(matrix)
        I = [[1 if i == j else 0 for j in range(n)] for i in range(n)]
        Aaug = [row + col for row, col in zip(matrix, I)]
        
        for i in range(n):
            max_row = max(range(i, n), key=lambda r: abs(Aaug[r][i]))
            if Aaug[max_row][i] == 0:
                return None  # Singular matrix
            Aaug[i], Aaug[max_row] = Aaug[max_row], Aaug[i]
            
            for j in range(n):
                Aaug[i][j] /= Aaug[i][i]
            
            for k in range(n):
                if k != i:
                    factor = Aaug[k][i]
                    for j in range(2*n):
                        Aaug[k][j] -= factor * Aaug[i][j]
        
        return [row[n:] for row in Aaug]
    
    def norm(matrix):
        n = len(matrix)
        return math.sqrt(sum(sum(x**2 for x in row) for row in matrix))
    
    def normalize_rows(matrix):
        n = len(matrix)
        return [[x / sum(row) if sum(row) != 0 else 0 for x in row] for row in matrix]
    
    def normalize_columns(matrix):
        n = len(matrix)
        return [[x / sum(col) if sum(col) != 0 else 0 for col in zip(*matrix)] for row in matrix]
    
    def is_diagonalizable(matrix):
        n = len(matrix)
        eigenvalues, eigenvectors = diagonalize(matrix)
        return all(eigenvalue == eigenvector[0] for eigenvalue, eigenvector in zip(eigenvalues, eigenvectors))
    
    def diagonalize(matrix):
        n = len(matrix)
        A = normalize(matrix)
        Q = identity(n)
        T = copy(A)
        
        for i in range(n-1):
            if abs(T[i+1][i]) > 1e-10:
                c = (T[i][i] - T[i+1][i+1]) / (2 * T[i+1][i])
                s = math.sqrt(1 + c**2)
                c /= s
                s /= s
                
                Q_i = identity(n)
                Q_i[i][i] = c
                Q_i[i+1][i+1] = c
                Q_i[i][i+1] = -s
                Q_i[i+1][i] = s
                
                T_i = copy(T)
                T_i[i][i] = T_i[i][i] * c**2 + 2 * T_i[i][i+1] * c * s + T_i[i+1][i+1] * s**2
                T_i[i][i+1] = (T_i[i][i] - T_i[i+1][i+1]) * c * s + (T_i[i][i+1] + T_i[i+1][i+1]) * c**2
                T_i[i+1][i] = T_i[i][i+1]
                T_i[i+1][i+1] = -T_i[i][i+1] * s**2 + 2 * T_i[i][i+1] * c * s + T_i[i+1][i+1] * c**2
                
                Q = multiply(Q, Q_i)
                T = multiply(multiply(Q_i, T), transpose(Q_i))
        
        eigenvalues = [T[i][i] for i in range(n)]
        eigenvectors = [Q[:, i] for i in range(n)]
        
        return eigenvalues, eigenvectors
    
    def identity(n):
        return [[1 if i == j else 0 for j in range(n)] for i in range(n)]
    
    def copy(matrix):
        n = len(matrix)
        return [[matrix[i][j] for j in range(n)] for i in range(n)]
    
    def random_instance(n, m):
        clauses = []
        for _ in range(m):
            clause = [random.randint(-n, n) for _ in range(random.randint(1, n))]
            clauses.append(clause)
        return clauses
    
    def hermitian_matrix(clauses, n):
        A = [[0] * (2*n) for _ in range(2*n)]
        for clause in clauses:
            for lit in clause:
                row, col = abs(lit)-1, 2*(abs(lit)-1)
                if lit > 0:
                    A[row][col] += 1
                else:
                    A[row][col+1] += 1
        return A
    
    def geometric_entropy(A):
        eigenvalues = power_method(A, 100)  # Power method to find the largest eigenvalue
        H = -sum(eigenvalue * math.log2(eigenvalue) for eigenvalue in eigenvalues if eigenvalue > 0)
        return H
    
    def power_method(matrix, max_iter=100):
        n = len(matrix)
        v = [random.random() for _ in range(n)]
        v /= sum(v)
        
        for _ in range(max_iter):
            Av = matrix @ v
            Av /= sum(Av)
            v = Av
        
        return Av
    
    def delta_phi(clauses, n):
        assignments = list(itertools.product([-1, 1], repeat=n))
        valid_assignments = [assignment for assignment in assignments if all(lit * assignment[abs(lit)-1] >= 0 for lit in clauses)]
        return len(valid_assignments)
    
    def is_square(matrix):
        n = len(matrix)
        return all(len(row) == n for row in matrix)
    
    def normalize(matrix):
        n = len(matrix)
        norm = sum(sum(abs(x) for x in row) for row in matrix)
        return [[x / norm for x in row] for row in matrix]
    
    def multiply(A, B):
        n = len(A)
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                for k in range(n):
                    C[i][j] += A[i][k] * B[k][j]
        return C
    
    def transpose(matrix):
        n = len(matrix)
        return [[matrix[j][i] for j in range(n)] for i in range(n)]
    
    def inverse(matrix):
        n = len(matrix)
        I = [[1 if i == j else 0 for j in range(n)] for i in range(n)]
        Aaug = [row + col for row, col in zip(matrix, I)]
        
        for i in range(n):
            max_row = max(range(i, n), key=lambda r: abs(Aaug[r][i]))
            if Aaug[max_row][i] == 0: