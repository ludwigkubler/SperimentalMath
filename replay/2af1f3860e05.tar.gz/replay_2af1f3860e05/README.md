# Replay package — entry 2af1f3860e05

Conjecture: Real Rank Lower Bound for ACC^0 Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-29 07:53 UTC.
Pre-registration hash committed before this test ran: `c3488a6fdaa3bb42`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
