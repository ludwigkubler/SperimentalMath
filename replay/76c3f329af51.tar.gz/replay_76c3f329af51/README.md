# Replay package — entry 76c3f329af51

Conjecture: Minimal Gromov-Wasserstein Distance and Circuit Size for k-Clique

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 21:29 UTC.
Pre-registration hash committed before this test ran: `765f99bef45a0ce6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
