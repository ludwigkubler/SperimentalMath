# Replay package — entry d9192d086450

Conjecture: Minimal Order of Frobenius-Schur Indicators and Circuit Entanglement Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 22:58 UTC.
Pre-registration hash committed before this test ran: `a6fa7354de6bb723`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
