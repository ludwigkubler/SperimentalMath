# Replay package — entry 2161bbe9ad19

Conjecture: Minimal Rank of Tropical Logarithmic Forms vs Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 21:24 UTC.
Pre-registration hash committed before this test ran: `e56a3afd370267e6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
