# Replay package — entry af48c5f5dddf

Conjecture: Minimal Rank of Hodge Classes over Tseitin Circuit Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 13:30 UTC.
Pre-registration hash committed before this test ran: `c6ea109996f195c6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
