# Replay package — entry 9336a97eb5e6

Conjecture: Minimal Rank of Non-Archimedean Valuations over DPLL Search Trees

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 12:40 UTC.
Pre-registration hash committed before this test ran: `fd7c755b160f6da8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
