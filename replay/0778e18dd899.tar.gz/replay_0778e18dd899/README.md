# Replay package — entry 0778e18dd899

Conjecture: Antichain Cover Number of KW Relation Lower-Bounds Monotone Formula Leaves

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 18:14 UTC.
Pre-registration hash committed before this test ran: `56037bc93c077438`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
