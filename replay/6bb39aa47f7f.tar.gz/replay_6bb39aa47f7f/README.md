# Replay package — entry 6bb39aa47f7f

Conjecture: Minimal Tropical Growth Rate of Polynomial Systems vs AC0 Parity Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 18:37 UTC.
Pre-registration hash committed before this test ran: `e9c30d39aa289abb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
