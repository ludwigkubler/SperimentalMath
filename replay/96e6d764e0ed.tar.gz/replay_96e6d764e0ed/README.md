# Replay package — entry 96e6d764e0ed

Conjecture: Minimal Rank of Sheaf Cohomology over Affine Schemes vs Circuit Lower Bounds for XOR Tautologies

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 10:13 UTC.
Pre-registration hash committed before this test ran: `b587858d7f1f6a8a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
