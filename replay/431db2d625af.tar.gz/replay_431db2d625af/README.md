# Replay package — entry 431db2d625af

Conjecture: Minimal Local Cohomology in Algebraic Geometry of Boolean Functions and Communication Complexity Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 03:15 UTC.
Pre-registration hash committed before this test ran: `fddec5dfd6733118`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
