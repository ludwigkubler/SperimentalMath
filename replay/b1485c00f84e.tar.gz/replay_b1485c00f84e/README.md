# Replay package — entry b1485c00f84e

Conjecture: Minimal Order of Hodge Decomposition and SAT Clause Subset Complexity Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 03:50 UTC.
Pre-registration hash committed before this test ran: `72346db82fef4cda`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
