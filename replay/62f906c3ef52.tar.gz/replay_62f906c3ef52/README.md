# Replay package — entry 62f906c3ef52

Conjecture: Symmetric Decomposition Coefficient Count Inversely Proportional to Deterministic Communication Complexity for XOR Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-13 12:08 UTC.
Pre-registration hash committed before this test ran: `c6c3a1984fce30c5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
