# Replay package — entry f5574a6cc9ec

Conjecture: Irreducible Component Count Inversely Proportional to ACC⁰ Circuit Size for Sipser-like Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 23:21 UTC.
Pre-registration hash committed before this test ran: `555e3d9af07a2c16`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
