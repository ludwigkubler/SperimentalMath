# Replay package — entry af82d173ff1a

Conjecture: Minimal Local Cohomology Rank over XOR-AND Tree Width of Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 11:11 UTC.
Pre-registration hash committed before this test ran: `03d61c7dba8269aa`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
