# Replay package — entry 0cc0a74d9dc9

Conjecture: Minimal Rank of Algebraic Hodge Decomposition over Boolean Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 18:41 UTC.
Pre-registration hash committed before this test ran: `5d2f73da455770b1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
