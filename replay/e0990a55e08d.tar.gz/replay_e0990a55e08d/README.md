# Replay package — entry e0990a55e08d

Conjecture: Coxeter Group Action Count and Circuit Lower Bounds for Monotone k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 12:25 UTC.
Pre-registration hash committed before this test ran: `17306bbf5ebaec88`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
