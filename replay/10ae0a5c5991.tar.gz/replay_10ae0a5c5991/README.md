# Replay package — entry 10ae0a5c5991

Conjecture: Minimal Hodge-theoretic Index and Frege Proof Depth Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 11:12 UTC.
Pre-registration hash committed before this test ran: `b78aacc6b81cfd0a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
