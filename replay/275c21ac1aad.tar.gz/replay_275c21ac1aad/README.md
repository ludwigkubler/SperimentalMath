# Replay package — entry 275c21ac1aad

Conjecture: Minimal Rank of Tensor Product of Polynomial Algebras Bounds Frege Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 04:33 UTC.
Pre-registration hash committed before this test ran: `8af92ca471b9e3b0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
