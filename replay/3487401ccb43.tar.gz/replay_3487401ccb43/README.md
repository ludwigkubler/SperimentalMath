# Replay package — entry 3487401ccb43

Conjecture: Minimal Rank of Tropicalized Symplectic Geometry over Manifolds vs AC0 Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 01:06 UTC.
Pre-registration hash committed before this test ran: `ed6b02d96eec339d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
