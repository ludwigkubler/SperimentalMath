# Replay package — entry fe4202f3ac75

Conjecture: Seed Length Optimality for Nisan-Wigderson PRGs in Fooling AC^0 Circuits

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 06:26 UTC.
Pre-registration hash committed before this test ran: `0e631bb7ec9a6550`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
