# Replay package — entry 1c07529f0c6c

Conjecture: Algebraic Automorphic Forms and DPLL Refutation Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 14:56 UTC.
Pre-registration hash committed before this test ran: `03dbc52c08a47174`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
