import sys
import random
import math
from itertools import permutations, combinations
from fractions import Fraction

def factorial(n):
    if n == 0:
        return 1
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result

def hook_walk(n):
    def hook_length_partition(n):
        partition = [n]
        while len(partition) < n:
            new_part = min(partition)
            partition.remove(new_part)
            partition.append(new_part - 1)
            partition.append(1)
        return partition
    
    def count_inversion_compatible_tableaux(n, partition):
        if n == 1:
            return 1
        count = 0
        for i in range(1, n + 1):
            new_partition = partition[:]
            new_partition[0] -= 1
            new_partition.insert(i - 1, 1)
            count += count_inversion_compatible_tableaux(n - 1, new_partition)
        return count
    
    partition = hook_length_partition(n)
    return count_inversion_compatible_tableaux(n, partition)

def permanent(matrix):
    n = len(matrix)
    if n == 0:
        return 0
    elif n == 1:
        return matrix[0][0]
    else:
        det = 0
        for j in range(n):
            submatrix = [row[:j] + row[j+1:] for row in matrix[1:]]
            sign = (-1) ** j
            det += sign * matrix[0][j] * permanent(submatrix)
        return det

def determinant(matrix):
    n = len(matrix)
    if n == 0:
        return 0
    elif n == 1:
        return matrix[0][0]
    else:
        det = 0
        for j in range(n):
            submatrix = [row[:j] + row[j+1:] for row in matrix[1:]]
            sign = (-1) ** j
            det += sign * matrix[0][j] * determinant(submatrix)
        return det

def tensor_rank(tensor, eps=1e-9):
    n = len(tensor)
    rank = 0
    while True:
        max_norm = 0
        for i in range(n):
            for j in range(n):
                norm = sum(abs(tensor[k][i][j]) for k in range(n))
                if norm > max_norm:
                    max_norm = norm
                    u = [tensor[k][i][j] / norm for k in range(n)]
                    v = [sum(tensor[k][i][j] * tensor[k][l][j] for k in range(n)) for l in range(n)]
        if max_norm < eps:
            break
        rank += 1
        for i in range(n):
            for j in range(n):
                tensor[i][j] -= u[i] * v[j]
    return rank

def run_trial(seed: int) -> dict:
    random.seed(seed)
    results = []
    for n in [2, 3, 4, 5, 6, 7]:
        Per_n = [[random.choice([0, 1]) for _ in range(n)] for _ in range(n)]
        Det_n = [[random.choice([0, 1]) for _ in range(n)] for _ in range(n)]
        
        T_Per_n = [[[Per_n[i][j] * Per_n[k][l] if (i == k and j == l) else 0 for l in range(n!)] for k in range(n)] for j in range(n)]
        T_Det_n = [[[Det_n[i][j] * Det_n[k][l] if (i == k and j == l) else 0 for l in range(n!)] for k in range(n)] for j in range(n)]
        
        SYT_n = hook_walk(n)
        B_n = math.ceil(math.log2(SYT_n / factorial(n)))
        
        D_n = tensor_rank(T_Per_n) - tensor_rank(T_Det_n)
        
        results.append({
            "n": n,
            "D_n": D_n,
            "B_n": B_n
        })
    
    metric_value = sum(result["D_n"] for result in results)
    instances_tested = len(results)
    conjecture_holds = all(result["D_n"] >= result["B_n"] for result in results) and all(result["D_n"] == result["B_n"] if result["n"] <= 3 else True for result in results)
    counterexample = "" if conjecture_holds else "mapping_undefined"
    
    return {
        "metric_name": "border_rank_difference",
        "metric_value": metric_value,
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    seeds = [int(s) for s in sys.argv[1:]] or [11, 23, 37, 53, 71]
    results = []
    
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    mean_value = sum(result["metric_value"] for result in results) / len(results)
    std_value = math.sqrt(sum((result["metric_value"] - mean_value) ** 2 for result in results) / len(results))
    support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)
    
    if all(result["conjecture_holds"] for result in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not result["conjecture_holds"] for result in results):
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"mapping_undefined\" first_failing_seed={first_failing_seed}")
    else:
        print(f"RESULT: INCONCLUSIVE mapping_undefined")