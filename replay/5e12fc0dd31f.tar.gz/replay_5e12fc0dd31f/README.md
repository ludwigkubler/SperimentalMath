# Replay package — entry 5e12fc0dd31f

Conjecture: Gonality Lower Bounds for Disjointness Communication Matrices

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 11:01 UTC.
Pre-registration hash committed before this test ran: `2c6ad11df6362c80`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
