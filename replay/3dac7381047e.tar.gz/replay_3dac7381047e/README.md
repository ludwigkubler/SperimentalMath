# Replay package — entry 3dac7381047e

Conjecture: Real Stable Rank Lower-Bounds AC⁰ PARITY Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 07:54 UTC.
Pre-registration hash committed before this test ran: `4845e18ab2e55319`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
