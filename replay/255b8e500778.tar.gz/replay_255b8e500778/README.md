# Replay package — entry 255b8e500778

Conjecture: Minimal Index of p-Adic Hodge Structures and DPLL Search Tree Diameter

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 08:59 UTC.
Pre-registration hash committed before this test ran: `80bcc69d0d72dfa6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
