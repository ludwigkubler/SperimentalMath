# Replay package — entry 0c8d03960af3

Conjecture: Minimal Order of Groupoid Representations and Communication Complexity Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 17:44 UTC.
Pre-registration hash committed before this test ran: `eb221e3cf530e462`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
