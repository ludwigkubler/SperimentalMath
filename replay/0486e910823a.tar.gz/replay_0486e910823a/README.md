# Replay package — entry 0486e910823a

Conjecture: Minimal Rank of Noncommutative Differential Forms vs AC0 Parity Circuit Threshold

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 03:29 UTC.
Pre-registration hash committed before this test ran: `133b2db7bafbc203`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
