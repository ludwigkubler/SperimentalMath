# Replay package — entry 3e4938e4b55f

Conjecture: Coxeter Group Actions on Boolean Functions Bound Communication Complexity for XOR

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 07:21 UTC.
Pre-registration hash committed before this test ran: `fe462cc7af22b0fe`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
