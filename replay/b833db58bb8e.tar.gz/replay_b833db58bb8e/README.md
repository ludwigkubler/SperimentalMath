# Replay package — entry b833db58bb8e

Conjecture: Minimal Order of Quadratic Forms and Communication Complexity Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 15:50 UTC.
Pre-registration hash committed before this test ran: `1a99ee70984fcbf0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
