# Replay package — entry db8920af08de

Conjecture: Minimal Rank of Algebraic K-Theory over Quotient Rings Bounds BP Read-Twice Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 12:32 UTC.
Pre-registration hash committed before this test ran: `2b93409ed1e7b383`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
