# Replay package — entry 7d784a7c24a5

Conjecture: Minimal Rank of Groupoid Actions over SAT Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 14:55 UTC.
Pre-registration hash committed before this test ran: `8c7f8ce002651e8d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
