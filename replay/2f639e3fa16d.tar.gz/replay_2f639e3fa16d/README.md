# Replay package — entry 2f639e3fa16d

Conjecture: Minimal Rank of Birfield Theory Bounds Monotone Circuit Size for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 00:27 UTC.
Pre-registration hash committed before this test ran: `fb1f24da99c347a6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
