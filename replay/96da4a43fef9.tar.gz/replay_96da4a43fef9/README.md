# Replay package — entry 96da4a43fef9

Conjecture: Minimal Quotient Rank of Tropical Curves and SOS Hierarchy Approximation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 09:13 UTC.
Pre-registration hash committed before this test ran: `7a3783d029963bce`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
