# Replay package — entry 92f0ad093ddc

Conjecture: Minimal Order of Frobenius Schur Indicators and Circuit Weights Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 14:55 UTC.
Pre-registration hash committed before this test ran: `da65acf09ca2f02b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
