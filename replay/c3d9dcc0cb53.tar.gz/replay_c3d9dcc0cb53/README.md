# Replay package — entry c3d9dcc0cb53

Conjecture: Minimal Root Systems in Geometry Bounds Circuit Size of k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 00:21 UTC.
Pre-registration hash committed before this test ran: `50e7c532b27443cb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
