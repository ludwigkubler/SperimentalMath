# Replay package — entry e2d883c9b94b

Conjecture: Minimal Rank of Noncommutative Differential Geometry over Function Fields vs ACC⁰ Circuit Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 14:09 UTC.
Pre-registration hash committed before this test ran: `62e77956f2930fed`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
