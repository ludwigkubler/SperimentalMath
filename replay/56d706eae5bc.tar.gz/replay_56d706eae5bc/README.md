# Replay package — entry 56d706eae5bc

Conjecture: Minimal Local Index of Tropical Motivic Cohomology Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 12:59 UTC.
Pre-registration hash committed before this test ran: `e4c888e33afa86d0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
