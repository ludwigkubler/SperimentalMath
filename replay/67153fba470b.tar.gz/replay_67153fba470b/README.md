# Replay package — entry 67153fba470b

Conjecture: Hessian-Rank of Clause-Count Polynomial Bounds DPLL Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 22:23 UTC.
Pre-registration hash committed before this test ran: `ed66eacd778f61d8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
