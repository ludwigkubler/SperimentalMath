# Replay package — entry 9dfcbea8b0a8

Conjecture: Baker-Norine ω-Gonality Lower-Bounds Tseitin DPLL Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 19:38 UTC.
Pre-registration hash committed before this test ran: `eb23cc2c77664282`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
