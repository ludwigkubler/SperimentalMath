import random
from fractions import Fraction
import sys
import math
import itertools
import collections

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_random_f(k):
        return [random.choice([-1, 1]) for _ in range(2**k)]
    
    def generate_structured_f(k, family):
        if family == 'IP_k':
            return [sum(f[i] * f[j] for i in range(k) for j in range(i+1, k)) for f in itertools.product([-1, 1], repeat=2**k)]
        elif family == 'EQ_k':
            return [sum(f[i] * f[j] for i in range(k) for j in range(i+1, k)) - sum(f[k+i] * f[k+j] for i in range(k) for j in range(i+1, k)) for f in itertools.product([-1, 1], repeat=2**k)]
        elif family == 'GT_k':
            return [sum(f[i] * f[j] for i in range(k) for j in range(i+1, k)) - sum(f[k+i] * f[k+j] for i in range(k) for j in range(i+1, k)) + 1 for f in itertools.product([-1, 1], repeat=2**k)]
        elif family == 'AND-of-XORs':
            return [sum(f[i] & f[j] for i in range(2**k)) for f in itertools.product([-1, 1], repeat=2**k)]
        elif family == 'MAJ_k(x XOR y)':
            return [sum(f[i] * (f[i] ^ f[j]) for i in range(k) for j in range(i+1, k))) for f in itertools.product([-1, 1], repeat=2**k)]
        else:
            raise ValueError("Unsupported family")
    
    def generate_low_rank_matrix(n, r):
        generators = [generate_random_f(math.ceil(math.log2(n))) for _ in range(r)]
        matrix = [[sum(g[i] * g[j] for j in range(r)) % 2 for i in range(n)] for g in generators]
        return matrix
    
    def projective_hamming_distance(row1, row2):
        return min(sum(a != b for a, b in zip(row1, row2)), len(row1) - sum(a != b for a, b in zip(row1, row2)))
    
    def union_find(n):
        parent = list(range(n))
        rank = [0] * n
        
        def find(x):
            if parent[x] != x:
                parent[x] = find(parent[x])
            return parent[x]
        
        def union(x, y):
            rootX = find(x)
            rootY = find(y)
            if rootX != rootY:
                if rank[rootX] > rank[rootY]:
                    parent[rootY] = rootX
                elif rank[rootX] < rank[rootY]:
                    parent[rootX] = rootY
                else:
                    parent[rootY] = rootX
                    rank[rootX] += 1
        
        return union, find
    
    def gaussian_elimination(matrix):
        n = len(matrix)
        m = len(matrix[0])
        augmented_matrix = [row + [Fraction(0)] for row in matrix]
        
        for i in range(n):
            max_row = i
            for j in range(i+1, n):
                if abs(augmented_matrix[j][i]) > abs(augmented_matrix[max_row][i]):
                    max_row = j
            
            augmented_matrix[i], augmented_matrix[max_row] = augmented_matrix[max_row], augmented_matrix[i]
            
            pivot = augmented_matrix[i][i]
            for j in range(m):
                augmented_matrix[i][j] /= pivot
            
            for j in range(n):
                if i != j:
                    factor = augmented_matrix[j][i]
                    for k in range(m):
                        augmented_matrix[j][k] -= factor * augmented_matrix[i][k]
        
        rank = 0
        for row in augmented_matrix:
            if any(row[i] != Fraction(0) for i in range(m)):
                rank += 1
        
        return rank
    
    def compute_rk_R(matrix):
        n = len(matrix)
        m = len(matrix[0])
        integer_matrix = [[Fraction(matrix[i][j]) for j in range(m)] for i in range(n)]
        return gaussian_elimination(integer_matrix)
    
    def compute_tau_plus_minus(M, k):
        n = len(M)
        union, find = union_find(n)
        
        for i in range(n):
            for j in range(i+1, n):
                d = projective_hamming_distance(M[i], M[j])
                if d <= 2**(k-2):
                    union(i, j)
        
        components = set()
        for i in range(n):
            components.add(find(i))
        
        return len(components)
    
    k_values = [3, 4, 5, 6]
    instances_tested = 0
    total_tau_plus_minus = 0
    total_rk_R = 0
    
    for k in k_values:
        n = 2**k
        
        for _ in range(30):
            f = generate_random_f(k)
            M_random = [generate_random_f(n) for _ in range(n)]
            M_structured = generate_structured_f(k, random.choice(['IP_k', 'EQ_k', 'GT_k', 'AND-of-XORs', 'MAJ_k(x XOR y)']))
            M_low_rank = generate_low_rank_matrix(n, 2**k)
            
            for M in [M_random, M_structured, M_low_rank]:
                M = [[Fraction(row[i]) for i in range(n)] for row in M]
                unique_rows = list(set(tuple(row) for row in M))
                tau_plus_minus = compute_tau_plus_minus(unique_rows, k)
                rk_R = compute_rk_R(M)
                
                total_tau_plus_minus += tau_plus_minus
                total_rk_R += rk_R
                instances_tested += 1
    
    mean_tau_plus_minus = total_tau_plus_minus / instances_tested
    mean_rk_R = total_rk_R / instances_tested
    
    conjecture_holds = all(tau_plus_minus <= rk_R for tau_plus_minus, rk_R in zip([mean_tau_plus_minus] * instances_tested, [mean_rk_R] * instances_tested))
    
    return {
        "metric_name": "tau_plus_minus",
        "metric_value": mean_tau_plus_minus,
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": "" if conjecture_holds else "mapping_undefined"
    }

if __name__ == "__main__":
    seeds = [int(s) for s in sys.argv[1:]] or [2**i + 1 for i in range(5, 8)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_tau_plus_minus = sum(r["metric_value"] for r in results) / len(results)
    std_tau_plus_minus = math.sqrt(sum((r["metric_value"] - mean_tau_plus_minus)**2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_tau_plus_minus} std={std_tau_plus_minus} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"mapping_undefined\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE mapping_undefined")