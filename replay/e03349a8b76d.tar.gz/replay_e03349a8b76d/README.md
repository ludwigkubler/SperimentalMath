# Replay package — entry e03349a8b76d

Conjecture: Minimal Tropical Hermitian Rank and DPLL Proof Length Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 11:20 UTC.
Pre-registration hash committed before this test ran: `e9f2da3bee753d3b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
