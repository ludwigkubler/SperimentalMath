# Replay package — entry 8906f7dde118

Conjecture: Minimal Tensor Product Entropy for Read-Twice BP Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 02:21 UTC.
Pre-registration hash committed before this test ran: `22e105237a5c55d8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
