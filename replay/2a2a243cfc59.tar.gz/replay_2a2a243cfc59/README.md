# Replay package — entry 2a2a243cfc59

Conjecture: Minimal Rank of Quotient Sheaves over Affine Schemes vs DPLL Refutation Tree Diameter

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 09:08 UTC.
Pre-registration hash committed before this test ran: `4d43325650e29ee2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
