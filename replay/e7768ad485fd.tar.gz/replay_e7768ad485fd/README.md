# Replay package — entry e7768ad485fd

Conjecture: Minimal Rank of Cocomplexes Bounds Resolution Refutation Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 17:27 UTC.
Pre-registration hash committed before this test ran: `22f389f1543c46f6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
