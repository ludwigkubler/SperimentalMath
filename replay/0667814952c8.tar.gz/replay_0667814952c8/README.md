# Replay package — entry 0667814952c8

Conjecture: Minimal Modular Form Rank and Resolution Proof Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 14:22 UTC.
Pre-registration hash committed before this test ran: `0082b9c87e8e4d08`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
