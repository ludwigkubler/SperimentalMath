# Replay package — entry 231c35be54ba

Conjecture: Minimal Order of Galois Representations over Tseitin Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 14:33 UTC.
Pre-registration hash committed before this test ran: `7cb46b4b4e7d4bc0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
