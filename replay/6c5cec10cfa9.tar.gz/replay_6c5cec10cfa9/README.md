# Replay package — entry 6c5cec10cfa9

Conjecture: Hypergeometric Function Moments Lower Bound for Read-Twice BP Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 14:33 UTC.
Pre-registration hash committed before this test ran: `d910391b283b8392`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
