# Replay package — entry 51d7c2e9512a

Conjecture: Restriction-Local Fourier Doubling Gap for ACC[2] vs Sipser

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 18:51 UTC.
Pre-registration hash committed before this test ran: `a4df5696d5f5589f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
