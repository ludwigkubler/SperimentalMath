# Replay package — entry ab358a8d3f4d

Conjecture: Minimal Local Indefinite Integral and Resolution Proof Width Correlation via Non-Commutative Geometry

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 10:31 UTC.
Pre-registration hash committed before this test ran: `a27a58652be50285`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
