# Replay package — entry 1947d5fb4445

Conjecture: Laplacian Eigenvalue Deficit Bounds SOS Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 18:47 UTC.
Pre-registration hash committed before this test ran: `ef1e382bbc2a1407`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
