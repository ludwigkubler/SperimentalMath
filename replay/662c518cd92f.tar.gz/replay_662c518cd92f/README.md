# Replay package — entry 662c518cd92f

Conjecture: Minimal Rank of Schur-Weyl Module Decomposition in Boolean Functions vs Circuit Lower Bounds for Monotone Circuits

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 12:33 UTC.
Pre-registration hash committed before this test ran: `973858d214da6de3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
