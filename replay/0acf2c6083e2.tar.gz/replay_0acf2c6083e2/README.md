# Replay package — entry 0acf2c6083e2

Conjecture: Noncommutative L^p Norm Lower Bounds for Disjointness

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 06:07 UTC.
Pre-registration hash committed before this test ran: `f1c1a638f0a34ac1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
