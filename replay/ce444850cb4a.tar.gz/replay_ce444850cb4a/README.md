# Replay package — entry ce444850cb4a

Conjecture: Three-Distance Beatty Ordering Matches Avg DPLL on Random 3-SAT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 08:28 UTC.
Pre-registration hash committed before this test ran: `89d3e86700be9013`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
