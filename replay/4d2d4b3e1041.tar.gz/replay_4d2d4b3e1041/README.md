# Replay package — entry 4d2d4b3e1041

Conjecture: Minimal Kostant Section Dimension and SAT Clause Subset Complexity Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 13:31 UTC.
Pre-registration hash committed before this test ran: `2ed0d936ded30801`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
