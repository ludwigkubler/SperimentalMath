# Replay package — entry 28168464ab42

Conjecture: Minimal Order of Local Units in Adjoint Group and Communication Complexity Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 13:49 UTC.
Pre-registration hash committed before this test ran: `62a59f190d8b9a60`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
