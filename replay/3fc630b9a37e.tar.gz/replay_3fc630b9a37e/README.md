# Replay package — entry 3fc630b9a37e

Conjecture: Real Rank of SOS Moment Matrices for Max-CUT Bounded by Degree

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 18:08 UTC.
Pre-registration hash committed before this test ran: `f93b57b11d86eca1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
