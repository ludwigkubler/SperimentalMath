# Replay package — entry 601b549ae4a5

Conjecture: Minimal Rank of K-Theory Bounds Resolution Proof Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 04:12 UTC.
Pre-registration hash committed before this test ran: `f72c4700181279fe`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
