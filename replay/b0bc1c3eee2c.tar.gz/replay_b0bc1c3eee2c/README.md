# Replay package — entry b0bc1c3eee2c

Conjecture: Schur-Weyl Multiplicity Gap in Symmetric Powers of Permutation Matrices

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 10:01 UTC.
Pre-registration hash committed before this test ran: `ccecb7de0204ff9e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
