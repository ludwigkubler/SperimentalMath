# Replay package — entry f2533eda1d01

Conjecture: Dilworth Width of Gate-Cone Poset Lower-Bounds AC⁰ PARITY Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 02:31 UTC.
Pre-registration hash committed before this test ran: `9e318e58042e9af2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
