# Replay package — entry 87ba831fceef

Conjecture: Free Entropy Lower Bound for Disjointness Communication Matrices

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 21:31 UTC.
Pre-registration hash committed before this test ran: `eb15aa6342263162`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
