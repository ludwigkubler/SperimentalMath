# Replay package — entry 4e9e9d0e9688

Conjecture: Minimal Rank of Real Algebraic Geometry Invariants vs Sum-of-Squares Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 19:46 UTC.
Pre-registration hash committed before this test ran: `9af04adb7d162cc5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
