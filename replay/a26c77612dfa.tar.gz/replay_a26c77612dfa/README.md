# Replay package — entry a26c77612dfa

Conjecture: Minimal Rank of Tropicalized Poisson Tensor Product over Boolean Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 00:18 UTC.
Pre-registration hash committed before this test ran: `54521d1dae2bca3a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
