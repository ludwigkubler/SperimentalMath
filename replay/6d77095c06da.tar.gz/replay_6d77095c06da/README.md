# Replay package — entry 6d77095c06da

Conjecture: Minimal Rank of Twisted Affine Schemes over XOR-AND Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 17:29 UTC.
Pre-registration hash committed before this test ran: `08d4cbbbc9efc814`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
