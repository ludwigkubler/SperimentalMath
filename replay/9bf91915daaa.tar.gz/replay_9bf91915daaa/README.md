# Replay package — entry 9bf91915daaa

Conjecture: Minimal Rank of Formal Language Invariants vs Resolution Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 21:07 UTC.
Pre-registration hash committed before this test ran: `2304d8c1ab05e758`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
