# Replay package — entry 58628c03994f

Conjecture: Spectral Gap Lower Bounds for Tseitin Resolution Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 09:55 UTC.
Pre-registration hash committed before this test ran: `ef4410e3b44e454e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
