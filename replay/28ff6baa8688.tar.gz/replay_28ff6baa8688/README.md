# Replay package — entry 28ff6baa8688

Conjecture: Minimal Topological Entropy of Planar Embeddings and SAT Clause Set Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 18:57 UTC.
Pre-registration hash committed before this test ran: `c583f789bad0a217`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
