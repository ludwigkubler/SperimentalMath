# Replay package — entry a27d8ed662d7

Conjecture: Minimal Rank of Quaternionic Kähler Manifolds over Tseitin Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 09:23 UTC.
Pre-registration hash committed before this test ran: `187703b02397d8ce`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
