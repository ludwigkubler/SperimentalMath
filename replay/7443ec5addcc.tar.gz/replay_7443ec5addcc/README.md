# Replay package — entry 7443ec5addcc

Conjecture: Semialgebraic Dimension Bounds for SOS Approximation of Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 10:27 UTC.
Pre-registration hash committed before this test ran: `488aec0533f65aef`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
