# Replay package — entry 28c3cf3ded57

Conjecture: Symmetric Group Orbit Count Invariant for AC⁰ PARITY Circuits

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 09:36 UTC.
Pre-registration hash committed before this test ran: `0a2bbc56cda6a348`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
