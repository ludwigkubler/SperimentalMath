# Replay package — entry b3173a582d9e

Conjecture: Minimal Rank of Quasi-Frobenius Algebras and DPLL Proof Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 05:38 UTC.
Pre-registration hash committed before this test ran: `e98a3ab9b910cfb2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
