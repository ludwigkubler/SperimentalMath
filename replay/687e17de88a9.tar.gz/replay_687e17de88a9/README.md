# Replay package — entry 687e17de88a9

Conjecture: Minimal Symplectic Form Rank Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 01:00 UTC.
Pre-registration hash committed before this test ran: `54a7f9254e8f6d81`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
