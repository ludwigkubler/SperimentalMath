# Replay package — entry 9d4e7ed1496a

Conjecture: Hodge Diamond Rank of Boolean Algebras vs AC⁰ PARITY Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 00:20 UTC.
Pre-registration hash committed before this test ran: `18bf85d28c909952`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
