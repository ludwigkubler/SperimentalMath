# Replay package — entry 57c4578c4518

Conjecture: Minimal Hodge Span of Tropical Curves Bounds Circuit Depth for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 16:14 UTC.
Pre-registration hash committed before this test ran: `53f3f73ac9a19b32`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
