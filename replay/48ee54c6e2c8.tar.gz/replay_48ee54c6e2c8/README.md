# Replay package — entry 48ee54c6e2c8

Conjecture: Minimal p-Adic Logarithmic Capacity and SAT Clause Depth Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 15:33 UTC.
Pre-registration hash committed before this test ran: `9bff0b7675545d65`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
