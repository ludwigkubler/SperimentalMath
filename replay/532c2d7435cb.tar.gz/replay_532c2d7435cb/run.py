import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_cnf(n):
        clauses = []
        for _ in range(n):
            clause = [random.randint(1, n), -random.randint(1, n)]
            clauses.append(clause)
        return clauses
    
    def permutation_action(cnf, var):
        action = {}
        for literal in cnf:
            if literal[0] == var:
                action[literal[1]] = -var
            elif literal[1] == var:
                action[-literal[0]] = -var
        return action
    
    def linear_representation(action, n):
        representation = []
        for i in range(1, n + 1):
            rep = [0] * (n + 1)
            rep[i] = 1
            for j in range(1, n + 1):
                if j in action:
                    rep[action[j]] += 1
            representation.append(rep)
        return representation
    
    def min_order(representation):
        order = 0
        for row in representation:
            non_zero_count = sum(abs(x) for x in row if x != 0)
            order = max(order, non_zero_count)
        return order
    
    def communication_complexity_rank(cnf):
        # Placeholder function; actual implementation needed
        return len(cnf)
    
    n_values = [5, 10, 15, 20, 30, 40]
    results = []
    
    for n in n_values:
        cnf = generate_cnf(n)
        action = permutation_action(cnf, 1)
        representation = linear_representation(action, n)
        min_order_value = min_order(representation)
        rank = communication_complexity_rank(cnf)
        
        results.append({
            "n": n,
            "min_order": min_order_value,
            "rank": rank
        })
    
    correlation_coefficient = 0.0
    for result in results:
        correlation_coefficient += (result["min_order"] - sum(result["min_order"] for result in results) / len(results)) * \
                                   (result["rank"] - sum(result["rank"] for result in results) / len(results))
    
    correlation_coefficient /= math.sqrt(sum((result["min_order"] - sum(result["min_order"] for result in results) / len(results)) ** 2
                                           for result in results)) *
                                math.sqrt(sum((result["rank"] - sum(result["rank"] for result in results) / len(results)) ** 2
                                          for result in results))
    
    return {
        "metric_name": "correlation_coefficient",
        "metric_value": correlation_coefficient,
        "instances_tested": len(n_values),
        "n_max": max(n_values),
        "conjecture_holds": correlation_coefficient >= 0.7,
        "counterexample": "" if correlation_coefficient >= 0.7 else "mapping_undefined"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(result["metric_value"] for result in results) / len(results)
    std_value = math.sqrt(sum((result["metric_value"] - mean_value) ** 2 for result in results) / len(results))
    support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)
    
    if all(result["conjecture_holds"] for result in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(result["seed"] for result in results if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample='mapping_undefined' first_failing_seed={first_failing_seed}")