# Replay package — entry cb84f01b5db0

Conjecture: Minimal Rank of Twisted Alexander Module over XOR-AND Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 19:42 UTC.
Pre-registration hash committed before this test ran: `4b970b07197f229e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
