# Replay package — entry 496534d5bd8f

Conjecture: Sandpile p-Rank Lower Bound for ACC^0 Circuits Approximating Parity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 18:01 UTC.
Pre-registration hash committed before this test ran: `b3277e181cce8441`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
