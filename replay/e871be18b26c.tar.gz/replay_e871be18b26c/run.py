import random
import math
from collections import defaultdict

def log2_floor(n):
    if n <= 0:
        raise ValueError("log2_floor is not defined for non-positive numbers")
    return int(math.log2(n))

def controlled_cover(R, k):
    N = k + 2**k
    X = [(i >> k) & ((1 << k) - 1), (i & ((1 << k) - 1)) for i in range(N)]
    cover = defaultdict(int)
    
    def bfs(node, radius):
        queue = [node]
        visited = set()
        while queue:
            node = queue.pop(0)
            if node not in visited:
                visited.add(node)
                for neighbor in X:
                    if abs(node - neighbor[0]) <= radius and abs(neighbor[1] - node) <= radius:
                        cover[node] += 1
                        queue.append(neighbor)
    
    for i in range(N):
        bfs(i, R // 2)
    
    return cover

def trace_product(cocycle, operator):
    N = len(operator)
    result = 0
    for i in range(N):
        for j in range(N):
            if operator[i][j] != 0:
                result += cocycle[(i >> k) & ((1 << k) - 1), (i & ((1 << k) - 1))] * \
                          cocycle[(j >> k) & ((1 << k) - 1), (j & ((1 << k) - 1))]
    return result

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    results = []
    for k in [2, 3, 4]:
        N = k + 2**k
        X = [(i >> k) & ((1 << k) - 1), (i & ((1 << k) - 1)) for i in range(N)]
        
        def d_IND_k(x, y):
            return log2_floor(min(abs(x[0] - y[0]), abs(x[1] - y[1])))
        
        max_R = 2**k
        cover_multiplicity = [0] * (max_R + 1)
        
        for R in range(1, max_R + 1):
            cover = controlled_cover(R, k)
            multiplicity = sum(cover.values())
            cover_multiplicity[R] = multiplicity
        
        asdim_slope = (math.log2(sum(multiplicity ** 0.5 for multiplicity in cover_multiplicity)) -
                        math.log2(max_R + 1)) / math.log2(max_R + 1)
        
        T_k = [[0] * N for _ in range(N)]
        c_k = defaultdict(int)
        
        for i in range(N):
            for j in range(N):
                if (i >> k) & ((1 << k) - 1) != (j >> k) & ((1 << k) - 1):
                    T_k[i][j] = 1
                c_k[(i >> k) & ((1 << k) - 1), (i & ((1 << k) - 1))] = (-1) ** i
        
        trace_cocycle_operator = trace_product(c_k, T_k)
        
        results.append({
            "k": k,
            "asdim_slope": asdim_slope,
            "trace_ratio": abs(trace_cocycle_operator / (2**k))
        })
    
    mean_asdim_slope = sum(result["asdim_slope"] for result in results) / len(results)
    mean_trace_ratio = sum(result["trace_ratio"] for result in results) / len(results)
    
    conjecture_holds = all(result["asdim_slope"] >= k - 2 and result["trace_ratio"] >= 0.5 * k for result, k in zip(results, [2, 3, 4]))
    
    return {
        "metric_name": "asdim_slope",
        "metric_value": mean_asdim_slope,
        "instances_tested": len(results),
        "conjecture_holds": conjecture_holds,
        "counterexample": "" if conjecture_holds else f"asdim_slope < k-2 or trace_ratio < 0.5*k for some k"
    }

if __name__ == "__main__":
    seeds = [int(arg) for arg in sys.argv[1:]] or [11, 23, 37, 53, 71]
    
    for seed in seeds:
        result = run_trial(seed)
        print(f'TRIAL: {result}')