# Replay package — entry 4b5de421e063

Conjecture: Real Radical Dimension Bounds SOS Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 22:53 UTC.
Pre-registration hash committed before this test ran: `8e87ed485ec429e8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
