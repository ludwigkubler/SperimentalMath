# Replay package — entry ba26a4ca7784

Conjecture: Free Entropy Gap in Disjointness Communication Matrices

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 07:51 UTC.
Pre-registration hash committed before this test ran: `bb3ab84d08d23e03`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
