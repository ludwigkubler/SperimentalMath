# Replay package — entry 6c8daf2ab19d

Conjecture: S-Transform Free-Mult Defect Lower-Bounds DISJ Communication

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 20:26 UTC.
Pre-registration hash committed before this test ran: `0b299805f1647daf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
