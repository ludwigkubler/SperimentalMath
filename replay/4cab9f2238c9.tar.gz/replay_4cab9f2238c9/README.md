# Replay package — entry 4cab9f2238c9

Conjecture: Minimal Index of Quandle Actions over Tseitin Circuit Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 04:10 UTC.
Pre-registration hash committed before this test ran: `6a55730ba363b78f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
