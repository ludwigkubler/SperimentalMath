# Replay package — entry ab1dddd32214

Conjecture: Minimal Order of Tropical Curves Bounds Davis-Putnam Resolution Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 14:32 UTC.
Pre-registration hash committed before this test ran: `8982a379a45c13af`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
