# Replay package — entry a0e6af1e7a28

Conjecture: Hypercontractive p→2 Norm of Restriction Operator Bounds Resolution Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 20:12 UTC.
Pre-registration hash committed before this test ran: `9f1667702c6eacb5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
