# Replay package — entry e0b483106b38

Conjecture: Minimal Rank of Geometric Langlands Correspondence over SAT Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 11:50 UTC.
Pre-registration hash committed before this test ran: `431d646773bf2b53`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
