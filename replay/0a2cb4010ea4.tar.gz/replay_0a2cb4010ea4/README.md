# Replay package — entry 0a2cb4010ea4

Conjecture: Minimal p-Adic Order of Unitary Groups and DPLL Proof Length Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 08:56 UTC.
Pre-registration hash committed before this test ran: `adf5561feefba987`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
