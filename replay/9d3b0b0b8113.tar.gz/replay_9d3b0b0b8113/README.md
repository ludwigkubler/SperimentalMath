# Replay package — entry 9d3b0b0b8113

Conjecture: Minimal Rank of Algebraic Topology Invariants vs SOS Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 08:48 UTC.
Pre-registration hash committed before this test ran: `085e9e167a08c38b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
