# Replay package — entry 41ae315462ac

Conjecture: Minimal Rank of Symplectic Leaves in Poisson Geometry vs DPLL Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 21:19 UTC.
Pre-registration hash committed before this test ran: `b7a220bc2bc12af9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
