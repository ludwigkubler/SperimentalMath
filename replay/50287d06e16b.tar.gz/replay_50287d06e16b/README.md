# Replay package — entry 50287d06e16b

Conjecture: Non-Abelian Fourier Analysis Determines Resolution Complexity for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 10:11 UTC.
Pre-registration hash committed before this test ran: `1e4c4784f7d8ffa7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
