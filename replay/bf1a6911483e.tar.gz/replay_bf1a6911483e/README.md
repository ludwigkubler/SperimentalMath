# Replay package — entry bf1a6911483e

Conjecture: Toric Varieties and Boolean Circuit Thresholds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 17:29 UTC.
Pre-registration hash committed before this test ran: `95269ccf24a9559e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
