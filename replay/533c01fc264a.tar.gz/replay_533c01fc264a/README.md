# Replay package — entry 533c01fc264a

Conjecture: Minimal Invariant Length of Coxeter Groups and Resolution Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 00:12 UTC.
Pre-registration hash committed before this test ran: `42be98a7ad57d72d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
