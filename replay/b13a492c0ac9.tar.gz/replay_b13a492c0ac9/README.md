# Replay package — entry b13a492c0ac9

Conjecture: Free Cumulant Spread Bounds Disjointness Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-13 02:43 UTC.
Pre-registration hash committed before this test ran: `340258440f6d64ce`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
