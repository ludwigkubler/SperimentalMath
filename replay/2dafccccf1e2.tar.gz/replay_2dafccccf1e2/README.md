# Replay package — entry 2dafccccf1e2

Conjecture: Minimal Symmetry Groups and Circuit Depth Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 17:26 UTC.
Pre-registration hash committed before this test ran: `3eb1f4547e5ad61a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
