# Replay package — entry cec0d90cee68

Conjecture: Additive Energy Bounds for SOS Refutations of Sipser Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-30 23:42 UTC.
Pre-registration hash committed before this test ran: `8d654a697b3702a3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
