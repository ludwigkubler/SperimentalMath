import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_boolean_function(n):
        return [random.randint(0, 1) for _ in range(2**n)]
    
    def tropical_diameter(f):
        n = int(math.log2(len(f)))
        points = [(i, f[i]) for i in range(len(f))]
        max_distance = 0
        for i in range(len(points)):
            for j in range(i + 1, len(points)):
                distance = sum(abs(a - b) for a, b in zip(points[i], points[j]))
                if distance > max_distance:
                    max_distance = distance
        return max_distance
    
    def ac0_circuit_size(f):
        n = int(math.log2(len(f)))
        # Simplified AC0 circuit size estimation (not actual implementation)
        return 2**n
    
    f = generate_boolean_function(random.randint(5, 40))
    trop_diameter = tropical_diameter(f)
    ac0_size = ac0_circuit_size(f)
    
    metric_value = ac0_size
    instances_tested = 1
    conjecture_holds = (ac0_size <= trop_diameter * math.log(len(f)))
    counterexample = "" if conjecture_holds else f"Function {f} with n={len(f)}, TropDiameter={trop_diameter}, AC0Size={ac0_size}"
    
    return {
        "metric_name": "AC0 Circuit Size",
        "metric_value": metric_value,
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    if len(sys.argv[1:]) > 0:
        seeds = [int(s) for s in sys.argv[1:]]
    else:
        # Default list of 30 primes
        seeds = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{results[0]['counterexample']}\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE mapping_undefined")