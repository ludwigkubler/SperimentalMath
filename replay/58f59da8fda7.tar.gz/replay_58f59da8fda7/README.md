# Replay package — entry 58f59da8fda7

Conjecture: Minimal Representation Rank of Quaternion Algebras and BP Read-Twice Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 22:53 UTC.
Pre-registration hash committed before this test ran: `7657317251676648`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
