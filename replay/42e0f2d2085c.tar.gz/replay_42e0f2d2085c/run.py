import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_q_difference_operator(k, n):
        # Placeholder for q-difference operator generation logic
        return [random.randint(0, 1) for _ in range(n)]
    
    def count_non_zero_hypergeometric_coefficients(operator):
        return sum(1 for x in operator if x != 0)
    
    k = random.randint(2, 5)  # Randomly choose k between 2 and 5
    n = random.randint(5, 40)  # Randomly choose n between 5 and 40
    
    operator = generate_q_difference_operator(k, n)
    count = count_non_zero_hypergeometric_coefficients(operator)
    
    metric_value = count
    conjecture_holds = count >= k * math.log(n)
    counterexample = "" if conjecture_holds else f"k={k}, n={n}, count={count}"
    
    return {
        "metric_name": "Non-zero hypergeometric coefficients",
        "metric_value": metric_value,
        "instances_tested": 1,
        "n_max": n,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] if len(sys.argv) > 1 else [random.randint(2, 97) for _ in range(30)]
    
    results = []
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    if all(result["conjecture_holds"] for result in results):
        mean_value = sum(result["metric_value"] for result in results) / len(results)
        std_value = math.sqrt(sum((result["metric_value"] - mean_value) ** 2 for result in results) / len(results))
        support_fraction = len([result for result in results if result["conjecture_holds"]]) / len(results)
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not result["conjecture_holds"] for result in results):
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{result['counterexample']}\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE mapping_undefined")