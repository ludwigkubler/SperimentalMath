# Replay package — entry ad88d68b855b

Conjecture: Minimal Rank of Groupoid Actions over Boolean Functions vs ACC⁰ Parity Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 16:00 UTC.
Pre-registration hash committed before this test ran: `ddf9f66ce72dfe7a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
