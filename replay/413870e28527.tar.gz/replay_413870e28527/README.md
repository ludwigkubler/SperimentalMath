# Replay package — entry 413870e28527

Conjecture: Schur Positivity of Clause-Indicator Polynomials Bounds ACC^0 Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 23:38 UTC.
Pre-registration hash committed before this test ran: `4a3721f106c0aeab`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
