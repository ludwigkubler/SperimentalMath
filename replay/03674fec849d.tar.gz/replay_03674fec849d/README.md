# Replay package — entry 03674fec849d

Conjecture: Minimal Local Ring Norm Correlation with SAT Clause Set Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 10:29 UTC.
Pre-registration hash committed before this test ran: `3dde84d5b5659683`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
