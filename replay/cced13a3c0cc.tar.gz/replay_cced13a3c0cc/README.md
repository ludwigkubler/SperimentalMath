# Replay package — entry cced13a3c0cc

Conjecture: Minimal Order of Geometric Flows and Boolean Function Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 21:13 UTC.
Pre-registration hash committed before this test ran: `9c9655b1d13e5860`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
