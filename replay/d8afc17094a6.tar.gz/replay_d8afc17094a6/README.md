# Replay package — entry d8afc17094a6

Conjecture: Minimal Symplectic Form and DPLL Proof Path Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 09:49 UTC.
Pre-registration hash committed before this test ran: `673f5e30a6aaa39b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
