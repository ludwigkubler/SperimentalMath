# Replay package — entry 7667172ecf05

Conjecture: Minimal Rank of Algebraic Cycles Bounds Exponential Time Hypothesis for Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 21:40 UTC.
Pre-registration hash committed before this test ran: `e41d3d9c18188c31`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
