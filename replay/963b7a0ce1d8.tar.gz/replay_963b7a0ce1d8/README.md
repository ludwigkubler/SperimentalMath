# Replay package — entry 963b7a0ce1d8

Conjecture: Schur-Weyl Duality Index and Communication Complexity of DISJOINTNESS

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 16:01 UTC.
Pre-registration hash committed before this test ran: `9f74109343055dc5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
