# Replay package — entry ea65fb839888

Conjecture: Tropical Geometric Quantization Rank vs Communication Complexity for XOR

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 15:12 UTC.
Pre-registration hash committed before this test ran: `1df38e37ab568bb3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
