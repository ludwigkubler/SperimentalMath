# Replay package — entry 32ff8743153e

Conjecture: Minimal Rank of Geometric Quantization over Manifolds vs. Resolution Proof Length for Non-clausal Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 22:54 UTC.
Pre-registration hash committed before this test ran: `31df5bf503abfa34`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
