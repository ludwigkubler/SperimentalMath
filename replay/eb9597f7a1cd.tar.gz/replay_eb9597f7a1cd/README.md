# Replay package — entry eb9597f7a1cd

Conjecture: Zarankiewicz Bound on Disjointness Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 03:52 UTC.
Pre-registration hash committed before this test ran: `f2aad48d8dd37064`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
