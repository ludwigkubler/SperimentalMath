# Replay package — entry e180d6571db0

Conjecture: Stanley-Reisner Projective Dimension Lower-Bounds Monotone-KW Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 11:47 UTC.
Pre-registration hash committed before this test ran: `d520870aa9ce9eb5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
