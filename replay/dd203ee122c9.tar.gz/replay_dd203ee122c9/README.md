# Replay package — entry dd203ee122c9

Conjecture: Kolmogorov Width of Lifted Functions Bounds MA^cc

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 10:22 UTC.
Pre-registration hash committed before this test ran: `7039608deb16b7fe`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
