# Replay package — entry d8251b5e8cc9

Conjecture: Minimal Rank of Noncommutative Crossed Products Bounds BP Read-Twice Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 20:31 UTC.
Pre-registration hash committed before this test ran: `f9a7eec3ac6320da`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
