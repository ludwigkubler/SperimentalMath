# Replay package — entry 110008527f75

Conjecture: Quadratic Form Rank Equals SoS Refutation Degree for 3-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 11:00 UTC.
Pre-registration hash committed before this test ran: `72ebb6e681602e43`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
