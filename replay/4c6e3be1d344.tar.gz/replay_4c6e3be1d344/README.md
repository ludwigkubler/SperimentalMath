# Replay package — entry 4c6e3be1d344

Conjecture: Resolution Width Lower Bound for Tseitin Formulas on Expander Graphs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 07:02 UTC.
Pre-registration hash committed before this test ran: `6e51b348f80e73f3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
