# Replay package — entry 85eba7198e24

Conjecture: Minimal Rank of Hodge-Theoretic Motives over Read-Twice Branching Programs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 11:03 UTC.
Pre-registration hash committed before this test ran: `a799e5593ca1c6f1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
