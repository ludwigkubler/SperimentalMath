# Replay package — entry d28d2fd6a186

Conjecture: Minimal Order of Hodge Theory and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 17:22 UTC.
Pre-registration hash committed before this test ran: `7350cc0f4df2e647`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
