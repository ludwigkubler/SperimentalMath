# Replay package — entry 7459ad02d73f

Conjecture: Minimal Norm of Integral Quotients vs DPLL Search Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 21:36 UTC.
Pre-registration hash committed before this test ran: `db324dac50fb0f66`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
