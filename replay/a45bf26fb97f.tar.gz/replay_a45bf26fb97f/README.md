# Replay package — entry a45bf26fb97f

Conjecture: Minimal Root Count of Algebraic Curves over Function Fields vs Exponential Depth of Frege Proofs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 13:57 UTC.
Pre-registration hash committed before this test ran: `7e990c0378af6562`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
