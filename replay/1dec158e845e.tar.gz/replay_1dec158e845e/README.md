# Replay package — entry 1dec158e845e

Conjecture: Minimal Symmetric Difference Divisors of Boolean Functions over AC⁰ Circuit Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 05:01 UTC.
Pre-registration hash committed before this test ran: `e06d73d6eeae682a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
