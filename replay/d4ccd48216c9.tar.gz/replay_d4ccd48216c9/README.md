# Replay package — entry d4ccd48216c9

Conjecture: Multiplicity of Symmetric Powers in Permanent Tensor Decomposition

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 13:05 UTC.
Pre-registration hash committed before this test ran: `c20410ebf3688af0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
