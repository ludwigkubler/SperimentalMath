# Replay package — entry 0e3f19cd1824

Conjecture: Minimal Number of Monomial Generators in Affine Schemes vs. DPLL Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 23:52 UTC.
Pre-registration hash committed before this test ran: `dcc09253dcad6705`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
