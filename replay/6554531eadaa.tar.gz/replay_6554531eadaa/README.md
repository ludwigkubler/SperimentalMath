# Replay package — entry 6554531eadaa

Conjecture: Real Radical Degree Lower Bound for AC⁰ Circuits Computing PARITY

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 12:40 UTC.
Pre-registration hash committed before this test ran: `88c3d6ae17c14b48`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
