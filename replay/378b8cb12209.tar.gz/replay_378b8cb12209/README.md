# Replay package — entry 378b8cb12209

Conjecture: Minimal Rank of Ehrhart Cohomology over Sipser Function Computation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 05:17 UTC.
Pre-registration hash committed before this test ran: `a9fcfa53c0148d2f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
