# Replay package — entry 935effdfdd01

Conjecture: Coxeter Group Order and Frege Proof Tree Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 01:39 UTC.
Pre-registration hash committed before this test ran: `79ad32927edfda4d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
