# Replay package — entry 3c80ef56e78e

Conjecture: Minimal Rank of Free Probability Spaces vs BP_ReadTwice Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 04:40 UTC.
Pre-registration hash committed before this test ran: `731ab6d05c1a9185`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
