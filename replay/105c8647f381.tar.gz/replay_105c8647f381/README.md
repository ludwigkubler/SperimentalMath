# Replay package — entry 105c8647f381

Conjecture: Minimal Rank of Tropical Curves over Read-Twice BP Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 02:16 UTC.
Pre-registration hash committed before this test ran: `a42e9b3d363d9ebf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
