# Replay package — entry 358d7bf55265

Conjecture: Minimal Order of Quasi-Polynomial Functions vs ACC⁰ Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 12:10 UTC.
Pre-registration hash committed before this test ran: `82aed2fdc6e3d504`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
