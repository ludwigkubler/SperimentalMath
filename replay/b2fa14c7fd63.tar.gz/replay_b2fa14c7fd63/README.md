# Replay package — entry b2fa14c7fd63

Conjecture: Minimal Order of Tropical Hodge Decomposition and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 22:48 UTC.
Pre-registration hash committed before this test ran: `54fef189b8546236`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
