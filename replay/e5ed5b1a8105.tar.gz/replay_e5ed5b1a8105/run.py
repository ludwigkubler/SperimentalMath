import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def xor_and_tree_width(f):
        n = len(f)
        if n == 1:
            return 0
        mid = n // 2
        left = f[:mid]
        right = f[mid:]
        return 1 + max(xor_and_tree_width(left), xor_and_tree_width(right))
    
    def geometric_quantization_rank(f):
        n = len(f)
        if n == 1:
            return 1
        mid = n // 2
        left = f[:mid]
        right = f[mid:]
        return 1 + max(geometric_quantization_rank(left), geometric_quantization_rank(right))
    
    n = random.randint(5, 40)
    f = [random.choice([0, 1]) for _ in range(n)]
    
    T_f = xor_and_tree_width(f)
    R_f = geometric_quantization_rank(f)
    
    return {
        "metric_name": "R(f)/T(f)",
        "metric_value": Fraction(R_f, T_f),
        "instances_tested": 1,
        "conjecture_holds": R_f <= T_f * 1.5,
        "counterexample": "" if R_f <= T_f * 1.5 else f"R({f})={R_f}, T({f})={T_f}"
    }

if __name__ == "__main__":
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    results = []
    
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_d = sum(r["metric_value"] for r in results) / len(results)
    std_dev = math.sqrt(sum((r["metric_value"] - mean_d) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_d} std={std_dev} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results) and support_fraction >= 0.8:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"R(f)/T(f) > 1.5\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE insufficient support")