# Replay package — entry 8d353ffb284b

Conjecture: Minimal Rank of Formal Language Invariants over AC⁰ Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 21:12 UTC.
Pre-registration hash committed before this test ran: `68a1668caaaf4113`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
