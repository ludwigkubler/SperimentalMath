# Replay package — entry b1e1fdcf3c47

Conjecture: Kronecker Coefficient Gap in Symmetric Decompositions of Permanent Polynomials

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 11:18 UTC.
Pre-registration hash committed before this test ran: `64f4861003016fb3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
