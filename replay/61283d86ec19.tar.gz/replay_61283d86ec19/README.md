# Replay package — entry 61283d86ec19

Conjecture: Minimal Distance between Matroid Representations and Monotone Circuit Size for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 18:22 UTC.
Pre-registration hash committed before this test ran: `7522573671a795ee`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
