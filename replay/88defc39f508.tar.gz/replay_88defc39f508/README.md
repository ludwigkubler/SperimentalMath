# Replay package — entry 88defc39f508

Conjecture: Immanant Log-Variance Separates Random Matrices from Det-Padded Blocks

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 19:47 UTC.
Pre-registration hash committed before this test ran: `253acf5b38006259`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
