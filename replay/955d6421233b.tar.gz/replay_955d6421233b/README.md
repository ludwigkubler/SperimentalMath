# Replay package — entry 955d6421233b

Conjecture: Minimal Ramanujan Sums and Communication Complexity Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-11 06:49 UTC.
Pre-registration hash committed before this test ran: `4d87f3ed7a3ce1cb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
