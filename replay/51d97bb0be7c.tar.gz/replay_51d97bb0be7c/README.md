# Replay package — entry 51d97bb0be7c

Conjecture: Minimal Local Induction Dimension and SAT Clause Subset Entropy Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 04:00 UTC.
Pre-registration hash committed before this test ran: `d6c7d5e29da9d7c8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
