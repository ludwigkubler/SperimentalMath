# Replay package — entry d04adc422e8c

Conjecture: Minimal Order of Brauer Groups and Communication Complexity Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 00:14 UTC.
Pre-registration hash committed before this test ran: `79ce24a3a8437bab`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
