# Replay package — entry 8fb2563d7c14

Conjecture: Persistent H1 of Random Row Subclouds Bounds DISJ Communication

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-16 21:14 UTC.
Pre-registration hash committed before this test ran: `a035651eaa64a597`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
