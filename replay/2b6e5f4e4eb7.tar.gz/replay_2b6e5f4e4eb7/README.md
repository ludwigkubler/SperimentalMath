# Replay package — entry 2b6e5f4e4eb7

Conjecture: Schur-Weyl Decomposition Dimension Bounds Resolution Width of 3-CNFs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 18:50 UTC.
Pre-registration hash committed before this test ran: `adf134cb6dca4207`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
