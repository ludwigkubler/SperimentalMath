# Replay package — entry b72e3aa34be5

Conjecture: Minimal Rank of Schur-Weyl Module Decomposition over Boolean Functions vs Permutation Circuit Lower Bounds for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 12:43 UTC.
Pre-registration hash committed before this test ran: `26ebc2e39058f475`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
