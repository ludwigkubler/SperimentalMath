# Replay package — entry 54d4b50dbd3a

Conjecture: Minimal Order of Symplectic Leaves and Frege Proof Depth Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 23:13 UTC.
Pre-registration hash committed before this test ran: `3aa2feabf639236b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
