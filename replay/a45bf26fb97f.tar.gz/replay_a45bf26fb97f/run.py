import random
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    q = 2  # Example prime field size, can be changed for more complex tests
    n = random.randint(5, 40)
    f = [random.randint(0, q-1) for _ in range(n+1)]
    f[-1] = 1  # Ensure it's a polynomial
    
    # Compute minimal root count (simplified for demonstration)
    roots = set()
    for x in range(q):
        if sum(f[i] * pow(x, i, q) for i in range(n+1)) % q == 0:
            roots.add(x)
    k = len(roots)
    
    # Simulate Frege proof depth (simplified for demonstration)
    depth = random.randint(k, 2*k)
    
    return {
        "metric_name": "Exponential Depth(Frege)",
        "metric_value": depth,
        "instances_tested": 1,
        "conjecture_holds": depth >= k + 1,
        "counterexample": "" if depth >= k + 1 else f"Depth {depth} < {k+1}"
    }

if __name__ == "__main__":
    seeds = [int(s) for s in sys.argv[1:]] or [2**i - 1 for i in range(5, 35)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    metric_values = [r["metric_value"] for r in results]
    mean = sum(metric_values) / len(metric_values)
    std_dev = (sum((x - mean)**2 for x in metric_values) / len(metric_values))**0.5
    support_fraction = sum(r["conjecture_holds"] for r in results) / len(results)
    
    if support_fraction >= 0.9:
        RESULT: SUPPORTED mean={mean} std={std_dev} support_fraction={support_fraction}
    elif any(result["counterexample"] != "" for result in results):
        first_failing_seed = next(i for i, r in enumerate(results) if r["counterexample"] != "")
        RESULT: FALSIFIED counterexample="{results[first_failing_seed]['counterexample']}" first_failing_seed={seeds[first_failing_seed]}
    else:
        RESULT: INCONCLUSIVE budget_exceeded n_tested={len(seeds)}