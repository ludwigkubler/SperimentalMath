# Replay package — entry 98a6133a0fd0

Conjecture: Minimal Rank of Multivariate Polynomials in Boolean Functions vs XOR-AND Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 22:34 UTC.
Pre-registration hash committed before this test ran: `81d563f063f3d0eb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
