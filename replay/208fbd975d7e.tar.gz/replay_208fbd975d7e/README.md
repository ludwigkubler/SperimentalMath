# Replay package — entry 208fbd975d7e

Conjecture: Minimal p-Adic Hensel Lifting Steps and DPLL Proof Length Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 18:03 UTC.
Pre-registration hash committed before this test ran: `a9d75863adb48013`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
