# Replay package — entry 3905f361f983

Conjecture: Polymer Cluster-Expansion Convergence Radius Bounds Tree-Res Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 21:20 UTC.
Pre-registration hash committed before this test ran: `0a4d5dd8a3e16d87`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
