# Replay package — entry 9dba9c55f385

Conjecture: Newton Polytope Volume Inverse Proportional to SOS Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 08:32 UTC.
Pre-registration hash committed before this test ran: `eb8262c739dd68cd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
