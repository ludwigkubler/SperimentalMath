# Replay package — entry aa474a3a9b0c

Conjecture: Coxeter Group Action Complexity for SAT Clause Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 07:32 UTC.
Pre-registration hash committed before this test ran: `34f3bcce7f4a0df6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
