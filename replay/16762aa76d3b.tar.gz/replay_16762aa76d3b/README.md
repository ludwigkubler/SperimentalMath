# Replay package — entry 16762aa76d3b

Conjecture: Minimal Hodge Index of Affine Plane Curves and ACC⁰ Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 03:34 UTC.
Pre-registration hash committed before this test ran: `7e52a799c46b72b5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
