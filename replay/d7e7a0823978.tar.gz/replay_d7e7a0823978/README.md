# Replay package — entry d7e7a0823978

Conjecture: Minimal Rank of Tropicalized Lie Algebras Bounds Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 03:02 UTC.
Pre-registration hash committed before this test ran: `33a7b9672b345ddf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
