# Replay package — entry e943d33a6696

Conjecture: Minimal Diophantine Equation Complexity and Communication Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 00:27 UTC.
Pre-registration hash committed before this test ran: `d369845a8be8ec0d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
