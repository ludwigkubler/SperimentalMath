# Replay package — entry 3463f11d52ac

Conjecture: Minimal Rank of Entropic Quantizers vs Randomized Disjointness Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 17:04 UTC.
Pre-registration hash committed before this test ran: `07a5fec3f59b1850`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
