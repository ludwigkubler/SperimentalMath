# Replay package — entry 4bacba9fe06f

Conjecture: Minimal Hodge Diamond Width and Circuit Monotone Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 05:06 UTC.
Pre-registration hash committed before this test ran: `60a0fb2edc3fc765`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
