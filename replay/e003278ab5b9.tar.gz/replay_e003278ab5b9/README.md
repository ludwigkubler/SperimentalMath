# Replay package — entry e003278ab5b9

Conjecture: Schur-Weyl Component Count Gap in Monotone Circuit Size for Permanent vs Determinant

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-13 09:19 UTC.
Pre-registration hash committed before this test ran: `7538fc02bac6018a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
