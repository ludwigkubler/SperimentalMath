# Replay package — entry 33f9e6d0c477

Conjecture: Minimal Symplectic Leaf Count and DPLL Proof Tree Path Length Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 02:23 UTC.
Pre-registration hash committed before this test ran: `7bdf6f06d51e7091`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
