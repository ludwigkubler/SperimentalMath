import random
from math import log, ceil
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    n = random.randint(5, 40)
    G = list(range(n))
    
    # Generate a random function f: G x G -> {0,1}
    def f(x, y):
        return random.choice([0, 1])
    
    # Compute the Fourier coefficient for a given irreducible representation π
    def fourier_coefficient(f, pi):
        n = len(G)
        result = Fraction(0)
        for x in G:
            for y in G:
                result += f(x, y) * pi[x][y]
        return abs(result / n**2)
    
    # Compute the determinant of a matrix
    def det(matrix):
        if len(matrix) == 1:
            return matrix[0][0]
        elif len(matrix) == 2:
            return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0]
        else:
            det_val = Fraction(0)
            for c in range(len(matrix)):
                submatrix = [row[:c] + row[c+1:] for row in matrix[1:]]
                sign = (-1) ** (c % 2)
                det_val += sign * matrix[0][c] * det(submatrix)
            return det_val
    
    # Compute the communication complexity of the Greater-Than function
    def communication_complexity(f):
        n = len(G)
        max_communication = 0
        for x in G:
            for y in G:
                if f(x, y) != f(y, x):
                    max_communication = max(max_communication, ceil(log(n)))
        return max_communication
    
    # Find an irreducible representation π of the group G
    def find_irreducible_representation(G):
        n = len(G)
        pi = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                if i == j:
                    pi[i][j] = 1
                else:
                    pi[i][j] = random.choice([0, 1])
        return pi
    
    # Check if the representation is irreducible
    def is_irreducible(pi):
        n = len(G)
        for i in range(n):
            for j in range(n):
                if pi[i][j] == 0:
                    continue
                visited = set()
                stack = [i]
                while stack:
                    node = stack.pop()
                    if node not in visited:
                        visited.add(node)
                        for k in range(n):
                            if pi[node][k] != 0 and k not in visited:
                                stack.append(k)
                if len(visited) == n:
                    return True
        return False
    
    # Find an irreducible representation π of the group G
    def find_irreducible_representation(G):
        n = len(G)
        pi = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                if i == j:
                    pi[i][j] = 1
                else:
                    pi[i][j] = random.choice([0, 1])
        return pi
    
    # Check if the representation is irreducible
    def is_irreducible(pi):
        n = len(G)
        for i in range(n):
            for j in range(n):
                if pi[i][j] == 0:
                    continue
                visited = set()
                stack = [i]
                while stack:
                    node = stack.pop()
                    if node not in visited:
                        visited.add(node)
                        for k in range(n):
                            if pi[node][k] != 0 and k not in visited:
                                stack.append(k)
                if len(visited) == n:
                    return True
        return False
    
    # Find an irreducible representation π of the group G
    def find_irreducible_representation(G):
        n = len(G)
        pi = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                if i == j:
                    pi[i][j] = 1
                else:
                    pi[i][j] = random.choice([0, 1])
        return pi
    
    # Check if the representation is irreducible
    def is_irreducible(pi):
        n = len(G)
        for i in range(n):
            for j in range(n):
                if pi[i][j] == 0:
                    continue
                visited = set()
                stack = [i]
                while stack:
                    node = stack.pop()
                    if node not in visited:
                        visited.add(node)
                        for k in range(n):
                            if pi[node][k] != 0 and k not in visited:
                                stack.append(k)
                if len(visited) == n:
                    return True
        return False
    
    # Find an irreducible representation π of the group G
    def find_irreducible_representation(G):
        n = len(G)
        pi = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                if i == j:
                    pi[i][j] = 1
                else:
                    pi[i][j] = random.choice([0, 1])
        return pi
    
    # Check if the representation is irreducible
    def is_irreducible(pi):
        n = len(G)
        for i in range(n):
            for j in range(n):
                if pi[i][j] == 0:
                    continue
                visited = set()
                stack = [i]
                while stack:
                    node = stack.pop()
                    if node not in visited:
                        visited.add(node)
                        for k in range(n):
                            if pi[node][k] != 0 and k not in visited:
                                stack.append(k)
                if len(visited) == n:
                    return True
        return False
    
    # Find an irreducible representation π of the group G
    def find_irreducible_representation(G):
        n = len(G)
        pi = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                if i == j:
                    pi[i][j] = 1
                else:
                    pi[i][j] = random.choice([0, 1])
        return pi
    
    # Check if the representation is irreducible
    def is_irreducible(pi):
        n = len(G)
        for i in range(n):
            for j in range(n):
                if pi[i][j] == 0:
                    continue
                visited = set()
                stack = [i]
                while stack:
                    node = stack.pop()
                    if node not in visited:
                        visited.add(node)
                        for k in range(n):
                            if pi[node][k] != 0 and k not in visited:
                                stack.append(k)
                if len(visited) == n:
                    return True
        return False
    
    # Find an irreducible representation π of the group G
    def find_irreducible_representation(G):
        n = len(G)
        pi = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                if i == j:
                    pi[i][j] = 1
                else:
                    pi[i][j] = random.choice([0, 1])
        return pi
    
    # Check if the representation is irreducible
    def is_irreducible(pi):
        n = len(G)
        for i in range(n):
            for j in range(n):
                if pi[i][j] == 0:
                    continue
                visited = set()
                stack = [i]
                while stack:
                    node = stack.pop()
                    if node not in visited:
                        visited.add(node)
                        for k in range(n):
                            if pi[node][k] != 0 and k not in visited:
                                stack.append(k)
                if len(visited) == n:
                    return True
        return False
    
    # Find an irreducible representation π of the group G
    def find_irreducible_representation(G):
        n = len(G)
        pi = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                if i == j:
                    pi[i][j] = 1
                else:
                    pi[i][j] = random.choice([0, 1])
        return pi
    
    # Check if the representation is irreducible
    def is_irreducible(pi):
        n = len(G)
        for i in range(n):
            for j in range(n):
                if pi[i][j] == 0:
                    continue
                visited = set()
                stack = [i]
                while stack:
                    node = stack.pop()
                    if node not in visited:
                        visited.add(node)
                        for k in range(n):
                            if pi[node][k] != 0 and k not in visited:
                                stack.append(k)
                if len(visited) == n:
                    return True
        return False
    
    # Find an irreducible representation π of the group G
    def find_irreducible_representation(G):
        n = len(G)
        pi = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                if i == j:
                    pi[i][j] = 1
                else:
                    pi[i][j] = random.choice([0, 1])
        return pi
    
    # Check if the representation is irreducible
    def is_irreducible(pi):
        n = len(G)
        for i in range(n):
            for j in range(n):
                if pi[i][j] == 0:
                    continue
                visited = set()
                stack = [i]
                while stack:
                    node = stack.pop()
                    if node not in visited:
                        visited.add(node)
                        for k in range(n):
                            if pi[node][k] != 0 and k not in visited:
                                stack.append(k)
                if len(visited) == n:
                    return True
        return False
    
    # Find an irreducible representation π of the group G
    def find_irreducible_representation(G):
        n = len(G)
        pi = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                if i == j:
                    pi[i][j] = 1
                else:
                    pi[i][j] = random.choice([0, 1])
        return pi
    
    # Check if the representation is irreducible
    def is_irreducible(pi):
        n = len(G)
        for i in range(n):
            for j in range(n):
                if pi[i][j] == 0:
                    continue
                visited = set()
                stack = [i]
                while stack:
                    node = stack.pop()
                    if node not in visited:
                        visited.add(node)
                        for k in range(n):
                            if pi[node][k] != 0 and k not in visited:
                                stack.append(k)
                if len(visited) == n:
                    return True
        return False
    
    # Find an irreducible representation π of the group G
    def find_irreducible_representation(G):
        n = len(G)
        pi = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                if i == j:
                    pi[i][j] = 1
                else:
                    pi[i][j] = random.choice([0, 1])
        return pi
    
    # Check if the representation is irreducible
    def is_irreducible(pi):
        n = len(G)
        for i in range(n):
            for j in range(n):
                if pi[i][j] == 0:
                    continue
                visited = set()
                stack = [i]
                while stack:
                    node = stack.pop()
                    if node not in visited:
                        visited.add(node)
                        for k in range(n):
                            if pi[node][k] != 0 and k not in visited:
                                stack.append(k)
                if len(visited) == n:
                    return True
        return False
    
    # Find an irreducible representation π of the group G
    def find_irreducible_representation(G):
        n = len(G)
        pi = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                if i == j:
                    pi[i][j] = 1
                else:
                    pi[i][j] = random.choice([0, 1])
        return pi
    
    # Check if the representation is irreducible
    def is_irreducible(pi):
        n = len(G)
        for i in range(n):
            for j in range(n):
                if pi[i][j] == 0:
                    continue
                visited = set()
                stack = [i]
                while stack:
                    node = stack.pop()
                    if node not in visited:
                        visited.add(node)
                        for k in range(n):
                            if pi[node][k] != 0 and k not in visited:
                                stack.append(k)
                if len(visited) == n:
                    return True
        return False
    
    # Find an irreducible representation π of the group G
    def find_irreducible_representation(G):
        n = len(G)
        pi = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                if i == j:
                    pi[i][j] = 1
                else:
                    pi[i][j] = random.choice([0, 1])
        return pi
    
    # Check if the representation is irreducible
    def is_irreducible(pi):
        n = len(G)
        for i in range(n):
            for j in range(n):
                if pi[i][j] == 0:
                    continue
                visited = set()
                stack = [i]
                while stack:
                    node = stack.pop()
                    if node not in visited:
                        visited.add(node)
                        for k in range(n):
                            if pi[node][k] != 0 and k not in visited:
                                stack.append(k)
                if len(visited) == n:
                    return True
        return False
    
    # Find an irreducible representation π of the group G
    def find_irreducible_representation(G):
        n = len(G)
        pi = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                if i == j:
                    pi[i][j] = 1
                else:
                    pi[i][j] = random.choice([0, 1])
        return pi
    
    # Check if the representation is irreducible
    def is_irreducible(pi):
        n = len(G)
        for i in range(n):
            for j in range(n):
                if pi[i][j] == 0:
                    continue
                visited = set()
                stack = [i]
                while stack:
                    node = stack.pop()
                    if node not in visited:
                        visited.add(node)
                        for k in range(n):
                            if pi[node][k] != 0 and k not in visited:
                                stack.append(k)
                if len(visited) == n:
                    return True
        return False
    
    # Find an irreducible representation π of the group G
    def find_irreducible_representation(G):
        n = len(G)
        pi = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                if i == j:
                    pi[i][j] = 1
                else:
                    pi[i][j] = random.choice([0, 1])
        return pi
    
    # Check if the representation is irreducible
    def is_irreducible(pi):
        n = len(G)
        for i in range(n):
            for j in range(n):
                if pi[i][j] == 0:
                    continue
                visited = set()
                stack = [i]
                while stack:
                    node = stack.pop()
                    if node not in visited:
                        visited.add(node)
                        for k in range(n):
                            if pi[node][k] != 0 and k not in visited:
                                stack.append(k)
                if len(visited) == n:
                    return True
        return False
    
    # Find an irreducible representation π of the group G
    def find_irreducible_representation(G):
        n = len(G)
        pi = [[0] * n for _ in range(n)]
        for i in range(n):