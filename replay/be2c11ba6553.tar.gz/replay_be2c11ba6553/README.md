# Replay package — entry be2c11ba6553

Conjecture: Riemann Hypothesis and Read-Once Branching Program Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 08:01 UTC.
Pre-registration hash committed before this test ran: `99acb40b902adbe3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
