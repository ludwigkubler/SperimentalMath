# Replay package — entry f4047dadc268

Conjecture: Minimal Order of p-adic Integers and DPLL Proof Length Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 04:59 UTC.
Pre-registration hash committed before this test ran: `7e4c2ad9e4dd3cad`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
