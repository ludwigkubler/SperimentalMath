# Replay package — entry d27e7e45b29b

Conjecture: Vertex Star-Discrepancy Equals Spectral Norm for XOR Comm

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 02:29 UTC.
Pre-registration hash committed before this test ran: `2d2bdbdaa37ccae1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
