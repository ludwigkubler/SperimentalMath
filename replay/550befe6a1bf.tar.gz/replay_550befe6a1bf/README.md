# Replay package — entry 550befe6a1bf

Conjecture: Monotone CLIQUE Lower Bound via GF(2) Rank Defect

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-29 03:21 UTC.
Pre-registration hash committed before this test ran: `45e69807bc44f622`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
