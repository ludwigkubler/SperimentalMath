# Replay package — entry 855495efc337

Conjecture: Coxeter Matrix Diagonal Growth Bounds Tree-like Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 11:45 UTC.
Pre-registration hash committed before this test ran: `b4664d3c5164b2c2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
