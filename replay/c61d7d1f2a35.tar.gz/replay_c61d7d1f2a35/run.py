import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_boolean_formula(n):
        if n == 1:
            return '0' if random.choice([True, False]) else '1'
        elif n == 2:
            return f"({'0' if random.choice([True, False]) else '1'}) {'AND' if random.choice([True, False]) else 'OR'} ({'0' if random.choice([True, False]) else '1'})"
        else:
            subformulas = [generate_boolean_formula(random.randint(1, n-1)) for _ in range(n-1)]
            return f"({' AND '.join(subformulas)}) {'AND' if random.choice([True, False]) else 'OR'} ({' OR '.join(subformulas)})"
    
    def compute_l_function_rank(formula):
        # Placeholder function to simulate L-function rank computation
        # In practice, this would involve complex number theory and automorphic forms
        return len(formula.split())
    
    n_values = [5, 10, 15, 20, 30, 40]
    results = []
    
    for n in n_values:
        for _ in range(5):  # Ensure at least 5 instances per size
            formula = generate_boolean_formula(n)
            rank = compute_l_function_rank(formula)
            Phi_n = math.log(n) ** 2  # Example polynomial function Φ(n) = log^2(n)
            results.append({
                "n": n,
                "formula": formula,
                "rank": rank,
                "Phi_n": Phi_n
            })
    
    max_rank = max(result["rank"] for result in results)
    conjecture_holds = all(max_rank <= result["Phi_n"] for result in results)
    counterexample = "" if conjecture_holds else f"Formula: {results[max(results, key=lambda x: x['rank'])]['formula']}, Rank: {max_rank}, Φ(n): {results[max(results, key=lambda x: x['rank'])]['Phi_n']}"
    
    return {
        "metric_name": "L-function rank",
        "metric_value": max_rank,
        "instances_tested": len(results),
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] if sys.argv[1:] else [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    
    results = []
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    mean_metric_value = sum(result["metric_value"] for result in results) / len(results)
    std_metric_value = math.sqrt(sum((result["metric_value"] - mean_metric_value) ** 2 for result in results) / len(results))
    support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)
    
    if all(result["conjecture_holds"] for result in results):
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_metric_value} support_fraction={support_fraction}")
    elif any(not result["conjecture_holds"] for result in results):
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{results[max(results, key=lambda x: x['rank'])]['formula']}\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE reason=unknown")