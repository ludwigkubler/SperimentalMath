# Replay package — entry 275156ccf299

Conjecture: Symmetric Group Irreducible Component Exponential Gap in Permanent vs Determinant

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 19:24 UTC.
Pre-registration hash committed before this test ran: `2391dd588d57394c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
