# Replay package — entry 3733d7bba3dc

Conjecture: Minimal Order of Quotient Algebras in Boolean Functions and Circuit Entropy Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 19:40 UTC.
Pre-registration hash committed before this test ran: `3c6740ede38b7f0a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
