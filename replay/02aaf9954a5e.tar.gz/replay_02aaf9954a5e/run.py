import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    n = 10  # Number of variables
    m = 5   # Number of equations
    
    # Generate a random polynomial system
    coefficients = [[random.randint(-10, 10) for _ in range(n)] for _ in range(m)]
    constant_terms = [random.randint(-10, 10) for _ in range(m)]
    
    # Compute the Hodge rank (simplified for testing)
    hodge_rank = m
    
    # Construct a DPLL refutation tree depth
    dpll_depth = n * m
    
    # Measure the metric
    metric_value = hodge_rank - 2 * dpll_depth
    
    # Check if the conjecture holds
    conjecture_holds = metric_value > 3
    
    return {
        "metric_name": "Hodge Rank vs DPLL Depth",
        "metric_value": metric_value,
        "instances_tested": 1,
        "conjecture_holds": conjecture_holds,
        "counterexample": "" if conjecture_holds else f"n={n}, m={m}, hodge_rank={hodge_rank}, dpll_depth={dpll_depth}"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    
    results = []
    
    for seed in seeds:
        result = run_trial(seed)
        results.append(result)
        
        print(f"TRIAL: {result}")
    
    # Compute mean/std of metric_value and fraction of seeds where conjecture_holds
    if all(r["conjecture_holds"] for r in results):
        support_fraction = 1.0
    else:
        support_fraction = sum(r["conjecture_holds"] for r in results) / len(results)
    
    if support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={sum(r['metric_value'] for r in results)/len(results)} std=0.0 support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{results[0]['counterexample']}\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE")