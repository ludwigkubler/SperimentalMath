# Replay package — entry 0267790756e1

Conjecture: Minimal Rank of Generalized Kostant Partition Functions vs Sum-of-Squares Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 12:49 UTC.
Pre-registration hash committed before this test ran: `e01c18a5d9f00a60`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
