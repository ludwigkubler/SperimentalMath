# Replay package — entry 7d536530206d

Conjecture: Minimal Rank of Group Representations vs DPLL Search Tree Height

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 15:51 UTC.
Pre-registration hash committed before this test ran: `9c5e0cdb3138e550`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
