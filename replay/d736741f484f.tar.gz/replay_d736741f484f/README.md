# Replay package — entry d736741f484f

Conjecture: Hypergeometric Function Moments and Monotone k-CLIQUE DNF Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 12:11 UTC.
Pre-registration hash committed before this test ran: `89b32c979e7c977d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
