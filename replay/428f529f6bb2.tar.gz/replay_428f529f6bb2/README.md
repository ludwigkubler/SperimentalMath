# Replay package — entry 428f529f6bb2

Conjecture: Minimal Automaton State Complexity Bounds Communication Complexity for k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 02:00 UTC.
Pre-registration hash committed before this test ran: `34b738b516600212`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
