# Replay package — entry 3543fce5bf14

Conjecture: Minimal p-Adic Root Count and Frege Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 10:48 UTC.
Pre-registration hash committed before this test ran: `cf820fffe33de3c5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
