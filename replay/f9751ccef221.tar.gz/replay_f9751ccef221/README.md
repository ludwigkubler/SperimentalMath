# Replay package — entry f9751ccef221

Conjecture: Minimal Tropical Hodge Index vs AC0 Parity Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 15:50 UTC.
Pre-registration hash committed before this test ran: `798bd488055e1f93`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
