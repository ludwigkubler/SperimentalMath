# Replay package — entry e21284fd5d23

Conjecture: Coxeter Group Rank and Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 09:32 UTC.
Pre-registration hash committed before this test ran: `679447f3417642c6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
