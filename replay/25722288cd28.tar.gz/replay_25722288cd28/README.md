# Replay package — entry 25722288cd28

Conjecture: Permanent of Sensitive-Boundary Bipartite Matrix Bounds Lifted Indexing CC

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 10:47 UTC.
Pre-registration hash committed before this test ran: `f03ba3422400bb7c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
