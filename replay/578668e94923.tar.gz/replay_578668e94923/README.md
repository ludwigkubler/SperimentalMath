# Replay package — entry 578668e94923

Conjecture: Galois Group of Tropicalized Boolean Algebras vs DPLL Search Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 15:41 UTC.
Pre-registration hash committed before this test ran: `5f70248a43d8e7f7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
