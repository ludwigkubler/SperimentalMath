# Replay package — entry 56044fada967

Conjecture: Kolmogorov Flow Lower Bounds Mixer Profile Decay in Product Dynamics

Verdict (original run): FALSIFIED

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 17:08 UTC.
Pre-registration hash committed before this test ran: `5d0235196406d2af`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
