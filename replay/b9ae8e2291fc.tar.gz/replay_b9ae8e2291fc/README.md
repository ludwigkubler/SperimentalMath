# Replay package — entry b9ae8e2291fc

Conjecture: Newton Polytope Lattice Width Lower-Bounds SoS Refutation Degree for 3-XOR

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 14:14 UTC.
Pre-registration hash committed before this test ran: `8f7c346b578defb7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
