# Replay package — entry 87f4d0e8600a

Conjecture: Minimal Rank of Kostant Partition Functions vs Communication Complexity for Disjointness

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 10:53 UTC.
Pre-registration hash committed before this test ran: `928d5dfd6ed85368`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
