# Replay package — entry d7ff047dea94

Conjecture: Minimal Order of Affine Generators Correlation with Resolution Proof Width via Symplectic Geometry

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 02:18 UTC.
Pre-registration hash committed before this test ran: `b39efea6de4c0272`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
