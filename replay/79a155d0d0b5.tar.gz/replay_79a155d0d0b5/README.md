# Replay package — entry 79a155d0d0b5

Conjecture: Minimal Rank of Tensor Products Bounds SAT to DPLL Conversion Time

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 02:31 UTC.
Pre-registration hash committed before this test ran: `073c79c319132816`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
