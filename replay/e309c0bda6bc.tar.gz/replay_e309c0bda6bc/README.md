# Replay package — entry e309c0bda6bc

Conjecture: Minimal Rank of Symplectic Geometry over XOR-AND Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 20:29 UTC.
Pre-registration hash committed before this test ran: `62ded563ddd6219d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
