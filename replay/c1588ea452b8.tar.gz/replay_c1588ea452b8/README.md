# Replay package — entry c1588ea452b8

Conjecture: Negative SoS-Fourier Hankel Spectrum Separates Sipser from ACC0[3]

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 19:25 UTC.
Pre-registration hash committed before this test ran: `21fe76326b885476`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
