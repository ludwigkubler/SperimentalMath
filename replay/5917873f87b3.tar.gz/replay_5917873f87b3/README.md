# Replay package — entry 5917873f87b3

Conjecture: Minimal Rank of Eichler-Shimura Sheaves over XOR-AND Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 23:13 UTC.
Pre-registration hash committed before this test ran: `dedd7678928fe839`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
