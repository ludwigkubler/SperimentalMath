# Replay package — entry a023d9562a86

Conjecture: Minimal Tropicalization of Automorphism Groups and DPLL Proof Path Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 17:21 UTC.
Pre-registration hash committed before this test ran: `761a019e1283c463`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
