# Replay package — entry 5f43f7f0aef3

Conjecture: Minimal Tropical Symplectic Index and Communication Complexity Rank Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 00:35 UTC.
Pre-registration hash committed before this test ran: `01a995559c8ef4c0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
