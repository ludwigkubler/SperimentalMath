# Replay package — entry 6a43042099b0

Conjecture: Grobner Basis Dimension and Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 09:21 UTC.
Pre-registration hash committed before this test ran: `bb68e6e9b6e9fe50`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
