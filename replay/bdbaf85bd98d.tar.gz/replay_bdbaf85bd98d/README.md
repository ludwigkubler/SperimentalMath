# Replay package — entry bdbaf85bd98d

Conjecture: Minimal Rank of Kostant Sheaves and AC^0 Circuit Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 23:53 UTC.
Pre-registration hash committed before this test ran: `5a8003b5992d214a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
