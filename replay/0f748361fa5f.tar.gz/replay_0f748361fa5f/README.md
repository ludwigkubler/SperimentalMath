# Replay package — entry 0f748361fa5f

Conjecture: Effective Resistance of Charged Vertex Pairs Bounds Tseitin DPLL Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 09:54 UTC.
Pre-registration hash committed before this test ran: `19d4072b9435d663`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
