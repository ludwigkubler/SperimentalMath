# Replay package — entry 6c975c602b79

Conjecture: Minimal Rank of Ehrhart Semigroups Bounds Communication Complexity for Symmetry Detection

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 09:51 UTC.
Pre-registration hash committed before this test ran: `7d065b329e85e18a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
