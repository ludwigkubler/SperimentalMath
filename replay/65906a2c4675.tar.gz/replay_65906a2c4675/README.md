# Replay package — entry 65906a2c4675

Conjecture: Minimal Rank of Hodge Integrals vs Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 18:00 UTC.
Pre-registration hash committed before this test ran: `101962fdfd68130e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
