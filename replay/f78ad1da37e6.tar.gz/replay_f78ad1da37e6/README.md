# Replay package — entry f78ad1da37e6

Conjecture: Dynamical Composition and Additive Kolmogorov Flow Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 09:33 UTC.
Pre-registration hash committed before this test ran: `3b293552ef0dc3b7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
