# Replay package — entry 4f6b54c188ba

Conjecture: Minimal Symplectic Capacity Bounds DPLL Size for XOR Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 23:37 UTC.
Pre-registration hash committed before this test ran: `4908dfc2df8d535d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
