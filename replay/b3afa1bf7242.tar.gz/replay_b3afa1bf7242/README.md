# Replay package — entry b3afa1bf7242

Conjecture: Minimal Rank of Tropicalized Classical Groups Bounds ACC⁰ Circuit Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 20:25 UTC.
Pre-registration hash committed before this test ran: `d07df7718a8bf6cb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
