import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def gaussian_elimination(A):
        m, n = len(A), len(A[0])
        for i in range(m):
            max_row = i + max(range(i, m), key=lambda x: abs(A[x][i]))
            A[i], A[max_row] = A[max_row], A[i]
            for j in range(n):
                if j != i:
                    factor = A[j][i] / A[i][i]
                    for k in range(n):
                        A[j][k] -= factor * A[i][k]
        return A
    
    def matrix_multiply(A, B):
        m, n, p = len(A), len(B), len(B[0])
        C = [[0] * p for _ in range(m)]
        for i in range(m):
            for j in range(p):
                for k in range(n):
                    C[i][j] += A[i][k] * B[k][j]
        return C
    
    def r_transform(A):
        m, n = len(A), len(A[0])
        if m != n:
            raise ValueError("Matrix must be square")
        
        # Perform Gaussian elimination to get the upper triangular form
        U = gaussian_elimination(A)
        
        # Calculate the R-transform
        log_det = 0.0
        for i in range(n):
            log_det += math.log(abs(U[i][i]))
        
        return log_det
    
    def generate_random_matrix(m, n):
        return [[random.choice([-1, 1]) for _ in range(n)] for _ in range(m)]
    
    def is_inner_product_mod_2_BP(A):
        m, n = len(A), len(A[0])
        if m != n:
            return False
        for i in range(m):
            for j in range(i + 1, m):
                if A[i][j] != -A[j][i]:
                    return False
        return True
    
    n = 40
    P = generate_random_matrix(n, n)
    IP_2 = generate_random_matrix(n, n)
    
    if not is_inner_product_mod_2_BP(IP_2):
        return {
            "metric_name": "free_entropy",
            "metric_value": None,
            "instances_tested": 1,
            "conjecture_holds": False,
            "counterexample": "mapping_undefined"
        }
    
    rho_P = r_transform(P)
    rho_IP_2 = r_transform(IP_2)
    
    return {
        "metric_name": "free_entropy",
        "metric_value": max(rho_P, rho_IP_2),
        "instances_tested": 1,
        "conjecture_holds": rho_IP_2 >= 10 * n and rho_P <= 10 * math.log(n),
        "counterexample": ""
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    total_metric_value = sum(r["metric_value"] for r in results if r["metric_value"] is not None)
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={total_metric_value/len(results)} std=0 support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(s for s, r in zip(seeds, results) if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample='' first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE reason=insufficient_evidence")