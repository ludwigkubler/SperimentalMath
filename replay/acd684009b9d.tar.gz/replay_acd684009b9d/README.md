# Replay package — entry acd684009b9d

Conjecture: Fourier Coefficient Sparsity and Deterministic Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-30 20:31 UTC.
Pre-registration hash committed before this test ran: `c497b8c719d6404a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
