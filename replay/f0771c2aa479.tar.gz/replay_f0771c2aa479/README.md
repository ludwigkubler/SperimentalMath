# Replay package — entry f0771c2aa479

Conjecture: Minimal Order of Hodge Loci Bounds Resolution Proof Width for Random k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 09:36 UTC.
Pre-registration hash committed before this test ran: `d5a1e134e9b160f4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
