# Replay package — entry c43dbad57206

Conjecture: Minimal Rank of Symplectic Forms over Boolean Algebras vs Resolution Proof Width for Random k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 03:15 UTC.
Pre-registration hash committed before this test ran: `95b91c8deb62b233`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
