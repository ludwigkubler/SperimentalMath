# Replay package — entry 0ad6b6e48ff0

Conjecture: Minimal Rank of Geometric Complexity Groups Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 12:08 UTC.
Pre-registration hash committed before this test ran: `ee831187fdd19b56`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
