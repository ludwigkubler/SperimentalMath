# Replay package — entry b712cdd1c010

Conjecture: Minimal Frobenius Normal Form Dimension and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 18:14 UTC.
Pre-registration hash committed before this test ran: `c01100d2cc69dfe4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
