# Replay package — entry e264fe6d0d8b

Conjecture: Minimal Number of Generators of Affine Algebraic Groups and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 07:55 UTC.
Pre-registration hash committed before this test ran: `5833ec353ee2e5b2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
