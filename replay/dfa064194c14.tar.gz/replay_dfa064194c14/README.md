# Replay package — entry dfa064194c14

Conjecture: Algebraic K-Theory Rank vs Boolean Tensor Product Valuations

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 06:50 UTC.
Pre-registration hash committed before this test ran: `574733055733c113`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
