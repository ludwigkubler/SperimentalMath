# Replay package — entry a78c1df6ba03

Conjecture: Algebraic Hodge Index and Extended Frege Proof Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 13:56 UTC.
Pre-registration hash committed before this test ran: `55c2cb3ed3084c91`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
