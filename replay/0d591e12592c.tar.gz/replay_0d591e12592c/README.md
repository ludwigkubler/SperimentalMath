# Replay package — entry 0d591e12592c

Conjecture: Minimal Rank of Tropicalized Algebraic K-theory over AC0-k-Distance Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 09:20 UTC.
Pre-registration hash committed before this test ran: `dda5d46758362cb0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
