# Replay package — entry 03c7b5e2f51b

Conjecture: Real Stable Polynomial Degree Bounds SOS Refutation Threshold for 3-XOR

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 04:02 UTC.
Pre-registration hash committed before this test ran: `cb6b749a0c70b311`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
