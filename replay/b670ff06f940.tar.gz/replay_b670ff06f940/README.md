# Replay package — entry b670ff06f940

Conjecture: Minimal Rank of Commutative Quadratic Forms Bounds BP Read-Twice Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 06:11 UTC.
Pre-registration hash committed before this test ran: `f5f5b32cea610346`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
