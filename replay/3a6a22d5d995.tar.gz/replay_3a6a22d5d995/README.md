# Replay package — entry 3a6a22d5d995

Conjecture: Minimal Rank of Non-Archimedean Valuations Bounds DISJ CC_R

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 15:08 UTC.
Pre-registration hash committed before this test ran: `64018f15f4aaf3b9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
