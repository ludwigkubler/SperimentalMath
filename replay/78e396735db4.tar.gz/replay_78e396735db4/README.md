# Replay package — entry 78e396735db4

Conjecture: Hypergeometric Function Zeros and Boolean Circuit Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 09:20 UTC.
Pre-registration hash committed before this test ran: `2bcad2c53b62482d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
