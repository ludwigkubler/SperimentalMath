# Replay package — entry 00ee8f0b996e

Conjecture: Minimal Rank of Geometrically Defined Schur-Weyl Modules over DPLL Proof Trees

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 02:21 UTC.
Pre-registration hash committed before this test ran: `e28f26212923aae0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
