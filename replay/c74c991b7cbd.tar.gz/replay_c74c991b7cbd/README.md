# Replay package — entry c74c991b7cbd

Conjecture: Minimal Rank of Tropicalized Lie Algebras and Permutation Circuit Threshold

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 13:52 UTC.
Pre-registration hash committed before this test ran: `245333eca4dcc7aa`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
