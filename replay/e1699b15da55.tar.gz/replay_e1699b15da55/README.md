# Replay package — entry e1699b15da55

Conjecture: Minimal Rank of Tropicalized K-Theory over Manifolds vs. ACC⁰ Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 03:11 UTC.
Pre-registration hash committed before this test ran: `e303801003913074`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
