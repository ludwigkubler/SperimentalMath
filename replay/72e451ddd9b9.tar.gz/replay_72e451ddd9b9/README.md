# Replay package — entry 72e451ddd9b9

Conjecture: Orbit Closure Dimension vs. Circuit Complexity for Permanent

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-30 18:22 UTC.
Pre-registration hash committed before this test ran: `e6d58e64c57d90fe`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
