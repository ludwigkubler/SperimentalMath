# Replay package — entry c3c9ed5c42f3

Conjecture: Minimal Geometric Entropy of Affine Hulls and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 09:41 UTC.
Pre-registration hash committed before this test ran: `82a4436ebb84026a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
