# Replay package — entry 35b64e33f7e5

Conjecture: Minimal K-theoretic Index and Frege Proof Depth Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 04:09 UTC.
Pre-registration hash committed before this test ran: `fb08358186843cb5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
