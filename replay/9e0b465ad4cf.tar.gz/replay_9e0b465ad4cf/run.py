import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_cnf(m):
        variables = set()
        clauses = []
        for _ in range(m):
            clause = [random.choice([1, -1]) * (i + 1) for i in range(random.randint(2, 5))]
            variables.update(abs(x) for x in clause)
            clauses.append(clause)
        return variables, clauses

    def tseitin_formula(variables, clauses):
        literals = list(variables)
        new_vars = {}
        formulas = []
        for literal in literals:
            formulas.append(f"X_{literal} <-> {literal}")
        
        for i, clause in enumerate(clauses):
            new_var = f"Y_{i}"
            new_vars[new_var] = len(new_vars) + 1
            formulas.append(f"{new_var} <-> ({' ∨ '.join(str(literal) if literal > 0 else f'-{abs(literal)}' for literal in clause)})")
        
        for i, clause in enumerate(clauses):
            new_var = f"Z_{i}"
            new_vars[new_var] = len(new_vars) + 1
            formulas.append(f"{new_var} <-> ({' ∧ '.join(str(new_vars[f'Y_{j}']) if j < i else str(-new_vars[f'Y_{j}']) for j in range(i)})")
        
        return formulas, new_vars

    def incidence_matrix(formulas):
        n = len(formulas)
        m = max(len(f.split()) for f in formulas)
        matrix = [[0] * (n + m) for _ in range(n)]
        for i, formula in enumerate(formulas):
            literals = formula.split()
            for literal in literals:
                if literal.startswith('X_'):
                    var = int(literal[2:])
                    matrix[i][var - 1] = 1
                elif literal.startswith('-X_'):
                    var = int(literal[3:])
                    matrix[i][var - 1] = -1
        return matrix

    def hodge_diamond_dimension(matrix):
        n = len(matrix)
        characteristic_poly = [1]
        for i in range(n):
            new_poly = []
            for j in range(len(characteristic_poly)):
                if j == 0:
                    new_poly.append(characteristic_poly[j] * matrix[i][i])
                elif j < i:
                    new_poly.append(characteristic_poly[j - 1] * matrix[i][i] + characteristic_poly[j] * matrix[i][n - j - 1])
                else:
                    new_poly.append(characteristic_poly[j - 1] * matrix[i][n - j - 1])
            characteristic_poly = new_poly
        
        def gcd(a, b):
            while b != 0:
                a, b = b, a % b
            return a
        
        def lcm(a, b):
            return abs(a * b) // gcd(a, b)
        
        dim = len(characteristic_poly) - 1
        for i in range(1, dim + 1):
            dim -= math.log(abs(characteristic_poly[i]), 2) / math.log(i + 1, 2)
        return int(dim)

    def communication_complexity(formulas):
        n = len(formulas)
        m = max(len(f.split()) for f in formulas)
        matrix = incidence_matrix(formulas)
        
        def gaussian_elimination(A):
            n = len(A)
            m = len(A[0])
            rank = 0
            for i in range(n):
                if A[i][i] == 0:
                    swap_found = False
                    for j in range(i + 1, n):
                        if A[j][i] != 0:
                            A[i], A[j] = A[j], A[i]
                            swap_found = True
                            break
                    if not swap_found:
                        continue
                pivot = A[i][i]
                for j in range(m):
                    A[i][j] /= pivot
                for k in range(n):
                    if k == i:
                        continue
                    factor = A[k][i]
                    for j in range(m):
                        A[k][j] -= factor * A[i][j]
            return sum(1 for row in A if any(row[j] != 0 for j in range(m)))
        
        rank = gaussian_elimination(matrix)
        return n - rank

    m_values = [5, 10, 15, 20, 30, 40]
    results = []
    
    for m in m_values:
        variables, clauses = generate_cnf(m)
        formulas, new_vars = tseitin_formula(variables, clauses)
        hdd = hodge_diamond_dimension(formulas)
        cc = communication_complexity(formulas)
        
        if hdd == 0 or cc == 0:
            continue
        
        results.append({
            "metric_name": "HDD vs Communication Complexity",
            "metric_value": hdd / cc,
            "instances_tested": 1,
            "n_max": m,
            "conjecture_holds": True,
            "counterexample": ""
        })
    
    return {
        "metric_name": "HDD vs Communication Complexity",
        "metric_value": sum(result["metric_value"] for result in results) / len(results),
        "instances_tested": len(results),
        "n_max": max(result["n_max"] for result in results),
        "conjecture_holds": all(result["conjecture_holds"] for result in results),
        "counterexample": ""
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(result["metric_value"] for result in results) / len(results)
    support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)
    
    if all(result["conjecture_holds"] for result in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std=0.0 support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std=0.0 support_fraction={support_fraction}")
    else:
        first_failing_seed = next((result["seed"] for result in results if not result["conjecture_holds"]), None)
        print(f"RESULT: FALSIFIED counterexample='not supported' first_failing_seed={first_failing_seed}")