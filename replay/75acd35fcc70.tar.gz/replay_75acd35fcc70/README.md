# Replay package — entry 75acd35fcc70

Conjecture: Coxeter Group Order of Polynomial Systems vs. Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 20:05 UTC.
Pre-registration hash committed before this test ran: `f475806c2efb690d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
