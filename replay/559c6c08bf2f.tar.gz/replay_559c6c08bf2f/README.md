# Replay package — entry 559c6c08bf2f

Conjecture: Minimal Rank of Quantum Logics and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 17:29 UTC.
Pre-registration hash committed before this test ran: `24dc648839fc11ff`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
