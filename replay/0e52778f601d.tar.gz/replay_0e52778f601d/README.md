# Replay package — entry 0e52778f601d

Conjecture: Riemannian Curvature Tensor Bounds for Communication Complexity of XOR Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 00:48 UTC.
Pre-registration hash committed before this test ran: `9ad9746073ad6679`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
