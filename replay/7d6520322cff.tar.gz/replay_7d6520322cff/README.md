# Replay package — entry 7d6520322cff

Conjecture: Minimal Index of p-Adic Differentials and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 16:11 UTC.
Pre-registration hash committed before this test ran: `38a21a4bf62ef4f0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
