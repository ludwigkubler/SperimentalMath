# Replay package — entry f3d3447db1f1

Conjecture: Minimal Lifting Index Correlation with SAT Clause Set Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 02:18 UTC.
Pre-registration hash committed before this test ran: `997b99a57a6b241b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
