# Replay package — entry 0a1327239a28

Conjecture: Minimal Symplectic Hull Diameter and Circuit Monotone Width Relationship

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 05:55 UTC.
Pre-registration hash committed before this test ran: `08938dff8428184c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
