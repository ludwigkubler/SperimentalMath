import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_cnf(n):
        clauses = []
        for i in range(1, n + 1):
            clause = [random.choice([-1, 1]) * j for j in range(1, n + 1)]
            clauses.append(clause)
        return clauses
    
    def resolution_width(cnf):
        # Simplified resolution width calculation
        seen_clauses = set()
        queue = cnf[:]
        while queue:
            clause = queue.pop()
            if not clause:
                return len(seen_clauses)
            for lit in clause:
                neg_lit = -lit
                if neg_lit in seen_clauses:
                    continue
                new_clause = [l for l in clause if l != lit]
                if not new_clause:
                    return len(seen_clauses)
                queue.append(new_clause)
                seen_clauses.add(neg_lit)
        return len(seen_clauses)
    
    def geometric_quantization_rank(cnf):
        # Simplified geometric quantization rank calculation
        rank = 0
        for clause in cnf:
            rank += len(clause)
        return rank
    
    n_values = [5, 10, 15, 20, 30, 40]
    results = []
    
    for n in n_values:
        cnf = generate_cnf(n)
        gqrank = geometric_quantization_rank(cnf)
        w = resolution_width(cnf)
        results.append({"n": n, "gqrank": gqrank, "w": w})
    
    if not results:
        return {
            "metric_name": "resolution_width",
            "metric_value": 0,
            "instances_tested": 0,
            "n_max": 0,
            "conjecture_holds": False,
            "counterexample": "mapping_undefined"
        }
    
    gqrank_values = [r["gqrank"] for r in results]
    w_values = [r["w"] for r in results]
    
    def pearson_correlation(x, y):
        n = len(x)
        mean_x = sum(x) / n
        mean_y = sum(y) / n
        cov_xy = sum((x[i] - mean_x) * (y[i] - mean_y) for i in range(n)) / n
        std_x = math.sqrt(sum((x[i] - mean_x) ** 2 for i in range(n)) / n)
        std_y = math.sqrt(sum((y[i] - mean_y) ** 2 for i in range(n)) / n)
        return cov_xy / (std_x * std_y)
    
    corr_coeff = pearson_correlation(gqrank_values, w_values)
    
    conjecture_holds = abs(corr_coeff) >= 0.8
    counterexample = "" if conjecture_holds else "mapping_undefined"
    
    return {
        "metric_name": "resolution_width",
        "metric_value": corr_coeff,
        "instances_tested": len(results),
        "n_max": max(r["n"] for r in results),
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    
    seeds = [int(arg) for arg in sys.argv[1:]] or [
        2, 3, 5, 7, 11, 13, 17, 19, 23, 29,
        31, 37, 41, 43, 47, 53, 59, 61, 67, 71,
        73, 79, 83, 89, 97, 101, 103, 107, 109, 113
    ]
    
    results = []
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    if all(r["conjecture_holds"] for r in results):
        mean_corr_coeff = sum(r["metric_value"] for r in results) / len(results)
        support_fraction = 1.0
        result = f"RESULT: SUPPORTED mean={mean_corr_coeff} std=0 support_fraction={support_fraction}"
    else:
        first_failing_seed = next((r["seed"] for r in results if not r["conjecture_holds"]), None)
        counterexample = "mapping_undefined"
        result = f"RESULT: FALSIFIED counterexample=\"{counterexample}\" first_failing_seed={first_failing_seed}"
    
    print(result)