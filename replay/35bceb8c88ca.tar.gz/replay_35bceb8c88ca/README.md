# Replay package — entry 35bceb8c88ca

Conjecture: Minimal Rank of Geometric Invariants in Morse Theory vs Resolution Proof Length for k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 12:05 UTC.
Pre-registration hash committed before this test ran: `642df72d960bbf39`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
