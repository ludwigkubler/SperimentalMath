# Replay package — entry d8610d1a556a

Conjecture: Coxeter Group Enumeration Complexity of Tseitin Tensor Product

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 18:46 UTC.
Pre-registration hash committed before this test ran: `4f97ee9abfa44add`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
