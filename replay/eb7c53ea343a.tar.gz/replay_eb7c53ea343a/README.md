# Replay package — entry eb7c53ea343a

Conjecture: Minimal Hodge Index and DPLL Proof Path Length Lower Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 08:36 UTC.
Pre-registration hash committed before this test ran: `f017beb2e64235fc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
