import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def gaussian_elimination(matrix):
        rows, cols = len(matrix), len(matrix[0])
        for i in range(rows):
            max_row = i + max(range(i, rows), key=lambda x: abs(matrix[x][i]))
            matrix[i], matrix[max_row] = matrix[max_row], matrix[i]
            pivot = matrix[i][i]
            if pivot == 0:
                continue
            for j in range(cols):
                matrix[i][j] /= pivot
            for k in range(rows):
                if k != i:
                    factor = matrix[k][i]
                    for j in range(cols):
                        matrix[k][j] -= factor * matrix[i][j]
        return matrix

    def rank(matrix):
        rows, cols = len(matrix), len(matrix[0])
        row echelon_form = gaussian_elimination(matrix)
        rank = 0
        for i in range(rows):
            if any(row[i] != 0 for row in row_echelon_form):
                rank += 1
        return rank

    def resolution_proof_depth(cnf_formula):
        # Simplified DPLL solver to estimate proof depth
        stack = []
        assignment = {}
        def dpll():
            if not cnf_formula:
                return True, 0
            literal = next((lit for lit in cnf_formula[0] if lit not in assignment and -lit not in assignment), None)
            if literal is None:
                return False, 0
            assignment[literal] = True
            stack.append(literal)
            depth = 1
            while stack:
                lit = stack[-1]
                if any(all(assignment[var] == (var > 0) for var in clause) for clause in cnf_formula):
                    return True, depth
                neg_lit = -lit
                if neg_lit in assignment and not assignment[neg_lit]:
                    stack.pop()
                    del assignment[lit]
                    continue
                new_clause = [var for var in cnf_formula[0] if var != lit and -var not in cnf_formula[0]]
                cnf_formula[0] = new_clause
                depth += 1
            return False, 0
        return dpll()[1]

    def generate_cnf(n):
        clauses = []
        for i in range(2**n):
            clause = [random.choice([-1, 1]) * (j + 1) for j in range(n)]
            if any(all(clause[var] == (var > 0) for var in clause) for clause in clauses):
                continue
            clauses.append(clause)
        return clauses

    n_values = [5, 10, 15, 20, 30, 40]
    total_rank = 0
    instances_tested = 0
    conjecture_holds = True
    counterexample = ""

    for n in n_values:
        cnf_formula = generate_cnf(n)
        proof_depth = resolution_proof_depth(cnf_formula)
        if proof_depth == 0:
            continue
        hypergeometric_sequence = [len([var for var in clause if var > 0]) for clause in cnf_formula]
        rank_value = rank(hypergeometric_sequence)
        total_rank += rank_value
        instances_tested += 1

        if rank_value < math.log(n):
            conjecture_holds = False
            counterexample = f"n={n}, proof_depth={proof_depth}, rank={rank_value}"

    mean_rank = Fraction(total_rank, instances_tested) / n
    support_fraction = instances_tested / len(n_values)

    return {
        "metric_name": "mean_rank/n",
        "metric_value": float(mean_rank),
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2**i - 1 for i in range(5, 30)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)

    mean_rank = sum(r["metric_value"] for r in results) / len(results)
    support_fraction = sum(r["conjecture_holds"] for r in results) / len(results)

    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_rank} std=0.0 support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{result['counterexample']}\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE reason=unknown")