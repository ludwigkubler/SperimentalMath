import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_boolean_matrix(n):
        return [[random.randint(0, 1) for _ in range(n)] for _ in range(n)]
    
    def matrix_multiplication(A, B):
        n = len(A)
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                for k in range(n):
                    C[i][j] += A[i][k] * B[k][j]
        return C
    
    def gaussian_elimination(A, b):
        n = len(A)
        for i in range(n):
            max_row = i
            for j in range(i+1, n):
                if abs(A[j][i]) > abs(A[max_row][i]):
                    max_row = j
            A[i], A[max_row] = A[max_row], A[i]
            b[i], b[max_row] = b[max_row], b[i]
            for j in range(i+1, n):
                factor = A[j][i] / A[i][i]
                for k in range(i, n):
                    A[j][k] -= factor * A[i][k]
                b[j] -= factor * b[i]
        x = [0] * n
        for i in range(n-1, -1, -1):
            x[i] = (b[i] - sum(A[i][j] * x[j] for j in range(i+1, n))) / A[i][i]
        return x
    
    def min_rank(matrix):
        n = len(matrix)
        rank = 0
        augmented_matrix = [row + [0] for row in matrix]
        for i in range(n):
            if augmented_matrix[i][i] == 0:
                for j in range(i+1, n):
                    if augmented_matrix[j][i] != 0:
                        augmented_matrix[i], augmented_matrix[j] = augmented_matrix[j], augmented_matrix[i]
                        break
                else:
                    continue
            rank += 1
            for j in range(n):
                if j == i:
                    continue
                factor = augmented_matrix[j][i] / augmented_matrix[i][i]
                for k in range(n+1):
                    augmented_matrix[j][k] -= factor * augmented_matrix[i][k]
        return rank
    
    def communication_complexity_disjointness(M):
        n = len(M)
        count = 0
        for i in range(n):
            for j in range(i+1, n):
                if M[i][j] == 1:
                    count += 1
        return count
    
    n = random.randint(5, 40)
    M = generate_boolean_matrix(n)
    Q_M = matrix_multiplication(M, M)
    rank = min_rank(Q_M)
    comm_complexity = communication_complexity_disjointness(M)
    
    return {
        "metric_name": "communication_complexity",
        "metric_value": comm_complexity,
        "instances_tested": 1,
        "conjecture_holds": rank <= comm_complexity,
        "counterexample": ""
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] if sys.argv[1:] else [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113]
    results = []
    
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if support_fraction >= 0.8:
        RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}
    elif any(not r["conjecture_holds"] for r in results):
        counterexample = next(r for r in results if not r["conjecture_holds"])["counterexample"]
        RESULT: FALSIFIED counterexample="{counterexample}" first_failing_seed={seeds[next(i for i, r in enumerate(results) if not r["conjecture_holds"])]}
    else:
        RESULT: INCONCLUSIVE reason=insufficient_evidence