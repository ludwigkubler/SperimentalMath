# Replay package — entry b44575be8ecb

Conjecture: Minimal Order of Modular Functions Bounds Tree-like Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 01:14 UTC.
Pre-registration hash committed before this test ran: `72e6fc3e9d744166`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
