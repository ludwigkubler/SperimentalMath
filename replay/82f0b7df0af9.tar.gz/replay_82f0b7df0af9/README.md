# Replay package — entry 82f0b7df0af9

Conjecture: Sandpile 2-Rank Lower-Bounds Tree-Resolution Size of Tseitin

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-07 19:28 UTC.
Pre-registration hash committed before this test ran: `981cf7fa3c81949b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
