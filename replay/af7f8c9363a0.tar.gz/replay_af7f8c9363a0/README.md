# Replay package — entry af7f8c9363a0

Conjecture: Minimal Rank of Groupoid Actions over Boolean Circuit Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 04:33 UTC.
Pre-registration hash committed before this test ran: `0fb63079b32dc0e6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
