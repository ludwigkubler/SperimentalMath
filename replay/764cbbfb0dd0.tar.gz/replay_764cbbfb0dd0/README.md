# Replay package — entry 764cbbfb0dd0

Conjecture: Minimal Order of Quadratic Residues Bounds Resolution Proof Width for Random k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 11:35 UTC.
Pre-registration hash committed before this test ran: `7bf47b0e8a97202b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
