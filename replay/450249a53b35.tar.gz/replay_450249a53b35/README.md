# Replay package — entry 450249a53b35

Conjecture: Minimal Index of Automorphism Groups in Hyperbolic Geometry Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 09:27 UTC.
Pre-registration hash committed before this test ran: `99bbc33a2840f076`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
