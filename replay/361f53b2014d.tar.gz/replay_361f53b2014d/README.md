# Replay package — entry 361f53b2014d

Conjecture: Minimal Polynomial Hierarchy Depth of Monotone DNF Formulas Bounds k-CLIQUE Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 13:30 UTC.
Pre-registration hash committed before this test ran: `7eb69d50222bbc6d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
