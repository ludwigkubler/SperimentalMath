# Replay package — entry 58e4fa98b759

Conjecture: Minimal Gromov-Witten Invariant and ACC0 Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 14:55 UTC.
Pre-registration hash committed before this test ran: `cde316cfe55d56fd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
