# Replay package — entry b045e08ff6c7

Conjecture: Tamari Rotation Rank of Canonical DT Lower-Bounds XOR-Lifted F2-Rank

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 19:17 UTC.
Pre-registration hash committed before this test ran: `89480b76d8a0a4b4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
