# Replay package — entry b6381d0fbb46

Conjecture: Minimal p-Adic Hensel's Lifting Exponent and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 02:54 UTC.
Pre-registration hash committed before this test ran: `c7fffa1fd0810c7a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
