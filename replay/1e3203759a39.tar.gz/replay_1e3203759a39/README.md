# Replay package — entry 1e3203759a39

Conjecture: Minimal Rank of Real Algebraic Varieties over Boolean Functions vs AC0 Parity Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 08:10 UTC.
Pre-registration hash committed before this test ran: `ef9d6e0fa7a902cd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
