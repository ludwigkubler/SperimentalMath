import random
import math
from fractions import Fraction

def generate_dnf_formula(n, k):
    if n < 1 or k < 1:
        return []
    
    variables = list(range(1, n + 1))
    clauses = []
    
    for _ in range(k):
        clause = random.sample(variables, random.randint(1, n))
        clauses.append(clause)
    
    return clauses

def characteristic_polynomial(dnf_formula):
    if not dnf_formula:
        return [1]
    
    n = len(dnf_formula[0])
    poly = [1] * (n + 1)
    
    for clause in dnf_formula:
        term = [1]
        for var in clause:
            term.append(-var)
        
        poly = polynomial_multiplication(poly, term)
    
    return poly

def polynomial_multiplication(p1, p2):
    result = [0] * (len(p1) + len(p2) - 1)
    
    for i, coeff1 in enumerate(p1):
        for j, coeff2 in enumerate(p2):
            result[i + j] += coeff1 * coeff2
    
    return result

def tropical_discriminant(poly):
    if not poly:
        return None
    
    n = len(poly) - 1
    discriminant = float('-inf')
    
    for i in range(1, n):
        term = poly[i]
        discriminant = max(discriminant, term)
    
    return discriminant

def run_trial(seed: int) -> dict:
    random.seed(seed)
    results = []
    
    for n in [5, 10, 15, 20, 30, 40]:
        k = random.randint(1, min(n // 2, 5))
        dnf_formula = generate_dnf_formula(n, k)
        
        if not dnf_formula:
            continue
        
        poly = characteristic_polynomial(dnf_formula)
        disc = tropical_discriminant(poly)
        
        if disc is None or disc <= 0:
            continue
        
        results.append((n, disc))
    
    if not results:
        return {
            "metric_name": "tropical_discriminant",
            "metric_value": float('nan'),
            "instances_tested": 0,
            "conjecture_holds": False,
            "counterexample": "mapping_undefined"
        }
    
    n_values = [n for n, _ in results]
    disc_values = [disc for _, disc in results]
    
    mean_disc = sum(disc_values) / len(disc_values)
    std_disc = math.sqrt(sum((disc - mean_disc) ** 2 for disc in disc_values) / len(disc_values))
    
    conjecture_holds = all(mean_disc >= n ** (3/2) for n, _ in results) and std_disc < 0.1 * mean_disc
    
    return {
        "metric_name": "tropical_discriminant",
        "metric_value": mean_disc,
        "instances_tested": len(results),
        "conjecture_holds": conjecture_holds,
        "counterexample": "" if conjecture_holds else f"mean<{mean_disc}, std<{std_disc}>"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    
    results = []
    
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {{\"seed\": {seed}, \"metric_name\": \"{result['metric_name']}\", \"metric_value\": {result['metric_value']}, \"instances_tested\": {result['instances_tested']}, \"conjecture_holds\": {result['conjecture_holds']}, \"counterexample\": \"{result['counterexample']}\"}}")
        results.append(result)
    
    mean_disc = sum(r['metric_value'] for r in results if not math.isnan(r['metric_value'])) / len(results)
    std_disc = math.sqrt(sum((r['metric_value'] - mean_disc) ** 2 for r in results if not math.isnan(r['metric_value'])) / len(results))
    
    support_fraction = sum(1 for r in results if r['conjecture_holds']) / len(results)
    
    if all(r['conjecture_holds'] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_disc} std={std_disc} support_fraction={support_fraction}")
    elif any(not r['conjecture_holds'] for r in results) and support_fraction >= 0.8:
        print(f"RESULT: FALSIFIED counterexample=\"{results[next(i for i, r in enumerate(results) if not r['conjecture_holds'])['counterexample']}\" first_failing_seed={seeds[next(i for i, r in enumerate(results) if not r['conjecture_holds'])]}")
    else:
        print(f"RESULT: INCONCLUSIVE reason=insufficient_evidence n_tested={len(results)}")