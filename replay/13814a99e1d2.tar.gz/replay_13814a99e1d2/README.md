# Replay package — entry 13814a99e1d2

Conjecture: Minimal Rank of Cyclic Homology over Boolean Tensor Product Valuations

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 14:51 UTC.
Pre-registration hash committed before this test ran: `c0c54ef8c24bdd2a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
