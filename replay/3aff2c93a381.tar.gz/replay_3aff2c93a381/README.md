# Replay package — entry 3aff2c93a381

Conjecture: Minimal Geometric Entropy of Tropical Curves in Tseitin Formula Resolution Proofs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 00:28 UTC.
Pre-registration hash committed before this test ran: `86cb49d8c15f80f4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
