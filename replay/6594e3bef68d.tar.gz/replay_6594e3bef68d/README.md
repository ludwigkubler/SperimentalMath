# Replay package — entry 6594e3bef68d

Conjecture: Kronecker Coefficient Asymmetry in Tensor Products of Permanent Representations

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 08:24 UTC.
Pre-registration hash committed before this test ran: `ea6237704d3fbd33`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
