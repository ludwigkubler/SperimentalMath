# Replay package — entry ebd764aaaa68

Conjecture: SOS Refutation Degree and Convex Body Volume for Random 3-SAT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 03:44 UTC.
Pre-registration hash committed before this test ran: `9b8b94118ce097c1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
