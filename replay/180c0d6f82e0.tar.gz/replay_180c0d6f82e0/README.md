# Replay package — entry 180c0d6f82e0

Conjecture: LZ78 Compression Ratio Lower-Bounds MCSP Truth-Table Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 15:37 UTC.
Pre-registration hash committed before this test ran: `c5ff237a1a6d3980`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
