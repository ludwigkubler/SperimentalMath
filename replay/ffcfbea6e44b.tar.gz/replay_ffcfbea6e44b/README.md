# Replay package — entry ffcfbea6e44b

Conjecture: Minimal Index of Automorphic Representations and Circuit Monotone Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 17:10 UTC.
Pre-registration hash committed before this test ran: `c0e78f019e0241f6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
