# Replay package — entry 7003ce43815a

Conjecture: Symmetric Group Fourier Coefficient Gap in Disjointness Communication Matrices

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 17:22 UTC.
Pre-registration hash committed before this test ran: `cc3f7a3df88ea6a5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
