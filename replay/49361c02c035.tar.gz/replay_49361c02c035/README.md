# Replay package — entry 49361c02c035

Conjecture: SOS Moment Matrix Spectral Gap and Max-CUT Approximation Ratio

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 08:09 UTC.
Pre-registration hash committed before this test ran: `735a0e68b05e8960`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
