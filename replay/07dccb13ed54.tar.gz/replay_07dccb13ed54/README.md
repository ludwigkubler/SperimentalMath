# Replay package — entry 07dccb13ed54

Conjecture: Minimal Rank of Representations Bounds Circuit Monotonicity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 23:57 UTC.
Pre-registration hash committed before this test ran: `9b831db349247bfe`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
