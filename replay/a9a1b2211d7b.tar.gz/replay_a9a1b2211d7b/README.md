# Replay package — entry a9a1b2211d7b

Conjecture: Minimal Rank of Noncrossing Partitions over Matroids vs Communication Complexity for Disjointness

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 11:40 UTC.
Pre-registration hash committed before this test ran: `03798296ae57304a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
