# Replay package — entry e2fdb76135d2

Conjecture: Minimal Rank of Configuration Space Metrics over Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 15:18 UTC.
Pre-registration hash committed before this test ran: `b1c8a93ffec256c5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
