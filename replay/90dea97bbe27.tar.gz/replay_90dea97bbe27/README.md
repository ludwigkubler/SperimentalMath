# Replay package — entry 90dea97bbe27

Conjecture: Fourier L1 Norm Cubed-Polynomial Bound for Read-Twice BPs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 11:54 UTC.
Pre-registration hash committed before this test ran: `b2e187c3c8db7131`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
