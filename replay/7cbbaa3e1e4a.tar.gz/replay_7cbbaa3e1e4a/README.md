# Replay package — entry 7cbbaa3e1e4a

Conjecture: Tropical Rank of Clause-Indicator Polynomial Bounds ACC Circuit Size

Verdict (original run): SUPPORTED

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 05:30 UTC.
Pre-registration hash committed before this test ran: `f837822c12848036`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
