# Replay package — entry bed1075d7871

Conjecture: Minimal Rank of Formal Contexts and Resolution Proof Width Lower Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 10:26 UTC.
Pre-registration hash committed before this test ran: `b101feb28633d4dc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
