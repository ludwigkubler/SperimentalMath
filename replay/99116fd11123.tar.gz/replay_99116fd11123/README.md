# Replay package — entry 99116fd11123

Conjecture: Minimal Number of Automorphic Forms and Resolution Proof Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 12:43 UTC.
Pre-registration hash committed before this test ran: `7d31ac23a1b6b8e8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
