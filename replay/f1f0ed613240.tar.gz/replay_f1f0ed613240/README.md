# Replay package — entry f1f0ed613240

Conjecture: Erdős-Rado Sunflower Petals Lower-Bound Lifted Log-Rank for IND_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 18:31 UTC.
Pre-registration hash committed before this test ran: `0c873af1ea057046`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
