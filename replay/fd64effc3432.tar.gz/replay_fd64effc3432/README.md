# Replay package — entry fd64effc3432

Conjecture: Minimal Rank of Noncrossing Partitions vs Read-Twice BP Size with Algebraic Geometry Invariants

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 14:37 UTC.
Pre-registration hash committed before this test ran: `c0f093e60cb816b2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
