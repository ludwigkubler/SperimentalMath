# Replay package — entry 160991b2d732

Conjecture: Minimal Rank of Geometric Algebra Representations vs Monotone Circuit Depth for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 22:57 UTC.
Pre-registration hash committed before this test ran: `a0eff0ad45917ef9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
