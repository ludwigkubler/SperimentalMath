# Replay package — entry e45b325ac803

Conjecture: Schur-Weyl Invariant Ratio for Random Boolean Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 00:46 UTC.
Pre-registration hash committed before this test ran: `10b9932ad53ce9cc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
