# Replay package — entry 949e268cc975

Conjecture: Minimal Order of Brauer Groups Bounds Read-Twice BP Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 07:27 UTC.
Pre-registration hash committed before this test ran: `a585626893ac4cae`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
