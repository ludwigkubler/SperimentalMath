# Replay package — entry 8de14a1366b2

Conjecture: Symmetric Tensor Rank Gap in Permanent vs Determinant Decompositions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 01:23 UTC.
Pre-registration hash committed before this test ran: `2ba31ecdad673661`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
