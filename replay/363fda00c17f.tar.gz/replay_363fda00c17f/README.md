# Replay package — entry 363fda00c17f

Conjecture: Fourier Spectral Entropy of Clause-Falsification Polynomial Bounds Tree-Resolution

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 01:40 UTC.
Pre-registration hash committed before this test ran: `fa729b956355e2cd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
