# Replay package — entry a532431426bd

Conjecture: Minimal Geometric Entropy Bound for DPLL Proof Path Length via Information Theoretic Invariants

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 18:25 UTC.
Pre-registration hash committed before this test ran: `83479af3691bdcc5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
