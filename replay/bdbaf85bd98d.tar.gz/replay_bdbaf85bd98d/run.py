import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_boolean_function(n):
        return [random.choice([0, 1]) for _ in range(2**n)]
    
    def circuit_size(f):
        n = len(f)
        if n == 1:
            return 1
        else:
            return 2 + min(circuit_size(f[:n//2]), circuit_size(f[n//2:]))
    
    def fourier_transform(f):
        n = len(f)
        result = [0] * (2*n)
        for k in range(2*n):
            sum_val = 0
            for j in range(n):
                sum_val += f[j] * math.cos(math.pi * j * k / n) + f[j+n] * math.sin(math.pi * j * k / n)
            result[k] = sum_val
        return result
    
    def min_rank_kostant_sheaf(f):
        n = len(f)
        fourier_f = fourier_transform(f)
        rank = 0
        for i in range(n):
            if fourier_f[i] != 0:
                rank += 1
        return rank
    
    n = random.randint(5, 40)
    f = generate_boolean_function(n)
    
    rank = min_rank_kostant_sheaf(f)
    circuit_size_val = circuit_size(f)
    
    if circuit_size_val == 0:
        return {
            "metric_name": "min_r rank(KostantSheaf(Fourier(f)))",
            "metric_value": float('inf'),
            "instances_tested": 1,
            "conjecture_holds": False,
            "counterexample": "Circuit size is zero"
        }
    
    c = 2  # Example constant, can be adjusted
    if rank <= c * circuit_size_val:
        return {
            "metric_name": "min_r rank(KostantSheaf(Fourier(f)))",
            "metric_value": rank,
            "instances_tested": 1,
            "conjecture_holds": True,
            "counterexample": ""
        }
    else:
        return {
            "metric_name": "min_r rank(KostantSheaf(Fourier(f)))",
            "metric_value": rank,
            "instances_tested": 1,
            "conjecture_holds": False,
            "counterexample": f"Counterexample: n={n}, rank={rank}, circuit_size={circuit_size_val}"
        }

if __name__ == "__main__":
    seeds = [int(arg) for arg in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    results = []
    
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    if all(result["conjecture_holds"] for result in results):
        mean_value = sum(result["metric_value"] for result in results) / len(results)
        support_fraction = 1.0
        print(f"RESULT: SUPPORTED mean={mean_value} std=0 support_fraction={support_fraction}")
    else:
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        counterexample = next(result["counterexample"] for result in results if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{counterexample}\" first_failing_seed={first_failing_seed}")