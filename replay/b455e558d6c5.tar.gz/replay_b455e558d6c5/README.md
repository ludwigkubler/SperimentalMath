# Replay package — entry b455e558d6c5

Conjecture: Hilbert Function Inverse Proportional to 3-SAT Solution Count

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 19:52 UTC.
Pre-registration hash committed before this test ran: `0148aa4ae5c86ffd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
