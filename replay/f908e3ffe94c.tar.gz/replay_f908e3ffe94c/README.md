# Replay package — entry f908e3ffe94c

Conjecture: Minimal Rank of tropical Grothendieck-Witt classes bounds monotone circuit size for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 22:16 UTC.
Pre-registration hash committed before this test ran: `922f4c1ccede757d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
