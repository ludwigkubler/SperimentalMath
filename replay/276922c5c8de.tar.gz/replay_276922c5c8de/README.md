# Replay package — entry 276922c5c8de

Conjecture: Minimal Rank of Configuration Spaces vs ACC⁰ Circuit Weights

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 19:33 UTC.
Pre-registration hash committed before this test ran: `1aef09a49627a913`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
