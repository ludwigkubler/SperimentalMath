# Replay package — entry 97906ec529b6

Conjecture: Szegedy Quantum-Walk Phase Gap Lower-Bounds Tseitin Tree-Resolution

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 08:08 UTC.
Pre-registration hash committed before this test ran: `dbc2f1b64162c9bd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
