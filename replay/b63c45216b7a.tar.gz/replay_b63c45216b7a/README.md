# Replay package — entry b63c45216b7a

Conjecture: Möbius Function of Minterm Lattice Bounds Indexing-Lifted Communication

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 08:47 UTC.
Pre-registration hash committed before this test ran: `2246a8c4a563b38d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
