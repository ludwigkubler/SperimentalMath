# Replay package — entry ecb24eb72dd3

Conjecture: Minimal Order of Tropical Hodge Decomposition and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 00:04 UTC.
Pre-registration hash committed before this test ran: `dcaca5ab6413f624`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
