# Replay package — entry 00bd44822e30

Conjecture: Minimal Order of p-adic Expansions and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 02:10 UTC.
Pre-registration hash committed before this test ran: `21dc1969b7c94f5c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
