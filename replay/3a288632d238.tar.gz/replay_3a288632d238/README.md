# Replay package — entry 3a288632d238

Conjecture: Invariant Ring Degree Bounds SOS Refutation Degree for Symmetric CSPs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 06:36 UTC.
Pre-registration hash committed before this test ran: `aecd9d80d007b5c6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
