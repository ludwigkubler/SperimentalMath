# Replay package — entry e249e7fc786f

Conjecture: Minimal Rank of K-theory over Function Fields vs Resolution Proof Length for Random k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 03:40 UTC.
Pre-registration hash committed before this test ran: `eb2b2fb93c19b33e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
