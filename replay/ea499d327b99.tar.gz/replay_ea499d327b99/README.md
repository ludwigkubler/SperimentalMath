# Replay package — entry ea499d327b99

Conjecture: Geometric Entanglement Measure of Boolean Functions vs Resolution Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 14:09 UTC.
Pre-registration hash committed before this test ran: `98d3381fec7838bf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
