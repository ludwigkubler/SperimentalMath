# Replay package — entry 5085ca5c3a42

Conjecture: Minimal Order of Hodge Decomposition of Boolean Functions Bounds Frege Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 05:35 UTC.
Pre-registration hash committed before this test ran: `159b6e621a60f286`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
