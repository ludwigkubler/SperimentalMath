# Replay package — entry 81ff78943fcc

Conjecture: Minimal Rank of Free Probability Distributions Bounds Disjointness Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 22:16 UTC.
Pre-registration hash committed before this test ran: `6308f4d6fd32e665`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
