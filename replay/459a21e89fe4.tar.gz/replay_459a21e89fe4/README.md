# Replay package — entry 459a21e89fe4

Conjecture: Minimal Rank of Nonpositive Curvature Metrics over Tseitin Circuit Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 10:04 UTC.
Pre-registration hash committed before this test ran: `2906941f7dc63448`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
