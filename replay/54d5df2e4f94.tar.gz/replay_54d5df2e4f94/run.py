import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_random_boolean_function(n):
        return [random.choice([0, 1]) for _ in range(2**n)]
    
    def quaternion_algebra(f):
        n = len(f)
        if n <= 1:
            return None
        Q_f = []
        for i in range(n):
            row = []
            for j in range(n):
                if f[i] == f[j]:
                    row.append(0)
                else:
                    row.append(1)
            Q_f.append(row)
        return Q_f
    
    def arithmetic_rank(Q):
        n = len(Q)
        rank = 0
        for i in range(n):
            pivot_row = None
            for j in range(i, n):
                if Q[j][i] != 0:
                    pivot_row = j
                    break
            if pivot_row is None:
                continue
            rank += 1
            for j in range(n):
                if j == pivot_row:
                    continue
                factor = Fraction(Q[j][i], Q[pivot_row][i])
                for k in range(n):
                    Q[j][k] -= factor * Q[pivot_row][k]
        return rank
    
    def communication_complexity(f):
        n = len(f)
        if n == 1:
            return 0
        return math.ceil(math.log2(n))
    
    f = generate_random_boolean_function(40)
    Q_f = quaternion_algebra(f)
    if Q_f is None:
        return {
            "metric_name": "arithmetic_rank",
            "metric_value": None,
            "instances_tested": 1,
            "conjecture_holds": False,
            "counterexample": "mapping_undefined"
        }
    
    R_QUAT = arithmetic_rank(Q_f)
    CC_R_DISJ = communication_complexity(f)
    
    return {
        "metric_name": "arithmetic_rank",
        "metric_value": R_QUAT,
        "instances_tested": 1,
        "conjecture_holds": R_QUAT >= math.ceil(0.5 * len(f)),
        "counterexample": ""
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] if sys.argv[1:] else [2**i + 3 for i in range(5, 8)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results if r["metric_value"] is not None) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value)**2 for r in results if r["metric_value"] is not None) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["metric_value"] is not None for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"mapping_undefined\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE reason=mapping_undefined")