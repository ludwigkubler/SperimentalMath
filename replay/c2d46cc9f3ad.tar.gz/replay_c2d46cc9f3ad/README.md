# Replay package — entry c2d46cc9f3ad

Conjecture: Hodge Diamond Invariant and Resolution Proof Width in Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 13:45 UTC.
Pre-registration hash committed before this test ran: `7a090a332153e05e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
