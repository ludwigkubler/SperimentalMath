# Replay package — entry 864deba2fadd

Conjecture: Minimal Rank of Braided Group Representations and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 06:50 UTC.
Pre-registration hash committed before this test ran: `be990279dec22880`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
