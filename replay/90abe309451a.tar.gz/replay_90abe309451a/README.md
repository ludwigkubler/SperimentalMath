# Replay package — entry 90abe309451a

Conjecture: Fourier Coefficient Spread and ACC⁰ Circuit Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 05:17 UTC.
Pre-registration hash committed before this test ran: `b72019fcb3187aa9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
