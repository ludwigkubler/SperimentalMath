# Replay package — entry 89d7e3ddf0de

Conjecture: Finite Field Rank and Branching Program Width for Boolean Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 04:08 UTC.
Pre-registration hash committed before this test ran: `40c71c1a6a88f5ee`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
