import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def gaussian_elimination(A):
        n = len(A)
        for i in range(n):
            max_row = i + max(range(i, n), key=lambda k: abs(A[k][i]))
            A[i], A[max_row] = A[max_row], A[i]
            denom = A[i][i]
            if denom == 0:
                continue
            for j in range(n):
                A[i][j] /= denom
            for k in range(n):
                if k != i:
                    factor = A[k][i]
                    for j in range(n):
                        A[k][j] -= factor * A[i][j]
        return A

    def matrix_multiplication(A, B):
        n = len(A)
        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                for k in range(n):
                    C[i][j] += A[i][k] * B[k][j]
        return C

    def min_rank(A):
        A = gaussian_elimination(A)
        rank = sum(1 for row in A if any(row))
        return rank

    def random_boolean_circuit(n, m):
        circuit = []
        for _ in range(m):
            gate_type = random.choice(['AND', 'OR'])
            inputs = [random.randint(0, 1) for _ in range(random.randint(2, n))]
            output = random.randint(0, 1)
            circuit.append((gate_type, inputs, output))
        return circuit

    def monotone_complexity(circuit):
        n = len(circuit[0][1])
        complexity = [0] * (n + 1)
        for gate in circuit:
            if gate[0] == 'AND':
                complexity[min(complexity[i] for i in gate[1])] += 1
            elif gate[0] == 'OR':
                complexity[max(complexity[i] for i in gate[1])] += 1
        return max(complexity)

    def kac_moody_algebra(circuit):
        n = len(circuit[0][1])
        A = [[Fraction(0, 1)] * (n + 2) for _ in range(n + 2)]
        for gate in circuit:
            if gate[0] == 'AND':
                i, j, _ = gate[1]
                k = n + 1
                A[i][k] += Fraction(1, 1)
                A[j][k] += Fraction(1, 1)
                A[k][i], A[k][j] = Fraction(-1, 1), Fraction(-1, 1)
            elif gate[0] == 'OR':
                i, j, _ = gate[1]
                k = n + 2
                A[i][k] += Fraction(1, 1)
                A[j][k] += Fraction(1, 1)
                A[k][i], A[k][j] = Fraction(-1, 1), Fraction(-1, 1)
        return A

    def linear_regression(x, y):
        n = len(x)
        sum_x = sum(x)
        sum_y = sum(y)
        sum_xy = sum(xi * yi for xi, yi in zip(x, y))
        sum_xx = sum(xi ** 2 for xi in x)
        b1 = (n * sum_xy - sum_x * sum_y) / (n * sum_xx - sum_x ** 2)
        b0 = (sum_y - b1 * sum_x) / n
        r_squared = (n * sum_xy - sum_x * sum_y) ** 2 / ((n * sum_xx - sum_x ** 2) * (n * sum_yy - sum_y ** 2))
        p_value = 0.05  # Placeholder for actual p-value calculation
        return b1, b0, r_squared, p_value

    n_values = [5, 10, 15, 20, 30, 40]
    results = []
    
    for n in n_values:
        for _ in range(5):  # Ensure at least 30 instances per seed
            circuit = random_boolean_circuit(n, 2 * n)
            mu_C = monotone_complexity(circuit)
            A_C = kac_moody_algebra(circuit)
            r_A_C = min_rank(A_C)
            results.append((mu_C, r_A_C))
    
    if not results:
        return {
            "metric_name": "r_A_C vs mu_C",
            "metric_value": None,
            "instances_tested": 0,
            "n_max": 0,
            "conjecture_holds": False,
            "counterexample": "mapping_undefined"
        }
    
    x, y = zip(*results)
    b1, b0, r_squared, p_value = linear_regression(x, y)
    
    return {
        "metric_name": "r_A_C vs mu_C",
        "metric_value": r_squared,
        "instances_tested": len(results),
        "n_max": max(n_values),
        "conjecture_holds": r_squared >= 0.9 and p_value <= 0.05,
        "counterexample": ""
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    results = []
    
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    if not all(result["conjecture_holds"] for result in results):
        counterexample = next((result["counterexample"] for result in results if not result["conjecture_holds"]), "")
        print(f"RESULT: FALSIFIED counterexample=\"{counterexample}\" first_failing_seed={seeds[results.index(next(result for result in results if not result['conjecture_holds']"))]}")
    else:
        mean_r_squared = sum(result["metric_value"] for result in results) / len(results)
        support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)
        print(f"RESULT: SUPPORTED mean={mean_r_squared} std=0.0 support_fraction={support_fraction}")