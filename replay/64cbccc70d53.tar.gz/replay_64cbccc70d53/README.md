# Replay package — entry 64cbccc70d53

Conjecture: Minimal Order of Groupoid Representations and Circuit Satisfiability Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 13:33 UTC.
Pre-registration hash committed before this test ran: `e91a1438723057c3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
