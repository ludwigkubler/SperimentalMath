# Replay package — entry 895f842e21c0

Conjecture: Minimal Rank of Cocomplexes and Circuit Monotone Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 06:32 UTC.
Pre-registration hash committed before this test ran: `f7ca6d59b1c4a03f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
