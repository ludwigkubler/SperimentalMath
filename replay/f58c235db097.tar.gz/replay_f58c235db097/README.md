# Replay package — entry f58c235db097

Conjecture: Moment Matrix Sparsity Lower Bound for Max-CUT SOS Approximation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 16:25 UTC.
Pre-registration hash committed before this test ran: `17653673121f5fcf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
