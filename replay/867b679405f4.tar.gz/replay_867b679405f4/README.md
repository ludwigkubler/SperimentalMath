# Replay package — entry 867b679405f4

Conjecture: Minimal Number of Coxeter Reflections Bound by Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 07:08 UTC.
Pre-registration hash committed before this test ran: `735691a2baeb841f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
