# Replay package — entry 88dea7710909

Conjecture: Minimal Rank of Noncrossing Partitions Bounds Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 03:23 UTC.
Pre-registration hash committed before this test ran: `166f34cd62b8bf04`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
