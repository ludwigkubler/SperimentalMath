# Replay package — entry 70e701d85c2e

Conjecture: Minimal Rank of Geometric Optics in Manifolds vs Circuit Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 16:38 UTC.
Pre-registration hash committed before this test ran: `50d843287492f620`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
