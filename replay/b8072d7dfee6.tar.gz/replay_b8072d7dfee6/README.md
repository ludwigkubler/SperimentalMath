# Replay package — entry b8072d7dfee6

Conjecture: Algebraic Topology Dimension Bounds Communication Complexity of XOR Games

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 08:40 UTC.
Pre-registration hash committed before this test ran: `0a75a84a8a540ca6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
