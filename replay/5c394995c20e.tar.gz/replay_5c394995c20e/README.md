# Replay package — entry 5c394995c20e

Conjecture: Minimal Rank of Algebraic K-Theory Groups over Tseitin Resolution Trees

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 22:42 UTC.
Pre-registration hash committed before this test ran: `7f0cf59a65e307b3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
