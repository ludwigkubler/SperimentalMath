# Replay package — entry a0e60f6945e2

Conjecture: Minimal Rank of Free Entropy over Graphs vs Distinguishing Tensor Width for BP_ReadTwice

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 07:20 UTC.
Pre-registration hash committed before this test ran: `4621b0947cbc5549`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
