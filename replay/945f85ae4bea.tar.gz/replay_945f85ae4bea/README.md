# Replay package — entry 945f85ae4bea

Conjecture: Minimal Nonnegative Minor Invariant Lower Bounds for Resolution Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 13:49 UTC.
Pre-registration hash committed before this test ran: `ad3d5840564cc5cc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
