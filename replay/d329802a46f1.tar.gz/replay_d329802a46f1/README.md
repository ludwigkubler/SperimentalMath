# Replay package — entry d329802a46f1

Conjecture: Golden-Ratio Rotation Discrepancy of Truth Tables Excludes ACC^0[m]

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 10:17 UTC.
Pre-registration hash committed before this test ran: `c2eb7a8547dc5c65`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
