# Replay package — entry e829c06885e3

Conjecture: Minimal Order of Groupoid Cospans and Communication Complexity Rank Variance Ratio

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 20:01 UTC.
Pre-registration hash committed before this test ran: `558910749bde17f7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
