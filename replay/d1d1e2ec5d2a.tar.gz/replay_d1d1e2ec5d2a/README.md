# Replay package — entry d1d1e2ec5d2a

Conjecture: Non-backtracking Spectral Gap Lower-Bounds Tseitin DPLL Trees

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 09:37 UTC.
Pre-registration hash committed before this test ran: `1ddccd36d31211cc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
