# Replay package — entry 4c309d5b8d47

Conjecture: Euler Characteristic of Configuration Spaces Bounds SAT Clause Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 21:07 UTC.
Pre-registration hash committed before this test ran: `ef3757cf60e6c4f0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
