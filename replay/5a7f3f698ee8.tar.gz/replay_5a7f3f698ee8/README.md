# Replay package — entry 5a7f3f698ee8

Conjecture: Minimal Rank of Kac-Moody Algebras and Circuit Monotone Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 15:26 UTC.
Pre-registration hash committed before this test ran: `b01886607d7f5acc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
