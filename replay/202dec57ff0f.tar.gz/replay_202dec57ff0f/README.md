# Replay package — entry 202dec57ff0f

Conjecture: Minimal Generality of Quasi-Polynomial Functors Bounds Circuit Depth for Boolean Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 03:22 UTC.
Pre-registration hash committed before this test ran: `e488d903607970da`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
