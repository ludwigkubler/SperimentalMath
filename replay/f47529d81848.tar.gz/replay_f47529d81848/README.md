# Replay package — entry f47529d81848

Conjecture: Minimal Order of Hodge Classes and Circuit Satisfiability Threshold

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 15:37 UTC.
Pre-registration hash committed before this test ran: `905978a03fe2fd00`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
