# Replay package — entry 28c209382021

Conjecture: Minimal Rank of Symplectic Geometry over XOR-AND Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 19:49 UTC.
Pre-registration hash committed before this test ran: `f58965df2fcf5f6c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
