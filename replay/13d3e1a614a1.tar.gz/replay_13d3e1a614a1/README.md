# Replay package — entry 13d3e1a614a1

Conjecture: Minimal Rank of Noncommutative Polynomial Representations vs DPLL Search Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 08:55 UTC.
Pre-registration hash committed before this test ran: `fe46c4f3edd962d8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
