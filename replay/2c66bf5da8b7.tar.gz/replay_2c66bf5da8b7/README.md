# Replay package — entry 2c66bf5da8b7

Conjecture: Minimal Order of Quaternion Algebras Bounds Tree-Like Resolution Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 19:18 UTC.
Pre-registration hash committed before this test ran: `86d80ca1fdbcfe1a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
