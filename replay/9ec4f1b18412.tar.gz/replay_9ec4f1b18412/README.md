# Replay package — entry 9ec4f1b18412

Conjecture: Level-1 Fourier Mass Fraction of Term Family Bounds Monotone CLIQUE DNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 02:22 UTC.
Pre-registration hash committed before this test ran: `9d5f901c3f362d2a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
