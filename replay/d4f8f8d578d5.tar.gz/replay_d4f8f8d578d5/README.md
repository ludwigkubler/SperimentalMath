# Replay package — entry d4f8f8d578d5

Conjecture: Minimal Local Index in Algebraic Topology and Frege Proof Depth Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 23:51 UTC.
Pre-registration hash committed before this test ran: `3ac8d3027f89dc46`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
