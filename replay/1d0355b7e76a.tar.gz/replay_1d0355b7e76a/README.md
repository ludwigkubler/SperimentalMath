# Replay package — entry 1d0355b7e76a

Conjecture: Euler Characteristic of Communication Graph Equals Deterministic Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 19:26 UTC.
Pre-registration hash committed before this test ran: `d9995c2825cde2fe`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
