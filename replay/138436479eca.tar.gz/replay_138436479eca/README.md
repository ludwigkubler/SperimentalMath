# Replay package — entry 138436479eca

Conjecture: Minimal Tropical Kähler Curvature and Circuit Monotone Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 07:44 UTC.
Pre-registration hash committed before this test ran: `c5987178460606e6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
