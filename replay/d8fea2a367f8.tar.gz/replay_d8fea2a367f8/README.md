# Replay package — entry d8fea2a367f8

Conjecture: Subfield Count in Finite Semifields Bounds ACC^0 Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 12:28 UTC.
Pre-registration hash committed before this test ran: `66f7348884409aad`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
