# Replay package — entry 83d26c2ef069

Conjecture: GCT Lie-Stabilizer Codimension Linearly Bounds ACC⁰ Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 00:01 UTC.
Pre-registration hash committed before this test ran: `28e89ae558787cfc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
