# Replay package — entry 497f8a1d1a5c

Conjecture: Minimal Rank of Tensors over Frege Proofs and Their Disproportionality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 16:33 UTC.
Pre-registration hash committed before this test ran: `78231b166a64c4fc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
