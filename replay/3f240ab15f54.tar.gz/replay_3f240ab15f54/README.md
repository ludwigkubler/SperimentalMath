# Replay package — entry 3f240ab15f54

Conjecture: Ideal Generator Count Bounds Extended Frege Proof Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 02:16 UTC.
Pre-registration hash committed before this test ran: `26ae9a907439bd85`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
