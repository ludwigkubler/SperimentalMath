# Replay package — entry e2141cf11087

Conjecture: Minimal Rank of p-Adic Valuations over Frege Proofs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 10:35 UTC.
Pre-registration hash committed before this test ran: `fe6f4ab35f5821a1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
