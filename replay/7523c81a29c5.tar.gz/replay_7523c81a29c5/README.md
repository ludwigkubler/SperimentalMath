# Replay package — entry 7523c81a29c5

Conjecture: Algebraic K-theory Rank and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 05:01 UTC.
Pre-registration hash committed before this test ran: `ea73245b778ac06f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
