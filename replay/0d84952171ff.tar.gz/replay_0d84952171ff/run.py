import random
import math

def generate_tseitin_formula(n):
    variables = [f'x{i}' for i in range(1, n+1)]
    clauses = []
    
    # Generate clauses for each variable
    for var in variables:
        clauses.append([var])
        clauses.append(['~', var])
    
    # Generate clauses for implications
    for i in range(n):
        for j in range(i+1, n):
            clauses.append([f'x{i}', f'x{j}', '~', f'x{random.randint(0, n-1)}'])
            clauses.append([f'~x{i}', f'~x{j}', f'x{random.randint(0, n-1)}'])
    
    # Generate the final clause
    literals = [f'x{i}' for i in range(n)]
    literals.extend(['~', f'x{i}' for i in range(n)])
    clauses.append(literals)
    
    return clauses

def dpll(clauses, assignment):
    if not clauses:
        return True
    
    unit_clauses = [c[0] for c in clauses if len(c) == 1]
    pure_literals = {}
    
    for l in set([c[0] for c in clauses]):
        positive_count = sum(1 for c in clauses if l in c)
        negative_count = sum(1 for c in clauses if '~' + l in c)
        
        if positive_count == 0:
            pure_literals[l] = False
        elif negative_count == 0:
            pure_literals[l] = True
    
    unit_clause = next((c[0] for c in clauses if len(c) == 1), None)
    if unit_clause:
        new_assignment = assignment.copy()
        new_assignment[unit_clause] = True
        return dpll([c for c in clauses if unit_clause not in c and '~' + unit_clause not in c], new_assignment)
    
    pure_literal = next((l for l, val in pure_literals.items() if all(l.startswith("~") != c.startswith("~") for c in clauses)), None)
    if pure_literal:
        new_assignment = assignment.copy()
        new_assignment[pure_literal] = pure_literals[pure_literal]
        return dpll([c for c in clauses if pure_literal not in c and '~' + pure_literal not in c], new_assignment)
    
    literal = random.choice(list(pure_literals.keys()))
    new_assignment_true = assignment.copy()
    new_assignment_true[literal] = True
    if dpll([c for c in clauses if literal not in c and '~' + literal not in c], new_assignment_true):
        return True
    
    new_assignment_false = assignment.copy()
    new_assignment_false[literal] = False
    return dpll([c for c in clauses if literal not in c and '~' + literal not in c], new_assignment_false)

def resolution_proof_length(clauses):
    def resolve(c1, c2):
        resolved = []
        for l1 in c1:
            if l1.startswith('~') and l1[1:] in c2:
                resolved.extend([l for l in c2 if l != l1[1:]])
                break
            elif not l1.startswith('~') and '~' + l1 in c2:
                resolved.extend([l for l in c2 if l != '~' + l1])
                break
        return resolved
    
    def dpll(clauses, assignment):
        if not clauses:
            return True
        
        unit_clauses = [c[0] for c in clauses if len(c) == 1]
        pure_literals = {}
        
        for l in set([c[0] for c in clauses]):
            positive_count = sum(1 for c in clauses if l in c)
            negative_count = sum(1 for c in clauses if '~' + l in c)
            
            if positive_count == 0:
                pure_literals[l] = False
            elif negative_count == 0:
                pure_literals[l] = True
        
        unit_clause = next((c[0] for c in clauses if len(c) == 1), None)
        if unit_clause:
            new_assignment = assignment.copy()
            new_assignment[unit_clause] = True
            return dpll([c for c in clauses if unit_clause not in c and '~' + unit_clause not in c], new_assignment)
        
        pure_literal = next((l for l, val in pure_literals.items() if all(l.startswith("~") != c.startswith("~") for c in clauses)), None)
        if pure_literal:
            new_assignment = assignment.copy()
            new_assignment[pure_literal] = pure_literals[pure_literal]
            return dpll([c for c in clauses if pure_literal not in c and '~' + pure_literal not in c], new_assignment)
        
        literal = random.choice(list(pure_literals.keys()))
        new_assignment_true = assignment.copy()
        new_assignment_true[literal] = True
        if dpll([c for c in clauses if literal not in c and '~' + literal not in c], new_assignment_true):
            return True
        
        new_assignment_false = assignment.copy()
        new_assignment_false[literal] = False
        return dpll([c for c in clauses if literal not in c and '~' + literal not in c], new_assignment_false)
    
    def resolve_all(clauses):
        while True:
            new_clauses = []
            found_resolvent = False
            
            for i in range(len(clauses)):
                for j in range(i+1, len(clauses)):
                    resolvent = resolve(clauses[i], clauses[j])
                    if resolvent:
                        new_clauses.append(resolvent)
                        found_resolvent = True
                        break
                if found_resolvent:
                    break
            
            if not found_resolvent:
                return clauses
            
            clauses.extend(new_clauses)
    
    resolved_clauses = resolve_all(clauses)
    return len(resolved_clauses)

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n = random.choice([5, 10, 15, 20, 30, 40])
    formula = generate_tseitin_formula(n)
    
    rank = len(formula)
    proof_length = resolution_proof_length(formula)
    
    return {
        "metric_name": "rank",
        "metric_value": rank,
        "instances_tested": 1,
        "conjecture_holds": rank <= 2 * proof_length,
        "counterexample": "" if rank <= 2 * proof_length else f"Tseitin formula with n={n}, rank={rank}, proof_length={proof_length}"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [random.randint(2, 997) for _ in range(30)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_rank = sum(r["metric_value"] for r in results) / len(results)
    std_dev = math.sqrt(sum((r["metric_value"] - mean_rank) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_rank} std={std_dev} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_rank} std={std_dev} support_fraction={support_fraction}")
    else:
        first_failing_seed = next((r["seed"] for r in results if not r["conjecture_holds"]), None)
        print(f"RESULT: FALSIFIED counterexample=\"rank exceeds twice proof length\" first_failing_seed={first_failing_seed}")