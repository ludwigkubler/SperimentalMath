# Replay package — entry c1ce4a4a2e2e

Conjecture: Minimal Rank of Tropicalized Geometric Quantization vs Branching Program Width for IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 23:16 UTC.
Pre-registration hash committed before this test ran: `725e1b8b1dec26c8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
