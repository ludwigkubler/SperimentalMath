# Replay package — entry eec41c045657

Conjecture: Minimal p-Adic Order and Frege Proof Depth Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 03:49 UTC.
Pre-registration hash committed before this test ran: `d0a077310d709ac5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
