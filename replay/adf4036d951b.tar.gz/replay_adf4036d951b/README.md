# Replay package — entry adf4036d951b

Conjecture: Free Cumulant Gap in Read-Twice BP for IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 01:28 UTC.
Pre-registration hash committed before this test ran: `f538441f45633a5a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
