# Replay package — entry 3ea965353734

Conjecture: Minimal Rank of Noncommutative Crossed Products over Boolean Algebras vs AC0 Parity Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 15:00 UTC.
Pre-registration hash committed before this test ran: `513f06f9ebf6f493`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
