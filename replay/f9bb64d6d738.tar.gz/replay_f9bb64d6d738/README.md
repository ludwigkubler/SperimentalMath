# Replay package — entry f9bb64d6d738

Conjecture: Minimal Rank of Generalized Ehrhart Lattice and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 06:43 UTC.
Pre-registration hash committed before this test ran: `c6d89a4b72060b00`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
