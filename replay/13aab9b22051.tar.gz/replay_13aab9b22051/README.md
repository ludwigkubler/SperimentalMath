# Replay package — entry 13aab9b22051

Conjecture: Castelnuovo-Mumford Regularity of Partial Derivative Ideals Bounds ABP Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 04:17 UTC.
Pre-registration hash committed before this test ran: `720a87873a39ba13`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
