# Replay package — entry 07a95b1fe6d5

Conjecture: Minimal Symplectic Volume in Affine Geometry and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 00:28 UTC.
Pre-registration hash committed before this test ran: `d67b3aeefb6da6de`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
