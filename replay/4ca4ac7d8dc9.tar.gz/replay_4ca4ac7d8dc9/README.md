# Replay package — entry 4ca4ac7d8dc9

Conjecture: Minimal Brauer Induction Index and Communication Rank Growth Correlation for Boolean Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 10:16 UTC.
Pre-registration hash committed before this test ran: `21a72b138964cc4b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
