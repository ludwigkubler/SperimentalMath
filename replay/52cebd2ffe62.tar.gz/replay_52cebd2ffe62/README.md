# Replay package — entry 52cebd2ffe62

Conjecture: Pebble-Cost Gadget Lifts Decision Tree Depth to KW-Game Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 01:38 UTC.
Pre-registration hash committed before this test ran: `110e5a59e2ba7796`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
