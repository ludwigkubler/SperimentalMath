# Replay package — entry d4127da8cdbb

Conjecture: Minimal Local Coherence of Vertex Operator Algebras and Circuit Depth Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 20:57 UTC.
Pre-registration hash committed before this test ran: `c152bfd30f6c2369`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
