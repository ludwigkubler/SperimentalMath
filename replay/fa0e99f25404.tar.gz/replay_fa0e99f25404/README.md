# Replay package — entry fa0e99f25404

Conjecture: Minimal Rank of Group Representations vs Circuit Lower Bounds for Polynomial Inversion

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 00:00 UTC.
Pre-registration hash committed before this test ran: `40e6500a56d74316`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
