# Replay package — entry 4dc9a0a83fd4

Conjecture: Minimal Rank of Noncrossing Partitions in Graph Theory and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 07:08 UTC.
Pre-registration hash committed before this test ran: `d53b772096c139a3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
