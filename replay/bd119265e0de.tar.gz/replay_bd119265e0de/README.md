# Replay package — entry bd119265e0de

Conjecture: Minimal Rank of Noncrossing Partition Matroids over Boolean Functions vs Randomized Communication Complexity for DISJOINTNESS

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 18:32 UTC.
Pre-registration hash committed before this test ran: `d407b0d5989be5bc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
