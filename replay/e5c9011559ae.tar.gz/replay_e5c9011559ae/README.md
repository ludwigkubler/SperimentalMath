# Replay package — entry e5c9011559ae

Conjecture: Minimal Order of Artin Groups Bounds Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 06:07 UTC.
Pre-registration hash committed before this test ran: `642523be5f3198f3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
