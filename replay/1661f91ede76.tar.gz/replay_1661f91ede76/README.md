# Replay package — entry 1661f91ede76

Conjecture: Cycle Matroid Rank Inverse Proportional to Resolution Proof Size for 3-SAT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 22:27 UTC.
Pre-registration hash committed before this test ran: `a36ff19f965e0b06`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
