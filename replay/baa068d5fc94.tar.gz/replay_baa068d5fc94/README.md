# Replay package — entry baa068d5fc94

Conjecture: Minimal Rank of Configuration Spaces over Boolean Functions vs Decision Tree State Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 15:38 UTC.
Pre-registration hash committed before this test ran: `09a61bce897fb203`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
