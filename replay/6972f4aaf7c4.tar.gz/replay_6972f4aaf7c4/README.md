# Replay package — entry 6972f4aaf7c4

Conjecture: Invariant Generator Count Bounds SOS Refutation Degree for Symmetric CSPs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 08:00 UTC.
Pre-registration hash committed before this test ran: `798ed89b3c584e34`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
