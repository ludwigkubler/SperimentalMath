# Replay package — entry 349d37e39ca6

Conjecture: Minimal Symplectic Capacity Bounds Tree-Like Resolution Proof Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 23:19 UTC.
Pre-registration hash committed before this test ran: `138a56bff5224dff`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
