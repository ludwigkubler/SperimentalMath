# Replay package — entry c18d42c448ab

Conjecture: Matroid Girth of Monotone DNF Implies k-CLIQUE Circuit Size Lower Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 09:26 UTC.
Pre-registration hash committed before this test ran: `cd223f8964c2e39e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
