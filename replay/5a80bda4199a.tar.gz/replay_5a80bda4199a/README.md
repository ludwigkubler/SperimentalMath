# Replay package — entry 5a80bda4199a

Conjecture: Minimal Rank of Noncommutative Yang-Baxter Equations and Circuit Monotone Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 07:49 UTC.
Pre-registration hash committed before this test ran: `2a3bb16c4416dad4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
