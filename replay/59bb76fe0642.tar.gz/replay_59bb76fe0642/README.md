# Replay package — entry 59bb76fe0642

Conjecture: Minimal Geometric Entropy of Boolean Functions vs. Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 11:25 UTC.
Pre-registration hash committed before this test ran: `f4ecedd19266c235`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
