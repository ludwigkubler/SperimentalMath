# Replay package — entry df51ab9d90c5

Conjecture: Minimal Geometric Langlands Dimension Correlation with Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 14:52 UTC.
Pre-registration hash committed before this test ran: `0d42e4e9c42b9b31`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
