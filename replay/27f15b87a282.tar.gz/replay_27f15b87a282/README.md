# Replay package — entry 27f15b87a282

Conjecture: Minimal Quadratic Form Rank Bound on Frege Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 20:37 UTC.
Pre-registration hash committed before this test ran: `25467b6967f4e330`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
