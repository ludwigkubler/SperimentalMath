# Replay package — entry 629b88289988

Conjecture: Minimal Hodge Index of Tropicalized Boolean Functions Bounds Resolution Proof Width for Random k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 10:53 UTC.
Pre-registration hash committed before this test ran: `77a0977bae39bc71`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
