# Replay package — entry 97e6bf05f9a9

Conjecture: Minimal Rank of Tropical Division Algebras vs SAT Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 10:26 UTC.
Pre-registration hash committed before this test ran: `d2a8e5aebab828d0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
