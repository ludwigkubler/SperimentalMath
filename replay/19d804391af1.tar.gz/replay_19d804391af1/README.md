# Replay package — entry 19d804391af1

Conjecture: Minimal Number of Automorphism Generators in Geometric Group Theory and Circuit Monotone Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 09:42 UTC.
Pre-registration hash committed before this test ran: `2cfb2746f3b8bef0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
