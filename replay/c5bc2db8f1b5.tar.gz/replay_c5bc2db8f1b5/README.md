# Replay package — entry c5bc2db8f1b5

Conjecture: Minimal Order of Quasi-Orthogonal Matrices Bounds Resolution Proof Width for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 07:52 UTC.
Pre-registration hash committed before this test ran: `4efd99f5fc57ccf5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
