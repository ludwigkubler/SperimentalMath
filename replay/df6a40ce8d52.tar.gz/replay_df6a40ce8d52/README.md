# Replay package — entry df6a40ce8d52

Conjecture: Frobenius-Schur Indicator and Quantum Circuit Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 20:04 UTC.
Pre-registration hash committed before this test ran: `e43fabe022f9d199`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
