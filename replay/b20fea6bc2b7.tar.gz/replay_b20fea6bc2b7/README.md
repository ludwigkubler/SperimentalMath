# Replay package — entry b20fea6bc2b7

Conjecture: Minimal Rank of Geometric Entanglement over Monotone Circuit Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 07:47 UTC.
Pre-registration hash committed before this test ran: `af3ad03900abe8eb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
