# Replay package — entry 3b4b48d800d8

Conjecture: Minimal Rank of Brauer Groups vs Resolution Proof Width for k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 01:00 UTC.
Pre-registration hash committed before this test ran: `a039b659fec6239f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
