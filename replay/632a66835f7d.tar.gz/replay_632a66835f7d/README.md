# Replay package — entry 632a66835f7d

Conjecture: Minimal Tropical Cyclotomic Polynomial Degree and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 04:25 UTC.
Pre-registration hash committed before this test ran: `f85fa1248500cac1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
