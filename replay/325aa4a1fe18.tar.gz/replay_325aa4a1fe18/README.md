# Replay package — entry 325aa4a1fe18

Conjecture: Minimal Rank of Free Entropy over Read-Twice BP Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 17:09 UTC.
Pre-registration hash committed before this test ran: `5a627fa36e1f55c1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
