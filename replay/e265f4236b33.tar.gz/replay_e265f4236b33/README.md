# Replay package — entry e265f4236b33

Conjecture: Symmetric Power Dimension Gap in Permanent vs Determinant Invariants

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 19:45 UTC.
Pre-registration hash committed before this test ran: `f4052a35d8858aa7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
