# Replay package — entry d1aaa5e9f44d

Conjecture: Minimal Number of Generators in Group Presentations vs DPLL Search Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 14:08 UTC.
Pre-registration hash committed before this test ran: `32ccb6788c867ab7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
