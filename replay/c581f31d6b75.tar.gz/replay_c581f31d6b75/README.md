# Replay package — entry c581f31d6b75

Conjecture: Tropical Hodge Norm Lower Bound for Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 17:46 UTC.
Pre-registration hash committed before this test ran: `021bdcd7ed264116`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
