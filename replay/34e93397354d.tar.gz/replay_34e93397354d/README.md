# Replay package — entry 34e93397354d

Conjecture: Minimal Rank of Configurable Sheaves vs SOS Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 19:28 UTC.
Pre-registration hash committed before this test ran: `fd19a376300bd389`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
