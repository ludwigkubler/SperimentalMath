# Replay package — entry c824f42d21af

Conjecture: Minimal Rank of Topological Quantum Field Theories over Boolean Tensor Product Valuations

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 13:47 UTC.
Pre-registration hash committed before this test ran: `751f9170b8be3e52`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
