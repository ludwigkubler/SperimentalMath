# Replay package — entry 99169426923b

Conjecture: Minimal Rank of Theta Functions over Kähler Manifolds vs SAT Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 05:24 UTC.
Pre-registration hash committed before this test ran: `4c8e5137fbb44855`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
