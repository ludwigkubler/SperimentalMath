# Replay package — entry ccc1f1b4b20d

Conjecture: Minimal Local Cohomology Rank of Tensor Product over Resolution Proof Trees

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 11:00 UTC.
Pre-registration hash committed before this test ran: `f89e1416652e744f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
