# Replay package — entry 78c9742281c4

Conjecture: Hermite Spectral-Diversity Lower Bound on Tseitin GW Slack

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 20:01 UTC.
Pre-registration hash committed before this test ran: `284b7a1c1280f2d4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
