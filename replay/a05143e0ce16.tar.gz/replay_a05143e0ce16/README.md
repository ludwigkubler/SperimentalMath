# Replay package — entry a05143e0ce16

Conjecture: Minimal Rank of Noncrossing Partitions Bounds Monotone Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 13:20 UTC.
Pre-registration hash committed before this test ran: `3fe73b6635350a09`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
