# Replay package — entry 6eb50265a825

Conjecture: [c003b_cumulative_entropy/SC3#c14] The width-aware totalLiteralWeight Σ_t Σ_{C∈σ_t}|C| scales with a strictly larger exponent than the count-based Φ (width amplifies cumulative weight).

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 16:21 UTC.
Pre-registration hash committed before this test ran: `53ab54e161d4984c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
