# Replay package — entry b3d99ac93f1c

Conjecture: Homotopy Type Bounds Cutting Planes Proof Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 09:40 UTC.
Pre-registration hash committed before this test ran: `6d1d7fda8e2bd8f2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
