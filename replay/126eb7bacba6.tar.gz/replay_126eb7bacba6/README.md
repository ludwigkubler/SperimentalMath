# Replay package — entry 126eb7bacba6

Conjecture: Minimal Order of Kac-Moody Generators and DPLL Proof Tree Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 13:41 UTC.
Pre-registration hash committed before this test ran: `b6923d56f7265018`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
