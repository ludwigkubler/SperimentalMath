# Replay package — entry 796531c3b7fa

Conjecture: q-Major Cancellation Gap Separates Permanent from Determinant Supports

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 03:32 UTC.
Pre-registration hash committed before this test ran: `ea7d4d6319e7c39d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
