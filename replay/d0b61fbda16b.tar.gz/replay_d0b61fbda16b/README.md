# Replay package — entry d0b61fbda16b

Conjecture: Minimal Rank of Noncommutative Tensor Products over Graphs vs Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 10:02 UTC.
Pre-registration hash committed before this test ran: `05b3d881ebe8582b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
