# Replay package — entry fec763a69d10

Conjecture: Multilinear Catalecticant Rank Scales Polynomially in ACC^0 Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 03:10 UTC.
Pre-registration hash committed before this test ran: `c1bb3410e281669c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
