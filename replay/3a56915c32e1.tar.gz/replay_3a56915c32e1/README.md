# Replay package — entry 3a56915c32e1

Conjecture: Fourier Coefficient Decay and Resolution Proof Length for k-CNF Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 06:15 UTC.
Pre-registration hash committed before this test ran: `ee8f6c4c1c8a0dbb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
