# Replay package — entry 02c57a92c88c

Conjecture: Matroid Matching of Term Co-Occurrence Graph Bounds k-CLIQUE Monotone DNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-16 20:46 UTC.
Pre-registration hash committed before this test ran: `cef7fa4bd00b4d5f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
