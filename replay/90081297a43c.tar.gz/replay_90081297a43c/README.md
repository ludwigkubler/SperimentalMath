# Replay package — entry 90081297a43c

Conjecture: Minimal Local Zeta Function Rank vs ACC⁰ Circuit Size for XOR

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 23:33 UTC.
Pre-registration hash committed before this test ran: `bb6908d72e37f130`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
