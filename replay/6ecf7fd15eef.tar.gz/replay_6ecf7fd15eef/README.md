# Replay package — entry 6ecf7fd15eef

Conjecture: Permutation-Orbit Stability of Tropical Doubling Defect at β=5

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 10:02 UTC.
Pre-registration hash committed before this test ran: `5507e1cd018d233d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
