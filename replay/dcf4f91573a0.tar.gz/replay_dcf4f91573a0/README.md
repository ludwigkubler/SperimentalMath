# Replay package — entry dcf4f91573a0

Conjecture: Minimal Tropicalized Local Cohomology Order and Resolution Proof Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 03:10 UTC.
Pre-registration hash committed before this test ran: `c36a1cb0caefd5de`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
