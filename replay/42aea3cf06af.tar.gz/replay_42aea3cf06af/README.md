# Replay package — entry 42aea3cf06af

Conjecture: Minimal Rank of Noncrossing Partitions over Tree-like Resolution Trees Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 04:32 UTC.
Pre-registration hash committed before this test ran: `ea7fc440a04928b4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
