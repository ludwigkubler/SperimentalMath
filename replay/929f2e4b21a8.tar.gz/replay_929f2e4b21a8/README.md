# Replay package — entry 929f2e4b21a8

Conjecture: SOS Degree Lower Bound via Eigenvalue Count in Moment Matrix

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 10:30 UTC.
Pre-registration hash committed before this test ran: `d75b925d9f413f4a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
