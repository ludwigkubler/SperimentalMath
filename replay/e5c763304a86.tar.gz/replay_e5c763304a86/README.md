# Replay package — entry e5c763304a86

Conjecture: Bounded Arithmetic Proof Complexity and Resolution Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-30 16:48 UTC.
Pre-registration hash committed before this test ran: `7412b79321de0d3a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
