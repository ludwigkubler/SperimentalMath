# Replay package — entry 4e25af61333f

Conjecture: Kolmogorov Complexity of Shortest Resolution Refutations Bounded by Circuit Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-30 02:07 UTC.
Pre-registration hash committed before this test ran: `b027c8390fe27609`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
