# Replay package — entry 73f4cc5b7dc5

Conjecture: Minimal Rank of Noncommutative Quantum Entropy over Boolean Circuit Valuations

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 21:44 UTC.
Pre-registration hash committed before this test ran: `36ed71fe277d01b2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
