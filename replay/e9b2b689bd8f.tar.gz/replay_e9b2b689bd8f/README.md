# Replay package — entry e9b2b689bd8f

Conjecture: Phase Merging Additivity in Tropical Proof Rank

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 09:35 UTC.
Pre-registration hash committed before this test ran: `443e732c7a58d552`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
