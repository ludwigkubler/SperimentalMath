# Replay package — entry 6fea9b7d7457

Conjecture: Minimal Modular Function Rank Correlation with SAT Clause Set Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 02:38 UTC.
Pre-registration hash committed before this test ran: `50648fdd33e66d5a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
