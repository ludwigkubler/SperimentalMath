# Replay package — entry d98c639fba28

Conjecture: Minimal Local Indeterminacy in Hyperbolic Geometry and Frege Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 12:24 UTC.
Pre-registration hash committed before this test ran: `e4fe5a7bffa081f8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
