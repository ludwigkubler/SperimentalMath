# Replay package — entry 20842460a41c

Conjecture: Minimal Tropical Cycle Rank Bounds Randomized Query Complexity for XOR

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 21:34 UTC.
Pre-registration hash committed before this test ran: `a33f83f7f7299dd8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
