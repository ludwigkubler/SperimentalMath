# Replay package — entry b6ce94d7be22

Conjecture: Minimal Eta-Invariant and Communication Complexity Rank Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 03:24 UTC.
Pre-registration hash committed before this test ran: `bca632be8480e51f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
