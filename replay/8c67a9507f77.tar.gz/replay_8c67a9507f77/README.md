# Replay package — entry 8c67a9507f77

Conjecture: Minimal Tropical Hodge Index Correlation with DPLL Search Tree Diameter

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 15:38 UTC.
Pre-registration hash committed before this test ran: `2032434feeebca6c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
