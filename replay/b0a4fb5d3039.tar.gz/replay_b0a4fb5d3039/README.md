# Replay package — entry b0a4fb5d3039

Conjecture: Forman-Ricci Min-Curvature of Term-Overlap Graph Lower-Bounds Monotone k-CLIQUE DNF

Verdict (original run): FALSIFIED

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 22:25 UTC.
Pre-registration hash committed before this test ran: `f465cd6fee8eadfb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
