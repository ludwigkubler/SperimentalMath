# Replay package — entry 2b2653395609

Conjecture: Bonami-Beckner 4-2 Saturation of Clause-Sum Bounds DPLL Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 03:29 UTC.
Pre-registration hash committed before this test ran: `91403c61299ba527`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
