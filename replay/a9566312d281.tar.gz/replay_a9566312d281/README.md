# Replay package — entry a9566312d281

Conjecture: Tseitin Resolution Width and Graph Genus

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 01:07 UTC.
Pre-registration hash committed before this test ran: `294bcc555bbbb2dc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
