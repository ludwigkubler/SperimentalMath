import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_formula(n):
        return ''.join(random.choice('01') for _ in range(2**n - 1))
    
    def resolution_length(formula):
        # Simplified heuristic to estimate resolution length
        return len(formula) ** 2
    
    def p_adic_space_rank(formula):
        # Simplified heuristic to estimate p-adic space rank
        return len(formula)
    
    n_values = [5, 10, 15, 20, 30, 40]
    instances_tested = 0
    total_h0 = 0
    total_L = 0
    
    for n in n_values:
        for _ in range(5):
            formula = generate_formula(n)
            h0 = p_adic_space_rank(formula)
            L = resolution_length(formula)
            instances_tested += 1
            total_h0 += h0
            total_L += L
    
    mean_h0 = total_h0 / instances_tested
    mean_L = total_L / instances_tested
    correlation_coefficient = (instances_tested * sum(h0 * L for h0, L in zip(total_h0, total_L)) - 
                               mean_h0 * total_L) / math.sqrt((instances_tested * sum(h0**2 for h0 in total_h0) - mean_h0**2) *
                                                            (instances_tested * sum(L**2 for L in total_L) - mean_L**2))
    
    conjecture_holds = correlation_coefficient > 0.7
    counterexample = "" if conjecture_holds else "mapping_undefined"
    
    return {
        "metric_name": "correlation_coefficient",
        "metric_value": correlation_coefficient,
        "instances_tested": instances_tested,
        "n_max": max(n_values),
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] if sys.argv[1:] else [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"mapping_undefined\" first_failing_seed={first_failing_seed}")