# Replay package — entry c11fc32ae00a

Conjecture: Minimal Number of Modular Representation Conjugacy Classes and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 01:06 UTC.
Pre-registration hash committed before this test ran: `531c4a047347f60e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
