# Replay package — entry 41ac56b6f189

Conjecture: Minimal Noncommutative Entropy of Matrix Algebras vs BP_ReadTwice Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 18:28 UTC.
Pre-registration hash committed before this test ran: `8a8882e68ccf6219`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
