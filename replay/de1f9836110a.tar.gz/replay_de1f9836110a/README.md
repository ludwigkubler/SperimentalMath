# Replay package — entry de1f9836110a

Conjecture: Minimal Order of Geometric Symmetry and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 07:18 UTC.
Pre-registration hash committed before this test ran: `2cf3f17d7aabfb65`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
