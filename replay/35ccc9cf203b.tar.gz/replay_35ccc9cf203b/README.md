# Replay package — entry 35ccc9cf203b

Conjecture: Minimal Rank of Kostka Coefficients over Boolean Function Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 15:17 UTC.
Pre-registration hash committed before this test ran: `2189b58c58dc16cc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
