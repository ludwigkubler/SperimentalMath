# Replay package — entry ccaa1f00c9ac

Conjecture: Minimal Order of Topological Entropy and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 08:30 UTC.
Pre-registration hash committed before this test ran: `03d0131d82ec19dd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
