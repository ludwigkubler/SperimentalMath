# Replay package — entry 56f23cc5162c

Conjecture: Arithmetic Power Law of Knot Genus for Random CNF Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 01:30 UTC.
Pre-registration hash committed before this test ran: `e16aeecf9c8cd292`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
