# Replay package — entry d5d5fa6cf34b

Conjecture: Coxeter Group Action Number Invariant for Tseitin Resolution Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 13:41 UTC.
Pre-registration hash committed before this test ran: `1e98db21c3ce7029`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
