import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_instance(n):
        return [random.choice([True, False]) for _ in range(n)]
    
    def construct_abelian_variants(instance):
        n = len(instance)
        abelian_variants = set()
        for i in range(1 << n):
            variant = []
            for j in range(n):
                if (i >> j) & 1:
                    variant.append(instance[j])
            abelian_variants.add(tuple(variant))
        return abelian_variants
    
    def measure_resolution_width(instance):
        # Placeholder for actual resolution width calculation
        # This is a dummy implementation for testing purposes
        return len(instance)
    
    n_max = 0
    total_metric_value = 0
    instances_tested = 0
    conjecture_holds = True
    counterexample = ""
    
    for n in [5, 10, 15, 20, 30, 40]:
        instance = generate_instance(n)
        abelian_variants = construct_abelian_variants(instance)
        resolution_width = measure_resolution_width(instance)
        metric_value = len(abelian_variants) / (n ** 2 * 1.5)
        
        total_metric_value += metric_value
        instances_tested += n
        n_max = max(n_max, n)
        
        if conjecture_holds and metric_value > 1:
            conjecture_holds = False
            counterexample = f"Instance size {n} with resolution width {resolution_width}"
    
    return {
        "metric_name": "abelian_variants",
        "metric_value": total_metric_value / instances_tested,
        "instances_tested": instances_tested,
        "n_max": n_max,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_metric_value = sum(r["metric_value"] for r in results) / len(results)
    std_metric_value = math.sqrt(sum((r["metric_value"] - mean_metric_value) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_metric_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_metric_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{results[0]['counterexample']}\" first_failing_seed={first_failing_seed}")