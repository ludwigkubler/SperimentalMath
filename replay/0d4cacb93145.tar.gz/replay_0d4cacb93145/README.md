# Replay package — entry 0d4cacb93145

Conjecture: Minimal Local Induction Dimension in Boolean Algebra and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 15:08 UTC.
Pre-registration hash committed before this test ran: `e953b936a363f224`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
