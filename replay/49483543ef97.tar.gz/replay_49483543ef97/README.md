# Replay package — entry 49483543ef97

Conjecture: Minimal Rank of Quadratic Residues over Elliptic Curves vs BP_ReadTwice Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 06:39 UTC.
Pre-registration hash committed before this test ran: `823435928756f90d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
