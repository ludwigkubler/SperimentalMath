import random
import math

def fast_walsh_hadamard_transform(f):
    n = len(f)
    if n == 1:
        return f
    even = fast_walsh_hadamard_transform(f[0::2])
    odd = fast_walsh_hadamard_transform(f[1::2])
    result = [0] * n
    for k in range(n // 2):
        result[k] = even[k] + odd[k]
        result[k + n // 2] = even[k] - odd[k]
    return result

def add(a, b):
    return a + b

def multiply(a, b):
    return a * b

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n = 10
    f = [random.randint(0, 1) for _ in range(2**n)]
    
    transformed_f = fast_walsh_hadamard_transform(f)
    E_f = sum(abs(transformed_f[i] * transformed_f[j]) for i in range(len(transformed_f)) for j in range(i + 1, len(transformed_f)))
    
    # Placeholder for ACC⁰ function check
    is_acc0 = False
    
    if is_acc0:
        conjecture_holds = E_f <= 2**(O(log**2 n))
    else:
        conjecture_holds = E_f >= 2**(Ω(n))
    
    return {
        "metric_name": "Additive Energy",
        "metric_value": E_f,
        "instances_tested": len(f),
        "conjecture_holds": conjecture_holds,
        "counterexample": "" if conjecture_holds else "mapping_undefined"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(x) for x in sys.argv[1:]] or [2**i - 1 for i in range(3, 6)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_E_f = sum(r["metric_value"] for r in results) / len(results)
    std_E_f = math.sqrt(sum((r["metric_value"] - mean_E_f)**2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_E_f} std={std_E_f} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_E_f} std={std_E_f} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample='mapping_undefined' first_failing_seed={first_failing_seed}")