import random
import math
from fractions import Fraction

def gaussian_elimination(A):
    m, n = len(A), len(A[0])
    for i in range(m):
        max_row = i
        for j in range(i + 1, m):
            if abs(A[j][i]) > abs(A[max_row][i]):
                max_row = j
        A[i], A[max_row] = A[max_row], A[i]
        pivot = A[i][i]
        for j in range(n):
            A[i][j] /= pivot
        for j in range(m):
            if j != i:
                factor = A[j][i]
                for k in range(n):
                    A[j][k] -= factor * A[i][k]

def matrix_multiplication(A, B):
    m, n, p = len(A), len(B), len(B[0])
    C = [[0] * p for _ in range(m)]
    for i in range(m):
        for j in range(p):
            for k in range(n):
                C[i][j] += A[i][k] * B[k][j]
    return C

def min_local_ring_norm(formula):
    # Placeholder implementation
    return random.random()

def resolution_proof_width(formula):
    # Placeholder implementation
    return random.randint(1, 10)

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n = random.choice([5, 10, 15, 20, 30, 40])
    instances_tested = 0
    min_lrn_sum = 0
    w_sum = 0
    counterexample = ""
    
    for _ in range(30):
        formula = ' & '.join(random.choices(['x1', 'x2', 'x3'], k=n))
        min_lrn = min_local_ring_norm(formula)
        w = resolution_proof_width(formula)
        
        if math.isnan(min_lrn) or math.isinf(w):
            continue
        
        instances_tested += 1
        min_lrn_sum += min_lrn
        w_sum += w
        
        if instances_tested >= 30:
            break
    
    if instances_tested < 30:
        return {
            "metric_name": "minLRN vs. Resolution Width",
            "metric_value": None,
            "instances_tested": instances_tested,
            "n_max": n,
            "conjecture_holds": False,
            "counterexample": "insufficient_instances"
        }
    
    mean_min_lrn = min_lrn_sum / instances_tested
    mean_w = w_sum / instances_tested
    correlation_coefficient = (instances_tested * sum(min_lrn * w for min_lrn, w in zip(min_lrn_list, w_list)) -
                               mean_min_lrn * mean_w) / math.sqrt((instances_tested * sum(min_lrn**2 for min_lrn in min_lrn_list) - mean_min_lrn**2) *
                                                                 (instances_tested * sum(w**2 for w in w_list) - mean_w**2))
    
    if correlation_coefficient >= 0.8 and 1 <= mean_min_lrn / mean_w <= 10:
        return {
            "metric_name": "minLRN vs. Resolution Width",
            "metric_value": correlation_coefficient,
            "instances_tested": instances_tested,
            "n_max": n,
            "conjecture_holds": True,
            "counterexample": ""
        }
    else:
        return {
            "metric_name": "minLRN vs. Resolution Width",
            "metric_value": correlation_coefficient,
            "instances_tested": instances_tested,
            "n_max": n,
            "conjecture_holds": False,
            "counterexample": f"correlation={correlation_coefficient}, mean_min_lrn/mean_w={mean_min_lrn / mean_w}"
        }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113]
    results = []
    
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {{\"seed\": {seed}, \"metric_name\": \"{result['metric_name']}\", \"metric_value\": {result['metric_value']}, \"instances_tested\": {result['instances_tested']}, \"n_max\": {result['n_max']}, \"conjecture_holds\": {result['conjecture_holds']}, \"counterexample\": \"{result['counterexample']}\"}}")
        results.append(result)
    
    mean_metric_value = sum(r['metric_value'] for r in results if r['metric_value'] is not None) / len(results)
    std_metric_value = math.sqrt(sum((r['metric_value'] - mean_metric_value)**2 for r in results if r['metric_value'] is not None) / len(results))
    support_fraction = sum(1 for r in results if r['conjecture_holds']) / len(results)
    
    if all(r['conjecture_holds'] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_metric_value} support_fraction={support_fraction}")
    elif sum(1 for r in results if not r['conjecture_holds']) / len(results) >= 0.2:
        print(f"RESULT: FALSIFIED counterexample=\"{results[next(i for i, r in enumerate(results) if not r['conjecture_holds'])['counterexample']}\") first_failing_seed={seeds[next(i for i, r in enumerate(results) if not r['conjecture_holds'])]}")
    else:
        print(f"RESULT: INCONCLUSIVE support_fraction={support_fraction}")