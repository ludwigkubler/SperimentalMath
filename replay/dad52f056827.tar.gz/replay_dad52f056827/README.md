# Replay package — entry dad52f056827

Conjecture: Lorentzian Defect of Cut Polynomial Lower-Bounds Max-CUT SoS-2 Gap

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 02:13 UTC.
Pre-registration hash committed before this test ran: `e6ebab19010cecce`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
