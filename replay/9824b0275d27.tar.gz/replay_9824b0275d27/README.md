# Replay package — entry 9824b0275d27

Conjecture: Minimal Order of Local Units in Adjoint Group and Circuit Entanglement Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 14:44 UTC.
Pre-registration hash committed before this test ran: `0201759015b618f9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
