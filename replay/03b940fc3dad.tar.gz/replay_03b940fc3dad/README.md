# Replay package — entry 03b940fc3dad

Conjecture: Minimal Geometric Entropy of Boolean Functions vs. Circuit Monotone Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 17:41 UTC.
Pre-registration hash committed before this test ran: `e1f0308bbd466f27`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
