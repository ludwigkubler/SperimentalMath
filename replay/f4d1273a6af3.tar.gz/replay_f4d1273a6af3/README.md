# Replay package — entry f4d1273a6af3

Conjecture: Cyclic Fourier Spread of Term-Vertex Incidence in Monotone k-CLIQUE DNFs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 11:23 UTC.
Pre-registration hash committed before this test ran: `bfd057beab5fd1bf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
