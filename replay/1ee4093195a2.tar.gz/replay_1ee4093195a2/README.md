# Replay package — entry 1ee4093195a2

Conjecture: Minimal Rank of Noncommutative Tensor Product Representations over Tseitin Circuit Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 00:16 UTC.
Pre-registration hash committed before this test ran: `611ad714c99dce86`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
