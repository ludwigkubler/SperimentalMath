# Replay package — entry e93b5c1898d5

Conjecture: Minimal Rank of Quaternionic Kähler Metrics vs BP_ReadTwice Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 17:43 UTC.
Pre-registration hash committed before this test ran: `f28ca1e0289d1002`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
