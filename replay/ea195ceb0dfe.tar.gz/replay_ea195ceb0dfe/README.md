# Replay package — entry ea195ceb0dfe

Conjecture: Minimal Grothendieck-Witt Class Rank of Binary Search Trees

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 01:39 UTC.
Pre-registration hash committed before this test ran: `ce95de4250f2cb2d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
