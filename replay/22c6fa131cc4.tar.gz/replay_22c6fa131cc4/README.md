# Replay package — entry 22c6fa131cc4

Conjecture: Real Algebraic Components of AC⁰ PARITY Circuits

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-30 18:56 UTC.
Pre-registration hash committed before this test ran: `49ea66ce2f628f5a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
