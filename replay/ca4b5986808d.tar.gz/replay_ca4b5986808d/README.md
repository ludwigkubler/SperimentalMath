# Replay package — entry ca4b5986808d

Conjecture: Minimal Local Zeta Function Order and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 18:21 UTC.
Pre-registration hash committed before this test ran: `cf6bbce1d4936c4f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
