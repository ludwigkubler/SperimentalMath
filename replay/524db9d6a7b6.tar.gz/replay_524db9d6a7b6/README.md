# Replay package — entry 524db9d6a7b6

Conjecture: Arithmetic of Tropical Hyperplanes Bounds DPLL Refutation Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 10:26 UTC.
Pre-registration hash committed before this test ran: `5d823451ce3f9728`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
