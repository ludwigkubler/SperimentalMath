# Replay package — entry e114a3904945

Conjecture: Minimal Order of Quasi-monte Carlo Integration Points and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 15:27 UTC.
Pre-registration hash committed before this test ran: `a449c48cd46f456a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
