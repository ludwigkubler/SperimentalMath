# Replay package — entry 80e49d578fbe

Conjecture: Minimal Rank of Noncommutative Polynomial Representations vs Random k-CNF Resolution Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 06:15 UTC.
Pre-registration hash committed before this test ran: `2bdbd351e6e0f9e9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
