# Replay package — entry 390e4c06544a

Conjecture: Schur-Weyl Dimension Gap in 3-CNF Permanent vs Determinant Shapes

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 12:46 UTC.
Pre-registration hash committed before this test ran: `c287fd5a5c1840c5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
