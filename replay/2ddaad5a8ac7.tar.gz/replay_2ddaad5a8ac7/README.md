# Replay package — entry 2ddaad5a8ac7

Conjecture: Minimal Order of Quadratic Reciprocity and Frege Proof Depth Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 23:39 UTC.
Pre-registration hash committed before this test ran: `b0ff46385244cc53`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
