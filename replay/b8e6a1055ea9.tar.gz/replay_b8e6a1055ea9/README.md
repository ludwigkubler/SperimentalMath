# Replay package — entry b8e6a1055ea9

Conjecture: Minimal Genus of Embedded Curves and DPLL Search Tree Diameter

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 01:27 UTC.
Pre-registration hash committed before this test ran: `028f591bdce310e1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
