# Replay package — entry df31c2a1aaf1

Conjecture: Minimal Local System Rank in Affine Geometry and SAT Clause Set Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 02:54 UTC.
Pre-registration hash committed before this test ran: `d1c999512d71adf7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
