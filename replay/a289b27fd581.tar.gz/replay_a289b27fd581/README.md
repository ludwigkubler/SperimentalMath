# Replay package — entry a289b27fd581

Conjecture: Free Entropy Distinguishes Read-Twice BPs from IP_2 Trivial Ones

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-30 17:44 UTC.
Pre-registration hash committed before this test ran: `7a43751d47eddd8c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
