# Replay package — entry 8bf8c5c64dba

Conjecture: Magnus Level-2 Defect Bounds DNF_min via Truth-Table Inversions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 13:27 UTC.
Pre-registration hash committed before this test ran: `68c92cf285d80822`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
