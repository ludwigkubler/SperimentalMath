# Replay package — entry a5d3f5fa5ab6

Conjecture: Minimal Order of Affine Generators and Resolution Proof Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 00:10 UTC.
Pre-registration hash committed before this test ran: `961093185f27bca9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
