# Replay package — entry 1fe1848085ac

Conjecture: Minimal Order of Geometric Galois Groups and DPLL Proof Tree Height Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 18:54 UTC.
Pre-registration hash committed before this test ran: `cdd833787c55a556`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
