# Replay package — entry d9faa5eb7bca

Conjecture: Mixer Profile Decay Rate and Communication Entropy Barrier

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 21:10 UTC.
Pre-registration hash committed before this test ran: `a1068d6aa54a1217`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
