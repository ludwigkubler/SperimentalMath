# Replay package — entry 8e22a8482c1a

Conjecture: Minimal Rank of Entropic Complexity over Monotone Circuit Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 02:15 UTC.
Pre-registration hash committed before this test ran: `06323908e8e3f375`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
