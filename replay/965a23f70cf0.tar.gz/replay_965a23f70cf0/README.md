# Replay package — entry 965a23f70cf0

Conjecture: Tropical Rank Gap in Read-Twice BP Transition Matrices

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 20:25 UTC.
Pre-registration hash committed before this test ran: `dd7ff9dda18f23a7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
