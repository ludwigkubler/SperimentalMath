# Replay package — entry c1b53c8c75d6

Conjecture: Noncommutative Crossed Products and Branching Program Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 23:54 UTC.
Pre-registration hash committed before this test ran: `b4aaf182c4dab8ca`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
