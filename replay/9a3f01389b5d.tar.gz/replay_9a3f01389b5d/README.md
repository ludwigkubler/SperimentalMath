# Replay package — entry 9a3f01389b5d

Conjecture: Moment-Matrix Spectral Norm Inverse Proportional to Communication Complexity Lower Bound for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 23:07 UTC.
Pre-registration hash committed before this test ran: `b6a3132f0c84b3f9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
