# Replay package — entry 5ca5616545f4

Conjecture: Coboundary Spectral Gap Lower-Bounds DPLL Tree Size on Tseitin

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 11:29 UTC.
Pre-registration hash committed before this test ran: `a3e18da4df2d1651`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
