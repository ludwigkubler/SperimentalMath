# Replay package — entry 54cd565a7ba3

Conjecture: Free Entropy Lower Bound on Disjointness Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 06:02 UTC.
Pre-registration hash committed before this test ran: `4cc79d5bbdfbd58a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
