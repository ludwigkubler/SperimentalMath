# Replay package — entry 14468302ae7b

Conjecture: Tropicalized Brauer Groups and AC0 Parity Circuit Threshold

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 05:07 UTC.
Pre-registration hash committed before this test ran: `66cafd3cc312839f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
