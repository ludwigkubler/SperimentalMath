# Replay package — entry 2634fcde1ae3

Conjecture: Minimal Modular Symmetry Rank and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 10:47 UTC.
Pre-registration hash committed before this test ran: `2608f225697f5b58`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
