import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def gaussian_elimination(matrix):
        rows, cols = len(matrix), len(matrix[0])
        for i in range(rows):
            max_row = i + max(range(i, rows), key=lambda r: abs(matrix[r][i]))
            matrix[i], matrix[max_row] = matrix[max_row], matrix[i]
            for j in range(cols):
                if i == j:
                    denom = matrix[i][j]
                    if denom == 0:
                        continue
                    for k in range(j, cols):
                        matrix[i][k] /= denom
                elif matrix[j][i]:
                    factor = matrix[j][i] / matrix[i][i]
                    for k in range(i, cols):
                        matrix[j][k] -= factor * matrix[i][k]
        return matrix

    def rank(matrix):
        rows, cols = len(matrix), len(matrix[0])
        row echelon_form = gaussian_elimination(matrix)
        rank = 0
        for i in range(rows):
            if any(row[i] != 0 for row in row_echelon_form):
                rank += 1
        return rank

    def tseitin_formula(n):
        variables = [f'x{i}' for i in range(1, n+1)]
        clauses = []
        for i in range(n):
            clauses.append([variables[i]])
            for j in range(i+1, n):
                clauses.append([f'~{variables[i]}', f'~{variables[j]}', variables[j]])
                clauses.append([f'~{variables[i]}', variables[j], f'~{variables[j]}'])
        return clauses

    def quandle_representation(clauses):
        quandle = {}
        for clause in clauses:
            indicator = tuple(sorted(clause))
            if indicator not in quandle:
                quandle[indicator] = len(quandle) + 1
        n = len(quandle)
        representation = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(i+1, n):
                representation[i][j] = 1
                representation[j][i] = -1
        return representation

    def tseitin_resolution(clauses):
        stack = clauses[:]
        while stack:
            clause = stack.pop()
            if not any(var.startswith('~') for var in clause):
                return len(stack) + 1
            neg_var = next(var[1:] for var in clause if var.startswith('~'))
            pos_var = next(var for var in clause if not var.startswith('~'))
            new_clauses = []
            for c in stack:
                if neg_var in c:
                    new_c = [var for var in c if var != neg_var]
                    if pos_var not in new_c and len(new_c) > 0:
                        new_clauses.append(new_c)
                elif pos_var in c:
                    continue
                else:
                    new_clauses.append(c)
            stack.extend(new_clauses)
        return float('inf')

    n = random.choice([5, 10, 15, 20, 30, 40])
    formula = tseitin_formula(n)
    quandle_rep = quandle_representation(formula)
    quandle_rank = rank(quandle_rep)
    resolution_length = tseitin_resolution(formula)

    return {
        "metric_name": "Spearman Rank Correlation",
        "metric_value": quandle_rank,
        "instances_tested": 1,
        "conjecture_holds": False,
        "counterexample": "mapping_undefined"
    }

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        seeds = [int(s) for s in sys.argv[1:]]
    else:
        primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]
        seeds = random.sample(primes, min(30, len(primes)))

    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)

    if all(r["conjecture_holds"] for r in results):
        mean_value = sum(r["metric_value"] for r in results) / len(results)
        support_fraction = 1.0
        result = f"RESULT: SUPPORTED mean={mean_value} std=0.0 support_fraction={support_fraction}"
    else:
        first_failing_seed = next((r["seed"] for r in results if not r["conjecture_holds"]), None)
        result = f"RESULT: FALSIFIED counterexample='mapping_undefined' first_failing_seed={first_failing_seed}"

    print(result)