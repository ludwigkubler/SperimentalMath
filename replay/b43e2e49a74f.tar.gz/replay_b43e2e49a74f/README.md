# Replay package — entry b43e2e49a74f

Conjecture: Minimal Monodromy Group Structure and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 21:09 UTC.
Pre-registration hash committed before this test ran: `e715250d53c3c77c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
