# Replay package — entry 5188828fe9da

Conjecture: Coxeter Group Action on Boolean Circuit Symmetry Groups

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 16:28 UTC.
Pre-registration hash committed before this test ran: `83dddeb6b9032caa`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
