# Replay package — entry fc9124ecdaa8

Conjecture: Σ^b_0-PIND Width-2 Closure Round-Count vs DPLL Leaves

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 08:46 UTC.
Pre-registration hash committed before this test ran: `4acd2f211f6f5128`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
