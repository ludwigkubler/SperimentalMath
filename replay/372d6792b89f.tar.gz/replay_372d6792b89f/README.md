# Replay package — entry 372d6792b89f

Conjecture: Minimal p-Adic Valuation Degree and SAT Clause Set Entropy Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 04:46 UTC.
Pre-registration hash committed before this test ran: `49381a52da9cf931`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
