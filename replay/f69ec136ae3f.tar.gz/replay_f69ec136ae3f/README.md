# Replay package — entry f69ec136ae3f

Conjecture: Minimal Tropical Hodge Index vs. Communication Complexity of Disjointness

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 14:38 UTC.
Pre-registration hash committed before this test ran: `7e9e890185013ab8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
