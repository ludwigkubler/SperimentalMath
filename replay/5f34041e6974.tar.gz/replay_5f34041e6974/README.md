# Replay package — entry 5f34041e6974

Conjecture: Phase Cell Count Bounded by Tropical Proof Rank

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-30 17:57 UTC.
Pre-registration hash committed before this test ran: `3fdd6a52b49b08c4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
