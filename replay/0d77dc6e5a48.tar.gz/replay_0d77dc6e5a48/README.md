# Replay package — entry 0d77dc6e5a48

Conjecture: Minimal Geometric Entropy of Boolean Functions Bounds Resolution Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 21:10 UTC.
Pre-registration hash committed before this test ran: `3dfbf3d1bce455c7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
