# Replay package — entry 2d5f55632128

Conjecture: Minimal Frobenius-Schur Indicators and Resolution Proof Width Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 01:15 UTC.
Pre-registration hash committed before this test ran: `b3dc0023bb9829bd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
