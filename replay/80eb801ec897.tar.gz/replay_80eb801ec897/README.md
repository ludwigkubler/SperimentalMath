# Replay package — entry 80eb801ec897

Conjecture: Minimal Order of Quasi-Plurality and Resolution Proof Width Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 03:45 UTC.
Pre-registration hash committed before this test ran: `827b0d3b5466008b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
