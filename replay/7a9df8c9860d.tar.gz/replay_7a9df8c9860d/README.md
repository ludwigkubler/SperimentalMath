# Replay package — entry 7a9df8c9860d

Conjecture: Coxeter Matrix Invariant vs BP_ReadTwice Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 13:53 UTC.
Pre-registration hash committed before this test ran: `c834ca438d10b4cb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
