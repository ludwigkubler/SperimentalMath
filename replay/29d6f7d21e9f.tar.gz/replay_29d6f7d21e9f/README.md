# Replay package — entry 29d6f7d21e9f

Conjecture: Fourier Coefficient Decay Bounds AC⁰ Circuit Size for Parity-Insensitive Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 05:43 UTC.
Pre-registration hash committed before this test ran: `581992b396f983b1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
