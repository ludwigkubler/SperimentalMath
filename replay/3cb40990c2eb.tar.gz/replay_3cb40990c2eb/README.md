# Replay package — entry 3cb40990c2eb

Conjecture: Shifted Partials of Clause Cubic Lower-Bound Tree-Resolution Leaves

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 16:59 UTC.
Pre-registration hash committed before this test ran: `ea8e53168911d3e2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
