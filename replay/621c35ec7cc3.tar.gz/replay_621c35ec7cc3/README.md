# Replay package — entry 621c35ec7cc3

Conjecture: Minimal Lattices and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 21:40 UTC.
Pre-registration hash committed before this test ran: `dd8ab7f7593f1c53`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
