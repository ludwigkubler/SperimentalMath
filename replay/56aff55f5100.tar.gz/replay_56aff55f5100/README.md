# Replay package — entry 56aff55f5100

Conjecture: Tropical Geometry of Convolutional Neural Networks vs SAT Satisfiability Time

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 04:29 UTC.
Pre-registration hash committed before this test ran: `3ec5c61a0dd89fd0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
