# Replay package — entry 22b9cf049023

Conjecture: [c003b_cumulative_entropy/SC2#c31] Φ(π) >= c·|S|² for a constant c>0, where |S| is the balanced separator size (the cumulative-entropy analogue of the space lower bound that A13 needs).

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 17:26 UTC.
Pre-registration hash committed before this test ran: `832103cb4c8b981e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
