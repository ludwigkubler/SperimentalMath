import random
import math
import fractions

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def gaussian_elimination(matrix):
        rows, cols = len(matrix), len(matrix[0])
        for i in range(rows):
            max_row = max(range(i, rows), key=lambda r: abs(matrix[r][i]))
            matrix[i], matrix[max_row] = matrix[max_row], matrix[i]
            pivot = matrix[i][i]
            if pivot == 0:
                continue
            for j in range(cols):
                matrix[i][j] /= pivot
            for k in range(rows):
                if k != i:
                    factor = matrix[k][i]
                    for j in range(cols):
                        matrix[k][j] -= factor * matrix[i][j]
        return matrix
    
    def rank(matrix):
        rows, cols = len(matrix), len(matrix[0])
        row echelon_form = gaussian_elimination(matrix)
        rank = 0
        for i in range(rows):
            if any(row[i] != 0 for row in row_echelon_form):
                rank += 1
        return rank
    
    def tseitin_formula(n):
        variables = [f'x{i}' for i in range(1, n+1)]
        clauses = []
        for i in range(1, n+1):
            clauses.append([variables[i-1]])
            for j in range(i+1, n+1):
                clauses.append([-variables[i-1], variables[j-1]])
                clauses.append([-variables[j-1], variables[i-1]])
        return clauses
    
    def tropicalized_boolean_algebra(clauses):
        n = len(clauses)
        matrix = [[0] * (2*n) for _ in range(2*n)]
        for i, clause in enumerate(clauses):
            for var in clause:
                if var.startswith('x'):
                    j = int(var[1:]) - 1
                    matrix[i][j] = 1
                    matrix[j+n][i] = 1
        return matrix
    
    n = random.randint(5, 40)
    formula = tseitin_formula(n)
    algebra_matrix = tropicalized_boolean_algebra(formula)
    minimal_rank = rank(algebra_matrix)
    
    alpha_n = n**2 * math.log(n)
    conjecture_holds = minimal_rank <= alpha_n
    counterexample = "" if conjecture_holds else f"Minimal rank {minimal_rank} > O({n}^2 log {n})"
    
    return {
        "metric_name": "Minimal Rank",
        "metric_value": minimal_rank,
        "instances_tested": 1,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] if sys.argv[1:] else list(range(2, 30))  # Default to first 29 primes
    
    results = []
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    mean_value = sum(result["metric_value"] for result in results) / len(results)
    std_value = math.sqrt(sum((result["metric_value"] - mean_value)**2 for result in results) / len(results))
    support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)
    
    if all(result["conjecture_holds"] for result in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not result["conjecture_holds"] for result in results):
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{results[0]['counterexample']}\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE reason=unknown")