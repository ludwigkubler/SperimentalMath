# Replay package — entry e630dc7b70e2

Conjecture: Minimal Tensor Rank Bound on Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 13:12 UTC.
Pre-registration hash committed before this test ran: `13a9530c647cb164`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
