# Replay package — entry 731f971fe626

Conjecture: Minimal Hodge Index vs Resolution Proof Width for Monomial Representations

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 08:39 UTC.
Pre-registration hash committed before this test ran: `0f2a5ada454ff0d7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
