# Replay package — entry 786703f89730

Conjecture: Minimal Index of Algebraic Quotients and DPLL Proof Depth Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 00:00 UTC.
Pre-registration hash committed before this test ran: `b13464df3029480d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
