# Replay package — entry ebcc6ccc6e5a

Conjecture: Minimal Rank of Quantum Topological Entanglement Entropy Bounds Tseitin Resolution Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 12:52 UTC.
Pre-registration hash committed before this test ran: `e0e3f4c8473d4818`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
