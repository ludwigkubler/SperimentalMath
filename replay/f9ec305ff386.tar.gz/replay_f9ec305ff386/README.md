# Replay package — entry f9ec305ff386

Conjecture: Coxeter-Dynkin Diagram Symmetry Measures Tree-Like Resolution Proof Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 13:07 UTC.
Pre-registration hash committed before this test ran: `b70e69d037292ef2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
