# Replay package — entry 91ca137f15f0

Conjecture: Minimal Rank of Geometric Loci vs Monotone k-CLIQUE Circuit Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 17:09 UTC.
Pre-registration hash committed before this test ran: `1582ce15f40627ca`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
