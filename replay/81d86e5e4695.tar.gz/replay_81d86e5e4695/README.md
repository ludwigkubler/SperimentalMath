# Replay package — entry 81d86e5e4695

Conjecture: Ramanujan's q-Series in AC0 Parity Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 16:07 UTC.
Pre-registration hash committed before this test ran: `d60c489e31932d91`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
