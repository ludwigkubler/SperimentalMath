# Replay package — entry 7ac5fad5a356

Conjecture: Average-Case DPLL Runtime Linked to Random Matrix Spectra

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 06:23 UTC.
Pre-registration hash committed before this test ran: `6b84c366580c2515`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
