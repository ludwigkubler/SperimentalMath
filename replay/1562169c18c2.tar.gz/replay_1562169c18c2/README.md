# Replay package — entry 1562169c18c2

Conjecture: Polymatroid Rank Deficit in Monotone DNF for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 22:24 UTC.
Pre-registration hash committed before this test ran: `67da669449c15e27`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
