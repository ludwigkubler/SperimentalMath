# Replay package — entry bb2ca26080a1

Conjecture: Monotone Formula Size Bounded by Hypergraph Discrepancy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 12:59 UTC.
Pre-registration hash committed before this test ran: `6523be5730bacc47`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
