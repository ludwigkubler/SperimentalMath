# Replay package — entry afe153586854

Conjecture: Matroid Rank Inverse Proportional to Monotone DNF Size for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 07:48 UTC.
Pre-registration hash committed before this test ran: `265887fcf134e5f1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
