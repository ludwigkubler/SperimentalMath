# Replay package — entry 0ab9cc94de3b

Conjecture: Minimal Order of Formal Concept Analysis and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 20:24 UTC.
Pre-registration hash committed before this test ran: `6cce0cefa91968ee`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
