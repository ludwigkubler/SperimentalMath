# Replay package — entry eb402b6828f3

Conjecture: Dyck Zero-Crossing Count of Row-Walks Capped by Log-Rank

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-28 20:08 UTC.
Pre-registration hash committed before this test ran: `f63b5f791f457295`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
