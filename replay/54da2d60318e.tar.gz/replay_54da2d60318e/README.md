# Replay package — entry 54da2d60318e

Conjecture: Symmetric Group Fourier Coefficient Gap in Read-Twice BPs for IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 12:51 UTC.
Pre-registration hash committed before this test ran: `78c5cdccadcff049`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
