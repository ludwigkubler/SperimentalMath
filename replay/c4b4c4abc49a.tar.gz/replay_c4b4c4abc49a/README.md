# Replay package — entry c4b4c4abc49a

Conjecture: Minimal Rank of Tropicalized Symplectic Leaves vs Monotone Circuit Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 21:28 UTC.
Pre-registration hash committed before this test ran: `6481ac297e7aa726`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
