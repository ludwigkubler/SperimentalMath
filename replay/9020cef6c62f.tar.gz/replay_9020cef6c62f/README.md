# Replay package — entry 9020cef6c62f

Conjecture: Free Entropy Lower Bound on Disjointness Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 18:58 UTC.
Pre-registration hash committed before this test ran: `18469b2cedbb104e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
