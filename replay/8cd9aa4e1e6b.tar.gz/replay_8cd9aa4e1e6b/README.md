# Replay package — entry 8cd9aa4e1e6b

Conjecture: Minimal Index of Quaternion Algebras and SAT Clause Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 18:35 UTC.
Pre-registration hash committed before this test ran: `eb2bea45278cc121`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
