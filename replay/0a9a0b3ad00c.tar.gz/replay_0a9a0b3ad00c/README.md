# Replay package — entry 0a9a0b3ad00c

Conjecture: Kendall tau Distance and Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 16:37 UTC.
Pre-registration hash committed before this test ran: `3e38bcd3bc1b3f07`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
