# Replay package — entry f3f1771fee37

Conjecture: Minimal Rank of Geometric Invariants in Convex Polytopes vs Monotone k-CLIQUE Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 05:45 UTC.
Pre-registration hash committed before this test ran: `55a697e5cfa781a0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
