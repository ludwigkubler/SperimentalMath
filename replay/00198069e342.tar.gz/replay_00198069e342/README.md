# Replay package — entry 00198069e342

Conjecture: SOS Moment Matrix Rank Bounded by Square Root of Variables for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 09:28 UTC.
Pre-registration hash committed before this test ran: `be6b1fa27f0fea8c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
