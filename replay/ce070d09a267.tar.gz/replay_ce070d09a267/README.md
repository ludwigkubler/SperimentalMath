# Replay package — entry ce070d09a267

Conjecture: Minimal Volume of Intersection Body and ACC⁰ Parity Circuit Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 19:54 UTC.
Pre-registration hash committed before this test ran: `e0479bd3cc8d9db2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
