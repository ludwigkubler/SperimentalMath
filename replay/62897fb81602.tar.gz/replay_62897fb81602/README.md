# Replay package — entry 62897fb81602

Conjecture: Minimal Rank of Weyl Groups in Representation Theory vs Permutation Circuit Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 10:30 UTC.
Pre-registration hash committed before this test ran: `5a2e7c2dda211c6c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
