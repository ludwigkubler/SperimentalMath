# Replay package — entry 667c28fe2e14

Conjecture: Minimal Quadratic Residue Symbol and DPLL Search Tree Height Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 09:59 UTC.
Pre-registration hash committed before this test ran: `28ace8e41dfafbf7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
