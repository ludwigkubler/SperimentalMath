# Replay package — entry dc7b1960b4f2

Conjecture: Minimal Rank of Bicategory Structure in Boolean Algebras over Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 22:50 UTC.
Pre-registration hash committed before this test ran: `c012873aba7757ac`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
