# Replay package — entry 50808532ce49

Conjecture: Minimal Alexander-Defect Invariant and Communication Complexity Rank Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 22:47 UTC.
Pre-registration hash committed before this test ran: `569880a31f7e08e0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
