# Replay package — entry d04fdfb9056c

Conjecture: Lyndon Factor Width Lower-Bounds Tree-Like Resolution

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-07 22:08 UTC.
Pre-registration hash committed before this test ran: `af47ca819c015f8b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
