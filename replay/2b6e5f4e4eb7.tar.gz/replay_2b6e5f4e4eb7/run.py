import random
from fractions import Fraction
import math
import itertools

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def incidence_tensor(clauses):
        n = max(abs(v) for v in set.union(*clauses))
        tensor = [[0] * (n + 1) for _ in range(n + 1)]
        for clause in clauses:
            for i, var in enumerate(clause):
                if var > 0:
                    tensor[var][var - i] += 1
                else:
                    tensor[-var][-var + i] += 1
        return tensor

    def symmetric_square(tensor):
        n = len(tensor)
        result = [[0] * (n + 1) for _ in range(n + 1)]
        for i in range(1, n + 1):
            for j in range(i, n + 1):
                result[i][j] += tensor[i][k] * tensor[j][k] for k in range(1, n + 1)
                result[j][i] = result[i][j]
        return result

    def young_tableaux_count(n, m):
        if n == 0 and m == 0:
            return 1
        if n < 0 or m < 0:
            return 0
        return young_tableaux_count(n - 1, m) + young_tableaux_count(n, m - 1)

    def resolution_width(clauses):
        # Simplified DPLL-style width analysis for demonstration purposes
        max_width = 0
        stack = [(clauses, [])]
        while stack:
            clauses, assignment = stack.pop()
            if not clauses:
                max_width = max(max_width, len(assignment))
                continue
            unit_clause = next((c for c in clauses if len(c) == 1), None)
            if unit_clause:
                var = unit_clause[0]
                new_assignment = assignment + [var]
                stack.append(([(v for v in c if v != var and -v not in new_assignment) for c in clauses], new_assignment))
                stack.append(([(v for v in c if v != -var and -v not in new_assignment) for c in clauses], new_assignment))
            else:
                literals = set()
                for clause in clauses:
                    literals.update(clause)
                literal, _ = random.choice(list(literals), 1)
                new_assignment = assignment + [literal]
                stack.append(([(v for v in c if v != literal and -v not in new_assignment) for c in clauses], new_assignment))
        return max_width

    def d_phi(tensor):
        n = len(tensor)
        partition = (n-1, 1)
        dim = young_tableaux_count(*partition)
        return dim

    def generate_random_3cnf(n, m):
        variables = list(range(1, n + 1))
        clauses = []
        for _ in range(m):
            clause = random.sample(variables, 3)
            random.shuffle(clause)
            clauses.append(clause)
        return clauses

    n = 40
    m = 2 * n**2  # Approximately 2^2n clauses for a dense 3-CNF
    clauses = generate_random_3cnf(n, m)

    tensor = incidence_tensor(clauses)
    symmetric_tensor = symmetric_square(tensor)
    d_phi_value = d_phi(symmetric_tensor)
    w_phi_value = resolution_width(clauses)

    if d_phi_value == 0:
        return {
            "metric_name": "resolution_width",
            "metric_value": -1,  # Indicate invalid case
            "instances_tested": 1,
            "conjecture_holds": False,
            "counterexample": "d(Φ) is zero"
        }

    lower_bound = 0.8 * d_phi_value**(1/3) / math.log(n)
    conjecture_holds = w_phi_value >= lower_bound
    counterexample = "" if conjecture_holds else f"w(Φ)={w_phi_value}, lower_bound={lower_bound}"

    return {
        "metric_name": "resolution_width",
        "metric_value": w_phi_value,
        "instances_tested": 1,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] if sys.argv[1:] else list(range(2, 30))  # Default to first 29 primes

    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)

    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value)**2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)

    if support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample='resolution_width' first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE reason=insufficient_support")