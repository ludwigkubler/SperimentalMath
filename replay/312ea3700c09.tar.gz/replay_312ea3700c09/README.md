# Replay package — entry 312ea3700c09

Conjecture: Algebraic Shifting Facet Count Bounds Tseitin Resolution Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 04:56 UTC.
Pre-registration hash committed before this test ran: `2eb2e54045f300f1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
