# Replay package — entry 1273f4c49121

Conjecture: Kronecker Coefficients of Hook Schur Functions Bound ABP Size for 3-CNFs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-25 01:17 UTC.
Pre-registration hash committed before this test ran: `4512d47cbb040f19`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
