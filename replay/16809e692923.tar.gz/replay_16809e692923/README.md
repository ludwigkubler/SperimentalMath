# Replay package — entry 16809e692923

Conjecture: TP_2 Minor-Sign Defect of Spectral Pseudo-Moment Matrix Bounds Max-CUT Ratio

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 09:29 UTC.
Pre-registration hash committed before this test ran: `d7213196951c828b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
