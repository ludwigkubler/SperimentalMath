# Replay package — entry 177506fee07e

Conjecture: Minimal Rank of Tropicalized Lie Algebras vs Boolean Circuit Weights

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 06:03 UTC.
Pre-registration hash committed before this test ran: `812b38b238d040f3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
