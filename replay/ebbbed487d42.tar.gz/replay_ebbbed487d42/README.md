# Replay package — entry ebbbed487d42

Conjecture: Minimal Symplectic Cohomology Rank Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 04:41 UTC.
Pre-registration hash committed before this test ran: `5c390d9b17fe7c61`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
