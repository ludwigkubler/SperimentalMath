# Replay package — entry 0f9459f83f8d

Conjecture: Minimal Rank of Quasipolynomial Functions vs DPLL Refutation Tree Diameter

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 11:36 UTC.
Pre-registration hash committed before this test ran: `83faf1bb115be13d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
