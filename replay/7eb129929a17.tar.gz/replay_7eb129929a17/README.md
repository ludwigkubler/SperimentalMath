# Replay package — entry 7eb129929a17

Conjecture: Random Matrix Eigenvalue Deficit and SOS Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 03:53 UTC.
Pre-registration hash committed before this test ran: `e3a20721267a3b74`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
