# Replay package — entry a7ed4b402584

Conjecture: Minimal Rank of Divisor Cycles Bounds Davis-Putnam Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 11:58 UTC.
Pre-registration hash committed before this test ran: `d253957730627152`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
