import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_boolean_function(n):
        return [random.choice([0, 1]) for _ in range(2**n)]
    
    def communication_complexity_rank(f):
        n = len(f)
        rank = 0
        for i in range(n):
            for j in range(i+1, n):
                if f[i] != f[j]:
                    rank += 1
        return rank
    
    def construct_lie_algebra(f):
        n = len(f)
        lie_algebra = []
        for i in range(n):
            for j in range(i+1, n):
                if f[i] == f[j]:
                    lie_algebra.append((i, j))
        return lie_algebra
    
    def minimal_index_of_coadjointness(lie_algebra):
        n = len(lie_algebra)
        index = 0
        for i in range(n):
            for j in range(i+1, n):
                if (lie_algebra[i][0], lie_algebra[j][0]) not in lie_algebra and (lie_algebra[i][1], lie_algebra[j][1]) not in lie_algebra:
                    index += 1
        return index
    
    def pearson_correlation(x, y):
        n = len(x)
        mean_x = sum(x) / n
        mean_y = sum(y) / n
        cov = sum((x[i] - mean_x) * (y[i] - mean_y) for i in range(n)) / n
        std_x = math.sqrt(sum((x[i] - mean_x)**2 for i in range(n)) / n)
        std_y = math.sqrt(sum((y[i] - mean_y)**2 for i in range(n)) / n)
        return cov / (std_x * std_y)
    
    results = []
    for _ in range(30):
        n = random.choice([5, 10, 15, 20, 30, 40])
        f = generate_boolean_function(n)
        r_f = communication_complexity_rank(f)
        lie_algebra = construct_lie_algebra(f)
        index_coadjointness = minimal_index_of_coadjointness(lie_algebra)
        results.append((r_f, index_coadjointness))
    
    if not results:
        return {
            "metric_name": "Pearson correlation",
            "metric_value": 0.0,
            "instances_tested": 0,
            "n_max": 0,
            "conjecture_holds": False,
            "counterexample": "mapping_undefined"
        }
    
    r_f_values, index_coadjointness_values = zip(*results)
    correlation = pearson_correlation(r_f_values, index_coadjointness_values)
    
    return {
        "metric_name": "Pearson correlation",
        "metric_value": correlation,
        "instances_tested": len(results),
        "n_max": max(len(f) for f in [generate_boolean_function(n) for n in [5, 10, 15, 20, 30, 40]]),
        "conjecture_holds": abs(correlation) >= 0.9,
        "counterexample": "" if abs(correlation) >= 0.9 else "Pearson correlation < 0.9"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113]
    results = []
    
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    if all(result["conjecture_holds"] for result in results):
        mean_value = sum(result["metric_value"] for result in results) / len(results)
        std_value = math.sqrt(sum((result["metric_value"] - mean_value)**2 for result in results) / len(results))
        support_fraction = 1.0
    else:
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        mean_value = sum(result["metric_value"] for result in results if result["conjecture_holds"]) / sum(1 for result in results if result["conjecture_holds"])
        std_value = math.sqrt(sum((result["metric_value"] - mean_value)**2 for result in results if result["conjecture_holds"])) / sum(1 for result in results if result["conjecture_holds"]))
        support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)
    
    print(f"RESULT: {'SUPPORTED' if all(result['conjecture_holds'] for result in results) else 'FALSIFIED'} mean={mean_value} std={std_value} support_fraction={support_fraction}")