# Replay package — entry 6308ca4eb644

Conjecture: Free Cumulant Gap in Read-Twice BPs for IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 20:56 UTC.
Pre-registration hash committed before this test ran: `cf0bc044911a7663`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
