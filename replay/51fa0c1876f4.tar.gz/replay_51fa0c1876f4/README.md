# Replay package — entry 51fa0c1876f4

Conjecture: Minimal Rank of Cocomplexes over Boolean Valuations

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 13:27 UTC.
Pre-registration hash committed before this test ran: `4a65133a6c7a1c17`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
