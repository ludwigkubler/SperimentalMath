# Replay package — entry 93b47d86db79

Conjecture: Free Cumulant Sum Bounded by Log-Size for Read-Twice BPs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 03:25 UTC.
Pre-registration hash committed before this test ran: `c79489174a46a48d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
