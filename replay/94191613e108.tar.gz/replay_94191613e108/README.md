# Replay package — entry 94191613e108

Conjecture: Bounded Arithmetic Proof Length and Circuit Complexity for Tautologies

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 03:27 UTC.
Pre-registration hash committed before this test ran: `d38e3e145a89d327`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
