# Replay package — entry bd2637caa228

Conjecture: Selmer Group 2-Rank of Pythagorean Triple CNF Formula Equals Resolution Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-24 10:44 UTC.
Pre-registration hash committed before this test ran: `bf346e291c20e7c3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
