# Replay package — entry 3510b1fe5d63

Conjecture: Minimal p-adic Order of Local Zeta Functions and SAT Clause Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 21:38 UTC.
Pre-registration hash committed before this test ran: `331fa0dfc4433424`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
