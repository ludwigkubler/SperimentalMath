# Replay package — entry 23db113e5412

Conjecture: Minimal Order of Ehrhart Quotient and Frege Proof Depth Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 11:32 UTC.
Pre-registration hash committed before this test ran: `f49d29847f9a97a2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
