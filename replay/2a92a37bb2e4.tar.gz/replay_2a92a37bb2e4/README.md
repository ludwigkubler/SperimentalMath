# Replay package — entry 2a92a37bb2e4

Conjecture: Minimal Rank of Hodge Classes over Algebraic Curves vs BP_ReadTwice Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 04:31 UTC.
Pre-registration hash committed before this test ran: `c7d5f95c5fb237b8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
