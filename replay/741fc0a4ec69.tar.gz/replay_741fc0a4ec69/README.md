# Replay package — entry 741fc0a4ec69

Conjecture: Hashimoto Non-Backtracking Pole Gap Lower-Bounds Tseitin Resolution

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-07 20:33 UTC.
Pre-registration hash committed before this test ran: `502dd79eb39e146a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
