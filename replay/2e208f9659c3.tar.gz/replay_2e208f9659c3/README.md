# Replay package — entry 2e208f9659c3

Conjecture: Minimal Local Index of Topological Entanglement Rank and Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 13:41 UTC.
Pre-registration hash committed before this test ran: `57cd6c5a57c00690`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
