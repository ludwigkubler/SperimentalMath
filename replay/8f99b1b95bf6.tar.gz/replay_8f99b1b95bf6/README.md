# Replay package — entry 8f99b1b95bf6

Conjecture: Minimal Rank of Entropic Complexity vs DPLL Refutation Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 06:48 UTC.
Pre-registration hash committed before this test ran: `a178c1e33e17707e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
