# Replay package — entry f7d5775dddc6

Conjecture: Tropical Derivation Sparsity Limits Phase Cell Count

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-30 07:04 UTC.
Pre-registration hash committed before this test ran: `cfc8b8a5ce4b5cbd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
