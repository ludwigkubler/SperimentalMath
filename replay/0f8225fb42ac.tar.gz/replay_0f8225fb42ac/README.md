# Replay package — entry 0f8225fb42ac

Conjecture: Minimal Order of Formal Language Automorphisms vs Monotone Circuit Depth for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 15:31 UTC.
Pre-registration hash committed before this test ran: `f2266858e4f7b152`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
