# Replay package — entry 2e16bb9b965a

Conjecture: Minimal Rank of Configuration Space Cohomology over Tseitin Resolution Trees Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 05:35 UTC.
Pre-registration hash committed before this test ran: `5ea0f252545b6fc0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
