# Replay package — entry 789449612a98

Conjecture: Minimal Noncommutative Tensor Product Rank Lower Bound for BP

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 21:19 UTC.
Pre-registration hash committed before this test ran: `6649517923dbebb3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
