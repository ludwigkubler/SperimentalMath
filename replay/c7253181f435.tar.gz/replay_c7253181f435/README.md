# Replay package — entry c7253181f435

Conjecture: Minimal Rank of Configuration Space Metrics vs Tseitin Resolution Length for Non-Expander Graphs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 18:11 UTC.
Pre-registration hash committed before this test ran: `ad133afbde6dd519`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
