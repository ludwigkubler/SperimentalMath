# Replay package — entry 787de79ea579

Conjecture: Minimal Rank of Quotient Algebras vs Tree-Width for k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 09:14 UTC.
Pre-registration hash committed before this test ran: `d652feea0d766d16`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
