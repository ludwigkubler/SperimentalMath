import random
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_cnf(n):
        clauses = []
        for _ in range(2**n - 1):
            clause = [random.choice([-1, 1]) * (i + 1) for i in range(n)]
            if all(clause[i] != -clause[j] for j in range(i)):
                clauses.append(clause)
        return clauses
    
    def tensor_network_valuation(cnf):
        n = len(cnf[0])
        T = [[0] * (2**n) for _ in range(2**n)]
        for clause in cnf:
            for i in range(2**n):
                if all((i >> j & 1) == abs(clause[j]) for j in range(n)):
                    T[i][i ^ sum([1 << j if clause[j] > 0 else 0 for j in range(n)] if clause[j] != 0 else 0 for j in range(n)))] += 1
        return T
    
    def min_rank(matrix):
        m, n = len(matrix), len(matrix[0])
        rank = 0
        for i in range(min(m, n)):
            pivot_row = -1
            for r in range(i, m):
                if matrix[r][i] != 0:
                    pivot_row = r
                    break
            if pivot_row == -1:
                continue
            rank += 1
            for j in range(n):
                matrix[pivot_row][j] /= matrix[pivot_row][i]
            for r in range(m):
                if r != pivot_row and matrix[r][i] != 0:
                    for j in range(n):
                        matrix[r][j] -= matrix[pivot_row][j] * matrix[r][i]
        return rank
    
    def g(n):
        max_rank = 0
        for _ in range(30):  # Ensure at least 30 instances per seed
            cnf = generate_cnf(n)
            T = tensor_network_valuation(cnf)
            rank = min_rank(T)
            if rank > max_rank:
                max_rank = rank
        return max_rank
    
    n_values = [5, 10, 15, 20, 30, 40]
    results = []
    for n in n_values:
        results.append(g(n))
    
    avg_g_n = sum(results) / len(results)
    conjecture_holds = all(r <= 2**n * math.log(n) for r, n in zip(results, n_values))
    counterexample = "" if conjecture_holds else f"max_rank={max(results)} > O(2^n log n)"
    
    return {
        "metric_name": "g(n)",
        "metric_value": avg_g_n,
        "instances_tested": len(results),
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2**i + 1 for i in range(5, 30)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result["metric_value"])
    
    avg_metric_value = sum(results) / len(results)
    support_fraction = sum(r <= 2**n * math.log(n) for r, n in zip(results, [5, 10, 15, 20, 30, 40])) / len(results)
    
    if all(r <= 2**n * math.log(n) for r, n in zip(results, [5, 10, 15, 20, 30, 40])):
        print(f"RESULT: SUPPORTED mean={avg_metric_value} std=NA support_fraction={support_fraction}")
    elif any(r > 2**n * math.log(n) for r, n in zip(results, [5, 10, 15, 20, 30, 40])):
        first_failing_seed = seeds[results.index(max(results))]
        print(f"RESULT: FALSIFIED counterexample=max_rank={max(results)} first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE reason=unknown")