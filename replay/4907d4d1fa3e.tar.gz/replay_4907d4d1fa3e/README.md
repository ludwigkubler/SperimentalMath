# Replay package — entry 4907d4d1fa3e

Conjecture: Newton-Inequality Defect of SAT Generating Polynomial Bounds DPLL Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 08:18 UTC.
Pre-registration hash committed before this test ran: `a6f6fb85401d4caf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
