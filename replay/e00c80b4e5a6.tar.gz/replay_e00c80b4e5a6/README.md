# Replay package — entry e00c80b4e5a6

Conjecture: Minimal Rank of Quandles Bounds Resolution Refutation Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 22:31 UTC.
Pre-registration hash committed before this test ran: `c219e5477b1b9835`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
