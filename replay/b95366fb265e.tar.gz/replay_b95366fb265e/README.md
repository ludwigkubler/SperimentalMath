# Replay package — entry b95366fb265e

Conjecture: Minimal Rank of Tropical Curves Bounds Cumulative Proof Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 11:55 UTC.
Pre-registration hash committed before this test ran: `1b2b4512b81533b1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
