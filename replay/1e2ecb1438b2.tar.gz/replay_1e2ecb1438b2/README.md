# Replay package — entry 1e2ecb1438b2

Conjecture: Minimal Geometric Entropy of Algebraic Curves and DPLL Proof Path Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 09:49 UTC.
Pre-registration hash committed before this test ran: `6f1b5b16463d9dc4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
