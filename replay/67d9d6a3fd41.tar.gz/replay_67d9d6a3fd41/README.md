# Replay package — entry 67d9d6a3fd41

Conjecture: Real Algebraic Geometry of XOR Circuit Weights Bounds AC⁰ Parity Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 15:00 UTC.
Pre-registration hash committed before this test ran: `ce443755edea4e9e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
