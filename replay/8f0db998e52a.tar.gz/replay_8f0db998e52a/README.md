# Replay package — entry 8f0db998e52a

Conjecture: Minimal Rank of Tropicalized Quantum Entanglement Bounds AC⁰ Circuit Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 03:24 UTC.
Pre-registration hash committed before this test ran: `ecff3879c03be37a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
