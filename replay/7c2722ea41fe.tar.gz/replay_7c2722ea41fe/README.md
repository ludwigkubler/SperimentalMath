# Replay package — entry 7c2722ea41fe

Conjecture: Minimal Eta-Invariant and Communication Complexity Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 17:40 UTC.
Pre-registration hash committed before this test ran: `00610f21d1d92317`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
