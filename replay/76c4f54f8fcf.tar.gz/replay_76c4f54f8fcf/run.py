import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def plethysm_coefficient(n):
        if n == 0:
            return 1
        coeff = 0
        for k in range(1, n + 1):
            coeff += (-1) ** (n - k) * Fraction(math.comb(n, k)) * plethysm_coefficient(k)
        return coeff
    
    def sos_refutation_size(n):
        # Placeholder function to simulate SOS refutation size
        # This is a dummy implementation and should be replaced with actual computation
        return n ** 2
    
    n = random.randint(5, 40)
    chi = plethysm_coefficient(n)
    sos_size = sos_refutation_size(n)
    c = Fraction(1, 10)  # Placeholder constant, adjust as needed
    
    metric_value = chi * sos_size
    instances_tested = 1
    conjecture_holds = metric_value >= c * math.log(n)
    counterexample = "" if conjecture_holds else f"n={n}, chi*{sos_size} < {c*math.log(n)}"
    
    return {
        "metric_name": "plethysm_coefficient * sos_refutation_size",
        "metric_value": metric_value,
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or list(range(2, 30))  # Default to first 29 primes if no seeds provided
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{results[0]['counterexample']}\" first_failing_seed={first_failing_seed}")