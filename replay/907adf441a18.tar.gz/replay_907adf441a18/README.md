# Replay package — entry 907adf441a18

Conjecture: SOS Moment Matrix Eigenvalue Sum Bounded by Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-13 07:16 UTC.
Pre-registration hash committed before this test ran: `30e8b6f0486c2105`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
