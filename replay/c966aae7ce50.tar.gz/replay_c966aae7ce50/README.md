# Replay package — entry c966aae7ce50

Conjecture: Minimal Rank of Commutative Algebraic Curves vs AC0 Parity Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 12:38 UTC.
Pre-registration hash committed before this test ran: `8c6b9e294e0ac02d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
