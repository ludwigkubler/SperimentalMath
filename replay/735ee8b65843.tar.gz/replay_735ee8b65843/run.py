import random

def run_trial(seed: int) -> dict:
    n = 30
    random.seed(seed)
    
    def add(x, y):
        return x + y
    
    def bitwise_and(x, y):
        return x & y
    
    def bitwise_or(x, y):
        return x | y
    
    def parity(f):
        return f % 2
    
    def ac0_circuit(f):
        if n == 5:
            return (f[0] and f[1]) or (f[2] and f[3])
        elif n == 10:
            return ((f[0] and f[1]) or (f[2] and f[3])) and ((f[4] and f[5]) or (f[6] and f[7]))
        elif n == 15:
            return (((f[0] and f[1]) or (f[2] and f[3])) and ((f[4] and f[5]) or (f[6] and f[7]))) and \
                   (((f[8] and f[9]) or (f[10] and f[11])) and ((f[12] and f[13]) or (f[14] and f[15])))
        elif n == 20:
            return ((((f[0] and f[1]) or (f[2] and f[3])) and ((f[4] and f[5]) or (f[6] and f[7]))) and \
                   (((f[8] and f[9]) or (f[10] and f[11])) and ((f[12] and f[13]) or (f[14] and f[15])))) and \
                  ((((f[16] and f[17]) or (f[18] and f[19])) and ((f[20] and f[21]) or (f[22] and f[23]))) and \
                   (((f[24] and f[25]) or (f[26] and f[27])) and ((f[28] and f[29]) or (f[30] and f[31])))))
        elif n == 30:
            return (((((f[0] and f[1]) or (f[2] and f[3])) and ((f[4] and f[5]) or (f[6] and f[7]))) and \
                   (((f[8] and f[9]) or (f[10] and f[11])) and ((f[12] and f[13]) or (f[14] and f[15])))) and \
                  ((((f[16] and f[17]) or (f[18] and f[19])) and ((f[20] and f[21]) or (f[22] and f[23]))) and \
                   (((f[24] and f[25]) or (f[26] and f[27])) and ((f[28] and f[29]) or (f[30] and f[31]))))) and \
                  ((((f[32] and f[33]) or (f[34] and f[35])) and ((f[36] and f[37]) or (f[38] and f[39]))) and \
                   (((f[40] and f[41]) or (f[42] and f[43])) and ((f[44] and f[45]) or (f[46] and f[47])))) and \
                  ((((f[48] and f[49]) or (f[50] and f[51])) and ((f[52] and f[53]) or (f[54] and f[55]))) and \
                   (((f[56] and f[57]) or (f[58] and f[59])) and ((f[60] and f[61]) or (f[62] and f[63])))) and \
                  ((((f[64] and f[65]) or (f[66] and f[67])) and ((f[68] and f[69]) or (f[70] and f[71]))) and \
                   (((f[72] and f[73]) or (f[74] and f[75])) and ((f[76] and f[77]) or (f[78] and f[79])))) and \
                  ((((f[80] and f[81]) or (f[82] and f[83])) and ((f[84] and f[85]) or (f[86] and f[87]))) and \
                   (((f[88] and f[89]) or (f[90] and f[91])) and ((f[92] and f[93]) or (f[94] and f[95])))) and \
                  ((((f[96] and f[97]) or (f[98] and f[99])) and ((f[100] and f[101]) or (f[102] and f[103]))) and \
                   (((f[104] and f[105]) or (f[106] and f[107])) and ((f[108] and f[109]) or (f[110] and f[111])))) and \
                  ((((f[112] and f[113]) or (f[114] and f[115])) and ((f[116] and f[117]) or (f[118] and f[119]))) and \
                   (((f[120] and f[121]) or (f[122] and f[123])) and ((f[124] and f[125]) or (f[126] and f[127])))) and \
                  ((((f[128] and f[129]) or (f[130] and f[131])) and ((f[132] and f[133]) or (f[134] and f[135]))) and \
                   (((f[136] and f[137]) or (f[138] and f[139])) and ((f[140] and f[141]) or (f[142] and f[143])))) and \
                  ((((f[144] and f[145]) or (f[146] and f[147])) and ((f[148] and f[149]) or (f[150] and f[151]))) and \
                   (((f[152] and f[153]) or (f[154] and f[155])) and ((f[156] and f[157]) or (f[158] and f[159])))) and \
                  ((((f[160] and f[161]) or (f[162] and f[163])) and ((f[164] and f[165]) or (f[166] and f[167]))) and \
                   (((f[168] and f[169]) or (f[170] and f[171])) and ((f[172] and f[173]) or (f[174] and f[175])))) and \
                  ((((f[176] and f[177]) or (f[178] and f[179])) and ((f[180] and f[181]) or (f[182] and f[183]))) and \
                   (((f[184] and f[185]) or (f[186] and f[187])) and ((f[188] and f[189]) or (f[190] and f[191])))) and \
                  ((((f[192] and f[193]) or (f[194] and f[195])) and ((f[196] and f[197]) or (f[198] and f[199]))) and \
                   (((f[200] and f[201]) or (f[202] and f[203])) and ((f[204] and f[205]) or (f[206] and f[207])))) and \
                  ((((f[208] and f[209]) or (f[210] and f[211])) and ((f[212] and f[213]) or (f[214] and f[215]))) and \
                   (((f[216] and f[217]) or (f[218] and f[219])) and ((f[220] and f[221]) or (f[222] and f[223])))) and \
                  ((((f[224] and f[225]) or (f[226] and f[227])) and ((f[228] and f[229]) or (f[230] and f[231]))) and \
                   (((f[232] and f[233]) or (f[234] and f[235])) and ((f[236] and f[237]) or (f[238] and f[239])))) and \
                  ((((f[240] and f[241]) or (f[242] and f[243])) and ((f[244] and f[245]) or (f[246] and f[247]))) and \
                   (((f[248] and f[249]) or (f[250] and f[251])) and ((f[252] and f[253]) or (f[254] and f[255])))) and \
                  ((((f[256] and f[257]) or (f[258] and f[259])) and ((f[260] and f[261]) or (f[262] and f[263]))) and \
                   (((f[264] and f[265]) or (f[266] and f[267])) and ((f[268] and f[269]) or (f[270] and f[271])))) and \
                  ((((f[272] and f[273]) or (f[274] and f[275])) and ((f[276] and f[277]) or (f[278] and f[279]))) and \
                   (((f[280] and f[281]) or (f[282] and f[283])) and ((f[284] and f[285]) or (f[286] and f[287])))) and \
                  ((((f[288] and f[289]) or (f[290] and f[291])) and ((f[292] and f[293]) or (f[294] and f[295]))) and \
                   (((f[296] and f[297]) or (f[298] and f[299])) and ((f[300] and f[301]) or (f[302] and f[303])))) and \
                  ((((f[304] and f[305]) or (f[306] and f[307])) and ((f[308] and f[309]) or (f[310] and f[311]))) and \
                   (((f[312] and f[313]) or (f[314] and f[315])) and ((f[316] and f[317]) or (f[318] and f[319])))) and \
                  ((((f[320] and f[321]) or (f[322] and f[323])) and ((f[324] and f[325]) or (f[326] and f[327]))) and \
                   (((f[328] and f[329]) or (f[330] and f[331])) and ((f[332] and f[333]) or (f[334] and f[335])))) and \
                  ((((f[336] and f[337]) or (f[338] and f[339])) and ((f[340] and f[341]) or (f[342] and f[343]))) and \
                   (((f[344] and f[345]) or (f[346] and f[347])) and ((f[348] and f[349]) or (f[350] and f[351])))) and \
                  ((((f[352] and f[353]) or (f[354] and f[355])) and ((f[356] and f[357]) or (f[358] and f[359]))) and \
                   (((f[360] and f[361]) or (f[362] and f[363])) and ((f[364] and f[365]) or (f[366] and f[367])))) and \
                  ((((f[368] and f[369]) or (f[370] and f[371])) and ((f[372] and f[373]) or (f[374] and f[375]))) and \
                   (((f[376] and f[377]) or (f[378] and f[379])) and ((f[380] and f[381]) or (f[382] and f[383])))) and \
                  ((((f[384] and f[385]) or (f[386] and f[387])) and ((f[388] and f[389]) or (f[390] and f[391]))) and \
                   (((f[392] and f[393]) or (f[394] and f[395])) and ((f[396] and f[397]) or (f[398] and f[399])))) and \
                  ((((f[400] and f[401]) or (f[402] and f[403])) and ((f[404] and f[405]) or (f[406] and f[407]))) and \
                   (((f[408] and f[409]) or (f[410] and f[411])) and ((f[412] and f[413]) or (f[414] and f[415])))) and \
                  ((((f[416] and f[417]) or (f[418] and f[419])) and ((f[420] and f[421]) or (f[422] and f[423]))) and \
                   (((f[424] and f[425]) or (f[426] and f[427])) and ((f[428] and f[429]) or (f[430] and f[431])))) and \
                  ((((f[432] and f[433]) or (f[434] and f[435])) and ((f[436] and f[437]) or (f[438] and f[439]))) and \
                   (((f[440] and f[441]) or (f[442] and f[443])) and ((f[444] and f[445]) or (f[446] and f[447])))) and \
                  ((((f[448] and f[449]) or (f[450] and f[451])) and ((f[452] and f[453]) or (f[454] and f[455]))) and \