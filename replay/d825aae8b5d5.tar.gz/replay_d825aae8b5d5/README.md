# Replay package — entry d825aae8b5d5

Conjecture: Dyadic Martingale Quadratic Variation Lower-Bounds Sign-Rank Discrepancy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 21:34 UTC.
Pre-registration hash committed before this test ran: `2a3b249ce721c953`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
