# Replay package — entry 810624ff41b4

Conjecture: Minimal Order of Divisor Class Group and SAT Clause Set Complexity Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 04:00 UTC.
Pre-registration hash committed before this test ran: `8ad89ab74858b72d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
