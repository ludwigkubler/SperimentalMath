# Replay package — entry ebd25f7a324a

Conjecture: Minimal Rank of Schur-Weyl Multiplicity for Permanent vs Determinant Separation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 08:03 UTC.
Pre-registration hash committed before this test ran: `4de070666afc5878`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
