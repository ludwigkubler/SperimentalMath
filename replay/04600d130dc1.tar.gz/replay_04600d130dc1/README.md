# Replay package — entry 04600d130dc1

Conjecture: Minimal Rank of Geometric Loci and DPLL Search Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 05:54 UTC.
Pre-registration hash committed before this test ran: `858b7b27955d3a2a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
