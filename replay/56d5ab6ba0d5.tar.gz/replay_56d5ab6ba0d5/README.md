# Replay package — entry 56d5ab6ba0d5

Conjecture: Minimal Local Coherence Index and SAT Clause Complexity Lower Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 12:00 UTC.
Pre-registration hash committed before this test ran: `be2526bba5d9b78e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
