# Replay package — entry 5adbb526b84d

Conjecture: Algebraic K-Theory Rank Bounds for Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 15:08 UTC.
Pre-registration hash committed before this test ran: `aac2ab927e4f42c6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
