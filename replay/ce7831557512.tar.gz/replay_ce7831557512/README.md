# Replay package — entry ce7831557512

Conjecture: Minimal Order of Categorial Invariants and Circuit Entanglement Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 22:11 UTC.
Pre-registration hash committed before this test ran: `2bfaec71c17ae1b1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
