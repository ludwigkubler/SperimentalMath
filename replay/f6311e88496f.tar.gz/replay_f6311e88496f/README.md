# Replay package — entry f6311e88496f

Conjecture: Minimal Rank of Tropicalized Quiver Representations vs Monotone Circuit Depth for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 07:03 UTC.
Pre-registration hash committed before this test ran: `205aca0c088cae14`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
