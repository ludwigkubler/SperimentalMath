# Replay package — entry ff5602ec92f9

Conjecture: Minimal Lattice Point Count in Affine Geometry versus SAT Proof Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 08:34 UTC.
Pre-registration hash committed before this test ran: `0ba1b80ef5d632ff`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
