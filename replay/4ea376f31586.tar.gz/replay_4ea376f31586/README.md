# Replay package — entry 4ea376f31586

Conjecture: Tropical Convex Hull Dimension Inverse Proportional to ACC^0 Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 21:18 UTC.
Pre-registration hash committed before this test ran: `6eadbc2b03ffa35f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
