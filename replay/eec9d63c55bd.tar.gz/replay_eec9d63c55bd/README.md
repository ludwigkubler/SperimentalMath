# Replay package — entry eec9d63c55bd

Conjecture: Minimal Rank of Hypergeometric Function Solutions over XOR-AND Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 18:23 UTC.
Pre-registration hash committed before this test ran: `f8bebe1362bb47e5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
