# Replay package — entry 3999b93633dd

Conjecture: Minimal Order of Braided Monoids and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 08:13 UTC.
Pre-registration hash committed before this test ran: `3af8f43c1500771d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
