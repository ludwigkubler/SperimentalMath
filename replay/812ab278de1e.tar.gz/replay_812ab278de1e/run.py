import random
import math

def gaussian_elimination(matrix):
    rows, cols = len(matrix), len(matrix[0])
    for i in range(rows):
        max_row = i + max(range(i, rows), key=lambda r: abs(matrix[r][i]))
        matrix[i], matrix[max_row] = matrix[max_row], matrix[i]
        for j in range(cols):
            if j != i:
                factor = -matrix[j][i] / matrix[i][i]
                for k in range(rows):
                    matrix[j][k] += factor * matrix[i][k]
    return matrix

def rank(matrix):
    rows, cols = len(matrix), len(matrix[0])
    row echelon_form = gaussian_elimination(matrix)
    rank = 0
    for i in range(min(rows, cols)):
        if row_echelon_form[i][i] != 0:
            rank += 1
    return rank

def incidence_matroid_rank(clauses):
    n = len(clauses[0])
    matroid = {var: set() for var in range(n)}
    for i, clause in enumerate(clauses):
        for var in clause:
            matroid[var].add(i)
    
    def is_independent(set_of_clauses):
        independent_set = list(set_of_clauses)
        if len(independent_set) == 0:
            return True
        if len(independent_set) > n:
            return False
        for _ in range(n - len(independent_set)):
            new_clause = set(range(n)) - matroid[sum(independent_set, start=0)]
            independent_set.append(new_clause)
        return len(independent_set) == n
    
    max_rank = 0
    for i in range(1 << n):
        set_of_clauses = [j for j in range(n) if (i & (1 << j)) != 0]
        if is_independent(set_of_clauses):
            max_rank = max(max_rank, len(set_of_clauses))
    
    return max_rank

def karchmer_wigderson_cost(clauses):
    n = len(clauses[0])
    matroid_rank = incidence_matroid_rank(clauses)
    return math.ceil(math.log2(matroid_rank + 1))

def generate_random_3cnf(n, m):
    variables = list(range(n))
    clauses = []
    for _ in range(m):
        clause = random.sample(variables, 3)
        clauses.append(clause)
    return clauses

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n = random.randint(5, 40)
    m = random.randint(n * 2, n * 5)
    clauses = generate_random_3cnf(n, m)
    
    matroid_rank = incidence_matroid_rank(clauses)
    karchmer_wigderson_cost_value = karchmer_wigderson_cost(clauses)
    
    return {
        "metric_name": "Karchmer-Wigderson cost",
        "metric_value": karchmer_wigderson_cost_value,
        "instances_tested": 1,
        "conjecture_holds": karchmer_wigderson_cost_value >= matroid_rank,
        "counterexample": "" if karchmer_wigderson_cost_value >= matroid_rank else f"Graph with n={n}, m={m}"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    results = []
    
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"Graph with n={results[0]['instances_tested']}, m={results[0]['instances_tested']*2}\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE insufficient_data")