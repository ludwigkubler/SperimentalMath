# Replay package — entry 9efd21df5cc8

Conjecture: Submodular Width of Polymatroid Rank Function and Monotone Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 09:58 UTC.
Pre-registration hash committed before this test ran: `22550f86323dec71`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
