# Replay package — entry a80c41a85b9f

Conjecture: Minimal Local Cohomology Rank and Communication Complexity for XOR

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 05:49 UTC.
Pre-registration hash committed before this test ran: `7988af0093e41943`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
