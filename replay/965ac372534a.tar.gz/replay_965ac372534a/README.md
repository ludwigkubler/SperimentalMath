# Replay package — entry 965ac372534a

Conjecture: Schur-Weyl Decomposition Component Count vs. Monotone Circuit Size for Permanent-like CNFs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 11:48 UTC.
Pre-registration hash committed before this test ran: `ff28269d5e6ae5e6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
