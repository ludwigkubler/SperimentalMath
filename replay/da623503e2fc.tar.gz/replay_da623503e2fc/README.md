# Replay package — entry da623503e2fc

Conjecture: Minimal Rank of Generalized Theta Functions and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 14:59 UTC.
Pre-registration hash committed before this test ran: `d720b7d348d3e8ff`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
