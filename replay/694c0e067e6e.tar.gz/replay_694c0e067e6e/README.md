# Replay package — entry 694c0e067e6e

Conjecture: Representation-Theoretic Rank Invariant for Permanent vs Determinant

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-29 05:27 UTC.
Pre-registration hash committed before this test ran: `d6eb9fbf8096fd7a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
