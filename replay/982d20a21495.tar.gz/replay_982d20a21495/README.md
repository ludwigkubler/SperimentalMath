# Replay package — entry 982d20a21495

Conjecture: Fourier Coefficient Sum Inverse Proportional to Disjointness Discrepancy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 01:40 UTC.
Pre-registration hash committed before this test ran: `df3cdadae5d90b0a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
