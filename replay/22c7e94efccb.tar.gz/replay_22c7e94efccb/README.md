# Replay package — entry 22c7e94efccb

Conjecture: Tropicalized Group C*-Algebra Norms vs BP_ReadTwice Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 02:26 UTC.
Pre-registration hash committed before this test ran: `03361a53c3756224`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
