# Replay package — entry 5ba04df7728c

Conjecture: Minimal Order of Hodge Decomposition Complexity and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 12:29 UTC.
Pre-registration hash committed before this test ran: `688ea66ae2ee1506`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
