# Replay package — entry 96d66c96c3a9

Conjecture: Quantum Topology Bounds on Tseitin Formula Resolution Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 02:34 UTC.
Pre-registration hash committed before this test ran: `5f7e0e8ed9406e94`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
