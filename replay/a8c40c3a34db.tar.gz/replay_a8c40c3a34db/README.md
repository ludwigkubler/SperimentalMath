# Replay package — entry a8c40c3a34db

Conjecture: Super-Exponential Lower Bound on Extended Frege Proofs for Ramsey-Type Tautologies

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 06:53 UTC.
Pre-registration hash committed before this test ran: `9809d58b1754165b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
