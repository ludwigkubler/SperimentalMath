# Replay package — entry 13b2236326ad

Conjecture: [c003b_cumulative_entropy/SC3#c38] The width-aware totalLiteralWeight Σ_t Σ_{C∈σ_t}|C| scales with a strictly larger exponent than the count-based Φ (width amplifies cumulative weight).

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 15:10 UTC.
Pre-registration hash committed before this test ran: `49c76baf5308542d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
