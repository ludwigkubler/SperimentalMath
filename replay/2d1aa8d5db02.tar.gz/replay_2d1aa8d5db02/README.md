# Replay package — entry 2d1aa8d5db02

Conjecture: Minimal Index of Hodge-Theta Duality over Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 22:55 UTC.
Pre-registration hash committed before this test ran: `a3d189f15b6b60cd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
