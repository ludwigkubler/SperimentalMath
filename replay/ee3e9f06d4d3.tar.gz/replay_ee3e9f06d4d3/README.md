# Replay package — entry ee3e9f06d4d3

Conjecture: Minimal Rank of Geometric Entanglement over Affine Manifolds vs Sum-of-Squares Circuit Size for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 00:27 UTC.
Pre-registration hash committed before this test ran: `0fb50e63cf348c5c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
