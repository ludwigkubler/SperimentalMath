# Replay package — entry b780cee78d58

Conjecture: Minimal Order of Kac-Moody Generators and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 08:08 UTC.
Pre-registration hash committed before this test ran: `cb121d67ee795b2a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
