# Replay package — entry 376a7658c1fe

Conjecture: Symmetric Group Orbit Count Distinguishes Read-Twice BPs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 05:31 UTC.
Pre-registration hash committed before this test ran: `bd9398da59d2a3b3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
