# Replay package — entry 8bd3855d67fc

Conjecture: Minimal Rank of Hodge Decomposition Components vs DPLL Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 01:02 UTC.
Pre-registration hash committed before this test ran: `a0db62e33f2a5507`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
