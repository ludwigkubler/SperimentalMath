# Replay package — entry c3f0b68a8fda

Conjecture: Minimal Rank of Quantum Logarithmic Capacity Bounds Monotone Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 01:08 UTC.
Pre-registration hash committed before this test ran: `27cd2cccd1c81476`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
