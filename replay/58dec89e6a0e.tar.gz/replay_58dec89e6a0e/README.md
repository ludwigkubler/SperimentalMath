# Replay package — entry 58dec89e6a0e

Conjecture: Minimal Order of Automorphism Groups and Boolean Circuit Entanglement

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 10:27 UTC.
Pre-registration hash committed before this test ran: `331a1f84215fc8c0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
