import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_random_boolean_function(n):
        return [random.choice([0, 1]) for _ in range(2**n)]
    
    def affine_group_order(f):
        # Placeholder function to calculate the order of the affine group
        # This is a dummy implementation and should be replaced with actual logic
        return len(f)
    
    def communication_complexity_rank_variance(f):
        # Placeholder function to calculate the communication complexity rank variance
        # This is a dummy implementation and should be replaced with actual logic
        return random.random()
    
    n = 5 + (seed % 6) * 5  # Sweep n through {5, 10, 15, 20, 30, 40}
    f = generate_random_boolean_function(n)
    order = affine_group_order(f)
    variance = communication_complexity_rank_variance(f)
    
    return {
        "metric_name": "Order of Affine Group Conjugacy Classes",
        "metric_value": order,
        "instances_tested": 1,
        "n_max": n,
        "conjecture_holds": abs(order - variance) <= 3 * math.sqrt(variance),
        "counterexample": ""
    }

if __name__ == "__main__":
    seeds = [int(arg) for arg in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    results = []
    
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"mapping_undefined\" first_failing_seed={first_failing_seed}")