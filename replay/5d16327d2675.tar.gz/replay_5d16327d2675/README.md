# Replay package — entry 5d16327d2675

Conjecture: Minimal Rank of Twisted Tensor Product Representations vs DPLL Refutation Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 12:01 UTC.
Pre-registration hash committed before this test ran: `a78465bb79070d10`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
