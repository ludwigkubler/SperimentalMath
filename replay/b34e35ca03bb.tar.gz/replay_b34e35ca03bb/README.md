# Replay package — entry b34e35ca03bb

Conjecture: Minimal Local Index of Lie Groups and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 20:36 UTC.
Pre-registration hash committed before this test ran: `d42e4ef709834019`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
