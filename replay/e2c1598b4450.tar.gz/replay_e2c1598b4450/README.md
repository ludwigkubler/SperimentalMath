# Replay package — entry e2c1598b4450

Conjecture: Minimal Rank of Algebraic Curvature vs Tree-like Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 02:41 UTC.
Pre-registration hash committed before this test ran: `c54c3fdc98999aaf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
