# Replay package — entry 1656dabd2aa6

Conjecture: Minimal Quadratic Entanglement in Quantum States and Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 08:52 UTC.
Pre-registration hash committed before this test ran: `dbe2064a3cfa463c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
