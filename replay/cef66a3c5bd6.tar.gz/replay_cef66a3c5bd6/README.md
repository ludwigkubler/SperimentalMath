# Replay package — entry cef66a3c5bd6

Conjecture: Hypergeometric Function Invariant for Resolution Proof Trees with Coxeter Group Enumeration

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 19:05 UTC.
Pre-registration hash committed before this test ran: `4936ed1e32fd020c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
