# Replay package — entry dd47721574e1

Conjecture: A5 Cayley-Walk Equidistribution Defect Detects 3-CNF Density Threshold

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 17:54 UTC.
Pre-registration hash committed before this test ran: `cead400a4fc76f58`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
