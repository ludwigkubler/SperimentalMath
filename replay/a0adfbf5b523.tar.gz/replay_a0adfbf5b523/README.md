# Replay package — entry a0adfbf5b523

Conjecture: Coxeter Matrix Spectral Gap and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 13:16 UTC.
Pre-registration hash committed before this test ran: `bb92361464ff87a0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
