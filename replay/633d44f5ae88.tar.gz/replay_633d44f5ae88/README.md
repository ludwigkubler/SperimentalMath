# Replay package — entry 633d44f5ae88

Conjecture: Total-Influence Defect of Clause-Indicator Bounds Tree-Resolution Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-27 21:18 UTC.
Pre-registration hash committed before this test ran: `27b184e2a3ea05c4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
