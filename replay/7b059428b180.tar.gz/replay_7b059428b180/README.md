# Replay package — entry 7b059428b180

Conjecture: Minimal Rank of Configuration Spaces vs Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 11:41 UTC.
Pre-registration hash committed before this test ran: `c9a002d144705f64`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
