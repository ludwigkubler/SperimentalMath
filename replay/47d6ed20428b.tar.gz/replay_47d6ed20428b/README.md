# Replay package — entry 47d6ed20428b

Conjecture: Minimal Rank of Brauer Groups over Randomized Query Complexity of XOR-AND Trees

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 02:59 UTC.
Pre-registration hash committed before this test ran: `f5753de9d7187b77`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
