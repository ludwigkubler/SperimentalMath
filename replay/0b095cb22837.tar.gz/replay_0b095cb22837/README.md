# Replay package — entry 0b095cb22837

Conjecture: Minimal Index of Noncommutative Rings and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 00:00 UTC.
Pre-registration hash committed before this test ran: `fedb3bf2aa846bc1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
