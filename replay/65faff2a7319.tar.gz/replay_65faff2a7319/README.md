# Replay package — entry 65faff2a7319

Conjecture: Minimal Symplectic Tensor Product Rank vs Permutation Circuit Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 07:22 UTC.
Pre-registration hash committed before this test ran: `20fe53c1c94f97f7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
