# Replay package — entry 934a387d12d9

Conjecture: Invariant Polynomial Generation Complexity in Determinant vs Permanent Orbits

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 16:16 UTC.
Pre-registration hash committed before this test ran: `ece581d94b3ca032`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
