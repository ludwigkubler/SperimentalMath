# Replay package — entry 68c92001b8ed

Conjecture: Minimal Rank of Schur Algebras vs Permutation Circuit Threshold

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 13:01 UTC.
Pre-registration hash committed before this test ran: `896a0a03f19bb31c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
