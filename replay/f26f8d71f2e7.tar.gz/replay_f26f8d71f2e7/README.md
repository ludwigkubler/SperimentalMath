# Replay package — entry f26f8d71f2e7

Conjecture: Inverse-β decay rate for tropical autoconvolution doubling defect at n=8

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 09:54 UTC.
Pre-registration hash committed before this test ran: `7e81f73352cb4c31`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
