# Replay package — entry 167c1bb13508

Conjecture: Minimal Rank of Tensor Product Representations over Monotone Circuit Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 20:20 UTC.
Pre-registration hash committed before this test ran: `7a6684ced8954e7c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
