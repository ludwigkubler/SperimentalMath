# Replay package — entry 10b91e07b63e

Conjecture: Betti Number Inverse Proportionality to DPLL Tree Size in 3-SAT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 21:15 UTC.
Pre-registration hash committed before this test ran: `a2f1d802695df0b4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
