# Replay package — entry 5564f7b774e2

Conjecture: Minimal Rank of Tropicalized Group Representations Bounds XOR-AND Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 17:48 UTC.
Pre-registration hash committed before this test ran: `f00adddb57686369`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
