# Replay package — entry 2b7421ced93f

Conjecture: Minimal Rank of Motivic Integrals vs Resolution Proof Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 08:10 UTC.
Pre-registration hash committed before this test ran: `3939e26f6dc67dc9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
