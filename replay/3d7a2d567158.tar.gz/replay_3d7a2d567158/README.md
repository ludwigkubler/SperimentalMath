# Replay package — entry 3d7a2d567158

Conjecture: Minimal Rank of Tropicalized Automorphic Representations vs. Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 07:19 UTC.
Pre-registration hash committed before this test ran: `63f03cd3d962d45c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
