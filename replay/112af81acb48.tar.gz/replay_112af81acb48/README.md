# Replay package — entry 112af81acb48

Conjecture: Tropical Geometry of Boolean Function Values over Affine Schemes vs AC0 Parity Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 12:31 UTC.
Pre-registration hash committed before this test ran: `b9e4721a127f2e86`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
