# Replay package — entry 99f896385624

Conjecture: Noncommutative Probability Invariant for BP Read-Twice Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 20:57 UTC.
Pre-registration hash committed before this test ran: `615533ce8328b60e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
