# Replay package — entry 0e98fc7c481f

Conjecture: Minimal Symmetric Braid Length and Circuit Depth Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 07:29 UTC.
Pre-registration hash committed before this test ran: `27a12b8ff0909f6f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
