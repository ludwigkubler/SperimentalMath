# Replay package — entry 8086a3a03a65

Conjecture: Zarankiewicz-Free Communication Matrices Imply Monotone Circuit Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 20:19 UTC.
Pre-registration hash committed before this test ran: `c1b8f574b28df193`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
