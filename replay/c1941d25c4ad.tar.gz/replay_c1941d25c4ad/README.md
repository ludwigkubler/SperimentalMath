# Replay package — entry c1941d25c4ad

Conjecture: Minimal Tensor Rank of Quaternion Algebras Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 14:28 UTC.
Pre-registration hash committed before this test ran: `ea606caf9c87e5b6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
