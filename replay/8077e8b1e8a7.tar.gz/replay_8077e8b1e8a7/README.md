# Replay package — entry 8077e8b1e8a7

Conjecture: Resultant Degree Bounds Frege Proof Size for Tautologies

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 15:41 UTC.
Pre-registration hash committed before this test ran: `a1d6b2031a3dbb6f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
