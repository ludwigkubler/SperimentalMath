# Replay package — entry 7cca45028040

Conjecture: Minimal Local Cohomology Rank of Quiver Representations vs Resolution Proof Length for Non-clausal Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 20:31 UTC.
Pre-registration hash committed before this test ran: `024a4374344b7c9e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
