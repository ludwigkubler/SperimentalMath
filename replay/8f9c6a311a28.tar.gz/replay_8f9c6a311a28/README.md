# Replay package — entry 8f9c6a311a28

Conjecture: Fourier Coefficient Flatness Implies Worst-Case Hardness for Boolean Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 11:59 UTC.
Pre-registration hash committed before this test ran: `2003c22c09c54b3e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
