# Replay package — entry 027781f6d598

Conjecture: Coxeter Group Enumeration of Boolean Function Entropy via Invariant Generators

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 01:21 UTC.
Pre-registration hash committed before this test ran: `8283b34f2a7062f6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
