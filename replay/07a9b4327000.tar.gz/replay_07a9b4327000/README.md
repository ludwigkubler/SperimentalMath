# Replay package — entry 07a9b4327000

Conjecture: Metric Dimension Lower Bound on Tseitin Resolution Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 05:18 UTC.
Pre-registration hash committed before this test ran: `145bef0cb78f42f4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
