# Replay package — entry 814036e46c39

Conjecture: Minimal Symplectic Hodge Index of Tseitin Formulas Bounds DPLL Proof Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 07:07 UTC.
Pre-registration hash committed before this test ran: `ef91fd1e7ff2702d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
