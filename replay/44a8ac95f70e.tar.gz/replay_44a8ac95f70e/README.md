# Replay package — entry 44a8ac95f70e

Conjecture: Noncommutative Fourier Spectrum Gap in Read-Twice BP for IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 23:44 UTC.
Pre-registration hash committed before this test ran: `2c4d8514d1dd9540`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
