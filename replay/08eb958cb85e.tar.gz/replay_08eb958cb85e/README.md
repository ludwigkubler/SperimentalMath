# Replay package — entry 08eb958cb85e

Conjecture: Minimal Order of Local Systems over Curves vs DPLL Proof Time Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 23:19 UTC.
Pre-registration hash committed before this test ran: `ee39b3ea09a94b60`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
