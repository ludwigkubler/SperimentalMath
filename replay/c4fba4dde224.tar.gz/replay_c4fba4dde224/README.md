# Replay package — entry c4fba4dde224

Conjecture: Secant Rank of Disjointness Communication Matrix Lower-Bounds Randomized Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 20:10 UTC.
Pre-registration hash committed before this test ran: `2280403580fed75d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
