# Replay package — entry 102ae91c53d3

Conjecture: Coxeter Polynomial Root Count Inverse Proportional to Resolution Length in 3-SAT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 21:50 UTC.
Pre-registration hash committed before this test ran: `cf7c3f0923717782`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
