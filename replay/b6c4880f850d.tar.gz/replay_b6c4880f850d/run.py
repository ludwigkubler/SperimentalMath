import random
import math

def gaussian_elimination(A):
    n = len(A)
    for i in range(n):
        max_row = i + max(range(i, n), key=lambda j: abs(A[j][i]))
        A[i], A[max_row] = A[max_row], A[i]
        for j in range(i+1, n):
            factor = A[j][i] / A[i][i]
            for k in range(n):
                A[j][k] -= factor * A[i][k]
    return A

def matrix_multiply(A, B):
    n = len(A)
    C = [[0]*n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            for k in range(n):
                C[i][j] += A[i][k] * B[k][j]
    return C

def spectral_norm(matrix, p=2):
    n = len(matrix)
    if p == 1:
        max_col_sum = max(sum(abs(matrix[j][i]) for j in range(n)) for i in range(n))
        max_row_sum = max(sum(abs(matrix[i][j]) for i in range(n)) for j in range(n))
        return max(max_col_sum, max_row_sum)
    elif p == 2:
        A = [[matrix[i][j] * matrix[i][j] for j in range(n)] for i in range(n)]
        eigenvalues = []
        I = [[1 if i == j else 0 for j in range(n)] for i in range(n)]
        for _ in range(100):
            x = [random.gauss(0, 1) for _ in range(n)]
            x_norm = math.sqrt(sum(x[i]**2 for i in range(n)))
            x = [x[i] / x_norm for i in range(n)]
            y = matrix_multiply(matrix, x)
            y_norm = math.sqrt(sum(y[i]**2 for i in range(n)))
            eigenvalue = sum(x[i] * y[i] for i in range(n)) / (y_norm * x_norm)
            eigenvalues.append(eigenvalue)
        return max(eigenvalues)**0.5
    else:
        raise ValueError("Unsupported p value")

def communication_complexity_disjointness(n):
    # Simplified model of communication complexity for disjointness function
    return n

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n = 10  # Start with a small size and increase if needed
    C_n = 1.0 / n  # Example constant, adjust as needed
    instances_tested = 30
    
    total_spectral_norm = 0
    total_communication_complexity = 0
    
    for _ in range(instances_tested):
        M1 = [[random.gauss(0, 1) for _ in range(n)] for _ in range(n)]
        M2 = [[random.gauss(0, 1) for _ in range(n)] for _ in range(n)]
        
        T = matrix_multiply(M1, M2)
        spectral_norm_T = spectral_norm(T)
        
        communication_complexity = communication_complexity_disjointness(n)
        
        total_spectral_norm += spectral_norm_T
        total_communication_complexity += communication_complexity
    
    average_spectral_norm = total_spectral_norm / instances_tested
    average_communication_complexity = total_communication_complexity / instances_tested
    
    conjecture_holds = average_spectral_norm >= C_n * average_communication_complexity
    counterexample = "" if conjecture_holds else "disjointness_function"
    
    return {
        "metric_name": "Spectral Norm vs Communication Complexity",
        "metric_value": average_spectral_norm,
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(arg) for arg in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_metric_value = sum(r["metric_value"] for r in results) / len(results)
    std_metric_value = (sum((r["metric_value"] - mean_metric_value)**2 for r in results) / len(results))**0.5
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_metric_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_metric_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next((r["seed"] for r in results if not r["conjecture_holds"]), None)
        print(f"RESULT: FALSIFIED counterexample=\"{result['counterexample']}\" first_failing_seed={first_failing_seed}")