# Replay package — entry 02bf89f63f6c

Conjecture: Minimal Rank of Free Entanglement Dimension Bounds BP Read-Twice Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 05:08 UTC.
Pre-registration hash committed before this test ran: `45f78feefb24d894`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
