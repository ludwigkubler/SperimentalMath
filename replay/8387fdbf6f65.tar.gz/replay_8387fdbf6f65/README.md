# Replay package — entry 8387fdbf6f65

Conjecture: Minimal Hyperbolic Rank and Resolution Proof Width Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 03:23 UTC.
Pre-registration hash committed before this test ran: `dc745bb5349a2192`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
