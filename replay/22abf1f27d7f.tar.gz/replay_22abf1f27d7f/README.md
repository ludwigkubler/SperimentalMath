# Replay package — entry 22abf1f27d7f

Conjecture: Edge-Expansion Rank Bound on Read-Twice BPs for Tseitin

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 20:26 UTC.
Pre-registration hash committed before this test ran: `481f8aa7188718cc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
