# Replay package — entry f20f24a2bf8b

Conjecture: Minimal Order of Quadratic Forms Bounds Communication Complexity for XOR

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 19:28 UTC.
Pre-registration hash committed before this test ran: `ee54ba7a51b200da`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
