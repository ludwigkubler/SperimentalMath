# Replay package — entry e90418e8fa5a

Conjecture: Graph Energy Lower Bound on Tseitin Resolution Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 15:39 UTC.
Pre-registration hash committed before this test ran: `25cb678ac90c6587`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
