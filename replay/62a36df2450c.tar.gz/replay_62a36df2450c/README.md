# Replay package — entry 62a36df2450c

Conjecture: Lee-Yang Zero Cluster Angle of Cut Polynomial Bounds Max-Cut SoS-2 Gap

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 11:29 UTC.
Pre-registration hash committed before this test ran: `8e1ba20db259bb46`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
