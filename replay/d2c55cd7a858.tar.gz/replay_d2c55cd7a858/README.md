# Replay package — entry d2c55cd7a858

Conjecture: Minimal Norm of Quadratic Forms over Function Fields vs DPLL Refutation Tree Height

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 13:47 UTC.
Pre-registration hash committed before this test ran: `1d520a010d1fe5f0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
