import random
import math
from fractions import Fraction
from itertools import combinations

# Helper functions for matrix operations
def identity_matrix(n):
    return [[1 if i == j else 0 for j in range(n)] for i in range(n)]

def transpose(matrix):
    return [list(row) for row in zip(*matrix)]

def matrix_add(A, B):
    return [[A[i][j] + B[i][j] for j in range(len(A[0]))] for i in range(len(A))]

def matrix_subtract(A, B):
    return [[A[i][j] - B[i][j] for j in range(len(A[0]))] for i in range(len(A))]

def matrix_multiply(A, B):
    n = len(A)
    m = len(B[0])
    result = [[sum(A[i][k] * B[k][j] for k in range(n)) for j in range(m)] for i in range(n)]
    return result

def determinant(matrix):
    if len(matrix) == 1:
        return matrix[0][0]
    det = 0
    for c in range(len(matrix)):
        submatrix = [row[:c] + row[c+1:] for row in matrix[1:]]
        sign = (-1) ** (c % 2)
        sub_det = determinant(submatrix)
        det += sign * matrix[0][c] * sub_det
    return det

def pinv(matrix):
    n = len(matrix)
    I = identity_matrix(n)
    augmented = [row + col for row, col in zip(matrix, I)]
    for i in range(n):
        pivot = augmented[i][i]
        if pivot == 0:
            raise ValueError("Matrix is not invertible")
        for j in range(n * 2):
            augmented[i][j] /= pivot
        for k in range(n):
            if k != i:
                factor = augmented[k][i]
                for j in range(n * 2):
                    augmented[k][j] -= factor * augmented[i][j]
    inverse = [row[n:] for row in augmented]
    return inverse

def max_cut(graph, n):
    max_cut_value = -1
    for subset in combinations(range(n), n // 2):
        cut_value = sum(graph[u][v] for u in subset for v in range(u + 1, n) if v not in subset)
        if cut_value > max_cut_value:
            max_cut_value = cut_value
    return max_cut_value

def delorme_poljak_bound(n, lambda_min):
    return n / 4 * abs(lambda_min)

def lorentzian_hessian_gap(H):
    eigenvalues = sorted(eigenvector_decomposition(H), reverse=True)
    return eigenvalues[0] - eigenvalues[1]

def eigenvector_decomposition(matrix):
    n = len(matrix)
    A = matrix_add(matrix, identity_matrix(n))
    for i in range(n):
        A[i][i] -= 2
    det_A = determinant(A)
    if det_A == 0:
        raise ValueError("Matrix is not invertible")
    eigenvalues = [1 + (det_A / (-n * n)) * ((-1) ** i) for i in range(n)]
    return eigenvalues

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n_values = [8, 10, 12, 14, 16]
    p_values = [0.4, 0.5, 0.6]
    c = 0.01
    results = []

    for n in n_values:
        for p in p_values:
            G = [[random.random() < p for _ in range(n)] for _ in range(n)]
            if any(sum(row) == 0 for row in G):
                continue

            # Compute Laplacian L and its inverse
            D = [sum(G[i]) for i in range(n)]
            L = [[D[i] - G[i][j] if i == j else -G[i][j] for j in range(n)] for i in range(n)]
            L_inv = pinv(L)

            # Compute Hessian entries
            p = [L_inv[i][i] + L_inv[j][j] - 2 * L_inv[i][j] for i, j in combinations(range(n), 2)]
            y = [[L_inv[u][u'] - L_inv[u][v'] - L_inv[v][u'] + L_inv[v][v'] for u', v' in combinations(range(n), 2)] for u, v in combinations(range(n), 2)]
            H = [[p[i] * p[j] - y[i][j]**2 if i != j else 0 for j in range(len(p))] for i in range(len(p))]

            # Compute eigenvalues and gap
            g_G = lorentzian_hessian_gap(H)
            lambda_min_A_G = min(sum(G[u][v] for v in range(u + 1, n)) for u in range(n))
            DP_G = delorme_poljak_bound(n, lambda_min_A_G)

            # Compute MaxCut
            max_cut_value = max_cut(G, n)

            # Check ratio and record result
            if g_G > 1e-6:
                ratio = (DP_G - max_cut_value) / (g_G * n)
                results.append((n, p, DP_G, max_cut_value, g_G, ratio))

    if not results:
        return {
            "metric_name": "ratio",
            "metric_value": 0,
            "instances_tested": 0,
            "conjecture_holds": False,
            "counterexample": "no_valid_instances"
        }

    min_ratio = min(ratio for _, _, _, _, _, ratio in results)
    median_ratio = sorted(ratio for _, _, _, _, _, ratio in results)[len(results) // 2]
    max_ratio = max(ratio for _, _, _, _, _, ratio in results)

    return {
        "metric_name": "ratio",
        "metric_value": (min_ratio + median_ratio + max_ratio) / 3,
        "instances_tested": len(results),
        "conjecture_holds": min_ratio >= c and all(ratio >= c for _, _, _, _, _, ratio in results),
        "counterexample": "" if min_ratio >= c else f"ratio={min_ratio} < {c}"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(x) for x in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    results = []

    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")

    ratios = [result["metric_value"] for result in results if result["instances_tested"] > 0]
    support_fraction = sum(result["conjecture_holds"] for result in results) / len(results)

    if all(r >= 1e-3 for r in ratios):
        print(f"RESULT: SUPPORTED mean={sum(ratios)/len(ratios)} std={math.sqrt(sum((r - (sum(ratios)/len(ratios)))**2 for r in ratios) / len(ratios))} support_fraction={support_fraction}")
    elif any(r < 1e-3 and g > 1e-6 for _, _, _, _, g, r in results):
        print(f"RESULT: FALSIFIED counterexample=\"ratio<{min(r for _, _, _, _, _, r in results if r < 1e-3)}\" first_failing_seed={seeds[ratios.index(min(r for _, _, _, _, _, r in results if r < 1e-3))]}")
    else:
        print(f"RESULT: INCONCLUSIVE reason=median_ratio_decays_by_2x n_tested={len(ratios)}")