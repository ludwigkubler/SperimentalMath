# Replay package — entry 4f6b79e26549

Conjecture: Minimal Rank of Algebraic Hodge Classes Bounds Geometric Complexity Theory Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 14:13 UTC.
Pre-registration hash committed before this test ran: `d7594650992bc262`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
