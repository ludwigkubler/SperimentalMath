# Replay package — entry 7159142fbe3a

Conjecture: Minimal Rank of Geometric Invariants in Graph Theory vs Communication Complexity for Max-Disjoint Paths

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 18:13 UTC.
Pre-registration hash committed before this test ran: `8953bfd6b5c20cc9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
