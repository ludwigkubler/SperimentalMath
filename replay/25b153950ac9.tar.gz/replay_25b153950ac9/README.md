# Replay package — entry 25b153950ac9

Conjecture: NW-Design Slice Spectral Discrepancy Bound for DISJ

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 10:54 UTC.
Pre-registration hash committed before this test ran: `26617bfa1b15ea65`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
