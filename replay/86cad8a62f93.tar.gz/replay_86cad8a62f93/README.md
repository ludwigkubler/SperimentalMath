# Replay package — entry 86cad8a62f93

Conjecture: Minimal Rank of Hodge Structures Bounds Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 07:52 UTC.
Pre-registration hash committed before this test ran: `b7311290abfeba0a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
