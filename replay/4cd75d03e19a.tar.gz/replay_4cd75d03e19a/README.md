# Replay package — entry 4cd75d03e19a

Conjecture: Minimal Order of Formal Grammar Entailment and SAT Clause Entropy Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 18:52 UTC.
Pre-registration hash committed before this test ran: `2e01c61338d7f1cc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
