# Replay package — entry 87bd7c388ea1

Conjecture: Minimal Order of Algebraic Topology Generators and SAT Clause Subset Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 00:23 UTC.
Pre-registration hash committed before this test ran: `a6042cf751e873e3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
