# Replay package — entry d06cb943aa07

Conjecture: Hyperbolic Metric Entropy Bound for Circuit Satisfiability Time

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 03:33 UTC.
Pre-registration hash committed before this test ran: `662f61d239e45e38`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
