# Replay package — entry 083cbe094ac1

Conjecture: Minimal Local Class Group Structure Correlation with DPLL Proof Tree Path Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 03:28 UTC.
Pre-registration hash committed before this test ran: `f6d58904622a5697`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
