import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_boolean_formula(n_vars, n_clauses):
        variables = [f'x{i}' for i in range(n_vars)]
        clauses = []
        for _ in range(n_clauses):
            clause = random.choice(['', '¬']) + random.choice(variables) for _ in range(random.randint(1, 3)))
            clauses.append('∨'.join(clause))
        return '∧'.join(clauses)
    
    def frege_proof_depth(formula):
        # Simplified estimation of Frege proof depth
        return len(formula.split('∧')) + len(formula.split('∨'))
    
    def minimal_brauer_character_order(n_vars, n_clauses):
        # Simplified estimation of minimal Brauer character order
        return max(n_vars, n_clauses)
    
    results = []
    for _ in range(30):
        n_vars = random.randint(5, 10)
        n_clauses = random.randint(5, 10)
        formula = generate_boolean_formula(n_vars, n_clauses)
        depth = frege_proof_depth(formula)
        order = minimal_brauer_character_order(n_vars, n_clauses)
        results.append((depth, order))
    
    if not results:
        return {
            "metric_name": "Pearson's Correlation Coefficient",
            "metric_value": None,
            "instances_tested": 0,
            "n_max": 10,
            "conjecture_holds": False,
            "counterexample": "No instances generated"
        }
    
    depths = [r[0] for r in results]
    orders = [r[1] for r in results]
    
    n = len(depths)
    mean_depth = sum(depths) / n
    mean_order = sum(orders) / n
    
    covariance = sum((depths[i] - mean_depth) * (orders[i] - mean_order) for i in range(n)) / n
    variance_depth = sum((depths[i] - mean_depth) ** 2 for i in range(n)) / n
    variance_order = sum((orders[i] - mean_order) ** 2 for i in range(n)) / n
    
    correlation_coefficient = covariance / (math.sqrt(variance_depth) * math.sqrt(variance_order))
    
    return {
        "metric_name": "Pearson's Correlation Coefficient",
        "metric_value": correlation_coefficient,
        "instances_tested": n,
        "n_max": 10,
        "conjecture_holds": abs(correlation_coefficient) > 0.5,
        "counterexample": ""
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    
    results = []
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    if not results:
        print("RESULT: INCONCLUSIVE no trials executed")
        sys.exit(0)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE insufficient support")