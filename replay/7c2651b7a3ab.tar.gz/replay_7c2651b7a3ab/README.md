# Replay package — entry 7c2651b7a3ab

Conjecture: Minimal Order of Quantum Logarithmic Potential over Tseitin Resolution Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 20:31 UTC.
Pre-registration hash committed before this test ran: `69b8f850a8149b83`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
