# Replay package — entry 5be7b1a76154

Conjecture: Schur-Weyl Duality Rank Bounds XOR Circuit Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 15:03 UTC.
Pre-registration hash committed before this test ran: `cf8519cd6ab887e4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
