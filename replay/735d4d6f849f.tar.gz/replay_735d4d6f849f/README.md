# Replay package — entry 735d4d6f849f

Conjecture: Metric Dispersion Lower Bound for Monotone DNF Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 17:48 UTC.
Pre-registration hash committed before this test ran: `3d3d664b6a912cb6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
