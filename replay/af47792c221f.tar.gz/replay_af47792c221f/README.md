# Replay package — entry af47792c221f

Conjecture: Minimal Order of Quantum Entanglement States vs Communication Complexity for XOR

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 14:51 UTC.
Pre-registration hash committed before this test ran: `36ee5eb31b1c37c2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
