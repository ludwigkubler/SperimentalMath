# Replay package — entry e916a26d0545

Conjecture: Coxeter Group Action Complexity of SAT under Tropicalization

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 13:08 UTC.
Pre-registration hash committed before this test ran: `9bd0714d43912bee`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
