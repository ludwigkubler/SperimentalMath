# Replay package — entry 99031b88f008

Conjecture: Minimal K-theoretic Index and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 01:28 UTC.
Pre-registration hash committed before this test ran: `4874cca2453ebc9a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
