# Replay package — entry 7897aa7acf7d

Conjecture: Minimal Rank of p-Adic Differentials vs AC0 Parity Circuit Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 10:23 UTC.
Pre-registration hash committed before this test ran: `15dbcf05405608c7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
