# Replay package — entry a0510d6a5b35

Conjecture: Minimal Order of Geometric Lattices Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-29 12:50 UTC.
Pre-registration hash committed before this test ran: `0d077c408b0a84d1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
