# Replay package — entry 4752cd699a11

Conjecture: Minimal Rank of Tropicalized Affine Sheaves vs AC0 Parity Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 16:02 UTC.
Pre-registration hash committed before this test ran: `2488ed858592ef01`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
