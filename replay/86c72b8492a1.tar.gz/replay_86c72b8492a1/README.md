# Replay package — entry 86c72b8492a1

Conjecture: Minimal Rank of Kac-Moody Algebras vs AC0 Parity Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 00:03 UTC.
Pre-registration hash committed before this test ran: `029f912bf98822ac`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
