import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_bp(n):
        if n == 1:
            return [0]
        bp = []
        for _ in range(n - 1):
            bp.append(random.choice([0, 1]))
        bp.append(bp[0] ^ bp[-2])
        return bp
    
    def compute_tropical_curve(bp):
        rank = 0
        for i in range(len(bp)):
            if bp[i] == 1:
                rank += 1
        return rank
    
    n_values = [5, 10, 15, 20, 30, 40]
    total_rank = 0
    instances_tested = 0
    
    for n in n_values:
        for _ in range(5):  # Ensure at least 5 instances per size
            bp = generate_bp(n)
            rank = compute_tropical_curve(bp)
            total_rank += rank
            instances_tested += 1
    
    mean_rank = Fraction(total_rank, instances_tested)
    
    if n_values[-1] > 30:
        return {
            "metric_name": "Rank vs DPLL Heig",
            "metric_value": float(mean_rank),
            "instances_tested": instances_tested,
            "conjecture_holds": False,
            "counterexample": "n_max_exceeded"
        }
    
    if mean_rank <= 2 * math.log(instances_tested, 2):
        return {
            "metric_name": "Rank vs DPLL Heig",
            "metric_value": float(mean_rank),
            "instances_tested": instances_tested,
            "conjecture_holds": True,
            "counterexample": ""
        }
    else:
        return {
            "metric_name": "Rank vs DPLL Heig",
            "metric_value": float(mean_rank),
            "instances_tested": instances_tested,
            "conjecture_holds": False,
            "counterexample": "mean_rank_exceeded"
        }

if __name__ == "__main__":
    import sys
    seeds = [int(x) for x in sys.argv[1:]] if sys.argv[1:] else [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_rank = sum(r["metric_value"] for r in results) / len(results)
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_rank} std=0.0 support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_rank} std=0.0 support_fraction={support_fraction}")
    else:
        for r in results:
            if not r["conjecture_holds"]:
                print(f"RESULT: FALSIFIED counterexample=\"{r['counterexample']}\" first_failing_seed={seed}")
                break