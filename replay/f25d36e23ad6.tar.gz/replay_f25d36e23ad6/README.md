# Replay package — entry f25d36e23ad6

Conjecture: Minimal Rank of Hodge Decomposition over Boolean Function Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 18:12 UTC.
Pre-registration hash committed before this test ran: `7a539848106ce495`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
