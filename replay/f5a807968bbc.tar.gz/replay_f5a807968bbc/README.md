# Replay package — entry f5a807968bbc

Conjecture: Minimal Rank of Tropical Hodge Structure over Circuit Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 09:40 UTC.
Pre-registration hash committed before this test ran: `207073a5788cbe9f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
