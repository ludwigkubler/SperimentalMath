# Replay package — entry 6ae57c36380b

Conjecture: Submodular Rank Gap in Monotone DNF for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 18:22 UTC.
Pre-registration hash committed before this test ran: `b6f82c9ce9d11c6e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
