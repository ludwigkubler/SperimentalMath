# Replay package — entry 3d8d981c2574

Conjecture: Minimal Local Indeterminacy in Quantum Information Geometry and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 04:57 UTC.
Pre-registration hash committed before this test ran: `3282226211c0ae32`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
