# Replay package — entry 08610d2777ba

Conjecture: Minimal Local Index of Configuration Spaces vs Sipser Function Entropic Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 11:43 UTC.
Pre-registration hash committed before this test ran: `e7d76ab94f571871`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
