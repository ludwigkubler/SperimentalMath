# Replay package — entry 3da60ffa5797

Conjecture: Minimal Order of Symplectic Quotients and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 02:25 UTC.
Pre-registration hash committed before this test ran: `2863327b0ad6bd10`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
