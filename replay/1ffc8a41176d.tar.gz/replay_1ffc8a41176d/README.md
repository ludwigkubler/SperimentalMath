# Replay package — entry 1ffc8a41176d

Conjecture: Minimal Local Induction Ring Rank and Circuit Entropy Variance Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 05:58 UTC.
Pre-registration hash committed before this test ran: `0381182100ab9b5f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
