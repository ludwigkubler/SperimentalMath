# Replay package — entry dad6f5b43d31

Conjecture: Minimal Galois Covering Degree and Communication Complexity Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 07:20 UTC.
Pre-registration hash committed before this test ran: `6dbda05bcbcdbe5f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
