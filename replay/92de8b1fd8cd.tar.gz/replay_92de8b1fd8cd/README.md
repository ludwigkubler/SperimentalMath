# Replay package — entry 92de8b1fd8cd

Conjecture: Minimal Riemann Hypothesis Exponent of Boolean Functions vs Randomized Communication Complexity for k-Clique

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 18:05 UTC.
Pre-registration hash committed before this test ran: `1575839279c8b78f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
