# Replay package — entry c7987efbd095

Conjecture: Matroid Polytope Integrality and Circuit Complexity of MCSP

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 00:51 UTC.
Pre-registration hash committed before this test ran: `c22ef1f1319d15b2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
