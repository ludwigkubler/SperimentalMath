# Replay package — entry caa2e11c2196

Conjecture: Minimal Order of Artin-Schreier Extensions and DPLL Search Tree Diameter

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 11:07 UTC.
Pre-registration hash committed before this test ran: `2e0bc969b0e8449f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
