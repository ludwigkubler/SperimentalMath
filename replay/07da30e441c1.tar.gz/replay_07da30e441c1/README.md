# Replay package — entry 07da30e441c1

Conjecture: Minimal Rank of Tropical Graphs Bounds ACC⁰ Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 15:58 UTC.
Pre-registration hash committed before this test ran: `27abaeee4803a022`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
