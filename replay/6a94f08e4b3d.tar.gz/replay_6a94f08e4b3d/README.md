# Replay package — entry 6a94f08e4b3d

Conjecture: Minimal Rank of Tropicalized Group Representations Bounds Resolution Refutation Size for XOR-AND Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 15:19 UTC.
Pre-registration hash committed before this test ran: `2dcf521cb69faf29`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
