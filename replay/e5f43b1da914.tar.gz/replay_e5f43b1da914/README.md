# Replay package — entry e5f43b1da914

Conjecture: Minimal Rank of Quadratic Forms Bounds Amplitude Amplification in Quantum Computing

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 10:42 UTC.
Pre-registration hash committed before this test ran: `661a5bc8061c5fa1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
