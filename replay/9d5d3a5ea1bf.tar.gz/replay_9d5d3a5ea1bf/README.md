# Replay package — entry 9d5d3a5ea1bf

Conjecture: Matroid Rank Deficit in Monotone DNF Depth for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 17:23 UTC.
Pre-registration hash committed before this test ran: `005326a000c5ea27`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
