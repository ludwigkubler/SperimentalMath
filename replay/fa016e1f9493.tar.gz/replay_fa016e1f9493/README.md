# Replay package — entry fa016e1f9493

Conjecture: Minimal Index of Topological Entanglement and Communication Complexity Rank Variance Ratio

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 17:11 UTC.
Pre-registration hash committed before this test ran: `43acbdc3d3f061fa`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
