# Replay package — entry 88163488fc07

Conjecture: Minimal Rank of Algebraic Curves over Function Fields vs Monotone Circuit Depth for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 14:11 UTC.
Pre-registration hash committed before this test ran: `ec02e5c7d52836d6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
