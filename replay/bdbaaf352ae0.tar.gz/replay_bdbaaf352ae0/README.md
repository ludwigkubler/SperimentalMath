# Replay package — entry bdbaaf352ae0

Conjecture: Dyadic Spectrum Entropy Invariants for Resolution Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 17:06 UTC.
Pre-registration hash committed before this test ran: `9fd37d3d0115f97b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
