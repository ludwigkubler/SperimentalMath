# Replay package — entry d1ac0509b45b

Conjecture: Minimal Rank of Tensor Product of Tropicalized Cohomology with Resolution Proof Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 08:44 UTC.
Pre-registration hash committed before this test ran: `d04818fed7a9aa5d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
