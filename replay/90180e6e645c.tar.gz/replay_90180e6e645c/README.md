# Replay package — entry 90180e6e645c

Conjecture: Minimal Order of Kähler Manifolds and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 21:24 UTC.
Pre-registration hash committed before this test ran: `a713b3e7dd1b9b1c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
