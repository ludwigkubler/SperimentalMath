# Replay package — entry c0d872afa484

Conjecture: Minimal Number of Automorphism Group Orbits and Communication Complexity Rank Variance Ratio

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 16:19 UTC.
Pre-registration hash committed before this test ran: `74d840736a800b7d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
