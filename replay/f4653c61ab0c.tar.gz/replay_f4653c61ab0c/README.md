# Replay package — entry f4653c61ab0c

Conjecture: Minimal Geometric Entropy of Quiver Representations and Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 19:40 UTC.
Pre-registration hash committed before this test ran: `6b071f5e605cd21f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
