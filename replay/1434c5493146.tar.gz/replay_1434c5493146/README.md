# Replay package — entry 1434c5493146

Conjecture: Noncommutative Fourier Coefficient Spread and Read-Twice BP Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 13:19 UTC.
Pre-registration hash committed before this test ran: `d9f3dace7661717e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
