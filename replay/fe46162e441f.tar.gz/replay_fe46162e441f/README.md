# Replay package — entry fe46162e441f

Conjecture: Euler Characteristic of Directed Clause-Variable Feedback Spaces Equals DPLL Backtrack Count

Verdict (original run): FALSIFIED

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-24 02:09 UTC.
Pre-registration hash committed before this test ran: `?`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
