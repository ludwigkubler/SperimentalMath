# Replay package — entry c7f898dc68a4

Conjecture: Quiver Mutation Neighborhood Lower-Bounds ACC0 by Sensitivity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 17:51 UTC.
Pre-registration hash committed before this test ran: `e0ef6d199d00d184`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
