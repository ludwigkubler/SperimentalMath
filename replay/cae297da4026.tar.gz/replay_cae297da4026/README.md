# Replay package — entry cae297da4026

Conjecture: Persistent Homology Bottleneck Distance Lower-Bounds Set-Disjointness Discrepancy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 17:44 UTC.
Pre-registration hash committed before this test ran: `2ab5c7191f3df507`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
