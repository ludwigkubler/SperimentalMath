# Replay package — entry e9123a8ea921

Conjecture: Automorphism Group Generator Count Bounded by ABP Width for Symmetric CNFs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 11:43 UTC.
Pre-registration hash committed before this test ran: `e9df3f581bf437c5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
