# Replay package — entry 595a1117d469

Conjecture: Finite Plane Line Count Bounds Tseitin Resolution Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 02:26 UTC.
Pre-registration hash committed before this test ran: `60f7b291c5a27f05`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
