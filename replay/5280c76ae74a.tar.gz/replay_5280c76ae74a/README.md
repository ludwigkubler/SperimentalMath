# Replay package — entry 5280c76ae74a

Conjecture: Minimal Rank of Quantum states vs Quantum Circuit T-depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 14:39 UTC.
Pre-registration hash committed before this test ran: `37a9c05aaf25122a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
