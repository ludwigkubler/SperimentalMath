# Replay package — entry 33c2a0c94718

Conjecture: Minimal p-Adic Valuation and SAT Clause Entropy Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 17:01 UTC.
Pre-registration hash committed before this test ran: `56820b4bd6cb0b23`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
