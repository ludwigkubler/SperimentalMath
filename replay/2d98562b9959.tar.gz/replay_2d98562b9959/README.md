# Replay package — entry 2d98562b9959

Conjecture: Trivial-Isotype Mass Gap Separates Perm from Padded Det

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 23:19 UTC.
Pre-registration hash committed before this test ran: `dbb6b816a6d7f5be`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
