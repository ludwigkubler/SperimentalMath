# Replay package — entry 2d001bb69a00

Conjecture: Minimal Rank of Noncrossing Partition Matrices over Tropical Semirings vs DPLL Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 23:22 UTC.
Pre-registration hash committed before this test ran: `6cf7ee1d1daf56a9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
