# Replay package — entry 91f293427310

Conjecture: VC-Dimension of Row-Induced Set System Bounds Monotone DNF Size for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-30 10:09 UTC.
Pre-registration hash committed before this test ran: `048486d81c2317d8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
