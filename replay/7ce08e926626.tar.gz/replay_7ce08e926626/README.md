# Replay package — entry 7ce08e926626

Conjecture: Euler Characteristic of Clique Complex Bounds Tseitin Resolution Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 13:17 UTC.
Pre-registration hash committed before this test ran: `23150296b230e0a7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
