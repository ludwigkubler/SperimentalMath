# Replay package — entry 9d4ad01564fe

Conjecture: Hypergraph Maximum Matching Inverse Proportional to ACC^0 Circuit Size for 3-CNFs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 03:58 UTC.
Pre-registration hash committed before this test ran: `73c19ad257ba90ab`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
