# Replay package — entry 86b6f85b5850

Conjecture: Minimal Local Coherence of Matroids Bounds Cumulative Proof Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 05:58 UTC.
Pre-registration hash committed before this test ran: `a6efb960d8213bbb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
