# Replay package — entry 65be0d50470d

Conjecture: Kronecker Coefficient Exponential Gap in Symmetric Power Decomposition for Permanent vs Determinant

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 08:49 UTC.
Pre-registration hash committed before this test ran: `06ead1a991875daa`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
