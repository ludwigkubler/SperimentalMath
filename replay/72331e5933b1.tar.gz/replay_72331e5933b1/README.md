# Replay package — entry 72331e5933b1

Conjecture: [c003b_cumulative_entropy/SC6#c29] Φ(π)/proof_size (number of DP steps) is monotone increasing in n, i.e. per-step active weight grows (the 'shadow heavier than the body' claim).

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-14 18:38 UTC.
Pre-registration hash committed before this test ran: `bcde756afe605d50`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
