# Replay package — entry 608a5dc77613

Conjecture: Minimal Order of Kähler Manifolds and SAT Clause Subset Complexity Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 14:36 UTC.
Pre-registration hash committed before this test ran: `377101d6a2600fb1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
