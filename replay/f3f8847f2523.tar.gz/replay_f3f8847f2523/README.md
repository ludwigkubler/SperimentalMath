# Replay package — entry f3f8847f2523

Conjecture: Minimal Rank of Tropical Modules and Circuit Monotone Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 09:35 UTC.
Pre-registration hash committed before this test ran: `2d90e1b9524c9937`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
