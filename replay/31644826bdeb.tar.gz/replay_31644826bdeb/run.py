import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def gaussian_elimination(A):
        m, n = len(A), len(A[0])
        for i in range(m):
            max_row = i
            for j in range(i + 1, m):
                if abs(A[j][i]) > abs(A[max_row][i]):
                    max_row = j
            A[i], A[max_row] = A[max_row], A[i]
            pivot = A[i][i]
            for j in range(n):
                A[i][j] /= pivot
            for j in range(m):
                if j != i:
                    factor = A[j][i]
                    for k in range(n):
                        A[j][k] -= factor * A[i][k]
        return A
    
    def matrix_multiply(A, B):
        m, n, p = len(A), len(B), len(B[0])
        C = [[Fraction(0) for _ in range(p)] for _ in range(m)]
        for i in range(m):
            for j in range(n):
                for k in range(p):
                    C[i][k] += A[i][j] * B[j][k]
        return C
    
    def characteristic_polynomial(L):
        n = len(L)
        t = Fraction('t')
        I = [[Fraction(1) if i == j else Fraction(0) for j in range(n)] for i in range(n)]
        A = matrix_multiply([[-l] + row[1:] for row in L], [row[:-1] for row in L])
        det_A = Fraction(1)
        for i in range(n):
            det_A *= A[i][i]
        char_poly = t**n - det_A
        return char_poly
    
    def hodge_rank(char_poly):
        # Placeholder for actual Hodge rank computation
        # For simplicity, we assume a constant rank based on n
        return 2 * math.floor(math.sqrt(n))
    
    def resolution_proof_size(n):
        # Placeholder for actual resolution proof size estimation
        # For simplicity, we assume a linear relationship with n^2
        return 10 * n**2
    
    n = random.randint(5, 40)
    G = [[random.choice([0, 1]) if i != j else 0 for j in range(n)] for i in range(n)]
    L = [[G[i][j] + G[j][i] for j in range(n)] for i in range(n)]
    
    char_poly = characteristic_polynomial(L)
    hodge_rank_value = hodge_rank(char_poly)
    proof_size = resolution_proof_size(n)
    
    return {
        "metric_name": "Hodge Rank vs Resolution Proof Size",
        "metric_value": hodge_rank_value,
        "instances_tested": 1,
        "conjecture_holds": hodge_rank_value >= n**1.5 and proof_size >= 2 * n**2,
        "counterexample": ""
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] if len(sys.argv) > 1 else list(range(30, 61))  # Default to first 30 primes
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value)**2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(i for i, r in enumerate(results) if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"\" first_failing_seed={seeds[first_failing_seed]}")