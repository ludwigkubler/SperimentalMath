# Replay package — entry 4ee94497fe16

Conjecture: Covering Radius Bound on Set System Discrepancy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 17:02 UTC.
Pre-registration hash committed before this test ran: `2d40442903abdb28`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
