# Replay package — entry 05aa8de48c39

Conjecture: Minimal Rank of Tropicalized Cohomology of Affine Schemes vs DPLL Search Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 18:37 UTC.
Pre-registration hash committed before this test ran: `f9182a357df2761f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
