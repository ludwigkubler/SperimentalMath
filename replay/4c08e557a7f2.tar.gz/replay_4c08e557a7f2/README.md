# Replay package — entry 4c08e557a7f2

Conjecture: Minimal Rank of Tropicalized Hodge Structures over Random SAT Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 21:21 UTC.
Pre-registration hash committed before this test ran: `7391a66f20cd7bad`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
