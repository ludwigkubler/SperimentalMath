# Replay package — entry 38f5fc8573e0

Conjecture: Minimal Order of Hodge Structures and SAT Clause Subset Complexity Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 02:51 UTC.
Pre-registration hash committed before this test ran: `550c948def00c2c8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
