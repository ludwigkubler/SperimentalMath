# Replay package — entry 0b9729e463a0

Conjecture: Minimal Rank of Geometric Langlands Correspondence over Circuit Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 19:49 UTC.
Pre-registration hash committed before this test ran: `1f41a29dba3b280f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
