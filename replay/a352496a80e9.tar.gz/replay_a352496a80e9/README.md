# Replay package — entry a352496a80e9

Conjecture: Minimal Hodge Decomposition Complexity of Tropical Schemes vs. DPLL Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 00:45 UTC.
Pre-registration hash committed before this test ran: `78a391d128432402`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
