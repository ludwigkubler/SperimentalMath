# Replay package — entry 8b1e34132025

Conjecture: [c003b_cumulative_entropy/SC5#c40] On expander-based Tseitin, Φ(π) is exp(Ω(n)) while on path/tree graphs Φ(π)=poly(n) — separating the entropy by graph expansion.

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 18:04 UTC.
Pre-registration hash committed before this test ran: `a3b45165226e41a8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
