# Replay package — entry 2a200936cac6

Conjecture: Minimal Order of Artinian Rings and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 20:24 UTC.
Pre-registration hash committed before this test ran: `68cf3b5872c43151`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
