# Replay package — entry cf2899710a87

Conjecture: Minimal Delaunay Complex Rank and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 13:17 UTC.
Pre-registration hash committed before this test ran: `d5e04068bd1ed9c5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
