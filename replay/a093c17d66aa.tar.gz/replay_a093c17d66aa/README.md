# Replay package — entry a093c17d66aa

Conjecture: Minimal Rank of Geometric Invariants vs Communication Complexity of DISJOINTNESS

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 15:24 UTC.
Pre-registration hash committed before this test ran: `ed6ab1092ad8730e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
