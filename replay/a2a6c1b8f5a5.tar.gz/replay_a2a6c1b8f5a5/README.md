# Replay package — entry a2a6c1b8f5a5

Conjecture: Minimal Rank of p-adic Power Series and BP_ReadTwice Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 14:12 UTC.
Pre-registration hash committed before this test ran: `cb09d880576e8a65`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
