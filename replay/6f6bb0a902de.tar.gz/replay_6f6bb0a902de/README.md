# Replay package — entry 6f6bb0a902de

Conjecture: Categorical Quantum Information Bounds BP Read-Twice Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 01:20 UTC.
Pre-registration hash committed before this test ran: `732c9f096b81057c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
