import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_formula(n):
        if n == 1:
            return "A"
        else:
            p = random.choice(["AND", "OR"])
            q = random.choice(generate_formula(n-1), generate_formula(n-1))
            return f"({p} {q})"
    
    def dpll_tree_diameter(formula):
        if formula == "A":
            return 1
        elif formula.startswith("(") and formula.endswith(")"):
            p, q = formula[2:-1].split()
            return max(dpll_tree_diameter(p), dpll_tree_diameter(q)) + 1
        else:
            raise ValueError("Invalid formula format")
    
    def compute_genus(formula):
        # Placeholder for the actual genus computation using topologylib
        # For now, we'll use a dummy function that returns a random value
        return random.random()
    
    n = random.choice([5, 10, 15, 20, 30, 40])
    formula = generate_formula(n)
    diameter = dpll_tree_diameter(formula)
    genus = compute_genus(formula)
    
    if genus is None:
        return {
            "metric_name": "genus",
            "metric_value": None,
            "instances_tested": 1,
            "n_max": n,
            "conjecture_holds": False,
            "counterexample": "mapping_undefined"
        }
    
    return {
        "metric_name": "genus",
        "metric_value": genus,
        "instances_tested": 1,
        "n_max": n,
        "conjecture_holds": True,
        "counterexample": ""
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    
    results = []
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    mean_value = sum(r["metric_value"] for r in results if r["metric_value"] is not None) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value) ** 2 for r in results if r["metric_value"] is not None) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(s for s, r in zip(seeds, results) if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"mapping_undefined\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE reason=unreachable")