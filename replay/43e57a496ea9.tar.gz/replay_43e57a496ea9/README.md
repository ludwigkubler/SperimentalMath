# Replay package — entry 43e57a496ea9

Conjecture: Minimal Order of Quasi-Continuous Functions and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-12 18:36 UTC.
Pre-registration hash committed before this test ran: `ec15f9093385c882`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
