# Replay package — entry 29dff0c510e9

Conjecture: Möbius Coinvariant of Minterm Intersection Lattice Bounds k-CLIQUE Monotone DNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 08:12 UTC.
Pre-registration hash committed before this test ran: `c74132490be02558`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
