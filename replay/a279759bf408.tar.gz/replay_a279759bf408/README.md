# Replay package — entry a279759bf408

Conjecture: Minimal Rank of Noncrossing Partitions over Communication Complexity of XOR-AND Trees

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 10:59 UTC.
Pre-registration hash committed before this test ran: `c2b535ab99efb747`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
