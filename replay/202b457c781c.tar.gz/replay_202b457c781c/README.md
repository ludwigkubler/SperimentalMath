# Replay package — entry 202b457c781c

Conjecture: Matroid Rank Gap in Monotone DNF for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 04:29 UTC.
Pre-registration hash committed before this test ran: `9de6352250f75a9f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
