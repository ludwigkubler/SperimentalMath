# Replay package — entry 192745953ad7

Conjecture: Minimal Rank of Geometric Quantization and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 14:05 UTC.
Pre-registration hash committed before this test ran: `95687b619d1749a1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
