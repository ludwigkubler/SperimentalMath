# Replay package — entry e07ae4e22c49

Conjecture: Minimal Ehrhart Semialgebra Rank and Communication Complexity Rank Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 07:30 UTC.
Pre-registration hash committed before this test ran: `09cdbbfffa9675bb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
