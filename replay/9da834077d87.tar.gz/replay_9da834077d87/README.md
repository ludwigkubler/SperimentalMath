# Replay package — entry 9da834077d87

Conjecture: Minimal Order of Formal Contexts and DPLL Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 16:10 UTC.
Pre-registration hash committed before this test ran: `1088a382090b1592`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
