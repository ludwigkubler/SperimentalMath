# Replay package — entry b1e77f376f5e

Conjecture: Sandpile Group Exponent Lower-Bounds Tseitin Tree-Resolution Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 02:48 UTC.
Pre-registration hash committed before this test ran: `a812aa7a21cc3203`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
