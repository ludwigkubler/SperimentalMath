import random
import math

def generate_cnf(n):
    cnf = []
    for _ in range(10 * n):  # Generate 10 clauses per variable on average
        clause = set()
        while len(clause) < n:
            lit = random.randint(-n, -1)
            if lit not in clause and -lit not in clause:
                clause.add(lit)
        cnf.append(list(clause))
    return cnf

def dpll_solve(cnf):
    def solve(lits_true, lits_false):
        if not cnf:
            return True
        unit_clause = next((c for c in cnf if len(c) == 1), None)
        if unit_clause:
            lit = unit_clause[0]
            if lit in lits_true or -lit in lits_false:
                return solve(lits_true | {lit}, lits_false)
            else:
                return False
        pure_literal = next((c for c in cnf if len(c) == 1), None)
        if not pure_literal:
            pure_literal = random.choice([l for l in range(1, n + 1)] + [-l for l in range(1, n + 1)])
        if pure_literal > 0:
            return solve(lits_true | {pure_literal}, lits_false)
        else:
            return solve(lits_true, lits_false | {-pure_literal})
    return solve(set(), set())

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n = random.choice([5, 10, 15, 20, 30, 40])
    cnf = generate_cnf(n)
    resolution_width = dpll_solve(cnf)
    
    # Construct polytope and compute maximum number of active Coxeter reflections
    # This is a placeholder for the actual computation which is not provided in the problem statement
    max_reflections = n  # Placeholder value, replace with actual computation
    
    if resolution_width is None:
        return {
            "metric_name": "resolution_width",
            "metric_value": None,
            "instances_tested": 1,
            "n_max": n,
            "conjecture_holds": False,
            "counterexample": "mapping_undefined"
        }
    
    correlation = resolution_width / max_reflections
    return {
        "metric_name": "resolution_width",
        "metric_value": correlation,
        "instances_tested": 1,
        "n_max": n,
        "conjecture_holds": abs(correlation) >= 0.5,
        "counterexample": ""
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    results = []
    
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    mean_value = sum(r["metric_value"] for r in results if r["metric_value"] is not None) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value) ** 2 for r in results if r["metric_value"] is not None) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"mapping_undefined\" first_failing_seed={first_failing_seed}")
    else:
        print(f"RESULT: INCONCLUSIVE reason=unsupported_conjecture")