# Replay package — entry 5f0331a7ea22

Conjecture: Minimal Coxeter Group Length of Boolean Functions vs KW Protocol Cost

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 20:49 UTC.
Pre-registration hash committed before this test ran: `b21ec6c885a32bb0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
