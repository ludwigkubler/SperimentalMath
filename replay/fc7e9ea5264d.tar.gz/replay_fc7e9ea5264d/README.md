# Replay package — entry fc7e9ea5264d

Conjecture: Coxeter Group Order and Frege Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 09:00 UTC.
Pre-registration hash committed before this test ran: `7b65b689d59bfdee`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
