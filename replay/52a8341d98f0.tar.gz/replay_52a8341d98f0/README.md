# Replay package — entry 52a8341d98f0

Conjecture: Minimal Rank of Tropicalized Brauer Groups vs SOS Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 10:18 UTC.
Pre-registration hash committed before this test ran: `f8a88f44fc60cf60`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
