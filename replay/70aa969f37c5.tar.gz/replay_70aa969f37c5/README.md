# Replay package — entry 70aa969f37c5

Conjecture: Noncommutative Tensor Product Rank vs BP_ReadTwice Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 04:54 UTC.
Pre-registration hash committed before this test ran: `32932b9894c452c5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
