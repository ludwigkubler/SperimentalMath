# Replay package — entry bb84b0308945

Conjecture: Minimal Symplectic rank of moment maps vs ACC⁰ Circuit Depth for Bounded Disjunctive Normal Forms

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 12:42 UTC.
Pre-registration hash committed before this test ran: `97c1086cdb197114`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
