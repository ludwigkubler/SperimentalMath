# Replay package — entry 04a45b9fed58

Conjecture: Minimal Rank of Coxeter Group Orbits over Tseitin Circuit Valuations

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 18:16 UTC.
Pre-registration hash committed before this test ran: `cb7516718355f65f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
