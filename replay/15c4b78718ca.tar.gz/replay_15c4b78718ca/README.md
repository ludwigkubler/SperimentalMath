# Replay package — entry 15c4b78718ca

Conjecture: Fourier Min-Coefficient Inverse Proportionality to CNF Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 08:50 UTC.
Pre-registration hash committed before this test ran: `48fb4ed434f7cadb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
