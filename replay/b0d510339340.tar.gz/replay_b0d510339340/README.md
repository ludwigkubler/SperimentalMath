# Replay package — entry b0d510339340

Conjecture: Matroid Rank Deficit in Monotone DNF for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 11:53 UTC.
Pre-registration hash committed before this test ran: `6c0817233f1bddca`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
