# Replay package — entry 743e042ea636

Conjecture: Plethysm Coefficient Growth and Permanent Circuit Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 13:20 UTC.
Pre-registration hash committed before this test ran: `26a271afb5384e04`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
