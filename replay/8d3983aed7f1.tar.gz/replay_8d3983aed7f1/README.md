# Replay package — entry 8d3983aed7f1

Conjecture: Minimal Order of Abelian Varieties Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 07:24 UTC.
Pre-registration hash committed before this test ran: `fe85d3a433a717e4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
