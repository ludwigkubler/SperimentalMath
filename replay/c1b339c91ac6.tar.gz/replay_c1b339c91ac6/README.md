# Replay package — entry c1b339c91ac6

Conjecture: Minimal Diophantine Exponent and SAT Clause Depth Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 02:12 UTC.
Pre-registration hash committed before this test ran: `138639e042b2b2d4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
