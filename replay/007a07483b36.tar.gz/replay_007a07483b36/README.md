# Replay package — entry 007a07483b36

Conjecture: Minimal Galois Group Complexity of Boolean Functions and Circuit Entanglement

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 17:11 UTC.
Pre-registration hash committed before this test ran: `cc291c4495c3f2b6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
