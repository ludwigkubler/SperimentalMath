# Replay package — entry 713f57619482

Conjecture: Noncommutative Fourier Gap in Read-Twice BPs for IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 07:23 UTC.
Pre-registration hash committed before this test ran: `a56c41cf0323d9d9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
