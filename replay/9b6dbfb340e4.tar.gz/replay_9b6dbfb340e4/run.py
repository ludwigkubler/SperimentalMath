import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_cnf(n, m):
        variables = set(range(1, n + 1))
        clauses = []
        for _ in range(m):
            clause = random.sample(variables, random.randint(1, n))
            if random.choice([True, False]):
                clause = [-v for v in clause]
            clauses.append(clause)
        return clauses
    
    def compute_automorphism_group(cnf):
        # Simplified version of computing automorphism group
        # This is a placeholder and should be replaced with actual computation
        return set(range(1, len(cnf) + 1))
    
    def compute_coxeter_group_rank(group):
        # Placeholder for computing the rank of the Coxeter group
        # This is a simplified example and should be replaced with actual computation
        return len(group)
    
    n = random.randint(5, 40)
    m = random.randint(n, n * 10)  # Ensure at least as many clauses as variables
    cnf = generate_cnf(n, m)
    group = compute_automorphism_group(cnf)
    rank = compute_coxeter_group_rank(group)
    
    expected_min_rank = n * math.log(m)
    conjecture_holds = rank >= expected_min_rank
    
    return {
        "metric_name": "Coxeter Group Rank",
        "metric_value": rank,
        "instances_tested": 1,
        "conjecture_holds": conjecture_holds,
        "counterexample": "" if conjecture_holds else f"CNF: {cnf}, Expected Min Rank: {expected_min_rank}, Actual Rank: {rank}"
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    results = []
    
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    if all(r["conjecture_holds"] for r in results):
        mean_d = sum(r["metric_value"] for r in results) / len(results)
        support_fraction = 1.0
        result = f"RESULT: SUPPORTED mean={mean_d} std=0 support_fraction={support_fraction}"
    else:
        first_failing_seed = next((r["seed"] for r in results if not r["conjecture_holds"]), None)
        counterexample = next((r["counterexample"] for r in results if not r["conjecture_holds"]), "")
        result = f"RESULT: FALSIFIED counterexample=\"{counterexample}\" first_failing_seed={first_failing_seed}"
    
    print(result)