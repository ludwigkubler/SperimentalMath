# Replay package — entry 2dc21e788874

Conjecture: Minimal Tropical Rank Correlation with SAT Clause Set Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 20:49 UTC.
Pre-registration hash committed before this test ran: `bca06ee9011eae2e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
