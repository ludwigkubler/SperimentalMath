# Replay package — entry 75d870407726

Conjecture: Minimal Rank of Quaternion Algebras and AC0 Parity Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 01:28 UTC.
Pre-registration hash committed before this test ran: `f44f5eeefca9b356`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
