# Replay package — entry 718420de2bd9

Conjecture: Galois Group Action Complexity for k-CNF Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 23:55 UTC.
Pre-registration hash committed before this test ran: `3dced8ca5abc30cd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
