# Replay package — entry 9fe8a8a65e74

Conjecture: Minimal Rank of Hodge Decomposition Modules vs DPLL Search Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 17:54 UTC.
Pre-registration hash committed before this test ran: `d5a57c0207879c73`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
