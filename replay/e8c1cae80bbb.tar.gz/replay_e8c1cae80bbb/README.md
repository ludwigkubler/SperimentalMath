# Replay package — entry e8c1cae80bbb

Conjecture: Plethysm Coefficient Ratio in SOS Refutations for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 13:22 UTC.
Pre-registration hash committed before this test ran: `bf442bfce9951161`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
