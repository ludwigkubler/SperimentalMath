# Replay package — entry 49649e15da49

Conjecture: Minimal Order of Automorphic Representations and Frege Proof Depth Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 14:32 UTC.
Pre-registration hash committed before this test ran: `a52571412c66da85`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
