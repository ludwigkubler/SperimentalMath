# Replay package — entry b7e143a5d286

Conjecture: Minimal Rank of Formal Language Entailment and Circuit Entanglement Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 19:08 UTC.
Pre-registration hash committed before this test ran: `49979aebcf7aaafc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
