import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def sign(x):
        return 1 if x >= 0 else -1
    
    def binomial(n, k):
        if k > n:
            return 0
        result = 1
        for i in range(k):
            result *= (n - i)
            result //= (i + 1)
        return result
    
    def kronecker_coefficient(λ, μ, ν):
        if len(λ) != len(μ) or len(μ) != len(ν):
            return 0
        n = len(λ)
        coeff = Fraction(1)
        for i in range(n):
            coeff *= binomial(λ[i] + μ[i], λ[i]) * binomial(μ[i] + ν[i], μ[i])
            coeff //= (binomial(λ[i] + ν[i], λ[i]) * binomial(ν[i] + λ[i], ν[i]))
        return abs(coeff)
    
    def perm(n):
        if n == 0:
            return [[]]
        result = []
        for i in range(n):
            for p in perm(n - 1):
                if not any(p[j] == i for j in range(len(p))):
                    result.append([i] + p)
        return result
    
    def sym_power(poly, k):
        result = [poly[0]]
        for _ in range(1, k):
            new_poly = [0] * (len(result) + len(poly) - 1)
            for i in range(len(result)):
                for j in range(len(poly)):
                    new_poly[i + j] += result[i] * poly[j]
            result = new_poly
        return result
    
    def tensor_product(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                result[i * len(poly2) + j] = poly1[i] * poly2[j]
        return result
    
    def kronecker_product(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                result[i * len(poly2) + j] = poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
        return result
    
    def kronecker_product_antisymmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i < j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric_antisymmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_antisymmetric_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i < j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
        return result
    
    def kronecker_product_antisymmetric_antisymmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i < j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric_antisymmetric_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_antisymmetric_symmetric_antisymmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i < j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric_antisymmetric_symmetric_antisymmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_antisymmetric_symmetric_antisymmetric_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i < j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric_antisymmetric_symmetric_antisymmetric_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i < j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i < j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i < j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i < j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i < j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i < j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i < j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i < j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i < j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i < j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i < j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i < j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i < j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_antisymmetric_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_antisymmetric_antisymmetric_symmetric_antisymmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i < j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_antisymmetric_symmetric_antisymmetric_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_antisymmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i < j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_antisymmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i < j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_antisymmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i < j:
                    result[i * len(poly2) + j] = poly1[i] * poly2[j]
                else:
                    result[i * len(poly2) + j] = -poly1[i] * poly2[j]
        return result
    
    def kronecker_product_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric_antisymmetric_symmetric(poly1, poly2):
        result = [0] * (len(poly1) * len(poly2))
        for i in range(len(poly1)):
            for j in range(len(poly2)):
                if i <= j: