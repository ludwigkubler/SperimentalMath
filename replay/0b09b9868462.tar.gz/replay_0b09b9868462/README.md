# Replay package — entry 0b09b9868462

Conjecture: Minimal Rank of Symplectic Leaves over Resolution Proof Trees

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 23:05 UTC.
Pre-registration hash committed before this test ran: `18b7d03b435e0aa1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
