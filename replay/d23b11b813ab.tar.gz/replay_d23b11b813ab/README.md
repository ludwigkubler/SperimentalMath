# Replay package — entry d23b11b813ab

Conjecture: Real Radical Dimension Inverse Proportional to SOS Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-13 00:19 UTC.
Pre-registration hash committed before this test ran: `2a7030ed22afd509`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
