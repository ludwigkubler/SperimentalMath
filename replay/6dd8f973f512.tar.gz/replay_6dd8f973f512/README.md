# Replay package — entry 6dd8f973f512

Conjecture: Minimal Rank of Tropicalized Ehrhart Matrices Bounds BP Read-Twice Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 07:18 UTC.
Pre-registration hash committed before this test ran: `a3e5b1b599f249b2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
