# Replay package — entry cdb8c9c7b239

Conjecture: Minimal Galois Group Order and Communication Complexity Rank Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 04:58 UTC.
Pre-registration hash committed before this test ran: `3a0c0c1535007f47`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
