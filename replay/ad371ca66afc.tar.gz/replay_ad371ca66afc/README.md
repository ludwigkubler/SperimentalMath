# Replay package — entry ad371ca66afc

Conjecture: Minimal Number of Integer Points in Cubic Surface Associated with CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 15:20 UTC.
Pre-registration hash committed before this test ran: `93217562827b3e84`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
