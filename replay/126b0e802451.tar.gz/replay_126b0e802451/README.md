# Replay package — entry 126b0e802451

Conjecture: Tropicalization of Representation Theory in Resolution Proofs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 17:33 UTC.
Pre-registration hash committed before this test ran: `e57f03f097d0a474`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
