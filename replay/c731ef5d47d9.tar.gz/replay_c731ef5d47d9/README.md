# Replay package — entry c731ef5d47d9

Conjecture: Minimal Rank of Tropicalized Knot Invariants under Torus Linking Numbers

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 07:45 UTC.
Pre-registration hash committed before this test ran: `73d8856b0195ebf6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
