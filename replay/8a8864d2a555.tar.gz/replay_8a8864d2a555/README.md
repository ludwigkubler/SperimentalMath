# Replay package — entry 8a8864d2a555

Conjecture: Minimal Rank of Eta-Quotient Modules over Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 12:04 UTC.
Pre-registration hash committed before this test ran: `969563b821655ae7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
