# Replay package — entry 55804d8e7a27

Conjecture: Minimal Automorphism Group Action Count and Frege Proof Tree Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 03:52 UTC.
Pre-registration hash committed before this test ran: `44886d7fc4552d55`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
