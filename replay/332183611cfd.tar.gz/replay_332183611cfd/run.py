import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def communication_complexity(n):
        # Placeholder for actual communication complexity calculation
        return n  # Simplified example
    
    def geometric_entropy(g):
        # Placeholder for actual geometric entropy calculation
        return g * math.log2(g + 1)
    
    n = random.randint(5, 40)
    f_complexity = communication_complexity(n)
    target_g = f_complexity ** 2
    
    for g in range(target_g + 2):
        hgeom_X = geometric_entropy(g)
        if hgeom_X >= f_complexity:
            return {
                "metric_name": "geometric_entropy",
                "metric_value": hgeom_X,
                "instances_tested": 1,
                "conjecture_holds": True,
                "counterexample": ""
            }
    
    return {
        "metric_name": "geometric_entropy",
        "metric_value": None,
        "instances_tested": 1,
        "conjecture_holds": False,
        "counterexample": f"No genus g found for n={n}, communication(f)={f_complexity}"
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {{\"seed\": {seed}, \"metric_name\": \"{result['metric_name']}\", \"metric_value\": {result['metric_value']}, \"instances_tested\": {result['instances_tested']}, \"conjecture_holds\": {result['conjecture_holds']}, \"counterexample\": \"{result['counterexample']}\"}}}")
        results.append(result)
    
    mean_metric = sum(result['metric_value'] for result in results if result['metric_value'] is not None) / len(results)
    std_metric = math.sqrt(sum((result['metric_value'] - mean_metric) ** 2 for result in results if result['metric_value'] is not None) / len(results))
    support_fraction = sum(1 for result in results if result['conjecture_holds']) / len(results)
    
    if all(result['conjecture_holds'] for result in results):
        print(f"RESULT: SUPPORTED mean={mean_metric} std={std_metric} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_metric} std={std_metric} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result['conjecture_holds'])
        print(f"RESULT: FALSIFIED counterexample=\"No genus g found\" first_failing_seed={first_failing_seed}")