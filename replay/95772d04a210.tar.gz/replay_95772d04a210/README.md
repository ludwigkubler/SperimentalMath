# Replay package — entry 95772d04a210

Conjecture: Real Rank of SOS Moment Matrix and Max-CUT Approximation Ratio

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 15:51 UTC.
Pre-registration hash committed before this test ran: `008b11aadc64ed46`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
