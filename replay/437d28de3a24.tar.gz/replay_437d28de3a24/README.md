# Replay package — entry 437d28de3a24

Conjecture: Minimal Rank of Quadratic Forms in Tropicalized Lattices vs Sum-of-Squares Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 08:53 UTC.
Pre-registration hash committed before this test ran: `e1673b70901b55bc`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
