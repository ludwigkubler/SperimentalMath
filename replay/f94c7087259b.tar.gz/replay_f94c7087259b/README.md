# Replay package — entry f94c7087259b

Conjecture: Minimal Rank of Kostant Sheaves vs Polynomial Hierarchy Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 14:00 UTC.
Pre-registration hash committed before this test ran: `de3425cd10050a72`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
