# Replay package — entry bd496e2b7d12

Conjecture: Minimal Rank of Kac-Moody Lie Algebras vs DPLL Search Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 00:33 UTC.
Pre-registration hash committed before this test ran: `aac7a0b012dfa63b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
