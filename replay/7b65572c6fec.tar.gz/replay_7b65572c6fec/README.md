# Replay package — entry 7b65572c6fec

Conjecture: Minimal Rank of Tropicalized Kerdock Codes over DPLL Search Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 12:30 UTC.
Pre-registration hash committed before this test ran: `8d0bee5e16a595bd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
