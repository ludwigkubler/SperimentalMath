# Replay package — entry f36846330fde

Conjecture: Free Cumulant Sum Gap in Read-Twice BPs for IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 17:37 UTC.
Pre-registration hash committed before this test ran: `a7ba9da99ef64c5f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
