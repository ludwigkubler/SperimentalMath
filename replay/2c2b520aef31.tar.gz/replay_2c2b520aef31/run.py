import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_d_regular_circuit(n, d):
        if (d * n) % 2 != 0:
            return None
        circuit = [[random.choice([0, 1]) for _ in range(d)] for _ in range(n)]
        return circuit
    
    def compute_monotone_width(circuit):
        # Simplified monotone width calculation (for demonstration)
        return len(circuit) * len(circuit[0])
    
    def is_automorphism(gate1, gate2, circuit):
        if len(gate1) != len(gate2):
            return False
        for i in range(len(gate1)):
            if gate1[i] != gate2[(i + 1) % len(gate1)]:
                return False
        return True
    
    def compute_automorphism_group(circuit):
        n = len(circuit)
        d = len(circuit[0])
        automorphisms = []
        for perm in itertools.permutations(range(n)):
            if all(is_automorphism(circuit[i], circuit[perm[i]], circuit) for i in range(n)):
                automorphisms.append(perm)
        return automorphisms
    
    def compute_min_generators(automorphisms):
        generators = set()
        for a in automorphisms:
            if len(a) == 1:
                generators.add(a[0])
        return len(generators)
    
    n_values = [5, 10, 15, 20, 30, 40]
    results = []
    for n in n_values:
        circuit = generate_d_regular_circuit(n, 2)
        if circuit is None:
            continue
        w_m = compute_monotone_width(circuit)
        G = compute_automorphism_group(circuit)
        if not G:
            continue
        |G| = compute_min_generators(G)
        results.append({
            "n": n,
            "|G|": |G|,
            "√w_m(C)": math.sqrt(w_m),
        })
    
    metric_name = "min_automorphism_generators"
    metric_value = sum(result["|G|"] for result in results) / len(results)
    instances_tested = len(results)
    n_max = max(result["n"] for result in results)
    conjecture_holds = all(math.sqrt(result["w_m(C)"]) >= result["|G|"] for result in results)
    counterexample = "" if conjecture_holds else "mapping_undefined"
    
    return {
        "metric_name": metric_name,
        "metric_value": metric_value,
        "instances_tested": instances_tested,
        "n_max": n_max,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample,
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113]
    results = []
    for seed in seeds:
        trial_result = run_trial(seed)
        print(f"TRIAL: {trial_result}")
        results.append(trial_result)
    
    mean_metric_value = sum(result["metric_value"] for result in results) / len(results)
    std_metric_value = math.sqrt(sum((result["metric_value"] - mean_metric_value) ** 2 for result in results) / len(results))
    support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)
    
    if all(result["conjecture_holds"] for result in results):
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_metric_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_metric_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"mapping_undefined\" first_failing_seed={first_failing_seed}")