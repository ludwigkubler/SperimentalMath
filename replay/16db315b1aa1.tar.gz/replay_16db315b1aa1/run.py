import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_cnf(n):
        clauses = []
        for _ in range(2**n):
            clause = [random.randint(-n, -1) for _ in range(random.randint(1, n))]
            if random.choice([True, False]):
                clause = [-x for x in clause]
            clauses.append(clause)
        return clauses
    
    def circuit_depth(cnf):
        stack = []
        for literal in cnf:
            if literal > 0:
                stack.append(literal)
            else:
                if not stack or -literal != stack.pop():
                    return float('inf')
        return len(stack)
    
    def mtr(graph):
        n = len(graph)
        dp = [[float('inf')] * (1 << n) for _ in range(n)]
        for i in range(n):
            dp[i][1 << i] = 1
        for mask in range(1, 1 << n):
            for i in range(n):
                if mask & (1 << i):
                    for j in range(i):
                        if graph[i][j] and mask & (1 << j):
                            dp[i][mask] = min(dp[i][mask], dp[j][mask ^ (1 << i)] + 1)
        return min(max(row) for row in dp)
    
    n = random.randint(5, 40)
    cnf = generate_cnf(n)
    graph = [[False] * n for _ in range(n)]
    for clause in cnf:
        for literal in clause:
            if literal > 0:
                i = abs(literal) - 1
                for other_literal in clause:
                    j = abs(other_literal) - 1
                    graph[i][j] = True
    
    mtr_value = mtr(graph)
    depth = circuit_depth(cnf)
    
    if mtr_value <= depth <= 2**(mtr_value + 1/n**2):
        conjecture_holds = True
        counterexample = ""
    else:
        conjecture_holds = False
        counterexample = "Circuit depth does not satisfy the inequality"
    
    return {
        "metric_name": "circuit_depth",
        "metric_value": depth,
        "instances_tested": 1,
        "n_max": n,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or [2**i + 3 for i in range(5, 8)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value)**2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{results[first_failing_seed]['counterexample']}\" first_failing_seed={first_failing_seed}")