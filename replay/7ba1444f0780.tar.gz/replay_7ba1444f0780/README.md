# Replay package — entry 7ba1444f0780

Conjecture: Minimal Rank of p-adic Logarithmic Potential and Tseitin Resolution Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 19:20 UTC.
Pre-registration hash committed before this test ran: `28f515704ce99ddb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
