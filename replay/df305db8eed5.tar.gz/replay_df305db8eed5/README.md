# Replay package — entry df305db8eed5

Conjecture: Minimal Rank of Quotient Hecke Algebras vs Permutation Circuit Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 10:21 UTC.
Pre-registration hash committed before this test ran: `95352c6424c20441`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
