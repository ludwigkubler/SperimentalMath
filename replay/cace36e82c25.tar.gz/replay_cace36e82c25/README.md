# Replay package — entry cace36e82c25

Conjecture: Minimal Rank of Lie Algebroids and Resolution Proof Depth Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 16:52 UTC.
Pre-registration hash committed before this test ran: `f1f0afebf80e6418`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
