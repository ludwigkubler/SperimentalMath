import random
import math
from fractions import Fraction

def gaussian_elimination(A, b):
    n = len(b)
    for i in range(n):
        max_row = i
        for j in range(i+1, n):
            if abs(A[j][i]) > abs(A[max_row][i]):
                max_row = j
        A[i], A[max_row] = A[max_row], A[i]
        b[i], b[max_row] = b[max_row], b[i]
        for j in range(i+1, n):
            factor = A[j][i] / A[i][i]
            for k in range(i, n):
                A[j][k] -= factor * A[i][k]
            b[j] -= factor * b[i]
    x = [0] * n
    for i in range(n-1, -1, -1):
        x[i] = (b[i] - sum(A[i][j] * x[j] for j in range(i+1, n))) / A[i][i]
    return x

def matrix_multiply(A, B):
    m = len(A)
    k = len(B[0])
    result = [[0] * k for _ in range(m)]
    for i in range(m):
        for j in range(k):
            for l in range(len(B)):
                result[i][j] += A[i][l] * B[l][j]
    return result

def characteristic_polynomial(acc_circuit):
    n = len(acc_circuit)
    x = Fraction('x')
    poly = [Fraction(1)]
    for i in range(n):
        new_poly = []
        for term in poly:
            new_poly.append(term * x - acc_circuit[i])
        poly = new_poly
    return poly

def hypergeometric_moments(poly, n):
    moments = [0] * (n + 1)
    for i in range(n + 1):
        moment = Fraction(1)
        for j in range(i):
            moment *= poly[j]
        moments[i] = moment
    return sum(moments)

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n = random.randint(5, 40)
    acc_circuit = [random.choice([-1, 1]) for _ in range(n)]
    characteristic_poly = characteristic_polynomial(acc_circuit)
    moments_sum = hypergeometric_moments(characteristic_poly, n)
    
    metric_name = "moments_sum"
    metric_value = abs(moments_sum) * n * math.log(n)
    instances_tested = 1
    conjecture_holds = metric_value <= 0.01 * n * math.log(n)
    counterexample = "" if conjecture_holds else f"n={n}, moments_sum={moments_sum}"
    
    return {
        "metric_name": metric_name,
        "metric_value": metric_value,
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        seeds = [int(s) for s in sys.argv[1:]]
    else:
        primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]
        seeds = random.sample(primes, 30)
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value)**2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        counterexample = next(r["counterexample"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"{counterexample}\" first_failing_seed={first_failing_seed}")