# Replay package — entry c6142ec20dd6

Conjecture: Persistent H1 Lifespan Bounds Resolution Width on Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-08 18:11 UTC.
Pre-registration hash committed before this test ran: `cde4f07c2972f9c3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
