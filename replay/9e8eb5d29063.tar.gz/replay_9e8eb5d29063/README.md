# Replay package — entry 9e8eb5d29063

Conjecture: Minimal Rank of Tropicalized Quaternion Algebras vs Monotone k-CLIQUE Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 03:42 UTC.
Pre-registration hash committed before this test ran: `c073ce5ea0b6ad68`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
