# Replay package — entry eeb89688e704

Conjecture: Minimal Rank of Quadratic Forms Bounds Monomial Circuit Size for XOR 3-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 11:04 UTC.
Pre-registration hash committed before this test ran: `ad5d4f334104141f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
