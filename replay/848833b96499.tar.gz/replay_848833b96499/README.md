# Replay package — entry 848833b96499

Conjecture: Minimal Order of Lie Algebroid Structures and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 12:54 UTC.
Pre-registration hash committed before this test ran: `3832d10c0f975084`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
