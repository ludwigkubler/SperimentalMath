# Replay package — entry 920462144f4f

Conjecture: Multiplicity of Hook Representation in Symmetric Powers of Permanent vs Determinant

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 07:30 UTC.
Pre-registration hash committed before this test ran: `dad40a96238f8ebd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
