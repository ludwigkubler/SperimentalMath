# Replay package — entry 0ee4ad06b6d9

Conjecture: Minimal Coxeter Group Complexity of Boolean Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 14:11 UTC.
Pre-registration hash committed before this test ran: `d5f28735c4444af8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
