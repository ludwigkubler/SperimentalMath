# Replay package — entry 48cac1149304

Conjecture: Minimal Rank of Entropic Geometry over Read-Twice BP Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 18:42 UTC.
Pre-registration hash committed before this test ran: `813ac225efe067ab`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
