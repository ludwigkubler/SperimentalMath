# Replay package — entry adcdc810fef8

Conjecture: Hypercontractive Constants of Tensor Powers and Max-CUT Approximation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 18:13 UTC.
Pre-registration hash committed before this test ran: `471bc653d0b356b6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
