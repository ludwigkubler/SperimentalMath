# Replay package — entry 10799b45ba82

Conjecture: Minimal Rank of Free Probability Distributions Bounds BP Read-Twice Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 21:28 UTC.
Pre-registration hash committed before this test ran: `d039af26a3e236a1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
