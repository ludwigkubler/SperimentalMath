import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n = random.randint(5, 40)
    instances_tested = 30
    metric_values = []

    for _ in range(instances_tested):
        # Generate a random n-bit XOR circuit
        C = [random.choice([0, 1]) for _ in range(n)]
        
        # Define the semialgebraic set and compute its minimal rank of Ehrhart cohomology group
        # This is a placeholder function. Replace with actual computation if possible.
        def ehrhart_cohomology_rank(C):
            # Placeholder: return a random rank between 1 and log(n)
            return random.randint(1, math.ceil(math.log2(n)))
        
        rank = ehrhart_cohomology_rank(C)
        metric_values.append(rank)

    mean_value = sum(metric_values) / instances_tested
    conjecture_holds = all(rank <= math.log2(n) for rank in metric_values)
    counterexample = "" if conjecture_holds else "mapping_undefined"

    return {
        "metric_name": "Ehrhart Cohomology Rank",
        "metric_value": mean_value,
        "instances_tested": instances_tested,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] if sys.argv[1:] else [random.randint(2, 97) for _ in range(30)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)

    mean_value = sum(r["metric_value"] for r in results) / len(results)
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)

    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std=0.0 support_fraction=1.0")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std=0.0 support_fraction={support_fraction}")
    else:
        first_failing_seed = next(seed for seed, r in zip(seeds, results) if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"mapping_undefined\" first_failing_seed={first_failing_seed}")