# Replay package — entry 797c606cf901

Conjecture: Moment Matrix Spectral Gap and SOS Degree for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 03:38 UTC.
Pre-registration hash committed before this test ran: `b6d10fcef4543813`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
