# Replay package — entry 4a8acdec1728

Conjecture: Minimal Number of Cuspidal Sheaves and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 03:39 UTC.
Pre-registration hash committed before this test ran: `40182f35fb38ac15`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
