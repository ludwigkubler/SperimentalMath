# Replay package — entry ec9bb33b8b92

Conjecture: Minimal Order of Quadratic Reciprocity Lattices Bounds QBF Refutation Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 18:19 UTC.
Pre-registration hash committed before this test ran: `f544babf8659504a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
