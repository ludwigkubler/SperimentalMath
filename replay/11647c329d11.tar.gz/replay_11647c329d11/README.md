# Replay package — entry 11647c329d11

Conjecture: Lie Nilpotency Class of Layer Algebra Distinguishes Read-Twice BPs from IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 08:32 UTC.
Pre-registration hash committed before this test ran: `e9139e5ecc5323e8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
