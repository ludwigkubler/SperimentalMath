import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_ac0_circuit(n):
        # Generate a random AC0 parity circuit of size n
        return [random.choice([0, 1]) for _ in range(2**n)]
    
    def compute_tropical_curve(circuit):
        # Compute the tropical curve associated with the circuit
        # This is a placeholder function; replace with actual implementation
        return len(circuit)
    
    def rank(tropical_curve):
        # Compute the rank of the tropical curve
        return len(tropical_curve)
    
    n = random.randint(5, 40)  # Sweep through different sizes
    circuit = generate_ac0_circuit(n)
    tropical_curve = compute_tropical_curve(circuit)
    psi_C = rank(tropical_curve)
    
    f_n = math.log(n, 2)
    metric_value = abs(psi_C - f_n)
    
    return {
        "metric_name": "Rank vs AC0 Circuit Size",
        "metric_value": metric_value,
        "instances_tested": 1,
        "conjecture_holds": metric_value <= 3,
        "counterexample": "" if psi_C == f_n else f"Counterexample: n={n}, psi(C)={psi_C}, f(n)={f_n}"
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] or list(range(2, 30))  # Default to first 30 primes if no seeds provided
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_metric_value = sum(r["metric_value"] for r in results) / len(results)
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std=0.0 support_fraction=1.0")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std=0.0 support_fraction={support_fraction}")
    else:
        for r in results:
            if not r["conjecture_holds"]:
                print(f"RESULT: FALSIFIED counterexample=\"{r['counterexample']}\" first_failing_seed={seed}")
                break