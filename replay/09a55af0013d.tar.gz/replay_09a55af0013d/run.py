import random
import math
from fractions import Fraction

def gaussian_elimination(matrix):
    n = len(matrix)
    augmented_matrix = [row[:] + [0 if i != j else 1 for j in range(n)] for row in matrix]
    
    for i in range(n):
        max_row = max(range(i, n), key=lambda r: abs(augmented_matrix[r][i]))
        augmented_matrix[i], augmented_matrix[max_row] = augmented_matrix[max_row], augmented_matrix[i]
        
        if augmented_matrix[i][i] == 0:
            raise ValueError("Singular matrix")
        
        for j in range(n):
            augmented_matrix[i][j] /= augmented_matrix[i][i]
        
        for k in range(n):
            if k != i:
                factor = augmented_matrix[k][i]
                for j in range(2 * n):
                    augmented_matrix[k][j] -= factor * augmented_matrix[i][j]
    
    rank = sum(1 for row in augmented_matrix if any(row[j] != 0 for j in range(n)))
    return rank

def generate_d_regular_graph(d, n):
    graph = {i: [] for i in range(n)}
    edges_added = set()
    
    while len(edges_added) < d * n // 2:
        u = random.randint(0, n - 1)
        v = random.randint(0, n - 1)
        
        if u != v and (u, v) not in edges_added and (v, u) not in edges_added:
            graph[u].append(v)
            graph[v].append(u)
            edges_added.add((u, v))
    
    return graph

def quandle_representation(graph):
    n = len(graph)
    quandle_matrix = [[0] * n for _ in range(n)]
    
    for i in range(n):
        for j in range(n):
            if j in graph[i]:
                quandle_matrix[i][j] = 1
    
    return quandle_matrix

def circuit_monotone_width(graph):
    n = len(graph)
    edges = [(i, j) for i in range(n) for j in range(i + 1, n) if j in graph[i]]
    
    def dfs(node, visited, path):
        if node in visited:
            return False
        visited.add(node)
        path.append(node)
        
        for neighbor in graph[node]:
            if not dfs(neighbor, visited, path):
                return False
        
        path.pop()
        visited.remove(node)
        return True
    
    max_width = 0
    for i in range(n):
        for j in range(i + 1, n):
            if (i, j) in edges:
                continue
            
            visited = set()
            path = []
            if dfs(j, visited, path):
                max_width = max(max_width, len(path))
    
    return max_width

def run_trial(seed: int) -> dict:
    random.seed(seed)
    n_values = [5, 10, 15, 20, 30, 40]
    instances_tested = 0
    total_min_rank = 0
    total_w_m = 0
    
    for n in n_values:
        for _ in range(5):
            graph = generate_d_regular_graph(3, n)
            quandle_matrix = quandle_representation(graph)
            min_rank = gaussian_elimination(quandle_matrix)
            w_m = circuit_monotone_width(graph)
            
            total_min_rank += min_rank
            total_w_m += w_m
            instances_tested += 1
    
    mean_min_rank = total_min_rank / instances_tested
    mean_w_m = total_w_m / instances_tested
    correlation_coefficient = (instances_tested * total_min_rank * total_w_m - 
                               sum(min_rank * w_m for min_rank, w_m in zip([mean_min_rank] * instances_tested, [mean_w_m] * instances_tested))) / \
                              math.sqrt((instances_tested * total_min_rank**2 - sum(min_rank**2 for min_rank in [mean_min_rank] * instances_tested)) *
                                        (instances_tested * total_w_m**2 - sum(w_m**2 for w_m in [mean_w_m] * instances_tested)))
    mean_abs_diff = sum(abs(mean_min_rank * w_m / mean_w_m - min_rank) for min_rank, w_m in zip([mean_min_rank] * instances_tested, [mean_w_m] * instances_tested))) / instances_tested
    
    return {
        "metric_name": "correlation_coefficient",
        "metric_value": correlation_coefficient,
        "instances_tested": instances_tested,
        "n_max": max(n_values),
        "conjecture_holds": correlation_coefficient >= 0.8 and mean_abs_diff <= 3,
        "counterexample": "" if correlation_coefficient >= 0.8 and mean_abs_diff <= 3 else "correlation_coefficient < 0.8 or mean_abs_diff > 3"
    }

if __name__ == "__main__":
    seeds = [int(arg) for arg in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {{\"seed\": {seed}, \"metric_name\": \"{result['metric_name']}\", \"metric_value\": {result['metric_value']}, \"instances_tested\": {result['instances_tested']}, \"n_max\": {result['n_max']}, \"conjecture_holds\": {result['conjecture_holds']}, \"counterexample\": \"{result['counterexample']}\"}}")
        results.append(result)
    
    mean_metric_value = sum(result["metric_value"] for result in results) / len(results)
    std_metric_value = math.sqrt(sum((result["metric_value"] - mean_metric_value)**2 for result in results) / len(results))
    support_fraction = sum(1 for result in results if result["conjecture_holds"]) / len(results)
    
    if all(result["conjecture_holds"] for result in results):
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_metric_value} support_fraction={support_fraction}")
    elif any(not result["conjecture_holds"] for result in results) and support_fraction >= 0.8:
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"correlation_coefficient < 0.8 or mean_abs_diff > 3\" first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE reason=insufficient_evidence")