# Replay package — entry e74372c9395b

Conjecture: Minimal Rank of Free Probability Spaces over Boolean Algebras vs BP_ReadTwice Circuit Threshold

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 13:02 UTC.
Pre-registration hash committed before this test ran: `a5e240a5718f99ea`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
