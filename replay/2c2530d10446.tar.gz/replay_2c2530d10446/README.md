# Replay package — entry 2c2530d10446

Conjecture: Minimal Geometric Fluctuation of Tropical Curves vs Monotone Circuit Lower Bounds for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 12:37 UTC.
Pre-registration hash committed before this test ran: `e8de5fa23292d406`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
