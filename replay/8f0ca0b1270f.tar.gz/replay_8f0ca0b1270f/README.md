# Replay package — entry 8f0ca0b1270f

Conjecture: Positivstellensatz Rank Lower-Bounds SOS Max-CUT Degree

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 07:43 UTC.
Pre-registration hash committed before this test ran: `f43897a91863e7dd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
