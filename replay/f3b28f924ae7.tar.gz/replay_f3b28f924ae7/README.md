# Replay package — entry f3b28f924ae7

Conjecture: Real Radical Degree Bounds SOS Refutation Threshold for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 19:30 UTC.
Pre-registration hash committed before this test ran: `5ac62d0190f5728f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
