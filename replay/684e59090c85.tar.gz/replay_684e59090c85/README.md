# Replay package — entry 684e59090c85

Conjecture: Hypercontractive Term-Pair Contraction Defect Bounds Monotone CLIQUE DNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 13:47 UTC.
Pre-registration hash committed before this test ran: `b83c5653ead8d932`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
