import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_ac0_circuit(n):
        # Generate a random AC⁰ parity circuit of size n
        return [random.choice([0, 1]) for _ in range(n)]
    
    def tropicalize(circuit):
        # Tropicalize the affine sheaf associated with the circuit
        # This is a placeholder function. Implement the actual tropicalization logic here.
        return sum(circuit)
    
    def rank(sheaf):
        # Compute the rank of the tropicalized sheaf
        # This is a placeholder function. Implement the actual rank computation logic here.
        return len(set(sheaf))
    
    n = random.randint(5, 40)  # Sweep n through at least 4 distinct sizes inside each trial
    circuit = generate_ac0_circuit(n)
    sheaf = tropicalize(circuit)
    measured_rank = rank(sheaf)
    lower_bound = math.log(n, 2)  # Ω(log(n))
    
    return {
        "metric_name": "Rank of Tropicalized Sheaf",
        "metric_value": measured_rank,
        "instances_tested": 1,
        "conjecture_holds": measured_rank >= lower_bound,
        "counterexample": "" if measured_rank >= lower_bound else f"Circuit size {n} with rank {measured_rank}"
    }

if __name__ == "__main__":
    seeds = [int(arg) for arg in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    results = []
    
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(res["metric_value"] for res in results) / len(results)
    std_value = math.sqrt(sum((res["metric_value"] - mean_value) ** 2 for res in results) / len(results))
    support_fraction = sum(1 for res in results if res["conjecture_holds"]) / len(results)
    
    if all(res["conjecture_holds"] for res in results):
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(res["seed"] for res in results if not res["conjecture_holds"])
        counterexample = next(res["counterexample"] for res in results if res["counterexample"])
        print(f"RESULT: FALSIFIED counterexample=\"{counterexample}\" first_failing_seed={first_failing_seed}")