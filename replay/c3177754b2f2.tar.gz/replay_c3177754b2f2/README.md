# Replay package — entry c3177754b2f2

Conjecture: Minimal Index of Quasi-Polynomial Growth of Boolean Fourier Coefficients over Tseitin Circuit Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 21:28 UTC.
Pre-registration hash committed before this test ran: `3d84c5c619a78e47`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
