# Replay package — entry 15edc8a5273c

Conjecture: Minimal Local Cohomology Rank of Boolean Functions and Communication Complexity Rank Variance

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 06:21 UTC.
Pre-registration hash committed before this test ran: `bbe69870bd4e5081`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
