# Replay package — entry 1bb37474b28f

Conjecture: Minimal Rank of Eichler-Shimura Densities vs AC0c Circuit Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 22:36 UTC.
Pre-registration hash committed before this test ran: `ffd11e1059a24aab`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
