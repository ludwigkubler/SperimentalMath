# Replay package — entry 87f5d4a9eef6

Conjecture: Schatten-1/Schatten-4 Ratio Lower-Bounds AND-Function Communication

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 17:24 UTC.
Pre-registration hash committed before this test ran: `7dcaa2120433d488`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
