# Replay package — entry 7ffdd386896b

Conjecture: Minimal Rank of Tropicalized K-theory Invariants vs BP_ReadTwice Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 18:43 UTC.
Pre-registration hash committed before this test ran: `e52497430cc143c8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
