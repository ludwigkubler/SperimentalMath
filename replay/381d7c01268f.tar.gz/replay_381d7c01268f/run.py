import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def resolution_width(cnf):
        # Placeholder for actual resolution width computation
        return len(cnf)  # Simplified for demonstration
    
    def tropicalization(cnf):
        # Placeholder for actual tropicalization
        return [len(cnf)]  # Simplified for demonstration
    
    def arithmetic_degree(tropicalized_cnf):
        # Placeholder for actual arithmetic degree computation
        return sum(tropicalized_cnf)
    
    cnf_list = []
    metric_values = []
    instances_tested = 0
    n_max = 0
    conjecture_holds = True
    counterexample = ""
    
    for n in [5, 10, 15, 20, 30, 40]:
        for _ in range(5):  # Ensure at least 30 instances per seed
            cnf = [[random.randint(1, n) for _ in range(random.randint(1, n))] for _ in range(n)]
            cnf_list.append(cnf)
            metric_values.append(arithmetic_degree(tropicalization(cnf)))
            instances_tested += 1
            if len(cnf) > n_max:
                n_max = len(cnf)
    
    mean = sum(metric_values) / len(metric_values)
    std = math.sqrt(sum((x - mean) ** 2 for x in metric_values) / len(metric_values))
    resolution_width_mean = sum(resolution_width(cnf) for cnf in cnf_list) / len(cnf_list)
    
    if len(metric_values) < 30:
        conjecture_holds = False
        counterexample = "insufficient_instances"
    
    correlation_coefficient = sum((metric_values[i] - mean) * (resolution_width(cnf_list[i]) - resolution_width_mean) for i in range(len(metric_values))) / (len(metric_values) * std * resolution_width_mean)
    
    if abs(correlation_coefficient) < 0.05:
        conjecture_holds = False
        counterexample = "insufficient_correlation"
    
    return {
        "metric_name": "arithmetic_degree",
        "metric_value": mean,
        "instances_tested": instances_tested,
        "n_max": n_max,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(x) for x in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    
    results = []
    
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_metric_value = sum(r["metric_value"] for r in results) / len(results)
    std_metric_value = math.sqrt(sum((r["metric_value"] - mean_metric_value) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_metric_value} support_fraction={support_fraction}")
    elif support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_metric_value} std={std_metric_value} support_fraction={support_fraction}")
    else:
        first_failing_seed = next(r["seed"] for r in results if not r["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample=\"insufficient_correlation\" first_failing_seed={first_failing_seed}")