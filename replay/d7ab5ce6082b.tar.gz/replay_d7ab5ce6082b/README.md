# Replay package — entry d7ab5ce6082b

Conjecture: Minimal Rank of Algebraic Topology Invariants vs Communication Complexity for k-Clique

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 07:26 UTC.
Pre-registration hash committed before this test ran: `6da50b7dfba94f67`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
