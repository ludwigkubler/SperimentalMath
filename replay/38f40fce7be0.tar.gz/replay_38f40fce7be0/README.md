# Replay package — entry 38f40fce7be0

Conjecture: Minimal Number of Self-Dual Codes and SAT Clause Subset Entropy Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 17:53 UTC.
Pre-registration hash committed before this test ran: `4d28530b7062fc27`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
