# Replay package — entry 4792defc9e57

Conjecture: Minimal Order of Category Monoids and Frege Proof Depth Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 19:28 UTC.
Pre-registration hash committed before this test ran: `dddda1b686c4c626`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
