# Replay package — entry fac73cba41ff

Conjecture: Minimal Tropical Motive Rank Bounds Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 04:27 UTC.
Pre-registration hash committed before this test ran: `9fd683007e1d09c5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
