# Replay package — entry b6e3239f2108

Conjecture: Minimal Rank of Tropicalized Cohomology and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 19:06 UTC.
Pre-registration hash committed before this test ran: `08c06afebc50bc9b`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
