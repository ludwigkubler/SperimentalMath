# Replay package — entry 175abe514ed4

Conjecture: Algebraic Topology of Knot Invariants vs Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 08:46 UTC.
Pre-registration hash committed before this test ran: `50ad6a48a0591f4d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
