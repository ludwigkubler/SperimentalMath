# Replay package — entry b8fcad7929fc

Conjecture: Minimal p-Adic Valuation Degree and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 13:07 UTC.
Pre-registration hash committed before this test ran: `ad66b40a5f48548c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
