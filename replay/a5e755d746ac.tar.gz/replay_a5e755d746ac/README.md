# Replay package — entry a5e755d746ac

Conjecture: Minimal Rank of K-Theory Groups over Free Probability Entanglement Dimensions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 04:47 UTC.
Pre-registration hash committed before this test ran: `f05b3167dd2a0d09`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
