# Replay package — entry 206ca70bef57

Conjecture: Minimal Geometric Entropy of Symplectic Leaves and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-12 22:41 UTC.
Pre-registration hash committed before this test ran: `54373525238254b5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
