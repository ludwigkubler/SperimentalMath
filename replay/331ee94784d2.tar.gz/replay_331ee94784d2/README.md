# Replay package — entry 331ee94784d2

Conjecture: Gowers Norm Inverse Proportional to ACC⁰ Circuit Size for Explicit Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 22:47 UTC.
Pre-registration hash committed before this test ran: `3ed0b3545f649ed2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
