# Replay package — entry 65d1ffdf3cc6

Conjecture: Cauchy Mean Width of Minterm Hull Lower-Bounds Monotone k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-17 01:28 UTC.
Pre-registration hash committed before this test ran: `1f6d4a0de5280cbf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
