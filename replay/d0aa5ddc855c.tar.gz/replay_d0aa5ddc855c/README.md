# Replay package — entry d0aa5ddc855c

Conjecture: Minimal Rank of Quasi-Symmetric Functions over Tropical Semirings vs BP_ReadTwice Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 01:52 UTC.
Pre-registration hash committed before this test ran: `fc5c4ac58cd3ef8c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
