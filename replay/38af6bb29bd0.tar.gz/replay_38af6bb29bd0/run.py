import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_cnf(n):
        clauses = []
        for _ in range(2**n):
            clause = [random.randint(-1, n-1) for _ in range(random.randint(1, 3))]
            clauses.append(clause)
        return clauses
    
    def frege_proof_width(cnf):
        # Simplified estimation of Frege proof width
        return len(cnf) * random.uniform(0.5, 2.0)
    
    def hodge_norm(cnf):
        # Simplified estimation of Hodge norm
        return math.log(frege_proof_width(cnf))
    
    n = random.randint(5, 40)
    cnf = generate_cnf(n)
    proof_width = frege_proof_width(cnf)
    hodge_nrm = hodge_norm(cnf)
    
    if hodge_nrm > 1.2 * math.log(proof_width):
        return {
            "metric_name": "Hodge norm / log(Frege width)",
            "metric_value": hodge_nrm,
            "instances_tested": 1,
            "n_max": n,
            "conjecture_holds": False,
            "counterexample": "Hodge norm exceeds 1.2 * log(Frege width)"
        }
    
    return {
        "metric_name": "Hodge norm / log(Frege width)",
        "metric_value": hodge_nrm,
        "instances_tested": 1,
        "n_max": n,
        "conjecture_holds": True,
        "counterexample": ""
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113]
    results = []
    
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    metric_values = [r["metric_value"] for r in results if r["conjecture_holds"]]
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if support_fraction >= 0.8:
        RESULT: SUPPORTED mean={sum(metric_values) / len(metric_values):.2f} std={math.sqrt(sum((x - sum(metric_values) / len(metric_values)) ** 2 for x in metric_values) / len(metric_values)):.2f} support_fraction={support_fraction:.2f}
    elif any(not r["conjecture_holds"] for r in results):
        counterexample = next(r["counterexample"] for r in results if not r["conjecture_holds"])
        RESULT: FALSIFIED counterexample="{counterexample}" first_failing_seed={next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])}
    else:
        RESULT: INCONCLUSIVE reason=insufficient_support_fraction support_fraction={support_fraction:.2f}