import random
import math

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_bp(n):
        bp = []
        for _ in range(2**n):
            row = [random.choice([0, 1]) for _ in range(n)]
            bp.append(row)
        return bp
    
    def size(bp):
        return len(bp)
    
    def k_theory_rank(bp):
        n = int(math.log2(len(bp)))
        if n == 0:
            return 0
        rank = 0
        for i in range(n):
            col = [bp[j][i] for j in range(2**n)]
            if sum(col) > 0:
                rank += 1
        return rank
    
    def is_ip_2_trivial(bp):
        n = int(math.log2(len(bp)))
        if n == 0:
            return True
        for i in range(n):
            col = [bp[j][i] for j in range(2**n)]
            if sum(col) != 1:
                return False
        return True
    
    def log_size(bp):
        return math.log(size(bp))
    
    n = random.randint(5, 40)
    bp = generate_bp(n)
    rho_K_P = k_theory_rank(bp)
    size_P = size(bp)
    
    if is_ip_2_trivial(bp):
        conjecture_holds = rho_K_P >= n
        counterexample = "IP_2 trivial BP" if not conjecture_holds else ""
    else:
        conjecture_holds = rho_K_P <= math.log(2**n) and rho_K_P >= log_size(bp)
        counterexample = "rho_K(P) out of bounds" if not conjecture_holds else ""
    
    return {
        "metric_name": "k_theory_rank",
        "metric_value": rho_K_P,
        "instances_tested": 1,
        "conjecture_holds": conjecture_holds,
        "counterexample": counterexample
    }

if __name__ == "__main__":
    import sys
    seeds = [int(s) for s in sys.argv[1:]] if sys.argv[1:] else [2**i + 1 for i in range(5, 6)]
    
    results = []
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_rho_K_P = sum(r["metric_value"] for r in results) / len(results)
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if all(r["conjecture_holds"] for r in results):
        print(f"RESULT: SUPPORTED mean={mean_rho_K_P} std=0.0 support_fraction=1.0")
    elif any(abs(r["metric_value"] - log_size(generate_bp(int(math.log2(len(r["instances_tested"]))))) > 3 for r in results):
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if abs(result["metric_value"] - log_size(generate_bp(int(math.log2(len(result["instances_tested"]))))) > 3)
        print(f"RESULT: FALSIFIED counterexample='rho_K(P) out of bounds' first_failing_seed={first_failing_seed}")
    else:
        print(f"RESULT: INCONCLUSIVE reason=insufficient_evidence")