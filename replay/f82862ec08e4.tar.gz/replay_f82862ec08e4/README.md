# Replay package — entry f82862ec08e4

Conjecture: Minimal Rank of Ehrhart Matrices in Lattice Point Enumeration Bound DPLL Refutation Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 03:51 UTC.
Pre-registration hash committed before this test ran: `f84c490ed1e78f6d`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
