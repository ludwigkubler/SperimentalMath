# Replay package — entry 046406fb9e61

Conjecture: Minimal Tropical Root Separation and ACC0 Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 19:06 UTC.
Pre-registration hash committed before this test ran: `6f6e8ae96fb117ab`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
