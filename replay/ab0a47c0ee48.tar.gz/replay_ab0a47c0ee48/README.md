# Replay package — entry ab0a47c0ee48

Conjecture: Negative Eigenvalue Count in SOS Moment Matrix Bounded by Log-Size for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-13 01:20 UTC.
Pre-registration hash committed before this test ran: `7fc49efc214c2060`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
