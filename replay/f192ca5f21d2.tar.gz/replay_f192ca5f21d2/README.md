# Replay package — entry f192ca5f21d2

Conjecture: Newton Polytope Vertex Count Bounds ACC^0[m] Size for Symmetric CNFs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 14:44 UTC.
Pre-registration hash committed before this test ran: `54d55519236d0f12`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
