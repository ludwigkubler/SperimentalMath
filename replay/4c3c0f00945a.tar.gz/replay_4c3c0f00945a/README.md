# Replay package — entry 4c3c0f00945a

Conjecture: Minimal Ehrhart Polynomial Degree and Circuit Satisfiability Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-10 02:32 UTC.
Pre-registration hash committed before this test ran: `d10f055a1055f269`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
