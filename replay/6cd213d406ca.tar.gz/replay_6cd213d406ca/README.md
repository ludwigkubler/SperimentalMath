# Replay package — entry 6cd213d406ca

Conjecture: Minimal Rank of Quasi-Quadratic Forms vs AC0 Parity Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 09:55 UTC.
Pre-registration hash committed before this test ran: `117b423743e655d6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
