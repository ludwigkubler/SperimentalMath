# Replay package — entry 6e9a9759cd5d

Conjecture: Minimal Order of Formal Power Series and Resolution Proof Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 13:12 UTC.
Pre-registration hash committed before this test ran: `321eaf36a1ee44db`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
