# Replay package — entry 44f82c29ed79

Conjecture: Tropical Shift-Invariance of MinimalFourierCoefficient under Additive Translation of TropicalPolynomials

Verdict (original run): FALSIFIED

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-26 20:50 UTC.
Pre-registration hash committed before this test ran: `0bd73be40d387490`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
