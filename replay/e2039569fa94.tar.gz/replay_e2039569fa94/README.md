# Replay package — entry e2039569fa94

Conjecture: Minimal Rank of Tropicalized Permutation Patterns vs AC⁰ Circuit Lower Bounds for Non-Linear Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 01:17 UTC.
Pre-registration hash committed before this test ran: `a127c5726dac7846`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
