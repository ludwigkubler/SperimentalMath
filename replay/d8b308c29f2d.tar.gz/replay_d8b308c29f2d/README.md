# Replay package — entry d8b308c29f2d

Conjecture: Minimal Symmetry Measure of Boolean Functions over Tseitin Circuit Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 06:34 UTC.
Pre-registration hash committed before this test ran: `b05d15925491e763`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
