# Replay package — entry e132a7fc4394

Conjecture: Minimal Number of Invariant Points and Communication Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-01 08:40 UTC.
Pre-registration hash committed before this test ran: `1ea97898e1533914`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
