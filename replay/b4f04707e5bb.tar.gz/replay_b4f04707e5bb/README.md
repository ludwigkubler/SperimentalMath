# Replay package — entry b4f04707e5bb

Conjecture: Persistent Homology of Read-Twice BPs Bounded by Log-Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-12 08:14 UTC.
Pre-registration hash committed before this test ran: `cc8b8ce10bc52b53`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
