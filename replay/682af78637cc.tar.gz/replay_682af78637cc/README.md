# Replay package — entry 682af78637cc

Conjecture: Minimal Number of Automorphic Representations and Resolution Proof Tree Height Invariant Under Local Field Extensions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 05:54 UTC.
Pre-registration hash committed before this test ran: `1eff0eebe0d4a707`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
