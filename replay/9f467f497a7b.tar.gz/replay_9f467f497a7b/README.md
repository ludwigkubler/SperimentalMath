# Replay package — entry 9f467f497a7b

Conjecture: Symmetric Power Decomposition Complexity Gap for 3-SAT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-11 03:39 UTC.
Pre-registration hash committed before this test ran: `384f9def6b1f4a90`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
