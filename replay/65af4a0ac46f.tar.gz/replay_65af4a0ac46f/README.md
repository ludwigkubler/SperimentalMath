# Replay package — entry 65af4a0ac46f

Conjecture: Minimal Rank of Algebraic Cycles over XOR-AND Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 07:03 UTC.
Pre-registration hash committed before this test ran: `ee07046fb4c74c03`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
