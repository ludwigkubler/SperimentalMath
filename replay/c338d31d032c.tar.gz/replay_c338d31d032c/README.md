# Replay package — entry c338d31d032c

Conjecture: Minimal Geometric Entropy of Delone Triangulations vs Resolution Refutation Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 23:45 UTC.
Pre-registration hash committed before this test ran: `237226e618b43dd2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
