# Replay package — entry 5b4e280f648f

Conjecture: Minimal Rank of Groupoid Cocomorphism over Frege Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 05:11 UTC.
Pre-registration hash committed before this test ran: `6c9cc962dea30769`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
