# Replay package — entry 7887f040a80a

Conjecture: Witness-Complex Betti Sum Lower-Bounds Formula Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 05:24 UTC.
Pre-registration hash committed before this test ran: `c148f9bed5152348`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
