# Replay package — entry 0e06b5f9fc52

Conjecture: Layer-Commutator Frobenius Discrepancy Separates Read-Twice BP for IP_2

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-16 20:13 UTC.
Pre-registration hash committed before this test ran: `a3cc03eb4e88f9bd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
