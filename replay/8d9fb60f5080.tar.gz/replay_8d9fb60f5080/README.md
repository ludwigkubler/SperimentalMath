# Replay package — entry 8d9fb60f5080

Conjecture: Minimal Hodge Theoretical Dimension and Circuit Monotone Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-05 20:23 UTC.
Pre-registration hash committed before this test ran: `f6e43484f4260ed9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
