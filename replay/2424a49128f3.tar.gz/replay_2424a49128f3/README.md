# Replay package — entry 2424a49128f3

Conjecture: Matrix Rigidity Bounds Communication Complexity of 3-SAT Instances

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-24 19:54 UTC.
Pre-registration hash committed before this test ran: `2d1dd22136b47975`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
