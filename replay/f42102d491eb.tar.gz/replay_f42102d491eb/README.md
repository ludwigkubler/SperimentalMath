# Replay package — entry f42102d491eb

Conjecture: Minimal Geometric Entanglement and Resolution Proof Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 08:25 UTC.
Pre-registration hash committed before this test ran: `005d5568c9be7497`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
