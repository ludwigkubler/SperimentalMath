# Replay package — entry 3d3a15569524

Conjecture: Minimal Rank of Noncrossing Partitions Bounds Resolution Proof Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 11:24 UTC.
Pre-registration hash committed before this test ran: `2683722428031a7e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
