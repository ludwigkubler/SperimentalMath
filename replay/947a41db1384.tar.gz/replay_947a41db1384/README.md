# Replay package — entry 947a41db1384

Conjecture: Spectral Gap Determines Resolution Length for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 08:34 UTC.
Pre-registration hash committed before this test ran: `1642edb9c0eb8cb8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
