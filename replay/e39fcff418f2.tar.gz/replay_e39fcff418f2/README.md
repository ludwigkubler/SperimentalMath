# Replay package — entry e39fcff418f2

Conjecture: Minimal Local Index of Noncrossing Partition Complexity for SAT Clause Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-31 11:51 UTC.
Pre-registration hash committed before this test ran: `240f5f0645335df8`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
