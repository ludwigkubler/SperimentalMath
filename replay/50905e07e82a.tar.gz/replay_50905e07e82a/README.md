# Replay package — entry 50905e07e82a

Conjecture: Minimal Local Indeterminacy in p-adic Analysis and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 19:12 UTC.
Pre-registration hash committed before this test ran: `6cedcb3189e1a6d0`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
