# Replay package — entry 8abf61884d0e

Conjecture: Minimal Rank of Hodge Integrals over Boolean Function Output Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 05:04 UTC.
Pre-registration hash committed before this test ran: `89bd3a63c5b30340`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
