# Replay package — entry c94dcc3ae3ad

Conjecture: Minimal Monodromy Rank of Algebraic Curves Bounds Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 14:39 UTC.
Pre-registration hash committed before this test ran: `3cf2c9afb2ebdec5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
