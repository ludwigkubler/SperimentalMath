# Replay package — entry f281162f1654

Conjecture: Noncommutative Geometry of Boolean Functions Bounds Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 18:34 UTC.
Pre-registration hash committed before this test ran: `0b7c64ccb61a1fb2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
