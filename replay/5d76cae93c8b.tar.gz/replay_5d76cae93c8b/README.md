# Replay package — entry 5d76cae93c8b

Conjecture: Hodge Theoretic Complexity of Boolean Function Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 23:45 UTC.
Pre-registration hash committed before this test ran: `574b4e6ac89918d4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
