# Replay package — entry d9492f3e4702

Conjecture: Minimal Number of Generators in Affine Quotient Groups and SAT Clause Subset Entropy

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 17:32 UTC.
Pre-registration hash committed before this test ran: `dcc20ac7a3f352ee`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
