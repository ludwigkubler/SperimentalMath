# Replay package — entry 250b9c1fef2a

Conjecture: Minimal Rank of Ehrhart Cohomology Bounds Communication Complexity for XOR

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 16:45 UTC.
Pre-registration hash committed before this test ran: `ea8c6787b58a7d04`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
