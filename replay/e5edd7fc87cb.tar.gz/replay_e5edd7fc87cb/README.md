# Replay package — entry e5edd7fc87cb

Conjecture: Minimal Rank of Quotient Algebras over Boolean Algebras vs Determinant Circuit Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 14:44 UTC.
Pre-registration hash committed before this test ran: `a0e8fd831b3a8d78`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
