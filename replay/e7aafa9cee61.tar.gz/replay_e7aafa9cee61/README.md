# Replay package — entry e7aafa9cee61

Conjecture: Minimal Rank of p-Adic Differentials over SAT Satisfiability

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 20:51 UTC.
Pre-registration hash committed before this test ran: `9797521ec6c23835`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
