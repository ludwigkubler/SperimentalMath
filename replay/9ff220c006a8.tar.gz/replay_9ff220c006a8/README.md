# Replay package — entry 9ff220c006a8

Conjecture: Minimal Rank of Delone Set Symmetry Patterns vs DPLL Proof Length for Random k-CNF

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 04:48 UTC.
Pre-registration hash committed before this test ran: `77182b0a1881e28e`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
