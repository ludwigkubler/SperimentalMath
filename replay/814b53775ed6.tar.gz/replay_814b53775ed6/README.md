# Replay package — entry 814b53775ed6

Conjecture: Minimal Local Index of Configuration Spaces vs ACC⁰ Circuit Depth for Sipser Functions

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-25 09:02 UTC.
Pre-registration hash committed before this test ran: `6d2eb2673f7b6ddf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
