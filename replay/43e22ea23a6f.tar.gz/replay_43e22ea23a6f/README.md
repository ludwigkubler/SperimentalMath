# Replay package — entry 43e22ea23a6f

Conjecture: Minimal Deligne-Lusztig Tree Depth and Resolution Proof Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 12:49 UTC.
Pre-registration hash committed before this test ran: `9743b5c041bb6a97`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
