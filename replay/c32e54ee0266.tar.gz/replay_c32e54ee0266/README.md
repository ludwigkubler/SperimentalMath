# Replay package — entry c32e54ee0266

Conjecture: Minimal Rank of Geometric Invariants in Representation Theory vs ACC0 Circuit Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 20:24 UTC.
Pre-registration hash committed before this test ran: `485fc0f51308db25`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
