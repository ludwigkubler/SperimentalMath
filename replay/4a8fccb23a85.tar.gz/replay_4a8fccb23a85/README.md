# Replay package — entry 4a8fccb23a85

Conjecture: Minimal Rank of Noncommutative Crossed Products and Frege Proof Length Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 16:34 UTC.
Pre-registration hash committed before this test ran: `8ddd8c28ad944ce2`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
