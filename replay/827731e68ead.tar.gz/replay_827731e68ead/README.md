# Replay package — entry 827731e68ead

Conjecture: Arithmetic Hierarchy Complexity of Boolean Functions and Circuit Monotone Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 05:42 UTC.
Pre-registration hash committed before this test ran: `7fa5160f7ce3646c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
