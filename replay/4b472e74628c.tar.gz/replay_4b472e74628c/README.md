# Replay package — entry 4b472e74628c

Conjecture: Minimal Local Index of Group Representations vs Resolution Proof Width for Tseitin Formulas

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-24 20:49 UTC.
Pre-registration hash committed before this test ran: `be618f4f7b273612`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
