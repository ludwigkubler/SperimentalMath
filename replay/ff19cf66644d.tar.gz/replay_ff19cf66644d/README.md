# Replay package — entry ff19cf66644d

Conjecture: Low-Degree Fourier Mass of Cut Indicator Bounds Tseitin Resolution

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 07:33 UTC.
Pre-registration hash committed before this test ran: `fecbae42c36f30cf`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
