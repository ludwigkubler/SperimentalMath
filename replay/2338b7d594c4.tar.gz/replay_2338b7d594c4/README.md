# Replay package — entry 2338b7d594c4

Conjecture: Free Probability Tensor Entanglement and BP_ReadTwice Lower Bounds

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 17:19 UTC.
Pre-registration hash committed before this test ran: `a947e08c2e5ec7b5`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
