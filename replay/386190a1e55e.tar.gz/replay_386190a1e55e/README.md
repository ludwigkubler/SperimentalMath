# Replay package — entry 386190a1e55e

Conjecture: Schur-Weyl Decomposition Irreducible Component Gap for Permanent vs Determinant

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-09 21:30 UTC.
Pre-registration hash committed before this test ran: `b69c78a3ea600961`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
