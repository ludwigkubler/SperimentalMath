# Replay package — entry 160abd91b150

Conjecture: Singular Locus Dimension Bounds SOS Refutation Size for 3-SAT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-01 15:02 UTC.
Pre-registration hash committed before this test ran: `70e792992eb8b9a7`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
