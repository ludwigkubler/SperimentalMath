# Replay package — entry eae916e0d29f

Conjecture: Minimal Geometric Entropy of Quantum States Bounds DPLL Search Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 02:57 UTC.
Pre-registration hash committed before this test ran: `f2fc8cf990f27a80`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
