# Replay package — entry 88c3870b1bd8

Conjecture: Minimal Hypergeometric Sum and Resolution Proof Width Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-07 20:55 UTC.
Pre-registration hash committed before this test ran: `875c074190a5c0a9`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
