# Replay package — entry 7c14f2dad553

Conjecture: Arithmetic Hodge Theory Lower Bound for Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 16:46 UTC.
Pre-registration hash committed before this test ran: `84dee5c599c00528`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
