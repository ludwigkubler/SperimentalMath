# Replay package — entry 8cb37d685d27

Conjecture: Minimal Number of Ternary Diatomic Sequences and SAT Clause Subset Complexity

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 21:36 UTC.
Pre-registration hash committed before this test ran: `05cfab429d654a9a`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
