# Replay package — entry 065246f51ff9

Conjecture: Minimal Root Separation of Tropical Curves and Resolution Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-21 17:27 UTC.
Pre-registration hash committed before this test ran: `ab38e73a21b2bcc6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
