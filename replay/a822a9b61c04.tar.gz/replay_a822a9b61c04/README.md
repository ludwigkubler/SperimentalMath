# Replay package — entry a822a9b61c04

Conjecture: Minimal Order of Formal Power Series and SAT Proof Width Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 00:45 UTC.
Pre-registration hash committed before this test ran: `21a387a2ee55e891`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
