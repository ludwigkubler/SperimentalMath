# Replay package — entry f333580239c9

Conjecture: Minimal Order of Formal Contexts and Circuit Monotone Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 13:10 UTC.
Pre-registration hash committed before this test ran: `660c0dcb49feb8d3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
