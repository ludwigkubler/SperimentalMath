# Replay package — entry 6cb7db7fda37

Conjecture: Minimal Rank of Boolean Differential Forms vs Monotone Circuit Depth for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-23 06:19 UTC.
Pre-registration hash committed before this test ran: `67fb4ccef355d696`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
