# Replay package — entry 61a6865ba577

Conjecture: Secant Variety Dimension Gap in Determinant vs Permanent Orbits for SAT Instances

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 14:15 UTC.
Pre-registration hash committed before this test ran: `2f8e98ab980a3da4`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
