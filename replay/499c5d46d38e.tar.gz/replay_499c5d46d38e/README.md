# Replay package — entry 499c5d46d38e

Conjecture: Matroid Representation Complexity of Monotone DNF for k-CLIQUE

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-08 21:44 UTC.
Pre-registration hash committed before this test ran: `eecd80a3a1a241cd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
