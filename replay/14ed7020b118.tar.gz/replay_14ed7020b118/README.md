# Replay package — entry 14ed7020b118

Conjecture: Birkhoff Spectral Gap of Gate Co-occurrence Bounds AC^0 PARITY Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-18 05:16 UTC.
Pre-registration hash committed before this test ran: `07afc7557bfe3c27`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
