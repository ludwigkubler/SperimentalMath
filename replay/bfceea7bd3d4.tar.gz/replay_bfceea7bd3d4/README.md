# Replay package — entry bfceea7bd3d4

Conjecture: Minimal Rank of Group Cocommutative Algebras Bounds BP Read-Twice Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 10:29 UTC.
Pre-registration hash committed before this test ran: `983a2cad45bab7a1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
