# Replay package — entry 4ae9b39ca1e9

Conjecture: Minimal Rank of Graphical Motives and Circuit Monotone Width Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-03 08:51 UTC.
Pre-registration hash committed before this test ran: `32d16d2a34f06de1`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
