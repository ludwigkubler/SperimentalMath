# Replay package — entry bb305220144e

Conjecture: Minimal Order of Formal Power Series and Frege Proof Length Correlation

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-02 15:19 UTC.
Pre-registration hash committed before this test ran: `1bbb53f57bed69b6`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
