import random
import math
from fractions import Fraction

def run_trial(seed: int) -> dict:
    random.seed(seed)
    
    def generate_boolean_formula(n):
        if n == 1:
            return 'P'
        op = random.choice(['∧', '∨'])
        left = generate_boolean_formula(n // 2)
        right = generate_boolean_formula(n - n // 2 - 1)
        return f'({left} {op} {right})'
    
    def dpll_solve(phi, assignment):
        if not phi:
            return True
        if not assignment:
            return False
        
        var = next(iter(assignment))
        for val in [True, False]:
            new_assignment = assignment.copy()
            new_assignment[var] = val
            if dpll_solve(phi, new_assignment):
                return True
        return False
    
    def frege_proof_length(phi):
        stack = []
        for char in phi:
            if char == '(':
                stack.append(char)
            elif char == ')':
                while stack[-1] != '(':
                    stack.pop()
                stack.pop()
                stack.append('∧')
            else:
                stack.append(char)
        return len(stack)
    
    def local_system_order(n):
        # Simplified model for demonstration purposes
        return n
    
    n = random.randint(5, 40)
    phi = generate_boolean_formula(n)
    proof_length = frege_proof_length(phi)
    order = local_system_order(n)
    
    return {
        "metric_name": "Frege Proof Length vs. Local System Order",
        "metric_value": proof_length,
        "instances_tested": 1,
        "n_max": n,
        "conjecture_holds": proof_length == order,
        "counterexample": "" if proof_length == order else f"phi={phi}, proof_length={proof_length}, order={order}"
    }

if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1:]] or [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] * 3
    results = []
    
    for seed in seeds:
        result = run_trial(seed)
        print(f"TRIAL: {result}")
        results.append(result)
    
    mean_value = sum(r["metric_value"] for r in results) / len(results)
    std_value = math.sqrt(sum((r["metric_value"] - mean_value) ** 2 for r in results) / len(results))
    support_fraction = sum(1 for r in results if r["conjecture_holds"]) / len(results)
    
    if support_fraction >= 0.8:
        print(f"RESULT: SUPPORTED mean={mean_value} std={std_value} support_fraction={support_fraction}")
    elif any(not r["conjecture_holds"] for r in results):
        first_failing_seed = next(seed for seed, result in zip(seeds, results) if not result["conjecture_holds"])
        print(f"RESULT: FALSIFIED counterexample='<not applicable>' first_failing_seed={first_failing_seed}")
    else:
        print("RESULT: INCONCLUSIVE insufficient_data")