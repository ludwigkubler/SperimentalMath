# Replay package — entry 804f405e6484

Conjecture: Minimal Index of Affine Group Action and Frege Proof Depth Inequality

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-06 19:45 UTC.
Pre-registration hash committed before this test ran: `d2ed7736efba8fd3`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
