# Replay package — entry c060cd48edae

Conjecture: O-Minimal Definability and SOS Degree Threshold for Max-CUT

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 08:26 UTC.
Pre-registration hash committed before this test ran: `b34fa399e45ed22c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
