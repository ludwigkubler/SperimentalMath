# Replay package — entry 67af54f5d24b

Conjecture: Minimal Rank of Quadratic Residues Bounds XOR-AND Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-27 18:37 UTC.
Pre-registration hash committed before this test ran: `99eacd960dbf04cd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
