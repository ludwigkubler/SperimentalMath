# Replay package — entry 0f4086585adb

Conjecture: Minimal Order of Geometric Invariant Theory Bounds Resolution Proof Size

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 01:07 UTC.
Pre-registration hash committed before this test ran: `1b2abaa60b582297`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
