# Replay package — entry f4e06590d9e7

Conjecture: Matroid Connectivity Determines Pseudorandom Generator Efficiency for Nisan-Wigderson Designs

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-19 09:19 UTC.
Pre-registration hash committed before this test ran: `2e73090cb07ae71c`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
