# Replay package — entry 8d60c087478f

Conjecture: SOS Moment Matrix Rank and Max-CUT Integrality Gap

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-10 20:31 UTC.
Pre-registration hash committed before this test ran: `210c1d80126c8054`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
