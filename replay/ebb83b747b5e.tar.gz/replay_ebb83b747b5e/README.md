# Replay package — entry ebb83b747b5e

Conjecture: [c003b_cumulative_entropy/SC6#c35] Φ(π)/proof_size (number of DP steps) is monotone increasing in n, i.e. per-step active weight grows (the 'shadow heavier than the body' claim).

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-30 15:00 UTC.
Pre-registration hash committed before this test ran: `c0a904507f0acd66`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
