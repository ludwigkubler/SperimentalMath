# Replay package — entry 797387c6c6e5

Conjecture: Algebraic Geometry over Finite Fields and EF Proof Length

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-04-30 23:07 UTC.
Pre-registration hash committed before this test ran: `81c0694fc2c2175f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
