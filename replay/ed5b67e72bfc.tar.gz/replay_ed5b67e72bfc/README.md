# Replay package — entry ed5b67e72bfc

Conjecture: Minimal Rank of Hodge Classes over Binary Decision Diagrams via Tropicalization

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 19:59 UTC.
Pre-registration hash committed before this test ran: `4796fb1fb5353f08`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
