# Replay package — entry 05eaaff1dd91

Conjecture: Minimal Rank of Multivariate Generalized Polynomials Bounds Frege Proof Depth

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-28 10:18 UTC.
Pre-registration hash committed before this test ran: `7a1e747884ed94cd`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
