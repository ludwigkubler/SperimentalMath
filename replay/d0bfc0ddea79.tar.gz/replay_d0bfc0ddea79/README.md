# Replay package — entry d0bfc0ddea79

Conjecture: Monotone DNF Discrepancy and Convex Hull Volume

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-20 11:59 UTC.
Pre-registration hash committed before this test ran: `d59f146c19b92525`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
