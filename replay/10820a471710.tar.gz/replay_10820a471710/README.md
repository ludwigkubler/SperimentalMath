# Replay package — entry 10820a471710

Conjecture: Minimal Hodge Norm and SAT Clause Subset Complexity Bound

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-06-04 13:02 UTC.
Pre-registration hash committed before this test ran: `28a66625c7fc2b0f`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
