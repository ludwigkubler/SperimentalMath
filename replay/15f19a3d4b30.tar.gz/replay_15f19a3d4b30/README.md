# Replay package — entry 15f19a3d4b30

Conjecture: Minimal Rank of Categorified Symplectic Forms over DPLL Search Tree Width

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-26 12:53 UTC.
Pre-registration hash committed before this test ran: `a932c59c1a8591fe`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
