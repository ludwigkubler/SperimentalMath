# Replay package — entry d2eea396721f

Conjecture: Schur-Weyl Duality and Permutation Circuit Threshold

Verdict (original run): INCONCLUSIVE

## Reproduce

```bash
python3 run.py 11 23 37 53 71
```

Compare output with `expected.txt`. The test is pure-stdlib; any Python 3.11+ should produce byte-identical TRIAL: lines.

## Provenance

Original cycle ran on the SEC server on 2026-05-22 19:22 UTC.
Pre-registration hash committed before this test ran: `674668d82ab80adb`.
Full LLM transcripts in `audit/{eid}.jsonl` of the SEC research repo.
